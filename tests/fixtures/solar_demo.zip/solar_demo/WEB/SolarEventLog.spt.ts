﻿
namespace WEB.Main.SupportClasses {
  export class SolarEventLog {
    private static entries: any[] = [];
    private static previous: any = {};
    public static maxRows: number = 200;

    public static add(source: string, message: string, priority: string = 'Info'): void {
      SolarEventLog.entries.unshift({ timestamp: new Date(), source: source, message: message, priority: priority });
      if (SolarEventLog.entries.length > SolarEventLog.maxRows) SolarEventLog.entries.length = SolarEventLog.maxRows;
    }

    public static trackState(source: string, key: string, value: any): void {
      const id = source + '|' + key;
      const text = value === null || value === undefined ? 'Unknown' : value.toString();
      if (SolarEventLog.previous[id] === undefined) { SolarEventLog.previous[id] = text; return; }
      if (SolarEventLog.previous[id] !== text) {
        SolarEventLog.previous[id] = text;
        SolarEventLog.add(source, key + ' changed to ' + text);
      }
    }

    public static getEntries(): any[] { return SolarEventLog.entries.slice(0); }
    public static clear(): void { SolarEventLog.entries = []; SolarEventLog.previous = {}; }
  }
}
