﻿
namespace WEB.Main.SupportClasses {
  export class SolarStatusHelper {
    public static resolveStandard(quality: any, fault: any, alarm: any, available: any,
                                  healthyState?: number, unavailableState?: number): number {
      const theme = WEB.Main.SupportClasses.SolarTheme;
      const s = theme.EquipmentState;
      if (!WEB.Main.SupportClasses.HmiValueHelper.toBool(quality)) return s.Offline;
      if (WEB.Main.SupportClasses.HmiValueHelper.toBool(fault)) return s.Fault;
      if (WEB.Main.SupportClasses.HmiValueHelper.toBool(alarm)) return s.Alarm;
      if (!WEB.Main.SupportClasses.HmiValueHelper.toBool(available)) {
        return unavailableState === undefined ? s.Standby : unavailableState;
      }
      return healthyState === undefined ? s.Healthy : healthyState;
    }

    public static resolveRunningAvailable(quality: any, fault: any, alarm: any,
                                          running: any, available: any): number {
      const s = WEB.Main.SupportClasses.SolarTheme.EquipmentState;
      const base = SolarStatusHelper.resolveStandard(quality, fault, alarm, available, s.Healthy, s.Standby);
      if (base !== s.Healthy) return base;
      return WEB.Main.SupportClasses.HmiValueHelper.toBool(running) ? s.Running : s.Standby;
    }

    public static getStatusText(state: number): string {
      const s = WEB.Main.SupportClasses.SolarTheme.EquipmentState;
      if (state === s.Healthy) return 'Healthy';
      if (state === s.Running) return 'Running';
      if (state === s.Standby) return 'Standby';
      if (state === s.Warning) return 'Warning';
      if (state === s.Alarm) return 'Alarm';
      if (state === s.Fault) return 'Fault';
      if (state === s.Offline) return 'Offline';
      return 'Unknown';
    }
  }
}
