﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/28/2026
 * Time: 11:37 PM
 *
 * Generic compact dashboard card.
 *
 * Existing JSON object mapping:
 * - txtSubtitle       : Device name
 * - txtTitle          : Asset name
 * - txtStatus         : Status text
 * - indStatus         : Status indicator
 * - txtPrimaryLabel   : Primary label
 * - txtPrimaryText    : Primary value + unit
 * - txtSecondaryLabel : Secondary label
 * - txtSecondaryText  : Secondary value + unit
 *
 * This file does not require any JSON change.
 */
namespace WEB.Main.Graphics {

  export class seDefaultCard
    extends NxtControl.GuiFramework.Graphic {

    @System.DefaultValue('WEB.Main.Graphics.seDefaultCard')
    protected type: string;

    @System.DefaultValue('Device')
    protected deviceName: string = 'Device';

    @System.DefaultValue('Asset')
    protected assetName: string = 'Asset';

    @System.DefaultValue(0)
    protected statusLevel: number = 0;

    @System.DefaultValue('')
    protected statusText: string = '';

    @System.DefaultValue('Primary Label')
    protected primaryLabel: string = 'Primary Label';

    @System.DefaultValue('--')
    protected primaryValue: string = '--';

    @System.DefaultValue('')
    protected primaryUnit: string = '';

    @System.DefaultValue('Secondary Label')
    protected secondaryLabel: string = 'Secondary Label';

    @System.DefaultValue('--')
    protected secondaryValue: string = '--';

    @System.DefaultValue('')
    protected secondaryUnit: string = '';

    private rectBase: any;
    private lblStatus: any;
    private divider: any;

    private txtSubtitle: any;
    private txtTitle: any;
    private txtStatus: any;
    private indStatus: any;

    private txtPrimaryLabel: any;
    private txtPrimaryText: any;
    private txtSecondaryLabel: any;
    private txtSecondaryText: any;

    private objectsReady: boolean = false;

    /**** DO NOT DELETE CONSTRUCTOR *****/
    constructor() {
      super();
    }

    load(options: any): this {
      options = options || {};
      super.load(options);

      this.rectBase = this.find('rectBase');
      this.lblStatus = this.find('lblStatus');
      this.divider = this.find('divider');

      this.txtSubtitle = this.find('txtSubtitle');
      this.txtTitle = this.find('txtTitle');
      this.txtStatus = this.find('txtStatus');
      this.indStatus = this.find('indStatus');

      this.txtPrimaryLabel = this.find('txtPrimaryLabel');
      this.txtPrimaryText = this.find('txtPrimaryText');
      this.txtSecondaryLabel = this.find('txtSecondaryLabel');
      this.txtSecondaryText = this.find('txtSecondaryText');

      this.objectsReady = true;
      this.updateUi();

      return this;
    }

    public getDeviceName(): string {
      return this.deviceName;
    }

    public setDeviceName(value: string): void {
      this._set('deviceName', value, true);
    }

    public getAssetName(): string {
      return this.assetName;
    }

    public setAssetName(value: string): void {
      this._set('assetName', value, true);
    }

    public getStatusLevel(): number {
      return this.statusLevel;
    }

    public setStatusLevel(value: number): void {
      this._set('statusLevel', value, true);
    }

    public getStatusText(): string {
      return this.statusText;
    }

    public setStatusText(value: string): void {
      this._set('statusText', value, true);
    }

    public getPrimaryLabel(): string {
      return this.primaryLabel;
    }

    public setPrimaryLabel(value: string): void {
      this._set('primaryLabel', value, true);
    }

    public getPrimaryValue(): string {
      return this.primaryValue;
    }

    public setPrimaryValue(value: string): void {
      this._set('primaryValue', value, true);
    }

    public getPrimaryUnit(): string {
      return this.primaryUnit;
    }

    public setPrimaryUnit(value: string): void {
      this._set('primaryUnit', value, true);
    }

    public getSecondaryLabel(): string {
      return this.secondaryLabel;
    }

    public setSecondaryLabel(value: string): void {
      this._set('secondaryLabel', value, true);
    }

    public getSecondaryValue(): string {
      return this.secondaryValue;
    }

    public setSecondaryValue(value: string): void {
      this._set('secondaryValue', value, true);
    }

    public getSecondaryUnit(): string {
      return this.secondaryUnit;
    }

    public setSecondaryUnit(value: string): void {
      this._set('secondaryUnit', value, true);
    }

    protected _set(
      key: string,
      value: any,
      invalidate: boolean = false
    ): this {
      switch (key) {
        case 'deviceName':
          this.deviceName = this.cleanText(value, 'Device');
          break;

        case 'assetName':
          this.assetName = this.cleanText(value, 'Asset');
          break;

        case 'statusLevel':
          this.statusLevel = this.normalizeStatus(value);
          break;

        case 'statusText':
          this.statusText = this.cleanText(value, '');
          break;

        case 'primaryLabel':
          this.primaryLabel = this.cleanText(value, 'Primary Label');
          break;

        case 'primaryValue':
          this.primaryValue = this.cleanText(value, '--');
          break;

        case 'primaryUnit':
          this.primaryUnit = this.cleanText(value, '');
          break;

        case 'secondaryLabel':
          this.secondaryLabel = this.cleanText(value, 'Secondary Label');
          break;

        case 'secondaryValue':
          this.secondaryValue = this.cleanText(value, '--');
          break;

        case 'secondaryUnit':
          this.secondaryUnit = this.cleanText(value, '');
          break;

        default:
          super._set(key, value, invalidate);
          return this;
      }

      if (this.objectsReady) {
        this.updateUi();
      }

      if (invalidate) {
        this.invalidate();
      }

      return this;
    }

    toObject(propertiesToInclude?: any[]): any {
      const object: any =
        NxtControl.Util.ObjectUtil.extend(
          super.toObject(propertiesToInclude),
          {
            deviceName: this.deviceName,
            assetName: this.assetName,
            statusLevel: this.statusLevel,
            statusText: this.statusText,
            primaryLabel: this.primaryLabel,
            primaryValue: this.primaryValue,
            primaryUnit: this.primaryUnit,
            secondaryLabel: this.secondaryLabel,
            secondaryValue: this.secondaryValue,
            secondaryUnit: this.secondaryUnit
          }
        );

      if (!this.includeDefaultValues) {
        this._removeDefaultValues(object);
      }

      return object;
    }

    /**
     * Complete card update.
     *
     * Parameter order:
     * 1  deviceName
     * 2  assetName
     * 3  state
     * 4  stateText
     * 5  primaryLabel
     * 6  primaryValue
     * 7  primaryUnit
     * 8  secondaryLabel
     * 9  secondaryValue
     * 10 secondaryUnit
     */
    public setCardData(
      deviceName: string,
      assetName: string,
      state: number,
      stateText: string,
      primaryLabel: string,
      primaryValue: string,
      primaryUnit: string,
      secondaryLabel: string,
      secondaryValue: string,
      secondaryUnit: string
    ): void {
      this.deviceName = this.cleanText(deviceName, 'Device');
      this.assetName = this.cleanText(assetName, 'Asset');

      this.statusLevel = this.normalizeStatus(state);
      this.statusText = this.cleanText(stateText, '');

      this.primaryLabel = this.cleanText(
        primaryLabel,
        'Primary Label'
      );
      this.primaryValue = this.cleanText(primaryValue, '--');
      this.primaryUnit = this.cleanText(primaryUnit, '');

      this.secondaryLabel = this.cleanText(
        secondaryLabel,
        'Secondary Label'
      );
      this.secondaryValue = this.cleanText(secondaryValue, '--');
      this.secondaryUnit = this.cleanText(secondaryUnit, '');

      this.updateUi();
    }

    public setHeader(
      deviceName: string,
      assetName: string
    ): void {
      this.deviceName = this.cleanText(deviceName, 'Device');
      this.assetName = this.cleanText(assetName, 'Asset');
      this.updateUi();
    }

    public setStatus(
      state: number,
      text?: string
    ): void {
      this.statusLevel = this.normalizeStatus(state);
      this.statusText = this.cleanText(text, '');
      this.updateUi();
    }

    public setPrimary(
      label: string,
      value: string,
      unit?: string
    ): void {
      this.primaryLabel = this.cleanText(label, 'Primary Label');
      this.primaryValue = this.cleanText(value, '--');
      this.primaryUnit = this.cleanText(unit, '');
      this.updateUi();
    }

    public setSecondary(
      label: string,
      value: string,
      unit?: string
    ): void {
      this.secondaryLabel = this.cleanText(
        label,
        'Secondary Label'
      );
      this.secondaryValue = this.cleanText(value, '--');
      this.secondaryUnit = this.cleanText(unit, '');
      this.updateUi();
    }

    private updateUi(): void {
      if (!this.objectsReady) {
        return;
      }

      const theme: any =
        WEB.Main.SupportClasses.SolarTheme;

      const display: any =
        WEB.Main.SupportClasses.HmiDisplayHelper;

      const statusHelper: any =
        WEB.Main.SupportClasses.SolarStatusHelper;

      if (!theme || !display || !statusHelper) {
        return;
      }

      const rawState: number =
        this.normalizeStatus(this.statusLevel);

      const displayedStatus: string =
        this.statusText.length > 0
          ? this.statusText
          : statusHelper.getStatusText(rawState);

      /*
       * Safety states can also be recovered from StatusText.
       * This prevents a stale Running/Healthy level from keeping the
       * status green when the CAT sends "Alarm", "Fault" or "Offline".
       */
      const effectiveState: number =
        this.resolveEffectiveState(
          rawState,
          displayedStatus
        );

      /*
       * Charging, Discharging, Importing and Exporting all belong to
       * the Running equipment state, but need different operational
       * colours. The visual resolver combines state priority with
       * the device-specific StatusText.
       */
      const visual: any =
        this.resolveStatusVisual(
          effectiveState,
          displayedStatus,
          theme
        );

      display.writeBrush(
        this.rectBase,
        theme.Surface.MainBoard
      );
      display.writePen(
        this.rectBase,
        theme.Border.MainBoard,
        1
      );

      /*
       * Apply the resolved colour to the whole status capsule:
       * background, border, indicator and text.
       */
      display.writeBrush(
        this.lblStatus,
        visual.surface
      );
      display.writePen(
        this.lblStatus,
        visual.border,
        1
      );
      display.writeBrush(
        this.indStatus,
        visual.color
      );
      display.writeText(
        this.txtStatus,
        displayedStatus
      );
      display.writeTextColor(
        this.txtStatus,
        visual.color
      );

      /*
       * Device and asset remain separate.
       */
      display.writeText(
        this.txtSubtitle,
        this.deviceName
      );
      display.writeTextColor(
        this.txtSubtitle,
        theme.Text.Secondary
      );

      display.writeText(
        this.txtTitle,
        this.assetName
      );
      display.writeTextColor(
        this.txtTitle,
        theme.Text.Primary
      );

      display.writeText(
        this.txtPrimaryLabel,
        this.primaryLabel
      );
      display.writeTextColor(
        this.txtPrimaryLabel,
        theme.Text.Secondary
      );

      display.writeText(
        this.txtPrimaryText,
        this.joinValueAndUnit(
          this.primaryValue,
          this.primaryUnit
        )
      );
      display.writeTextColor(
        this.txtPrimaryText,
        theme.Text.Primary
      );

      display.writeBrush(
        this.divider,
        theme.Border.Divider
      );
      display.writePen(
        this.divider,
        theme.Border.Divider,
        1
      );

      display.writeText(
        this.txtSecondaryLabel,
        this.secondaryLabel
      );
      display.writeTextColor(
        this.txtSecondaryLabel,
        theme.Text.Secondary
      );

      display.writeText(
        this.txtSecondaryText,
        this.joinValueAndUnit(
          this.secondaryValue,
          this.secondaryUnit
        )
      );
      display.writeTextColor(
        this.txtSecondaryText,
        theme.Text.Primary
      );

      this.invalidate();
    }

    private joinValueAndUnit(
      value: string,
      unit: string
    ): string {
      const cleanValue: string =
        this.cleanText(value, '--');

      const cleanUnit: string =
        this.cleanText(unit, '');

      return cleanUnit.length > 0
        ? cleanValue + ' ' + cleanUnit
        : cleanValue;
    }

    private resolveEffectiveState(
      state: number,
      statusText: string
    ): number {
      const states: any =
        WEB.Main.SupportClasses
          .SolarTheme
          .EquipmentState;

      const text: string =
        this.cleanText(statusText, '')
          .toLowerCase();

      /*
       * Text-based safety recovery has priority because the displayed
       * status must never say Fault/Alarm while remaining green.
       */
      if (
        this.containsAny(
          text,
          ['fault', 'trip', 'tripped']
        )
      ) {
        return states.Fault;
      }

      if (
        this.containsAny(
          text,
          ['alarm']
        )
      ) {
        return states.Alarm;
      }

      if (
        this.containsAny(
          text,
          [
            'warning',
            'limited',
            'curtail',
            'high load',
            'string fault'
          ]
        )
      ) {
        return states.Warning;
      }

      if (
        this.containsAny(
          text,
          [
            'offline',
            'disconnected',
            'disconnect',
            'no communication',
            'no comm'
          ]
        )
      ) {
        return states.Offline;
      }

      if (
        this.containsAny(
          text,
          ['unknown', 'waiting']
        )
      ) {
        return states.Unknown;
      }

      if (
        this.containsAny(
          text,
          ['standby', 'idle']
        )
      ) {
        return states.Standby;
      }

      return state;
    }

    private resolveStatusVisual(
      state: number,
      statusText: string,
      theme: any
    ): any {
      const states: any =
        theme.EquipmentState;

      const text: string =
        this.cleanText(statusText, '')
          .toLowerCase();

      let color: any =
        theme.getStatusColor(state);

      /*
       * Safety and availability colours always take priority over
       * operational direction.
       */
      if (state === states.Fault) {
        color = theme.Status.Fault;

        return {
          color: color,
          surface: this.makeTint(
            color,
            0.18,
            theme.Surface.Fault
          ),
          border: theme.Border.Fault
        };
      }

      if (state === states.Alarm) {
        /*
         * Alarm is orange while Fault remains red so the two states
         * are immediately distinguishable.
         */
        color =
          theme.Flow && theme.Flow.AcPower
            ? theme.Flow.AcPower
            : theme.Status.Warning;

        return {
          color: color,
          surface: this.makeTint(
            color,
            0.16,
            theme.Surface.Warning
          ),
          border: color
        };
      }

      if (state === states.Warning) {
        color = theme.Status.Warning;

        return {
          color: color,
          surface: this.makeTint(
            color,
            0.14,
            theme.Surface.Warning
          ),
          border: theme.Border.Warning
        };
      }

      if (state === states.Offline) {
        color = theme.Status.Offline;

        return {
          color: color,
          surface: theme.Surface.Disabled,
          border: theme.Border.Disabled
        };
      }

      if (state === states.Unknown) {
        color = theme.Status.Unknown;

        return {
          color: color,
          surface: theme.Surface.Disabled,
          border: theme.Border.Disabled
        };
      }

      if (state === states.Standby) {
        color = theme.Status.Standby;

        return {
          color: color,
          surface: theme.Surface.RaisedPanel,
          border: theme.Border.Normal
        };
      }

      /*
       * Operational direction colours.
       *
       * Charging / Importing     : blue
       * Discharging              : orange
       * Exporting                : green
       * Running / Healthy        : standard green
       */
      if (
        this.containsAny(
          text,
          ['charging', 'charge']
        )
      ) {
        color = theme.Status.Info;

        return {
          color: color,
          surface: this.makeTint(
            color,
            0.14,
            theme.Surface.RaisedPanel
          ),
          border: color
        };
      }

      if (
        this.containsAny(
          text,
          ['discharging', 'discharge']
        )
      ) {
        color =
          theme.Flow && theme.Flow.AcPower
            ? theme.Flow.AcPower
            : theme.Status.Warning;

        return {
          color: color,
          surface: this.makeTint(
            color,
            0.14,
            theme.Surface.RaisedPanel
          ),
          border: color
        };
      }

      if (
        this.containsAny(
          text,
          ['importing', 'import']
        )
      ) {
        color = theme.Status.Info;

        return {
          color: color,
          surface: this.makeTint(
            color,
            0.14,
            theme.Surface.RaisedPanel
          ),
          border: color
        };
      }

      if (
        this.containsAny(
          text,
          ['exporting', 'export']
        )
      ) {
        color = theme.Status.Healthy;

        return {
          color: color,
          surface: this.makeTint(
            color,
            0.12,
            theme.Surface.RaisedPanel
          ),
          border: color
        };
      }

      return {
        color: color,
        surface:
          typeof theme.getStatusSurface === 'function'
            ? theme.getStatusSurface(state)
            : theme.Surface.RaisedPanel,
        border:
          typeof theme.getStatusBorder === 'function'
            ? theme.getStatusBorder(state)
            : color
      };
    }

    private makeTint(
      color: any,
      alpha: number,
      fallback: any
    ): any {
      if (
        color &&
        color.length >= 3
      ) {
        return [
          color[0],
          color[1],
          color[2],
          alpha
        ];
      }

      return fallback;
    }

    private containsAny(
      text: string,
      tokens: string[]
    ): boolean {
      if (!text || !tokens) {
        return false;
      }

      for (
        let index: number = 0;
        index < tokens.length;
        index++
      ) {
        if (
          text.indexOf(tokens[index]) >= 0
        ) {
          return true;
        }
      }

      return false;
    }

    private normalizeStatus(value: any): number {
      const states: any =
        WEB.Main.SupportClasses
          .SolarTheme
          .EquipmentState;

      let state: number =
        states.Unknown;

      if (
        typeof value === 'number' &&
        isFinite(value)
      ) {
        state = Math.round(value);
      } else if (
        typeof value === 'string' &&
        value.trim().length > 0 &&
        isFinite(Number(value))
      ) {
        /*
         * eHMI properties can sometimes arrive as numeric strings.
         */
        state = Math.round(Number(value));
      }

      if (
        state === states.Unknown ||
        state === states.Healthy ||
        state === states.Running ||
        state === states.Standby ||
        state === states.Warning ||
        state === states.Fault ||
        state === states.Offline ||
        state === states.Alarm
      ) {
        return state;
      }

      return states.Unknown;
    }

    private cleanText(
      value: any,
      fallback: string
    ): string {
      if (value === null || value === undefined) {
        return fallback;
      }

      const text: string =
        value.toString().trim();

      return text.length > 0
        ? text
        : fallback;
    }

    /** Event NxtControl.GuiHTMLFramework.Button:click **/
    protected btnEnable_click(sender: any, ea: NxtControl.ISystemEventArgs) {
      
    }

  }
}