﻿/*
 * Created by EcoStruxure Automation Expert.
 *
 * Compact dashboard symbol for Grid.
 *
 * Required objects:
 * - dataCard
 * - PIMP
 * - PEXP
 * - FRQ
 * - QLT
 * - IFLT
 * - IALM
 * - ICONN
 *
 * Uses WEB.Main.Graphics.seDefaultCard with the 10-parameter interface.
 * No timer and no JSON modification are required.
 */
namespace WEB.Main.Symbols.acGrid_v1_0 {

  export class seDefault
    extends NxtControl.GuiFramework.RuntimeSymbol {

    @System.DefaultValue(
      'WEB.Main.Symbols.acGrid_v1_0.seDefault'
    )
    protected type: string;

    private dataCard: any;
    private qualityReceived: boolean = false;
    private assetName: string = 'GRID01';

    private PIMP: any;
    private PEXP: any;
    private FRQ: any;
    private QLT: any;
    private IFLT: any;
    private IALM: any;
    private ICONN: any;

    private readonly FLOW_DEADBAND: number = 0.01;

    /**** DO NOT DELETE CONSTRUCTOR *****/
    constructor() {
      super();
    }

    load(options: any): this {
      options = options || {};
      super.load(options);

      this.findObjects();
      this.bindInputs();
      this.updateOverview();

      return this;
    }

    private findObjects(): void {
      this.dataCard = this.find('dataCard');
      this.PIMP = this.find('PIMP');
      this.PEXP = this.find('PEXP');
      this.FRQ = this.find('FRQ');
      this.QLT = this.find('QLT');
      this.IFLT = this.find('IFLT');
      this.IALM = this.find('IALM');
      this.ICONN = this.find('ICONN');
    }

    private bindInputs(): void {
      const display: any =
        WEB.Main.SupportClasses.HmiDisplayHelper;

      display.bindBridge(
        this.PIMP,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.PEXP,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.FRQ,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.QLT,
        () => {
          this.qualityReceived = true;
          this.updateOverview();
        }
      );

      display.bindBridge(
        this.IFLT,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.IALM,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.ICONN,
        () => this.updateOverview()
      );
    }

    private updateOverview(): void {
      if (
        !this.dataCard ||
        typeof this.dataCard.setCardData !== 'function'
      ) {
        return;
      }

      const helper: any =
        WEB.Main.SupportClasses.HmiValueHelper;

      const quality: boolean =
        helper.toBool(helper.readBridge(this.QLT, false), false);

      const fault: boolean =
        helper.toBool(helper.readBridge(this.IFLT, false), false);

      const alarm: boolean =
        helper.toBool(helper.readBridge(this.IALM, false), false);

      const connected: boolean =
        helper.toBool(helper.readBridge(this.ICONN, false), false);

      const importedPower: number =
        helper.toNumber(helper.readBridge(this.PIMP, 0), 0);

      const exportedPower: number =
        helper.toNumber(helper.readBridge(this.PEXP, 0), 0);

      const frequency: number =
        helper.toNumber(helper.readBridge(this.FRQ, 0), 0);

      const netPower: number =
        exportedPower - importedPower;

      const flow: any =
        this.resolveFlow(netPower);

      const status: any =
        this.resolveStatus(
          quality,
          fault,
          alarm,
          connected,
          netPower
        );

      this.dataCard.setCardData(
        'Grid',
        this.assetName,
        status.level,
        status.text,
        flow.label,
        flow.value,
        'MW',
        'Frequency',
        frequency.toFixed(2),
        'Hz'
      );
    }

    private resolveStatus(
      quality: boolean,
      fault: boolean,
      alarm: boolean,
      connected: boolean,
      netPower: number
    ): any {
      const state: any =
        WEB.Main.SupportClasses
          .SolarTheme
          .EquipmentState;

      if (!this.qualityReceived) {
        return { level: state.Unknown, text: 'Unknown' };
      }

      if (!quality || !connected) {
        return { level: state.Offline, text: 'Offline' };
      }

      if (fault) {
        return { level: state.Fault, text: 'Fault' };
      }

      if (alarm) {
        return { level: state.Alarm, text: 'Alarm' };
      }

      if (netPower > this.FLOW_DEADBAND) {
        return { level: state.Running, text: 'Exporting' };
      }

      if (netPower < -this.FLOW_DEADBAND) {
        return { level: state.Running, text: 'Importing' };
      }

      return { level: state.Healthy, text: 'Connected' };
    }

    private resolveFlow(netPower: number): any {
      if (netPower > this.FLOW_DEADBAND) {
        return {
          label: 'Export Power',
          value: netPower.toFixed(2)
        };
      }

      if (netPower < -this.FLOW_DEADBAND) {
        return {
          label: 'Import Power',
          value: Math.abs(netPower).toFixed(2)
        };
      }

      return {
        label: 'Net Power',
        value: '0.00'
      };
    }


    public setAssetName(value: string): void {
      if (
        value !== null &&
        value !== undefined &&
        value.toString().trim().length > 0
      ) {
        this.assetName = value.toString().trim();
        this.updateOverview();
      }
    }
  }
}
