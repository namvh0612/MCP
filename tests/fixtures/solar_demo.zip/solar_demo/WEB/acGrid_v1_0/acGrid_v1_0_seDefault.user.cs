﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:    
 * Date: 7/29/2026
 * Time: 2:56 PM
 * 
 */

using System;
using System.Drawing;
using NxtControl.GuiHTMLFramework;

namespace WEB.Main.Symbols.acGrid_v1_0
{
	/// <summary>
	/// Description of seDefault.
	/// </summary>
	public partial class seDefault : NxtControl.GuiHTMLFramework.RuntimeSymbol
	{
	}
}
