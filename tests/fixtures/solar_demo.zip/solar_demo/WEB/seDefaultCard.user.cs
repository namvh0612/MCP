﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/28/2026
 * Time: 11:37 PM
 * 
 */

using System;
using System.Drawing;
using NxtControl.GuiHTMLFramework;

namespace WEB.Main.Graphics
{
	/// <summary>
	/// Description of seDefaultCard.
	/// </summary>
	public partial class seDefaultCard : NxtControl.GuiHTMLFramework.Graphic
	{
	}
}
