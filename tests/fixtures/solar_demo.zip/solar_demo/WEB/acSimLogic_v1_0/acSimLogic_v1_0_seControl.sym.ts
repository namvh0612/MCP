﻿namespace WEB.Main.Symbols.acSimLogic_v1_0 {
  export class seControl extends NxtControl.GuiFramework.RuntimeSymbol {
    @System.DefaultValue('WEB.Main.Symbols.acSimLogic_v1_0.seControl')
    protected type: string;

    private bridges: any = {};
    private titleText: string = 'Simulation Control';
    private hovered: boolean = false;
    private refreshTimer: any = null;

    constructor() { super(); }

    load(options: any): this {
      options = options || {};
      super.load(options);
      const names: string[] = ['SIM_EN', 'SIM_CASE'];
      for (let i = 0; i < names.length; i++) {
        this.bridges[names[i]] = this.find(names[i]);
        this.H().bindBridge(this.bridges[names[i]], () => this.updateUi());
      }
      this.refreshTimer = setInterval(() => this.updateUi(), 1000);
      this.updateUi();
      return this;
    }

    disposeEvents() {
      if (this.refreshTimer) { clearInterval(this.refreshTimer); this.refreshTimer = null; }
      super.disposeEvents();
    }

    protected AssetName_valueChanged(sender: any, ea: any) {
      this.titleText = this.V().safeText(this.V().extractEventValue(sender, ea), 'Simulation Control');
      this.updateUi();
    }

    protected CardMouseEnter(sender: any, ea: any) { this.hovered = true; this.updateUi(); }
    protected CardMouseLeave(sender: any, ea: any) { this.hovered = false; this.updateUi(); }
    protected CardClick(sender: any, ea: any) {
      const owner: any = this;
      if (owner._doOpenFaceplates) owner._doOpenFaceplates();
    }

    private value(name: string, fallback: any = 0): any {
      return this.V().readBridge(this.bridges[name], fallback);
    }


    private H(): any { return WEB.Main.SupportClasses.HmiDisplayHelper; }
    private V(): any { return WEB.Main.SupportClasses.HmiValueHelper; }
    private T(): any { return WEB.Main.SupportClasses.SolarTheme; }
    private S(): any { return WEB.Main.SupportClasses.SolarStatusHelper; }

    private updateUi(): void {
      const enabled = this.V().toBool(this.value('SIM_EN'));
      const mode = this.V().toInt(this.value('SIM_CASE'));
      this.H().writeText(this.find('txtTitle'), this.titleText);
      this.H().writeText(this.find('txtStatus'), enabled ? 'Enabled' : 'Disabled');
      this.H().writeTextColor(this.find('txtStatus'), enabled ? this.T().Status.Healthy : this.T().Status.Offline);
      this.H().writeBrush(this.find('indStatus'), enabled ? this.T().Status.Healthy : this.T().Status.Offline);
      this.H().writeBrush(this.find('btnEnable'), enabled ? this.T().Surface.Selected : this.T().Surface.Panel);
      this.H().writePen(this.find('btnEnable'), enabled ? this.T().Border.Selected : this.T().Border.Normal, enabled ? 2 : 1);
      const values: number[] = [0,1,4,5,2,7,9,14];
      for (let i = 0; i < values.length; i++) {
        const selected = enabled && values[i] === mode;
        this.H().writeBrush(this.find('btnMode' + i), !enabled ? this.T().Surface.Disabled : (selected ? this.T().Surface.Selected : this.T().Surface.Panel));
        this.H().writePen(this.find('btnMode' + i), selected ? this.T().Border.Selected : this.T().Border.Normal, selected ? 2 : 1);
        this.H().writeTextColor(this.find('txtMode' + i), !enabled ? this.T().Text.Muted : this.T().Text.Primary);
      }
      this.invalidate();
    }

    protected ToggleSimulation(sender: any, ea: any) {
      this.H().sendCommand(this.bridges['SIM_EN'], !this.V().toBool(this.value('SIM_EN')));
    }
    protected SelectMode0(sender: any, ea: any) { this.selectMode(0); }
    protected SelectMode1(sender: any, ea: any) { this.selectMode(1); }
    protected SelectMode2(sender: any, ea: any) { this.selectMode(4); }
    protected SelectMode3(sender: any, ea: any) { this.selectMode(5); }
    protected SelectMode4(sender: any, ea: any) { this.selectMode(2); }
    protected SelectMode5(sender: any, ea: any) { this.selectMode(7); }
    protected SelectMode6(sender: any, ea: any) { this.selectMode(9); }
    protected SelectMode7(sender: any, ea: any) { this.selectMode(14); }
    private selectMode(mode: number) {
      if (!this.V().toBool(this.value('SIM_EN'))) return;
      this.H().sendCommand(this.bridges['SIM_CASE'], mode);
    }
  }
}
