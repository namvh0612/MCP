﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:    
 * Date: 7/27/2026
 * Time: 11:10 PM
 * 
 */

using System;
using System.Drawing;
using NxtControl.GuiHTMLFramework;

namespace WEB.Main.Symbols.acSimLogic_v1_0
{
	/// <summary>
	/// Description of seControl.
	/// </summary>
	public partial class seControl : NxtControl.GuiHTMLFramework.RuntimeSymbol
	{
	}
}
