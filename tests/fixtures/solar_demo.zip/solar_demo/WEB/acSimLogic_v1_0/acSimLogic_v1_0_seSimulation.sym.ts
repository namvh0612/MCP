﻿namespace WEB.Main.Symbols.acSimLogic_v1_0 {
  export class seSimulation extends NxtControl.GuiFramework.RuntimeSymbol {
    @System.DefaultValue('WEB.Main.Symbols.acSimLogic_v1_0.seSimulation')
    protected type: string;

    private bridges: any = {};
    private titleText: string = 'Simulation';
    private hovered: boolean = false;
    private refreshTimer: any = null;

    constructor() { super(); }

    load(options: any): this {
      options = options || {};
      super.load(options);
      const names: string[] = ['SIM_EN'];
      for (let i = 0; i < names.length; i++) {
        this.bridges[names[i]] = this.find(names[i]);
        this.H().bindBridge(this.bridges[names[i]], () => this.updateUi());
      }
      this.refreshTimer = setInterval(() => this.updateUi(), 1000);
      this.updateUi();
      return this;
    }

    disposeEvents() {
      if (this.refreshTimer) { clearInterval(this.refreshTimer); this.refreshTimer = null; }
      super.disposeEvents();
    }

    protected AssetName_valueChanged(sender: any, ea: any) {
      this.titleText = this.V().safeText(this.V().extractEventValue(sender, ea), 'Simulation');
      this.updateUi();
    }

    protected CardMouseEnter(sender: any, ea: any) { this.hovered = true; this.updateUi(); }
    protected CardMouseLeave(sender: any, ea: any) { this.hovered = false; this.updateUi(); }
    protected CardClick(sender: any, ea: any) {
      const owner: any = this;
      if (owner._doOpenFaceplates) owner._doOpenFaceplates();
    }

    private value(name: string, fallback: any = 0): any {
      return this.V().readBridge(this.bridges[name], fallback);
    }


    private H(): any { return WEB.Main.SupportClasses.HmiDisplayHelper; }
    private V(): any { return WEB.Main.SupportClasses.HmiValueHelper; }
    private T(): any { return WEB.Main.SupportClasses.SolarTheme; }
    private S(): any { return WEB.Main.SupportClasses.SolarStatusHelper; }

    private updateUi(): void {
      const enabled = this.V().toBool(this.value('SIM_EN'));
      this.H().writeText(this.find('txtTitle'), 'SIMULATION');
      this.H().writeBrush(this.find('btnSim'), enabled ? this.T().Surface.Selected : (this.hovered ? this.T().Surface.Hover : this.T().Surface.Panel));
      this.H().writePen(this.find('btnSim'), enabled ? this.T().Border.Selected : (this.hovered ? this.T().Border.Hover : this.T().Border.Normal), enabled || this.hovered ? 2 : 1);
      this.H().writeBrush(this.find('indStatus'), enabled ? this.T().Status.Healthy : this.T().Status.Offline);
      this.H().writeTextColor(this.find('txtTitle'), enabled ? this.T().Text.Primary : this.T().Text.Secondary);
      this.invalidate();
    }

    protected ToggleSimulation(sender: any, ea: any) {
      this.H().sendCommand(this.bridges['SIM_EN'], !this.V().toBool(this.value('SIM_EN')));
    }
  }
}
