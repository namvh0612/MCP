﻿/*
 * Created by EcoStruxure Automation Expert.
 *
 * Compact dashboard symbol for Transformer.
 *
 * Required objects:
 * - dataCard
 * - LOAD
 * - TOIL
 * - QLT
 * - IFLT
 * - IALM
 * - IAVL
 *
 * Uses WEB.Main.Graphics.seDefaultCard with the 10-parameter interface.
 * No timer and no JSON modification are required.
 */
namespace WEB.Main.Symbols.acTransformer_v1_0 {

  export class seDefault
    extends NxtControl.GuiFramework.RuntimeSymbol {

    @System.DefaultValue(
      'WEB.Main.Symbols.acTransformer_v1_0.seDefault'
    )
    protected type: string;

    private dataCard: any;
    private qualityReceived: boolean = false;
    private assetName: string = 'TRF001';

    private LOAD: any;
    private TOIL: any;
    private QLT: any;
    private IFLT: any;
    private IALM: any;
    private IAVL: any;

    /**** DO NOT DELETE CONSTRUCTOR *****/
    constructor() {
      super();
    }

    load(options: any): this {
      options = options || {};
      super.load(options);

      this.findObjects();
      this.bindInputs();
      this.updateOverview();

      return this;
    }

    private findObjects(): void {
      this.dataCard = this.find('dataCard');
      this.LOAD = this.find('LOAD');
      this.TOIL = this.find('TOIL');
      this.QLT = this.find('QLT');
      this.IFLT = this.find('IFLT');
      this.IALM = this.find('IALM');
      this.IAVL = this.find('IAVL');
    }

    private bindInputs(): void {
      const display: any =
        WEB.Main.SupportClasses.HmiDisplayHelper;

      display.bindBridge(
        this.LOAD,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.TOIL,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.QLT,
        () => {
          this.qualityReceived = true;
          this.updateOverview();
        }
      );

      display.bindBridge(
        this.IFLT,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.IALM,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.IAVL,
        () => this.updateOverview()
      );
    }

    private updateOverview(): void {
      if (
        !this.dataCard ||
        typeof this.dataCard.setCardData !== 'function'
      ) {
        return;
      }

      const helper: any =
        WEB.Main.SupportClasses.HmiValueHelper;

      const quality: boolean =
        helper.toBool(helper.readBridge(this.QLT, false), false);

      const fault: boolean =
        helper.toBool(helper.readBridge(this.IFLT, false), false);

      const alarm: boolean =
        helper.toBool(helper.readBridge(this.IALM, false), false);

      const available: boolean =
        helper.toBool(helper.readBridge(this.IAVL, false), false);

      const loadLevel: number =
        helper.toNumber(helper.readBridge(this.LOAD, 0), 0);

      const oilTemperature: number =
        helper.toNumber(helper.readBridge(this.TOIL, 0), 0);

      const status: any =
        this.resolveStatus(
          quality,
          fault,
          alarm,
          available
        );

      this.dataCard.setCardData(
        'Transformer',
        this.assetName,
        status.level,
        status.text,
        'Load Level',
        loadLevel.toFixed(1),
        '%',
        'Oil Temperature',
        oilTemperature.toFixed(0),
        '°C'
      );
    }

    private resolveStatus(
      quality: boolean,
      fault: boolean,
      alarm: boolean,
      available: boolean
    ): any {
      const state: any =
        WEB.Main.SupportClasses
          .SolarTheme
          .EquipmentState;

      if (!this.qualityReceived) {
        return { level: state.Unknown, text: 'Unknown' };
      }

      if (!quality) {
        return { level: state.Offline, text: 'Offline' };
      }

      if (fault) {
        return { level: state.Fault, text: 'Fault' };
      }

      if (alarm) {
        return { level: state.Alarm, text: 'Alarm' };
      }

      if (!available) {
        return { level: state.Standby, text: 'Standby' };
      }

      return { level: state.Healthy, text: 'Available' };
    }


    public setAssetName(value: string): void {
      if (
        value !== null &&
        value !== undefined &&
        value.toString().trim().length > 0
      ) {
        this.assetName = value.toString().trim();
        this.updateOverview();
      }
    }
  }
}
