﻿/*
 * Created by EcoStruxure Automation Expert.
 *
 * Compact dashboard symbol for Plant Power Controller.
 *
 * Required objects:
 * - dataCard
 * - ASPCMD
 * - PBATCMD
 * - ISTA
 * - IRUN
 * - QLT
 * - IFLT
 * - IALM
 * - IAVL
 *
 * Uses WEB.Main.Graphics.seDefaultCard with the 10-parameter interface.
 * No timer and no JSON modification are required.
 */
namespace WEB.Main.Symbols.acPPC_v1_0 {

  export class seDefault
    extends NxtControl.GuiFramework.RuntimeSymbol {

    @System.DefaultValue(
      'WEB.Main.Symbols.acPPC_v1_0.seDefault'
    )
    protected type: string;

    private dataCard: any;
    private qualityReceived: boolean = false;
    private assetName: string = 'PPC001';

    private ASPCMD: any;
    private PBATCMD: any;
    private ISTA: any;
    private IRUN: any;
    private QLT: any;
    private IFLT: any;
    private IALM: any;
    private IAVL: any;

    /**** DO NOT DELETE CONSTRUCTOR *****/
    constructor() {
      super();
    }

    load(options: any): this {
      options = options || {};
      super.load(options);

      this.findObjects();
      this.bindInputs();
      this.updateOverview();

      return this;
    }

    private findObjects(): void {
      this.dataCard = this.find('dataCard');
      this.ASPCMD = this.find('ASPCMD');
      this.PBATCMD = this.find('PBATCMD');
      this.ISTA = this.find('ISTA');
      this.IRUN = this.find('IRUN');
      this.QLT = this.find('QLT');
      this.IFLT = this.find('IFLT');
      this.IALM = this.find('IALM');
      this.IAVL = this.find('IAVL');
    }

    private bindInputs(): void {
      const display: any =
        WEB.Main.SupportClasses.HmiDisplayHelper;

      display.bindBridge(
        this.ASPCMD,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.PBATCMD,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.ISTA,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.IRUN,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.QLT,
        () => {
          this.qualityReceived = true;
          this.updateOverview();
        }
      );

      display.bindBridge(
        this.IFLT,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.IALM,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.IAVL,
        () => this.updateOverview()
      );
    }

    private updateOverview(): void {
      if (
        !this.dataCard ||
        typeof this.dataCard.setCardData !== 'function'
      ) {
        return;
      }

      const helper: any =
        WEB.Main.SupportClasses.HmiValueHelper;

      const quality: boolean =
        helper.toBool(helper.readBridge(this.QLT, false), false);

      const fault: boolean =
        helper.toBool(helper.readBridge(this.IFLT, false), false);

      const alarm: boolean =
        helper.toBool(helper.readBridge(this.IALM, false), false);

      const available: boolean =
        helper.toBool(helper.readBridge(this.IAVL, false), false);

      const running: boolean =
        helper.toBool(helper.readBridge(this.IRUN, false), false);

      const applicationState: number =
        helper.toInt(helper.readBridge(this.ISTA, 0), 0);

      const plantSetpoint: number =
        helper.toNumber(helper.readBridge(this.ASPCMD, 0), 0);

      const bessCommand: number =
        helper.toNumber(helper.readBridge(this.PBATCMD, 0), 0);

      const status: any =
        this.resolveStatus(
          quality,
          fault,
          alarm,
          available,
          running,
          applicationState
        );

      this.dataCard.setCardData(
        'Plant Power Controller',
        this.assetName,
        status.level,
        status.text,
        'Plant Setpoint',
        this.formatSigned(plantSetpoint, 2),
        'MW',
        'BESS Command',
        this.formatSigned(bessCommand, 2),
        'MW'
      );
    }

    private resolveStatus(
      quality: boolean,
      fault: boolean,
      alarm: boolean,
      available: boolean,
      running: boolean,
      applicationState: number
    ): any {
      const state: any =
        WEB.Main.SupportClasses
          .SolarTheme
          .EquipmentState;

      if (!this.qualityReceived) {
        return { level: state.Unknown, text: 'Unknown' };
      }

      if (!quality) {
        return { level: state.Offline, text: 'Offline' };
      }

      if (fault) {
        return { level: state.Fault, text: 'Fault' };
      }

      if (alarm) {
        return { level: state.Alarm, text: 'Alarm' };
      }

      if (!available) {
        return { level: state.Standby, text: 'Standby' };
      }

      if (applicationState === 4 || running) {
        return { level: state.Running, text: 'Running' };
      }

      if (applicationState === 3) {
        return { level: state.Standby, text: 'Standby' };
      }

      if (applicationState === 2) {
        return { level: state.Running, text: 'Starting' };
      }

      if (applicationState === 1) {
        return { level: state.Healthy, text: 'Ready' };
      }

      return { level: state.Standby, text: 'Idle' };
    }

    private formatSigned(
      value: number,
      decimals: number
    ): string {
      const prefix: string =
        value > 0 ? '+' : '';

      return prefix + value.toFixed(decimals);
    }


    public setAssetName(value: string): void {
      if (
        value !== null &&
        value !== undefined &&
        value.toString().trim().length > 0
      ) {
        this.assetName = value.toString().trim();
        this.updateOverview();
      }
    }
  }
}
