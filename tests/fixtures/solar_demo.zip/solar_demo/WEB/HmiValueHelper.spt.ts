﻿
namespace WEB.Main.SupportClasses {
  export class HmiValueHelper {
    public static toNumber(value: any, fallback: number = 0): number {
      if (value === null || value === undefined || value === '') return fallback;
      const n = Number(value);
      return isNaN(n) || !isFinite(n) ? fallback : n;
    }

    public static toInt(value: any, fallback: number = 0): number {
      return Math.round(HmiValueHelper.toNumber(value, fallback));
    }

    public static toBool(value: any, fallback: boolean = false): boolean {
      if (value === null || value === undefined) return fallback;
      if (typeof value === 'boolean') return value;
      if (typeof value === 'number') return value !== 0;
      const s = value.toString().trim().toLowerCase();
      if (s === 'true' || s === '1' || s === 'on' || s === 'yes') return true;
      if (s === 'false' || s === '0' || s === 'off' || s === 'no') return false;
      return fallback;
    }

    public static safeText(value: any, fallback: string = ''): string {
      if (value === null || value === undefined) return fallback;
      const s = value.toString().replace(/'/g, '').trim();
      return s.length > 0 ? s : fallback;
    }

    public static clamp(value: any, minimum: number, maximum: number): number {
      return Math.max(minimum, Math.min(maximum, HmiValueHelper.toNumber(value)));
    }

    public static format(value: any, decimals: number, unit: string = '', fallback: string = '--'): string {
      const n = Number(value);
      if (value === null || value === undefined || isNaN(n) || !isFinite(n)) return fallback + unit;
      return n.toFixed(Math.max(0, decimals)) + unit;
    }

    public static formatSigned(value: any, decimals: number, unit: string = ''): string {
      const n = HmiValueHelper.toNumber(value);
      const prefix = n > 0 ? '+' : '';
      return prefix + n.toFixed(Math.max(0, decimals)) + unit;
    }

    public static extractEventValue(sender: any, ea: any): any {
      if (ea) {
        if (ea.value !== undefined) return ea.value;
        if (ea.Value !== undefined) return ea.Value;
        if (ea.newValue !== undefined) return ea.newValue;
      }
      if (sender) {
        if (sender.value !== undefined) return sender.value;
        if (sender.Value !== undefined) return sender.Value;
        if (sender.Val !== undefined) return sender.Val;
      }
      return null;
    }

    public static readBridge(bridge: any, fallback: any = 0): any {
      if (!bridge) return fallback;
      try {
        if (bridge.getSnapshot) {
          const data = bridge.getSnapshot();
          if (data) {
            if (data.value !== undefined) return data.value;
            if (data.feedbackValue !== undefined) return data.feedbackValue;
            if (data.currentValue !== undefined) return data.currentValue;
            if (data.Val !== undefined) return data.Val;
          }
        }
        if (bridge.getValue) return bridge.getValue();
        if (bridge.getCurrentValue) return bridge.getCurrentValue();
        if (bridge.getVal) return bridge.getVal();
        if (bridge.Val !== undefined) return bridge.Val;
        if (bridge.val !== undefined) return bridge.val;
        if (bridge.value !== undefined) return bridge.value;
      } catch (e) {
        return fallback;
      }
      return fallback;
    }
  }
}
