﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:    
 * Date: 7/29/2026
 * Time: 11:13 AM
 * 
 */
namespace WEB.Main.Canvases {

  export class ControlPage extends NxtControl.GuiFramework.Canvas {

    /**
     * Type of an object (never change this)
     * @type String
     * @default
     */
    @System.DefaultValue('WEB.Main.Canvases.ControlPage')
    protected type: string;
    
	/// ************ DO NOT DELETE THIS METHOD !!!	******///	
    /**
     * Returns {@link WEB.Main.ControlPage} instance from an object representation
     * @static
     * @param {Object} object Object to create a symbol from
     * @return {WEB.Main.ControlPage} An instance of WEB.Main.ControlPage
     */
    static fromObject(element?: HTMLCanvasElement | string, options?: any): ControlPage {
      return <ControlPage> new ControlPage(element, options);
    }
    
  } 
}
