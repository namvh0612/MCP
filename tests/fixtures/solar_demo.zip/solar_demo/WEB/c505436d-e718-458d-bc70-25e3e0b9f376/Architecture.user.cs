﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:    
 * Date: 7/29/2026
 * Time: 10:46 PM
 * 
 */

using System;
using System.Drawing;
using NxtControl.GuiHTMLFramework;

namespace WEB.Main.Canvases
{
	/// <summary>
	/// Description of Architecture.
	/// </summary>
	public partial class Architecture : NxtControl.GuiHTMLFramework.Canvas
	{
	}
}
