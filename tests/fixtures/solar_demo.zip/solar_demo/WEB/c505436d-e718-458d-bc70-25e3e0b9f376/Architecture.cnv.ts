﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:    
 * Date: 7/29/2026
 * Time: 10:46 PM
 * 
 */
namespace WEB.Main.Canvases {

  export class Architecture extends NxtControl.GuiFramework.Canvas {

    /**
     * Type of an object (never change this)
     * @type String
     * @default
     */
    @System.DefaultValue('WEB.Main.Canvases.Architecture')
    protected type: string;
    
	/// ************ DO NOT DELETE THIS METHOD !!!	******///	
    /**
     * Returns {@link WEB.Main.Architecture} instance from an object representation
     * @static
     * @param {Object} object Object to create a symbol from
     * @return {WEB.Main.Architecture} An instance of WEB.Main.Architecture
     */
    static fromObject(element?: HTMLCanvasElement | string, options?: any): Architecture {
      return <Architecture> new Architecture(element, options);
    }
    
  } 
}
