﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:    
 * Date: 7/29/2026
 * Time: 11:13 AM
 * 
 */

using System;
using System.Drawing;
using NxtControl.GuiHTMLFramework;

namespace WEB.Main.Canvases
{
	/// <summary>
	/// Description of ControlPage.
	/// </summary>
	public partial class ControlPage : NxtControl.GuiHTMLFramework.Canvas
	{
	}
}
