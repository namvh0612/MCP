﻿/*
 * Created by EcoStruxure Automation Expert.
 *
 * Compact dashboard symbol for Inverter.
 *
 * Required objects:
 * - dataCard
 * - PAC
 * - EFF
 * - IRUN
 * - QLT
 * - IFLT
 * - IALM
 * - IAVL
 *
 * Uses WEB.Main.Graphics.seDefaultCard with the 10-parameter interface.
 * No timer and no JSON modification are required.
 */
namespace WEB.Main.Symbols.acInverter_v1_0 {

  export class seDefault
    extends NxtControl.GuiFramework.RuntimeSymbol {

    @System.DefaultValue(
      'WEB.Main.Symbols.acInverter_v1_0.seDefault'
    )
    protected type: string;

    private dataCard: any;
    private qualityReceived: boolean = false;
    private assetName: string = 'INV001';

    private PAC: any;
    private EFF: any;
    private IRUN: any;
    private QLT: any;
    private IFLT: any;
    private IALM: any;
    private IAVL: any;

    /**** DO NOT DELETE CONSTRUCTOR *****/
    constructor() {
      super();
    }

    load(options: any): this {
      options = options || {};
      super.load(options);

      this.findObjects();
      this.bindInputs();
      this.updateOverview();

      return this;
    }

    private findObjects(): void {
      this.dataCard = this.find('dataCard');
      this.PAC = this.find('PAC');
      this.EFF = this.find('EFF');
      this.IRUN = this.find('IRUN');
      this.QLT = this.find('QLT');
      this.IFLT = this.find('IFLT');
      this.IALM = this.find('IALM');
      this.IAVL = this.find('IAVL');
    }

    private bindInputs(): void {
      const display: any =
        WEB.Main.SupportClasses.HmiDisplayHelper;

      display.bindBridge(
        this.PAC,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.EFF,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.IRUN,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.QLT,
        () => {
          this.qualityReceived = true;
          this.updateOverview();
        }
      );

      display.bindBridge(
        this.IFLT,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.IALM,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.IAVL,
        () => this.updateOverview()
      );
    }

    private updateOverview(): void {
      if (
        !this.dataCard ||
        typeof this.dataCard.setCardData !== 'function'
      ) {
        return;
      }

      const helper: any =
        WEB.Main.SupportClasses.HmiValueHelper;

      const quality: boolean =
        helper.toBool(helper.readBridge(this.QLT, false), false);

      const fault: boolean =
        helper.toBool(helper.readBridge(this.IFLT, false), false);

      const alarm: boolean =
        helper.toBool(helper.readBridge(this.IALM, false), false);

      const available: boolean =
        helper.toBool(helper.readBridge(this.IAVL, false), false);

      const running: boolean =
        helper.toBool(helper.readBridge(this.IRUN, false), false);

      const acPower: number =
        helper.toNumber(helper.readBridge(this.PAC, 0), 0);

      const efficiency: number =
        helper.toNumber(helper.readBridge(this.EFF, 0), 0);

      const status: any =
        this.resolveStatus(
          quality,
          fault,
          alarm,
          available,
          running
        );

      this.dataCard.setCardData(
        'Inverter',
        this.assetName,
        status.level,
        status.text,
        'AC Power',
        acPower.toFixed(2),
        'MW',
        'Efficiency',
        efficiency.toFixed(1),
        '%'
      );
    }

    private resolveStatus(
      quality: boolean,
      fault: boolean,
      alarm: boolean,
      available: boolean,
      running: boolean
    ): any {
      const state: any =
        WEB.Main.SupportClasses
          .SolarTheme
          .EquipmentState;

      if (!this.qualityReceived) {
        return { level: state.Unknown, text: 'Unknown' };
      }

      if (!quality) {
        return { level: state.Offline, text: 'Offline' };
      }

      if (fault) {
        return { level: state.Fault, text: 'Fault' };
      }

      if (alarm) {
        return { level: state.Alarm, text: 'Alarm' };
      }

      if (!available) {
        return { level: state.Standby, text: 'Standby' };
      }

      if (running) {
        return { level: state.Running, text: 'Running' };
      }

      return { level: state.Standby, text: 'Standby' };
    }


    public setAssetName(value: string): void {
      if (
        value !== null &&
        value !== undefined &&
        value.toString().trim().length > 0
      ) {
        this.assetName = value.toString().trim();
        this.updateOverview();
      }
    }
  }
}
