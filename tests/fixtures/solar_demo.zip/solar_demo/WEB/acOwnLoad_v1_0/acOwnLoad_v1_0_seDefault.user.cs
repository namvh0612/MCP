﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:    
 * Date: 7/29/2026
 * Time: 6:47 PM
 * 
 */

using System;
using System.Drawing;
using NxtControl.GuiHTMLFramework;

namespace WEB.Main.Symbols.acOwnLoad_v1_0
{
	/// <summary>
	/// Description of seDefault.
	/// </summary>
	public partial class seDefault : NxtControl.GuiHTMLFramework.RuntimeSymbol
	{
	}
}
