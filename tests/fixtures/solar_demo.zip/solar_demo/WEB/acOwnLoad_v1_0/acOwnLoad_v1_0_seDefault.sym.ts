﻿/*
 * Created by EcoStruxure Automation Expert.
 *
 * Compact dashboard symbol for Own Load.
 *
 * Required objects:
 * - dataCard
 * - PLOAD
 * - LOADLIM
 * - IACT
 * - QLT
 * - IFLT
 * - IALM
 * - IAVL
 *
 * Uses WEB.Main.Graphics.seDefaultCard with the 10-parameter interface.
 * No timer and no JSON modification are required.
 */
namespace WEB.Main.Symbols.acOwnLoad_v1_0 {

  export class seDefault
    extends NxtControl.GuiFramework.RuntimeSymbol {

    @System.DefaultValue(
      'WEB.Main.Symbols.acOwnLoad_v1_0.seDefault'
    )
    protected type: string;

    private dataCard: any;
    private qualityReceived: boolean = false;
    private assetName: string = 'LOAD01';

    private PLOAD: any;
    private LOADLIM: any;
    private IACT: any;
    private QLT: any;
    private IFLT: any;
    private IALM: any;
    private IAVL: any;

    private readonly ACTIVE_POWER_LIMIT: number = 0.01;

    /**** DO NOT DELETE CONSTRUCTOR *****/
    constructor() {
      super();
    }

    load(options: any): this {
      options = options || {};
      super.load(options);

      this.findObjects();
      this.bindInputs();
      this.updateOverview();

      return this;
    }

    private findObjects(): void {
      this.dataCard = this.find('dataCard');
      this.PLOAD = this.find('PLOAD');
      this.LOADLIM = this.find('LOADLIM');
      this.IACT = this.find('IACT');
      this.QLT = this.find('QLT');
      this.IFLT = this.find('IFLT');
      this.IALM = this.find('IALM');
      this.IAVL = this.find('IAVL');
    }

    private bindInputs(): void {
      const display: any =
        WEB.Main.SupportClasses.HmiDisplayHelper;

      display.bindBridge(
        this.PLOAD,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.LOADLIM,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.IACT,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.QLT,
        () => {
          this.qualityReceived = true;
          this.updateOverview();
        }
      );

      display.bindBridge(
        this.IFLT,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.IALM,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.IAVL,
        () => this.updateOverview()
      );
    }

    private updateOverview(): void {
      if (
        !this.dataCard ||
        typeof this.dataCard.setCardData !== 'function'
      ) {
        return;
      }

      const helper: any =
        WEB.Main.SupportClasses.HmiValueHelper;

      const quality: boolean =
        helper.toBool(helper.readBridge(this.QLT, false), false);

      const fault: boolean =
        helper.toBool(helper.readBridge(this.IFLT, false), false);

      const alarm: boolean =
        helper.toBool(helper.readBridge(this.IALM, false), false);

      const available: boolean =
        helper.toBool(helper.readBridge(this.IAVL, false), false);

      const active: boolean =
        helper.toBool(helper.readBridge(this.IACT, false), false);

      const loadPower: number =
        helper.toNumber(helper.readBridge(this.PLOAD, 0), 0);

      const loadLimit: number =
        helper.toNumber(helper.readBridge(this.LOADLIM, 0), 0);

      const status: any =
        this.resolveStatus(
          quality,
          fault,
          alarm,
          available,
          active,
          loadPower,
          loadLimit
        );

      this.dataCard.setCardData(
        'Own Load',
        this.assetName,
        status.level,
        status.text,
        'Load Power',
        loadPower.toFixed(2),
        'MW',
        'Load Limit',
        loadLimit.toFixed(1),
        'MW'
      );
    }

    private resolveStatus(
      quality: boolean,
      fault: boolean,
      alarm: boolean,
      available: boolean,
      active: boolean,
      loadPower: number,
      loadLimit: number
    ): any {
      const state: any =
        WEB.Main.SupportClasses
          .SolarTheme
          .EquipmentState;

      if (!this.qualityReceived) {
        return { level: state.Unknown, text: 'Unknown' };
      }

      if (!quality) {
        return { level: state.Offline, text: 'Offline' };
      }

      if (fault) {
        return { level: state.Fault, text: 'Fault' };
      }

      if (alarm) {
        return { level: state.Alarm, text: 'Alarm' };
      }

      if (
        loadLimit > 0 &&
        loadPower > loadLimit
      ) {
        return { level: state.Warning, text: 'High Load' };
      }

      if (!available) {
        return { level: state.Standby, text: 'Standby' };
      }

      if (
        active &&
        loadPower > this.ACTIVE_POWER_LIMIT
      ) {
        return { level: state.Running, text: 'Running' };
      }

      return { level: state.Standby, text: 'Standby' };
    }


    public setAssetName(value: string): void {
      if (
        value !== null &&
        value !== undefined &&
        value.toString().trim().length > 0
      ) {
        this.assetName = value.toString().trim();
        this.updateOverview();
      }
    }
  }
}
