﻿
namespace WEB.Main.SupportClasses {
  export class SolarTheme {
    public static EquipmentState: any = {
      Unknown: 0, Healthy: 1, Running: 2, Standby: 3,
      Warning: 4, Fault: 5, Offline: 6, Alarm: 7
    };

    public static Surface: any = {
      Page: [2, 12, 12, 1], Header: [3, 16, 15, 1], MainBoard: [5, 22, 21, 1],
      Panel: [8, 28, 27, 1], RaisedPanel: [12, 35, 33, 1], Disabled: [17, 27, 27, 1],
      Hover: [18, 45, 42, 1], Selected: [18, 67, 42, 1], Warning: [65, 51, 16, 1],
      Fault: [70, 25, 29, 1]
    };

    public static Border: any = {
      MainBoard: [29, 61, 57, 1], Normal: [37, 64, 61, 1], Divider: [42, 70, 66, 1],
      Disabled: [46, 56, 54, 1], Hover: [54, 91, 84, 1], Selected: [61, 205, 88, 1],
      Warning: [161, 129, 31, 1], Fault: [160, 57, 63, 1]
    };

    public static Text: any = {
      Primary: [238, 243, 241, 1], Heading: [210, 220, 216, 1], Secondary: [174, 187, 182, 1],
      Label: [132, 148, 143, 1], Muted: [92, 108, 104, 1], Accent: [84, 176, 103, 1],
      Icon: [194, 205, 201, 1]
    };

    public static Status: any = {
      Healthy: [61, 205, 88, 1], Running: [61, 205, 88, 1], Standby: [117, 129, 124, 1],
      Offline: [73, 84, 81, 1], Unknown: [92, 108, 104, 1], Warning: [255, 200, 61, 1],
      Alarm: [232, 86, 92, 1], Fault: [232, 86, 92, 1], Info: [66, 180, 230, 1]
    };

    public static Progress: any = {
      Track: [17, 27, 27, 1], Fill: [69, 166, 96, 1], Warning: [255, 200, 61, 1], Fault: [232, 86, 92, 1]
    };

    public static Flow: any = {
      DcPower: [216, 178, 50, 1], AcPower: [226, 104, 43, 1], Telemetry: [45, 128, 112, 1],
      ControlSetpoint: [92, 158, 119, 1], Inactive: [73, 84, 81, 1]
    };

    public static getStatusColor(state: number): any {
      const s = SolarTheme.EquipmentState;
      if (state === s.Healthy || state === s.Running) return SolarTheme.Status.Healthy;
      if (state === s.Standby) return SolarTheme.Status.Standby;
      if (state === s.Warning) return SolarTheme.Status.Warning;
      if (state === s.Alarm) return SolarTheme.Status.Alarm;
      if (state === s.Fault) return SolarTheme.Status.Fault;
      if (state === s.Offline) return SolarTheme.Status.Offline;
      return SolarTheme.Status.Unknown;
    }

    public static getStatusSurface(state: number): any {
      const s = SolarTheme.EquipmentState;
      if (state === s.Warning) return SolarTheme.Surface.Warning;
      if (state === s.Alarm || state === s.Fault) return SolarTheme.Surface.Fault;
      if (state === s.Offline || state === s.Unknown) return SolarTheme.Surface.Disabled;
      return SolarTheme.Surface.MainBoard;
    }

    public static getStatusBorder(state: number): any {
      const s = SolarTheme.EquipmentState;
      if (state === s.Warning) return SolarTheme.Border.Warning;
      if (state === s.Alarm || state === s.Fault) return SolarTheme.Border.Fault;
      if (state === s.Offline || state === s.Unknown) return SolarTheme.Border.Disabled;
      return SolarTheme.Border.Normal;
    }
  }
}
