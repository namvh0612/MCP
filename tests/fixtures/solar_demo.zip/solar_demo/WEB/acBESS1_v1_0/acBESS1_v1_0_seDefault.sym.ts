﻿/*
 * Created by EcoStruxure Automation Expert.
 *
 * Compact dashboard symbol for BESS.
 *
 * Required objects:
 * - dataCard
 * - SOC
 * - PBAT
 * - ICHG
 * - IDIS
 * - ISTBY
 * - IRUN
 * - QLT
 * - IFLT
 * - IALM
 * - IAVL
 *
 * Uses WEB.Main.Graphics.seDefaultCard with the 10-parameter interface.
 * No timer and no JSON modification are required.
 */
namespace WEB.Main.Symbols.acBESS1_v1_0 {

  export class seDefault
    extends NxtControl.GuiFramework.RuntimeSymbol {

    @System.DefaultValue(
      'WEB.Main.Symbols.acBESS1_v1_0.seDefault'
    )
    protected type: string;

    private dataCard: any;
    private qualityReceived: boolean = false;
    private assetName: string = 'BESS01';

    private SOC: any;
    private PBAT: any;
    private ICHG: any;
    private IDIS: any;
    private ISTBY: any;
    private IRUN: any;
    private QLT: any;
    private IFLT: any;
    private IALM: any;
    private IAVL: any;

    /**** DO NOT DELETE CONSTRUCTOR *****/
    constructor() {
      super();
    }

    load(options: any): this {
      options = options || {};
      super.load(options);

      this.findObjects();
      this.bindInputs();
      this.updateOverview();

      return this;
    }

    private findObjects(): void {
      this.dataCard = this.find('dataCard');
      this.SOC = this.find('SOC');
      this.PBAT = this.find('PBAT');
      this.ICHG = this.find('ICHG');
      this.IDIS = this.find('IDIS');
      this.ISTBY = this.find('ISTBY');
      this.IRUN = this.find('IRUN');
      this.QLT = this.find('QLT');
      this.IFLT = this.find('IFLT');
      this.IALM = this.find('IALM');
      this.IAVL = this.find('IAVL');
    }

    private bindInputs(): void {
      const display: any =
        WEB.Main.SupportClasses.HmiDisplayHelper;

      display.bindBridge(
        this.SOC,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.PBAT,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.ICHG,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.IDIS,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.ISTBY,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.IRUN,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.QLT,
        () => {
          this.qualityReceived = true;
          this.updateOverview();
        }
      );

      display.bindBridge(
        this.IFLT,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.IALM,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.IAVL,
        () => this.updateOverview()
      );
    }

    private updateOverview(): void {
      if (
        !this.dataCard ||
        typeof this.dataCard.setCardData !== 'function'
      ) {
        return;
      }

      const helper: any =
        WEB.Main.SupportClasses.HmiValueHelper;

      const quality: boolean =
        helper.toBool(helper.readBridge(this.QLT, false), false);

      const fault: boolean =
        helper.toBool(helper.readBridge(this.IFLT, false), false);

      const alarm: boolean =
        helper.toBool(helper.readBridge(this.IALM, false), false);

      const available: boolean =
        helper.toBool(helper.readBridge(this.IAVL, false), false);

      const charging: boolean =
        helper.toBool(helper.readBridge(this.ICHG, false), false);

      const discharging: boolean =
        helper.toBool(helper.readBridge(this.IDIS, false), false);

      const standby: boolean =
        helper.toBool(helper.readBridge(this.ISTBY, false), false);

      const running: boolean =
        helper.toBool(helper.readBridge(this.IRUN, false), false);

      const soc: number =
        helper.toNumber(helper.readBridge(this.SOC, 0), 0);

      const batteryPower: number =
        helper.toNumber(helper.readBridge(this.PBAT, 0), 0);

      const status: any =
        this.resolveStatus(
          quality,
          fault,
          alarm,
          available,
          charging,
          discharging,
          standby,
          running
        );

      this.dataCard.setCardData(
        'BESS',
        this.assetName,
        status.level,
        status.text,
        'State of Charge',
        soc.toFixed(1),
        '%',
        'Battery Power',
        this.formatSigned(batteryPower, 2),
        'MW'
      );
    }

    private resolveStatus(
      quality: boolean,
      fault: boolean,
      alarm: boolean,
      available: boolean,
      charging: boolean,
      discharging: boolean,
      standby: boolean,
      running: boolean
    ): any {
      const state: any =
        WEB.Main.SupportClasses
          .SolarTheme
          .EquipmentState;

      if (!this.qualityReceived) {
        return { level: state.Unknown, text: 'Unknown' };
      }

      if (!quality) {
        return { level: state.Offline, text: 'Offline' };
      }

      if (fault) {
        return { level: state.Fault, text: 'Fault' };
      }

      if (alarm) {
        return { level: state.Alarm, text: 'Alarm' };
      }

      if (charging) {
        return { level: state.Running, text: 'Charging' };
      }

      if (discharging) {
        return { level: state.Running, text: 'Discharging' };
      }

      if (standby) {
        return { level: state.Standby, text: 'Standby' };
      }

      if (running) {
        return { level: state.Running, text: 'Running' };
      }

      if (available) {
        return { level: state.Healthy, text: 'Available' };
      }

      return { level: state.Standby, text: 'Standby' };
    }

    private formatSigned(
      value: number,
      decimals: number
    ): string {
      const prefix: string =
        value > 0 ? '+' : '';

      return prefix + value.toFixed(decimals);
    }


    public setAssetName(value: string): void {
      if (
        value !== null &&
        value !== undefined &&
        value.toString().trim().length > 0
      ) {
        this.assetName = value.toString().trim();
        this.updateOverview();
      }
    }
  }
}
