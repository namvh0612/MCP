﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/29/2026
 * Time: 11:14 AM
 *
 * DC Combiner compact dashboard symbol.
 *
 * Required graphic objects:
 * - dataCard : WEB.Main.Graphics.seDefaultCard
 * - QLT      : HMI_Indication_Bool
 * - IFLT     : HMI_Indication_Bool
 * - IALM     : HMI_Indication_Bool
 * - IAVL     : HMI_Indication_Bool
 * - PDC      : HMI_Indication_Real
 * - STRFLT   : HMI_Indication_Integer
 */

namespace WEB.Main.Symbols.acDCCombiner_v1_0 {

  export class seDefault
    extends NxtControl.GuiFramework.RuntimeSymbol {

    /**
     * Type of an object. Never change this.
     */
    @System.DefaultValue(
      'WEB.Main.Symbols.acDCCombiner_v1_0.seDefault'
    )
    protected type: string;

    private dataCard: any;

    private QLT: any;
    private IFLT: any;
    private IALM: any;
    private IAVL: any;
    private PDC: any;
    private STRFLT: any;

    private assetName: string = 'DCC001';

    /*
     * DC Combiner is considered active when measurable
     * DC power is available.
     */
    private readonly ACTIVE_POWER_LIMIT: number = 0.01;

    /**** DO NOT DELETE CONSTRUCTOR *****/
    constructor() {
      super();
    }

    /**
     * Called when the symbol is loaded.
     */
    load(options: any): this {
      options = options || {};
      super.load(options);

      this.findObjects();
      this.bindInputs();
      this.updateOverview();

      return this;
    }

    /**
     * Find the dashboard card and input bridges.
     */
    private findObjects(): void {
      this.dataCard = this.find('dataCard');

      this.QLT = this.find('QLT');
      this.IFLT = this.find('IFLT');
      this.IALM = this.find('IALM');
      this.IAVL = this.find('IAVL');
      this.PDC = this.find('PDC');
      this.STRFLT = this.find('STRFLT');
    }

    /**
     * Refresh the card when any input value changes.
     */
    private bindInputs(): void {
      const display: any =
        WEB.Main.SupportClasses.HmiDisplayHelper;

      display.bindBridge(
        this.QLT,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.IFLT,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.IALM,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.IAVL,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.PDC,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.STRFLT,
        () => this.updateOverview()
      );
    }

    /**
     * Read the current values and update the generic card.
     */
    private updateOverview(): void {
      if (
        !this.dataCard ||
        typeof this.dataCard.setCardData !== 'function'
      ) {
        return;
      }

      const helper: any =
        WEB.Main.SupportClasses.HmiValueHelper;

      /*
       * Keep raw quality separately so the initial state
       * can remain Unknown before the first value is received.
       */
      const rawQuality: any =
        helper.readBridge(this.QLT, null);

      const hasQualityData: boolean =
        rawQuality !== null &&
        rawQuality !== undefined;

      const quality: boolean =
        helper.toBool(rawQuality, false);

      const fault: boolean =
        helper.toBool(
          helper.readBridge(this.IFLT, false),
          false
        );

      const alarm: boolean =
        helper.toBool(
          helper.readBridge(this.IALM, false),
          false
        );

      const available: boolean =
        helper.toBool(
          helper.readBridge(this.IAVL, false),
          false
        );

      const dcPower: number =
        helper.toNumber(
          helper.readBridge(this.PDC, 0),
          0
        );

      const stringFaults: number =
        helper.toInt(
          helper.readBridge(this.STRFLT, 0),
          0
        );

      const status: any =
        this.resolveStatus(
          hasQualityData,
          quality,
          fault,
          alarm,
          available,
          dcPower
        );

      /*
       * New card interface:
       *
       * Device name
       * Asset name
       * Status level
       * Status text
       * Primary label
       * Primary value
       * Primary unit
       * Secondary label
       * Secondary value
       * Secondary unit
       */
      
      this.dataCard.setCardData(
        'DC Combiner',
        this.assetName,
        status.level,
        status.text,
        'DC Power',
        dcPower.toFixed(2),
        'MW',
        'String Faults',
        stringFaults.toString(),
        'string (s)'
      );
    }

    /**
     * Resolve one overall status for the DC Combiner.
     *
     * Priority:
     * Unknown → Offline → Fault → Alarm
     * → Standby → Active
     */
    private resolveStatus(
      hasQualityData: boolean,
      quality: boolean,
      fault: boolean,
      alarm: boolean,
      available: boolean,
      dcPower: number
    ): any {
      const state: any =
        WEB.Main.SupportClasses
          .SolarTheme
          .EquipmentState;

      if (!hasQualityData) {
        return {
          level: state.Unknown,
          text: 'Unknown'
        };
      }

      if (!quality) {
        return {
          level: state.Offline,
          text: 'Offline'
        };
      }

      if (fault) {
        return {
          level: state.Fault,
          text: 'Fault'
        };
      }

      if (alarm) {
        return {
          level: state.Alarm,
          text: 'Alarm'
        };
      }

      if (!available) {
        return {
          level: state.Standby,
          text: 'Standby'
        };
      }

      if (dcPower > this.ACTIVE_POWER_LIMIT) {
        return {
          level: state.Running,
          text: 'Active'
        };
      }

      return {
        level: state.Standby,
        text: 'Standby'
      };
    }

    /**
     * Optional method for changing the asset name
     * from the parent canvas.
     */
    public setAssetName(value: string): void {
      if (
        value !== null &&
        value !== undefined &&
        value.toString().trim().length > 0
      ) {
        this.assetName =
          value.toString().trim();

        this.updateOverview();
      }
    }
  }
}