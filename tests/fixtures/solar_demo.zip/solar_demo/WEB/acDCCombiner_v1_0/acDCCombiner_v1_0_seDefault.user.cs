﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:    
 * Date: 7/29/2026
 * Time: 11:14 AM
 * 
 */

using System;
using System.Drawing;
using NxtControl.GuiHTMLFramework;

namespace WEB.Main.Symbols.acDCCombiner_v1_0
{
	/// <summary>
	/// Description of seDefault.
	/// </summary>
	public partial class seDefault : NxtControl.GuiHTMLFramework.RuntimeSymbol
	{
	}
}
