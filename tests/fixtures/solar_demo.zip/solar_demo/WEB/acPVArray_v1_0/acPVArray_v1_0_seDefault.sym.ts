﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/28/2026
 * Time: 11:48 PM
 *
 * PV Array compact overview card.
 *
 * Required objects:
 * - dataCard : DeviceOverviewCard_v1_3
 * - QLT      : HMI_Indication_Bool
 * - IFLT     : HMI_Indication_Bool
 * - IALM     : HMI_Indication_Bool
 * - IAVL     : HMI_Indication_Bool
 * - PDC      : HMI_Indication_Real
 * - IRR      : HMI_Indication_Real
 */

namespace WEB.Main.Symbols.acPVArray_v1_0 {

  export class seDefault
    extends NxtControl.GuiFramework.RuntimeSymbol {

    @System.DefaultValue(
      'WEB.Main.Symbols.acPVArray_v1_0.seDefault'
    )
    protected type: string;

    private dataCard: any;

    private QLT: any;
    private IFLT: any;
    private IALM: any;
    private IAVL: any;
    private PDC: any;
    private IRR: any;

    /*
     * Default asset name for this demo.
     * It can later be replaced by a CAT property.
     */
    private assetName: string = 'PV001';

    private readonly RUNNING_POWER_LIMIT: number = 0.01;

    /**** DO NOT DELETE CONSTRUCTOR *****/
    constructor() {
      super();
    }

    /**
     * Called when the symbol is loaded.
     */
    load(options: any): this {
      options = options || {};
      super.load(options);

      this.findObjects();
      this.bindInputs();
      this.updateOverview();

      return this;
    }

    /**
     * Find the card and all hidden data bridges.
     */
    private findObjects(): void {
      this.dataCard = this.find('dataCard');

      this.QLT = this.find('QLT');
      this.IFLT = this.find('IFLT');
      this.IALM = this.find('IALM');
      this.IAVL = this.find('IAVL');
      this.PDC = this.find('PDC');
      this.IRR = this.find('IRR');
    }

    /**
     * Refresh the card whenever a CAT value changes.
     */
    private bindInputs(): void {
      const display: any =
        WEB.Main.SupportClasses.HmiDisplayHelper;

      display.bindBridge(
        this.QLT,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.IFLT,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.IALM,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.IAVL,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.PDC,
        () => this.updateOverview()
      );

      display.bindBridge(
        this.IRR,
        () => this.updateOverview()
      );
    }

    /**
     * Read all values and update the generic dashboard card.
     */
    private updateOverview(): void {
      if (
        !this.dataCard ||
        typeof this.dataCard.setCardData !== 'function'
      ) {
        return;
      }

      const values: any =
        WEB.Main.SupportClasses.HmiValueHelper;

      const quality: boolean =
        values.toBool(
          values.readBridge(this.QLT, false)
        );

      const fault: boolean =
        values.toBool(
          values.readBridge(this.IFLT, false)
        );

      const alarm: boolean =
        values.toBool(
          values.readBridge(this.IALM, false)
        );

      const available: boolean =
        values.toBool(
          values.readBridge(this.IAVL, false)
        );

      const dcPower: number =
        values.toNumber(
          values.readBridge(this.PDC, 0)
        );

      const irradiance: number =
        values.toNumber(
          values.readBridge(this.IRR, 0)
        );

      const status: any =
        this.resolveStatus(
          quality,
          fault,
          alarm,
          available,
          dcPower
        );

      const dcPowerText: string =
        values.format(
          dcPower,
          2,
          ' MW',
          '--'
        );

      const irradianceText: string =
        values.format(
          irradiance,
          0,
          ' W/m²',
          '--'
        );

      this.dataCard.setCardData(
        'PV Array',
        this.assetName,
        status.level,
        status.text,
        'DC Power',
        dcPower.toFixed(2),
        'MW',
        'Irradiance',
        irradiance.toFixed(0),
        'W/m²'
      );
     }

    /**
     * Resolve one overall status for the PV Array card.
     *
     * Priority:
     * Offline → Fault → Alarm → Standby → Generating
     */
    private resolveStatus(
      quality: boolean,
      fault: boolean,
      alarm: boolean,
      available: boolean,
      dcPower: number
    ): any {
      const state: any =
        WEB.Main.SupportClasses
          .SolarTheme
          .EquipmentState;

      if (!quality) {
        return {
          level: state.Offline,
          text: 'Offline'
        };
      }

      if (fault) {
        return {
          level: state.Fault,
          text: 'Fault'
        };
      }

      if (alarm) {
        return {
          level: state.Alarm,
          text: 'Alarm'
        };
      }

      if (!available) {
        return {
          level: state.Standby,
          text: 'Standby'
        };
      }

      if (dcPower > this.RUNNING_POWER_LIMIT) {
        return {
          level: state.Running,
          text: 'Generating'
        };
      }

      return {
        level: state.Standby,
        text: 'Standby'
      };
    }

    /**
     * Optional method for changing the displayed asset name.
     */
    public setAssetName(value: string): void {
      if (
        typeof value === 'string' &&
        value.trim().length > 0
      ) {
        this.assetName = value.trim();
        this.updateOverview();
      }
    }
  }
}