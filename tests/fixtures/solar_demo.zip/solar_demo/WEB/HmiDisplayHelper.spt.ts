﻿
namespace WEB.Main.SupportClasses {
  export class HmiDisplayHelper {
    public static bindBridge(bridge: any, callback: any): void {
      if (!bridge || !callback) return;
      try {
        if (bridge.setValueChangedHandler) {
          bridge.setValueChangedHandler((sender: any, data: any) => callback(sender, data));
          return;
        }
        if (bridge.valueChanged && bridge.valueChanged.add) {
          bridge.valueChanged.add((sender: any, data: any) => callback(sender, data));
        }
      } catch (e) {
        console.warn('[Solar eHMI] Unable to bind bridge callback', e);
      }
    }

    public static writeText(obj: any, value: any): void {
      if (!obj) return;
      const text = value === null || value === undefined ? '' : value.toString();
      if (obj.setText) obj.setText(text);
      else if (obj._set) obj._set('text', text, true);
      else obj.text = text;
    }

    public static writeTextColor(obj: any, color: any): void {
      if (!obj) return;
      if (obj.setTextColor) obj.setTextColor(color);
      else if (obj._set) obj._set('textColor', color, true);
      else obj.textColor = color;
    }

    public static writeBrush(obj: any, color: any): void {
      if (!obj) return;
      const brush = { color: color };
      if (obj.setBrush) obj.setBrush(brush);
      else if (obj._set) obj._set('brush', brush, true);
      else obj.brush = brush;
    }

    public static writePen(obj: any, color: any, width?: number): void {
      if (!obj) return;
      const pen: any = { color: color };
      if (width !== undefined) pen.width = width;
      if (obj.setPen) obj.setPen(pen);
      else if (obj._set) obj._set('pen', pen, true);
      else obj.pen = pen;
    }

    public static writeVisible(obj: any, value: boolean): void {
      if (!obj) return;
      if (obj.setVisible) obj.setVisible(value);
      else if (obj._set) obj._set('visible', value, true);
      else obj.visible = value;
    }

    public static writeWidth(obj: any, value: number): void {
      if (!obj) return;
      if (obj.setWidth) obj.setWidth(value);
      else if (obj._set) obj._set('width', value, true);
      else obj.width = value;
    }

    public static applyStatusCard(border: any, background: any, indicator: any,
                                  statusText: any, state: number, hovered: boolean): void {
      const theme = WEB.Main.SupportClasses.SolarTheme;
      HmiDisplayHelper.writeBrush(background, hovered ? theme.Surface.Hover : theme.getStatusSurface(state));
      HmiDisplayHelper.writePen(border, hovered ? theme.Border.Hover : theme.getStatusBorder(state), hovered ? 2 : 1);
      HmiDisplayHelper.writeBrush(indicator, theme.getStatusColor(state));
      HmiDisplayHelper.writeText(statusText, WEB.Main.SupportClasses.SolarStatusHelper.getStatusText(state));
      HmiDisplayHelper.writeTextColor(statusText, theme.getStatusColor(state));
    }

    public static sendCommand(bridge: any, value: any, valueName: string = 'oValue'): boolean {
      if (!bridge) return false;
      try {
        if (bridge.setCommand) { bridge.setCommand(value); return true; }
        if (bridge.setCommandOptimistic) { bridge.setCommandOptimistic(value); return true; }
        if (bridge.commitValues) {
          const values: { Name: string, Value: any }[] = [];
          values.push({ Name: valueName, Value: value });
          bridge.commitValues(values);
          return true;
        }
      } catch (e) {
        console.error('[Solar eHMI] Command failed', e);
      }
      return false;
    }
  }
}
