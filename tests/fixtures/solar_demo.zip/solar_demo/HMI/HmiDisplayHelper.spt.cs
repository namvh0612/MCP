﻿/*
 * Common HMI display renderer.
 */

using System;
using NxtControl.Drawing;

using GuiLabel =
	NxtControl.GuiFramework.Label;

using GuiEllipse =
	NxtControl.GuiFramework.Ellipse;

using GuiRectangle =
	NxtControl.GuiFramework.RoundedRectangle;

namespace HMI.Main.SupportClasses
{
	public partial class HmiDisplayHelper
	{
		public HmiDisplayHelper()
		{
		}

		public sealed class DisplayItem
		{
			public GuiLabel Target;
			public string Text;
			public bool Visible;
			public bool UseTextColor;
			public Color TextColor;

			public DisplayItem()
			{
				Visible = true;
				UseTextColor = false;
				TextColor = SolarTheme.Text.Primary;
			}
		}

		public sealed class DisplayData
		{
			public SolarTheme.EquipmentState Status;

			/*
			 * Leave empty to use the standard status text.
			 * Use this for Charging, Discharging, Exporting, etc.
			 */
			public string StatusText;

			public GuiLabel StatusLabel;
			public GuiEllipse StatusIndicator;

			public GuiRectangle CardBorder;
			public GuiRectangle CardBackground;

			public bool IsHovered;

			public DisplayItem[] Items;

			public DisplayData()
			{
				Status =
					SolarTheme.EquipmentState.Unknown;

				StatusText =
					string.Empty;

				Items =
					new DisplayItem[0];
			}
		}

		public static DisplayItem CreateValue(
			GuiLabel target,
			object value,
			string format,
			string unit)
		{
			return CreateValue(
				target,
				value,
				format,
				unit,
				SolarTheme.Text.Primary);
		}

		public static DisplayItem CreateValue(
			GuiLabel target,
			object value,
			string format,
			string unit,
			Color textColor)
		{
			DisplayItem item =
				new DisplayItem();

			item.Target = target;

			item.Text =
				HmiValueHelper.Format(
					value,
					format,
					unit);

			item.TextColor = textColor;
			item.UseTextColor = true;

			return item;
		}

		public static DisplayItem CreateText(
			GuiLabel target,
			string text)
		{
			return CreateText(
				target,
				text,
				SolarTheme.Text.Primary);
		}

		public static DisplayItem CreateText(
			GuiLabel target,
			string text,
			Color textColor)
		{
			DisplayItem item =
				new DisplayItem();

			item.Target = target;

			item.Text =
				string.IsNullOrEmpty(text)
					? "--"
					: text;

			item.TextColor = textColor;
			item.UseTextColor = true;

			return item;
		}

		public static DisplayItem CreateHidden(
			GuiLabel target)
		{
			DisplayItem item =
				new DisplayItem();

			item.Target = target;
			item.Text = string.Empty;
			item.Visible = false;

			return item;
		}

		public static void Apply(
			DisplayData data)
		{
			if (data == null)
				return;

			Color statusColor =
				SolarTheme.GetStatusColor(
					data.Status);

			string statusText =
				string.IsNullOrEmpty(data.StatusText)
					? SolarStatusHelper.GetStatusText(
						data.Status)
					: data.StatusText;

			SetLabel(
				data.StatusLabel,
				statusText,
				statusColor,
				true);

			SetIndicator(
				data.StatusIndicator,
				statusColor);

			ApplyStatusCard(
				data.CardBorder,
				data.CardBackground,
				data.Status,
				data.IsHovered);

			if (data.Items == null)
				return;

			for (int i = 0;
				i < data.Items.Length;
				i++)
			{
				ApplyItem(data.Items[i]);
			}
		}

		private static void ApplyItem(
			DisplayItem item)
		{
			if (item == null ||
				item.Target == null)
			{
				return;
			}

			try
			{
				item.Target.Visible =
					item.Visible;

				if (!item.Visible)
					return;

				item.Target.Text =
					item.Text ?? string.Empty;

				if (item.UseTextColor)
				{
					item.Target.TextColor =
						item.TextColor;
				}
			}
			catch
			{
				// Prevent an invalid HMI control from crashing runtime.
			}
		}

		public static void SetLabel(
			GuiLabel label,
			string text,
			Color textColor,
			bool visible)
		{
			if (label == null)
				return;

			try
			{
				label.Visible = visible;

				if (!visible)
					return;

				label.Text =
					text ?? string.Empty;

				label.TextColor =
					textColor;
			}
			catch
			{
				// Prevent HMI runtime failure.
			}
		}

		public static void SetLabelsColor(
			Color textColor,
			params GuiLabel[] labels)
		{
			if (labels == null)
				return;

			for (int i = 0;
				i < labels.Length;
				i++)
			{
				if (labels[i] == null)
					continue;

				try
				{
					labels[i].TextColor =
						textColor;
				}
				catch
				{
					// Continue updating other labels.
				}
			}
		}

		public static void SetIndicator(
			GuiEllipse indicator,
			Color color)
		{
			if (indicator == null)
				return;

			try
			{
				indicator.BrushColor =
					color;
			}
			catch
			{
				// Prevent HMI runtime failure.
			}
		}

		public static void ApplyStatusCard(
			GuiRectangle border,
			GuiRectangle background,
			SolarTheme.EquipmentState status,
			bool isHovered)
		{
			try
			{
				if (background != null)
				{
					background.BrushColor =
						isHovered
							? SolarTheme.Surface.Hover
							: SolarTheme.Surface.MainBoard;
				}

				if (border == null)
					return;

				switch (status)
				{
					
					case SolarTheme.EquipmentState.Alarm:
					case SolarTheme.EquipmentState.Fault:
					
						border.PenColor =
							SolarTheme.Border.Fault;
					
						border.PenWidth =
							SolarTheme.Pen.Status;
					
						break;

					case SolarTheme.EquipmentState.Warning:

						border.PenColor =
							SolarTheme.Border.Warning;

						border.PenWidth =
							SolarTheme.Pen.Status;

						break;

					case SolarTheme.EquipmentState.Offline:
					case SolarTheme.EquipmentState.Unknown:

						border.PenColor =
							SolarTheme.Border.Disabled;

						border.PenWidth =
							SolarTheme.Pen.Normal;

						break;

					default:

						border.PenColor =
							isHovered
								? SolarTheme.Border.Hover
								: SolarTheme.Border.Normal;

						border.PenWidth =
							isHovered
								? SolarTheme.Pen.Panel
								: SolarTheme.Pen.Normal;

						break;
				}
			}
			catch
			{
				// Prevent HMI runtime failure.
			}
		}

		public static void ApplyButton(
			GuiRectangle button,
			bool isSelected,
			bool isHovered,
			bool isEnabled)
		{
			if (button == null)
				return;

			try
			{
				if (!isEnabled)
				{
					button.BrushColor =
						SolarTheme.Surface.Disabled;

					button.PenColor =
						SolarTheme.Border.Disabled;

					button.PenWidth =
						SolarTheme.Pen.Normal;
				}
				else if (isSelected)
				{
					button.BrushColor =
						SolarTheme.Surface.Selected;

					button.PenColor =
						SolarTheme.Border.Selected;

					button.PenWidth =
						SolarTheme.Pen.Selected;
				}
				else if (isHovered)
				{
					button.BrushColor =
						SolarTheme.Surface.Hover;

					button.PenColor =
						SolarTheme.Border.Hover;

					button.PenWidth =
						SolarTheme.Pen.Panel;
				}
				else
				{
					button.BrushColor =
						SolarTheme.Surface.RaisedPanel;

					button.PenColor =
						SolarTheme.Border.Normal;

					button.PenWidth =
						SolarTheme.Pen.Normal;
				}
			}
			catch
			{
				// Prevent HMI runtime failure.
			}
		}
	}
}