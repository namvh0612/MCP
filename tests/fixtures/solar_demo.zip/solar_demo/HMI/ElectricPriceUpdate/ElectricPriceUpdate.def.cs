/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 8/24/2026
 * Time: 2:29 PM
 * 
 */
using System;
using NxtControl.GuiFramework;
using NxtControl.Services;

#region Definitions;

#endregion Definitions;
