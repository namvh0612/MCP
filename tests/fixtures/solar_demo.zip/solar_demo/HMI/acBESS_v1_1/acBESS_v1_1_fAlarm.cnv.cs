/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/15/2026
 * Time: 12:49 PM
 * 
 */

using System;
using System.Collections.Generic;
using NxtControl.GuiFramework;
using NxtControl.Drawing;

namespace HMI.Main.Faceplates.acBESS_v1_1
{
	/// <summary>
	/// Description of fAlarm.
	/// </summary>
	public partial class fAlarm : NxtControl.GuiFramework.HMIFaceplate
	{
		private static readonly Color COLOR_ALARM   = new Color(234, 22, 30);
		private static readonly Color COLOR_OFFLINE = new Color(114, 110, 106);

		private readonly Dictionary<int, string> _alarmText = new Dictionary<int, string>();
		private NxtControl.GuiFramework.Label[] _alarmLabels;

		public fAlarm()
		{
			InitializeComponent();

			InitializeAlarmText();
			InitializeAlarmLabels();

			ALMW.OnValChanged += OnAlarmWordChanged;

			UpdateAlarmDisplay();
			this.REQ_Fired += REQ_Fired_EventHandler;
		}

		private void InitializeAlarmText()
		{
			_alarmText[0] = "Data quality lost";
			_alarmText[1] = "SOC measurement invalid";
			_alarmText[2] = "Battery overtemperature";
			_alarmText[3] = "Vol. operating range error";
			_alarmText[4] = "SOC high limit reached";
			_alarmText[5] = "SOC low limit reached";
			_alarmText[6] = "Commands conflict";
			_alarmText[7] = "Simulated BESS / PCS trip";
			_alarmText[8] = "Capability limited";
			_alarmText[9] = "Battery current too high";
		}

		private void InitializeAlarmLabels()
		{
			_alarmLabels = new NxtControl.GuiFramework.Label[]
			{
				label1,
				label2,
				label3,
				label4,
				label5,
				label6,
				label7,
				label8,
				label9,
				label10
			};
		}

		private void OnAlarmWordChanged(object sender, EventArgs e)
		{
			UpdateAlarmDisplay();
		}

		private void UpdateAlarmDisplay()
		{
			int alarmWord = ToInt(ALMW.Val);

			for (int bit = 0; bit < _alarmLabels.Length; bit++)
			{
				if (_alarmText.ContainsKey(bit))
				{
					bool isActive = IsBitSet(alarmWord, bit);

					_alarmLabels[bit].Text = _alarmText[bit];

					SetLabelVisible(_alarmLabels[bit], true);

					if (isActive)
					{
						SetLabelColor(_alarmLabels[bit], COLOR_ALARM);
					}
					else
					{
						SetLabelColor(_alarmLabels[bit], COLOR_OFFLINE);
					}
				}
				else
				{
					_alarmLabels[bit].Text = "";
					SetLabelVisible(_alarmLabels[bit], false);
				}
			}
		}

		private bool IsBitSet(int value, int bit)
		{
			return (value & (1 << bit)) != 0;
		}

		private int ToInt(object value)
		{
			try
			{
				return Convert.ToInt32(value);
			}
			catch
			{
				return 0;
			}
		}

		private void SetLabelColor(NxtControl.GuiFramework.Label label, Color textColor)
		{
			try
			{
				label.TextColor = textColor;
			}
			catch
			{
				// Do nothing
			}
		}

		private void SetLabelVisible(NxtControl.GuiFramework.Label label, bool visible)
		{
			try
			{
				label.Visible = visible;
			}
			catch
			{
				// Do nothing
			}
		}

		void REQ_Fired_EventHandler(object sender, HMI.Main.Symbols.acBESS_v1_1.REQEventArgs e)
		{
			Title = e.AssetName;
		}
	}
}
