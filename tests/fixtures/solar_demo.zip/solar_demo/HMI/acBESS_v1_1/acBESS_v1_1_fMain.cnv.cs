/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/14/2026
 * Time: 9:11 PM
 * 
 */

using System;
using NxtControl.GuiFramework;
using NxtControl.Drawing;

namespace HMI.Main.Faceplates.acBESS_v1_1
{
	/// <summary>
	/// Description of fMain.
	/// </summary>
	public partial class fMain : NxtControl.GuiFramework.HMIFaceplate
	{
		// =====================================================================
		// UI COLOR CONFIG
		// =====================================================================

		private static readonly Color COLOR_CHARGING =
			new Color(61, 205, 88);

		private static readonly Color COLOR_DISCHARGING =
			new Color(255, 111, 40);

		private static readonly Color COLOR_STANDBY =
			new Color(27, 92, 43);

		private static readonly Color COLOR_AVAILABLE =
			new Color(61, 205, 88);

		private static readonly Color COLOR_ALARM =
			new Color(234, 22, 30);

		private static readonly Color COLOR_OFFLINE =
			new Color(114, 110, 106);

		private static readonly Color COLOR_NORMAL =
			new Color(255, 255, 255);

		private enum BessVisualStatus
		{
			Offline,
			Fault,
			Alarm,
			Charging,
			Discharging,
			Standby,
			Available
		}

		public fMain()
		{
			//
			// The InitializeComponent() call is required for
			// Windows Forms designer support.
			//
			InitializeComponent();


			IAVL.OnValChanged  += OnBessValueChanged;
			IRUN.OnValChanged  += OnBessValueChanged;
			ICHG.OnValChanged  += OnBessValueChanged;
			IDIS.OnValChanged  += OnBessValueChanged;
			ISTBY.OnValChanged += OnBessValueChanged;

			IALM.OnValChanged += OnBessValueChanged;
			IFLT.OnValChanged += OnBessValueChanged;
			QLT.OnValChanged  += OnBessValueChanged;

			VBAT.OnValChanged  += OnBessValueChanged;
			IBAT.OnValChanged  += OnBessValueChanged;
			TBAT.OnValChanged  += OnBessValueChanged;
			SOCSP.OnValChanged += OnBessValueChanged;

			UpdateDisplay();
		}

		private void OnBessValueChanged(
			object sender,
			EventArgs e)
		{
			UpdateDisplay();
		}

		private void UpdateDisplay()
		{
			BessVisualStatus status =
				ResolveStatus();

			Color statusColor =
				GetStatusColor(status);

			txtStatus.Text =
				GetStatusText(status);

			txtStatus.TextColor =
				statusColor;

			txtVBAT.Text =
				FormatReal(VBAT.Val, "0") + " V";

			txtIBAT.Text =
				FormatSignedReal(IBAT.Val, "0") + " A";

			txtTBAT.Text =
				FormatReal(TBAT.Val, "0") + " °C";

			txtSOCSP.Text =
				FormatReal(SOCSP.Val, "0") + " %";

			UpdateValueColors(status);
		}

		// =====================================================================
		// STATUS LOGIC
		// =====================================================================

		private BessVisualStatus ResolveStatus()
		{
			if (!ToBool(QLT.Val))
			{
				return BessVisualStatus.Offline;
			}

			if (ToBool(IFLT.Val))
			{
				return BessVisualStatus.Fault;
			}

			if (ToBool(IALM.Val))
			{
				return BessVisualStatus.Alarm;
			}

			if (ToBool(ICHG.Val))
			{
				return BessVisualStatus.Charging;
			}

			if (ToBool(IDIS.Val))
			{
				return BessVisualStatus.Discharging;
			}

			if (ToBool(ISTBY.Val))
			{
				return BessVisualStatus.Standby;
			}

			if (ToBool(IAVL.Val))
			{
				return BessVisualStatus.Available;
			}

			return BessVisualStatus.Standby;
		}

		private string GetStatusText(
			BessVisualStatus status)
		{
			switch (status)
			{
				case BessVisualStatus.Offline:
					return "Offline";

				case BessVisualStatus.Fault:
					return "Fault";

				case BessVisualStatus.Alarm:
					return "Alarm";

				case BessVisualStatus.Charging:
					return "Charging";

				case BessVisualStatus.Discharging:
					return "Discharging";

				case BessVisualStatus.Standby:
					return "Standby";

				case BessVisualStatus.Available:
					return "Available";

				default:
					return "Unknown";
			}
		}

		private Color GetStatusColor(
			BessVisualStatus status)
		{
			switch (status)
			{
				case BessVisualStatus.Offline:
					return COLOR_OFFLINE;

				case BessVisualStatus.Fault:
					return COLOR_ALARM;

				case BessVisualStatus.Alarm:
					return COLOR_ALARM;

				case BessVisualStatus.Charging:
					return COLOR_CHARGING;

				case BessVisualStatus.Discharging:
					return COLOR_DISCHARGING;

				case BessVisualStatus.Standby:
					return COLOR_STANDBY;

				case BessVisualStatus.Available:
					return COLOR_AVAILABLE;

				default:
					return COLOR_OFFLINE;
			}
		}

		// =====================================================================
		// VALUE COLOR LOGIC
		// =====================================================================

		private void UpdateValueColors(
			BessVisualStatus status)
		{
			if (status == BessVisualStatus.Offline)
			{
				SetAllValueColors(COLOR_OFFLINE);
				return;
			}

			if (status == BessVisualStatus.Fault)
			{
				SetAllValueColors(COLOR_ALARM);
				return;
			}

			txtVBAT.TextColor =
				IsVoltageValid(VBAT.Val)
					? COLOR_NORMAL
					: COLOR_ALARM;

			txtTBAT.TextColor =
				IsTemperatureValid(TBAT.Val)
					? COLOR_NORMAL
					: COLOR_ALARM;

			txtSOCSP.TextColor =
				IsSocSetpointValid(SOCSP.Val)
					? COLOR_NORMAL
					: COLOR_ALARM;

			switch (status)
			{
				case BessVisualStatus.Charging:
					txtIBAT.TextColor =
						COLOR_CHARGING;
					break;

				case BessVisualStatus.Discharging:
					txtIBAT.TextColor =
						COLOR_DISCHARGING;
					break;

				case BessVisualStatus.Standby:
					txtIBAT.TextColor =
						COLOR_STANDBY;
					break;

				default:
					txtIBAT.TextColor =
						COLOR_NORMAL;
					break;
			}
		}

		private void SetAllValueColors(
			Color color)
		{
			txtVBAT.TextColor  = color;
			txtIBAT.TextColor  = color;
			txtTBAT.TextColor  = color;
			txtSOCSP.TextColor = color;
		}

		private bool IsVoltageValid(
			object value)
		{
			double voltage =
				ToDouble(value);

			return voltage >= 600.0
				&& voltage <= 900.0;
		}

		private bool IsTemperatureValid(
			object value)
		{
			double temperature =
				ToDouble(value);

			return temperature < 55.0;
		}

		private bool IsSocSetpointValid(
			object value)
		{
			double setpoint =
				ToDouble(value);

			return setpoint >= 0.0
				&& setpoint <= 100.0;
		}

		// =====================================================================
		// HELPERS
		// =====================================================================

		private string FormatReal(
			object value,
			string format)
		{
			try
			{
				return Convert
					.ToDouble(value)
					.ToString(format);
			}
			catch
			{
				return "0";
			}
		}

		private string FormatSignedReal(
			object value,
			string format)
		{
			try
			{
				double number =
					Convert.ToDouble(value);

				if (number > 0.0)
				{
					return "+"
						+ number.ToString(format);
				}

				return number.ToString(format);
			}
			catch
			{
				return "0";
			}
		}

		private bool ToBool(
			object value)
		{
			try
			{
				return Convert.ToBoolean(value);
			}
			catch
			{
				return false;
			}
		}

		private double ToDouble(
			object value)
		{
			try
			{
				return Convert.ToDouble(value);
			}
			catch
			{
				return 0.0;
			}
		}

		void REQ_Fired_EventHandler(
			object sender,
			HMI.Main.Symbols.acBESS_v1_1.REQEventArgs e)
		{
			Title = e.AssetName;
		}
	}
}