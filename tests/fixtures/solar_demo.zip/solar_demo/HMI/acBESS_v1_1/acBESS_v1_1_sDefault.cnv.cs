/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/14/2026
 * Time: 2:58 PM
 * 
 */

using System;
using NxtControl.GuiFramework;
using NxtControl.Drawing;

namespace HMI.Main.Symbols.acBESS_v1_1
{
	/// <summary>
	/// Description of sDefault.
	/// </summary>
	public partial class sDefault : NxtControl.GuiFramework.HMISymbol
	{
		private bool _isRectBtnHovered = false;
		private VisualStatus _currentStatus = VisualStatus.Offline;

		// =====================================================================
		// UI COLOR CONFIG
		// =====================================================================

		private const double BORDER_OFF_DARKEN_FACTOR = 0.45;

		private static readonly UiColor COLOR_CHARGING =
			new UiColor(61, 205, 88);

		private static readonly UiColor COLOR_DISCHARGING =
			new UiColor(255, 111, 40);

		private static readonly UiColor COLOR_STANDBY =
			new UiColor(27, 92, 43);

		private static readonly UiColor COLOR_AVAILABLE =
			new UiColor(61, 205, 88);

		private static readonly UiColor COLOR_ALARM =
			new UiColor(234, 22, 30);

		private static readonly UiColor COLOR_OFFLINE =
			new UiColor(114, 110, 106);

		private static readonly UiColor COLOR_WHITE =
			new UiColor(255, 255, 255);

		private static readonly UiColor BG_HOVER_ON =
			new UiColor(5, 21, 10);

		private static readonly UiColor BG_HOVER_OFF =
			new UiColor(0, 13, 12);

		private enum VisualStatus
		{
			Offline,
			Fault,
			Alarm,
			Charging,
			Discharging,
			Standby,
			Available
		}

		private sealed class UiColor
		{
			public readonly byte R;
			public readonly byte G;
			public readonly byte B;

			public UiColor(byte r, byte g, byte b)
			{
				R = r;
				G = g;
				B = b;
			}

			public Color ToColor()
			{
				return new Color(R, G, B);
			}

			public Color Darken(double factor)
			{
				return new Color(
					Clamp((int)(R * factor)),
					Clamp((int)(G * factor)),
					Clamp((int)(B * factor))
				);
			}

			private static byte Clamp(int value)
			{
				if (value < 0)
				return 0;

				if (value > 255)
					return 255;

				return (byte)value;
			}
		}

		public sDefault()
		{
			//
			// The InitializeComponent() call is required for
			// Windows Forms designer support.
			//
			InitializeComponent();

			this.REQ_Fired += REQ_Fired_EventHandler;

			IAVL.OnValChanged += OnValueChanged;
			IRUN.OnValChanged += OnValueChanged;
			ICHG.OnValChanged += OnValueChanged;
			IDIS.OnValChanged += OnValueChanged;
			ISTBY.OnValChanged += OnValueChanged;

			IALM.OnValChanged += OnValueChanged;
			IFLT.OnValChanged += OnValueChanged;
			QLT.OnValChanged += OnValueChanged;

			SOC.OnValChanged += OnValueChanged;
			PBAT.OnValChanged += OnValueChanged;
			MODE.OnValChanged += OnValueChanged;

			UpdateDisplay();
		}

		private void OnValueChanged(object sender, EventArgs e)
		{
			UpdateDisplay();
		}

		private void UpdateDisplay()
		{
			_currentStatus = ResolveStatus();

			UiColor statusColor =
				GetStatusColor(_currentStatus);

			float soc =
				ClampReal(SOC.Val, 0.0f, 100.0f);

			txtStatus.Text =
				GetStatusText(_currentStatus);

			txtStatus.TextColor =
				statusColor.ToColor();

			indStatus.BrushColor =
				statusColor.ToColor();

			txtSOC.Text =
				FormatReal(soc, "0") + "%";

			progressBarSOC.FillPercent = soc;

			progressBarSOC.BrushColor =
				GetSocColor(soc).ToColor();

			txtMODE.Text =
				GetModeText(MODE.Val);

			txtPower.Text =
				GetPowerText(PBAT.Val);

			txtPower.TextColor =
				GetPowerColor(PBAT.Val).ToColor();

			UpdateRectButtonVisual();
		}

		private void UpdateRectButtonVisual()
		{
			UiColor baseColor =
				GetStatusColor(_currentStatus);

			if (_isRectBtnHovered)
			{
				rectBtn.PenColor =
					baseColor.ToColor();

				rectBase.BrushColor =
					BG_HOVER_ON.ToColor();
			}
			else
			{
				rectBtn.PenColor =
					baseColor.Darken(
						BORDER_OFF_DARKEN_FACTOR
					);

				rectBase.BrushColor =
					BG_HOVER_OFF.ToColor();
			}
		}

		// =====================================================================
		// STATUS LOGIC
		// =====================================================================

		private VisualStatus ResolveStatus()
		{
			if (!ToBool(QLT.Val))
			{
				return VisualStatus.Offline;
			}

			if (ToBool(IFLT.Val))
			{
				return VisualStatus.Fault;
			}

			if (ToBool(IALM.Val))
			{
				return VisualStatus.Alarm;
			}

			if (ToBool(ICHG.Val))
			{
				return VisualStatus.Charging;
			}

			if (ToBool(IDIS.Val))
			{
				return VisualStatus.Discharging;
			}

			if (ToBool(ISTBY.Val))
			{
				return VisualStatus.Standby;
			}

			if (ToBool(IAVL.Val))
			{
				return VisualStatus.Available;
			}

			return VisualStatus.Standby;
		}

		private string GetStatusText(
			VisualStatus status)
		{
			switch (status)
			{
				case VisualStatus.Offline:
					return "Offline";

				case VisualStatus.Fault:
					return "Fault";

				case VisualStatus.Alarm:
					return "Alarm";

				case VisualStatus.Charging:
					return "Charging";

				case VisualStatus.Discharging:
					return "Discharging";

				case VisualStatus.Standby:
					return "Standby";

				case VisualStatus.Available:
					return "Available";

				default:
					return "Unknown";
			}
		}

		private UiColor GetStatusColor(
			VisualStatus status)
		{
			switch (status)
			{
				case VisualStatus.Offline:
					return COLOR_OFFLINE;

				case VisualStatus.Fault:
					return COLOR_ALARM;

				case VisualStatus.Alarm:
					return COLOR_ALARM;

				case VisualStatus.Charging:
					return COLOR_CHARGING;

				case VisualStatus.Discharging:
					return COLOR_DISCHARGING;

				case VisualStatus.Standby:
					return COLOR_STANDBY;

				case VisualStatus.Available:
					return COLOR_AVAILABLE;

				default:
					return COLOR_OFFLINE;
			}
		}

		// =====================================================================
		// BATTERY DISPLAY
		// =====================================================================

		private UiColor GetSocColor(double soc)
		{
			if (!ToBool(QLT.Val))
			{
				return COLOR_OFFLINE;
			}

			if (ToBool(IFLT.Val))
			{
				return COLOR_ALARM;
			}

			if (soc <= 20.0)
			{
				return COLOR_ALARM;
			}

			if (_currentStatus == VisualStatus.Discharging)
			{
				return COLOR_DISCHARGING;
			}

			if (_currentStatus == VisualStatus.Standby)
			{
				return COLOR_STANDBY;
			}

			return COLOR_CHARGING;
		}

		private string GetPowerText(object value)
		{
			double power =
				ToDouble(value);

			const double deadband = 0.001;

			if (power > deadband)
			{
				return "+"
					+ power.ToString("0.00")
					+ " MW Discharge";
			}

			if (power < -deadband)
			{
				return power.ToString("0.00")
					+ " MW Charge";
			}

			return "0.00 MW Standby";
		}

		private UiColor GetPowerColor(object value)
		{
			double power =
				ToDouble(value);

			const double deadband = 0.001;

			if (!ToBool(QLT.Val))
			{
				return COLOR_OFFLINE;
			}

			if (ToBool(IFLT.Val))
			{
				return COLOR_ALARM;
			}

			if (power > deadband)
			{
				return COLOR_DISCHARGING;
			}

			if (power < -deadband)
			{
				return COLOR_CHARGING;
			}

			return COLOR_STANDBY;
		}

		private string GetModeText(object value)
		{
			int mode =
				ToInt(value);

			switch (mode)
			{
				case 0:
					return "Off";

				case 1:
					return "Auto";

				case 2:
					return "Manual";

				default:
					return "Unknown";
			}
		}

		// =====================================================================
		// HELPERS
		// =====================================================================

		private string FormatReal(
			object value,
			string format)
		{
			try
			{
				return Convert
					.ToDouble(value)
					.ToString(format);
			}
			catch
			{
				return "0";
			}
		}

		private bool ToBool(object value)
		{
			try
			{
				return Convert.ToBoolean(value);
			}
			catch
			{
				return false;
			}
		}

		private int ToInt(object value)
		{
			try
			{
				return Convert.ToInt32(value);
			}
			catch
			{
				return 0;
			}
		}

		private double ToDouble(object value)
		{
			try
			{
				return Convert.ToDouble(value);
			}
			catch
			{
				return 0.0;
			}
		}

		private float ClampReal(
			float value,
			float minimum,
			float maximum)
		{
			if (value < minimum)
			{
				return minimum;
			}

			if (value > maximum)
			{
				return maximum;
			}

			return value;
		}

		// =====================================================================
		// UI EVENTS
		// =====================================================================

		void RectBtnMouseEnter(
			object sender,
			EventArgs e)
		{
			_isRectBtnHovered = true;
			UpdateRectButtonVisual();
		}

		void RectBtnMouseLeave(
			object sender,
			EventArgs e)
		{
			_isRectBtnHovered = false;
			UpdateRectButtonVisual();
		}

		void REQ_Fired_EventHandler(
			object sender,
			REQEventArgs e)
		{
			lblSymbol.Text = e.AssetName;
		}
	}
}