/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/14/2026
 * Time: 9:11 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using NxtControl.GuiFramework;

namespace HMI.Main.Faceplates.acBESS_v1_1
{
	/// <summary>
	/// Summary description for fMain.
	/// </summary>
	partial class fMain
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fMain));
			this.txtVBAT = new NxtControl.GuiFramework.Label();
			this.txtIBAT = new NxtControl.GuiFramework.Label();
			this.txtTBAT = new NxtControl.GuiFramework.Label();
			this.freeText1 = new NxtControl.GuiFramework.FreeText();
			this.freeText2 = new NxtControl.GuiFramework.FreeText();
			this.freeText3 = new NxtControl.GuiFramework.FreeText();
			this.txtStatus = new NxtControl.GuiFramework.Label();
			this.freeText7 = new NxtControl.GuiFramework.FreeText();
			this.txtSOCSP = new NxtControl.GuiFramework.Label();
			this.freeText8 = new NxtControl.GuiFramework.FreeText();
			this.rectangle1 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle2 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle3 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle4 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle5 = new NxtControl.GuiFramework.Rectangle();
			this.freeText4 = new NxtControl.GuiFramework.FreeText();
			this.line3 = new NxtControl.GuiFramework.Line();
			this.sButtonNavDemo2 = new SE.Agile.Symbols.Broadcaster_v1_0.sButtonNavDemo();
			this.IALM = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IAVL = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IBAT = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.ICHG = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IDIS = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IFLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IRUN = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.ISTBY = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.QLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.TBAT = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.VBAT = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.SOCSP = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValChanged();
			// 
			// txtVBAT
			// 
			this.txtVBAT.AngleIgnore = true;
			this.txtVBAT.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtVBAT.Bounds = new NxtControl.Drawing.RectF(((float)(120D)), ((float)(47D)), ((float)(92D)), ((float)(14D)));
			this.txtVBAT.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtVBAT.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtVBAT.FontScale = true;
			this.txtVBAT.Name = "txtVBAT";
			this.txtVBAT.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtVBAT.Text = "400 V";
			this.txtVBAT.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtVBAT.TextAutoSizeHorizontalOffset = 10;
			this.txtVBAT.TextColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.txtVBAT.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// txtIBAT
			// 
			this.txtIBAT.AngleIgnore = true;
			this.txtIBAT.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtIBAT.Bounds = new NxtControl.Drawing.RectF(((float)(120D)), ((float)(77D)), ((float)(92D)), ((float)(14D)));
			this.txtIBAT.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtIBAT.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtIBAT.FontScale = true;
			this.txtIBAT.Name = "txtIBAT";
			this.txtIBAT.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtIBAT.Text = "150 A";
			this.txtIBAT.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtIBAT.TextAutoSizeHorizontalOffset = 10;
			this.txtIBAT.TextColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.txtIBAT.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// txtTBAT
			// 
			this.txtTBAT.AngleIgnore = true;
			this.txtTBAT.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtTBAT.Bounds = new NxtControl.Drawing.RectF(((float)(120D)), ((float)(107D)), ((float)(92D)), ((float)(14D)));
			this.txtTBAT.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtTBAT.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtTBAT.FontScale = true;
			this.txtTBAT.Name = "txtTBAT";
			this.txtTBAT.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtTBAT.Text = "32 °C";
			this.txtTBAT.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtTBAT.TextAutoSizeHorizontalOffset = 10;
			this.txtTBAT.TextColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.txtTBAT.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText1
			// 
			this.freeText1.Color = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.freeText1.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText1.Location = new NxtControl.Drawing.PointF(40D, 45D);
			this.freeText1.Name = "freeText1";
			this.freeText1.Text = "Voltage";
			// 
			// freeText2
			// 
			this.freeText2.Color = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.freeText2.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText2.Location = new NxtControl.Drawing.PointF(40D, 75D);
			this.freeText2.Name = "freeText2";
			this.freeText2.Text = "Current";
			// 
			// freeText3
			// 
			this.freeText3.Color = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.freeText3.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText3.Location = new NxtControl.Drawing.PointF(40D, 105D);
			this.freeText3.Name = "freeText3";
			this.freeText3.Text = "Temperature";
			// 
			// txtStatus
			// 
			this.txtStatus.AngleIgnore = true;
			this.txtStatus.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtStatus.Bounds = new NxtControl.Drawing.RectF(((float)(120D)), ((float)(17D)), ((float)(92D)), ((float)(14D)));
			this.txtStatus.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtStatus.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtStatus.FontScale = true;
			this.txtStatus.Name = "txtStatus";
			this.txtStatus.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fAlarm", NxtControl.GuiFramework.MouseButtonType.Click));
			this.txtStatus.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtStatus.Text = "Healthy";
			this.txtStatus.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtStatus.TextAutoSizeHorizontalOffset = 10;
			this.txtStatus.TextColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.txtStatus.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText7
			// 
			this.freeText7.Color = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.freeText7.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText7.Location = new NxtControl.Drawing.PointF(40D, 15D);
			this.freeText7.Name = "freeText7";
			this.freeText7.Text = "Status";
			// 
			// txtSOCSP
			// 
			this.txtSOCSP.AngleIgnore = true;
			this.txtSOCSP.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtSOCSP.Bounds = new NxtControl.Drawing.RectF(((float)(120D)), ((float)(139D)), ((float)(92D)), ((float)(14D)));
			this.txtSOCSP.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtSOCSP.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtSOCSP.FontScale = true;
			this.txtSOCSP.Name = "txtSOCSP";
			this.txtSOCSP.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtSOCSP.Text = "80 %";
			this.txtSOCSP.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtSOCSP.TextAutoSizeHorizontalOffset = 10;
			this.txtSOCSP.TextColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.txtSOCSP.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText8
			// 
			this.freeText8.Color = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.freeText8.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText8.Location = new NxtControl.Drawing.PointF(40D, 137D);
			this.freeText8.Name = "freeText8";
			this.freeText8.Text = "Set Point";
			// 
			// rectangle1
			// 
			this.rectangle1.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(16D)), ((float)(16D)), ((float)(16D)));
			this.rectangle1.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle1.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle1.ImageBytes = resources.GetString("rectangle1.ImageBytes");
			this.rectangle1.Name = "rectangle1";
			this.rectangle1.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle2
			// 
			this.rectangle2.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(46D)), ((float)(16D)), ((float)(16D)));
			this.rectangle2.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle2.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle2.ImageBytes = resources.GetString("rectangle2.ImageBytes");
			this.rectangle2.Name = "rectangle2";
			this.rectangle2.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle3
			// 
			this.rectangle3.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(76D)), ((float)(16D)), ((float)(16D)));
			this.rectangle3.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle3.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle3.ImageBytes = resources.GetString("rectangle3.ImageBytes");
			this.rectangle3.Name = "rectangle3";
			this.rectangle3.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle4
			// 
			this.rectangle4.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(106D)), ((float)(16D)), ((float)(16D)));
			this.rectangle4.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle4.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle4.ImageBytes = resources.GetString("rectangle4.ImageBytes");
			this.rectangle4.Name = "rectangle4";
			this.rectangle4.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle5
			// 
			this.rectangle5.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(138D)), ((float)(16D)), ((float)(16D)));
			this.rectangle5.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle5.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle5.ImageBytes = resources.GetString("rectangle5.ImageBytes");
			this.rectangle5.Name = "rectangle5";
			this.rectangle5.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// freeText4
			// 
			this.freeText4.Color = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.freeText4.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Italic);
			this.freeText4.Location = new NxtControl.Drawing.PointF(14D, 175D);
			this.freeText4.Name = "freeText4";
			this.freeText4.Text = "Connector Info.";
			// 
			// line3
			// 
			this.line3.EndPoint = new NxtControl.Drawing.PointF(227D, 165D);
			this.line3.Name = "line3";
			this.line3.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(19)), ((byte)(76)), ((byte)(30))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line3.StartPoint = new NxtControl.Drawing.PointF(1D, 165D);
			// 
			// sButtonNavDemo2
			// 
			this.sButtonNavDemo2.BeginInit();
			this.sButtonNavDemo2.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 198D, 176D);
			this.sButtonNavDemo2.Name = "sButtonNavDemo2";
			this.sButtonNavDemo2.SecurityToken = ((uint)(4294967295u));
			this.sButtonNavDemo2.TagName = "BESS.Broadcaster_v1_0";
			this.sButtonNavDemo2.EndInit();
			// 
			// IALM
			// 
			this.IALM.BeginInit();
			this.IALM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 142D, 55D);
			this.IALM.Name = "IALM";
			this.IALM.SecurityToken = ((uint)(4294967295u));
			this.IALM.TagName = "IALM";
			this.IALM.Val = false;
			this.IALM.EndInit();
			// 
			// IAVL
			// 
			this.IAVL.BeginInit();
			this.IAVL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 105D, 70D);
			this.IAVL.Name = "IAVL";
			this.IAVL.SecurityToken = ((uint)(4294967295u));
			this.IAVL.TagName = "IAVL";
			this.IAVL.Val = false;
			this.IAVL.EndInit();
			// 
			// IBAT
			// 
			this.IBAT.BeginInit();
			this.IBAT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 115D, 84D);
			this.IBAT.Name = "IBAT";
			this.IBAT.SecurityToken = ((uint)(4294967295u));
			this.IBAT.TagName = "IBAT";
			this.IBAT.Val = 0F;
			this.IBAT.ValDecimalPlaces = ((byte)(0));
			this.IBAT.ValMaximum = 0F;
			this.IBAT.ValMinimum = 0F;
			this.IBAT.ValUnits = null;
			this.IBAT.EndInit();
			// 
			// ICHG
			// 
			this.ICHG.BeginInit();
			this.ICHG.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 116D, 94D);
			this.ICHG.Name = "ICHG";
			this.ICHG.SecurityToken = ((uint)(4294967295u));
			this.ICHG.TagName = "ICHG";
			this.ICHG.Val = false;
			this.ICHG.EndInit();
			// 
			// IDIS
			// 
			this.IDIS.BeginInit();
			this.IDIS.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 139D, 101D);
			this.IDIS.Name = "IDIS";
			this.IDIS.SecurityToken = ((uint)(4294967295u));
			this.IDIS.TagName = "IDIS";
			this.IDIS.Val = false;
			this.IDIS.EndInit();
			// 
			// IFLT
			// 
			this.IFLT.BeginInit();
			this.IFLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 118D, 101D);
			this.IFLT.Name = "IFLT";
			this.IFLT.SecurityToken = ((uint)(4294967295u));
			this.IFLT.TagName = "IFLT";
			this.IFLT.Val = false;
			this.IFLT.EndInit();
			// 
			// IRUN
			// 
			this.IRUN.BeginInit();
			this.IRUN.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 122D, 80D);
			this.IRUN.Name = "IRUN";
			this.IRUN.SecurityToken = ((uint)(4294967295u));
			this.IRUN.TagName = "IRUN";
			this.IRUN.Val = false;
			this.IRUN.EndInit();
			// 
			// ISTBY
			// 
			this.ISTBY.BeginInit();
			this.ISTBY.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 120D, 97D);
			this.ISTBY.Name = "ISTBY";
			this.ISTBY.SecurityToken = ((uint)(4294967295u));
			this.ISTBY.TagName = "ISTBY";
			this.ISTBY.Val = false;
			this.ISTBY.EndInit();
			// 
			// QLT
			// 
			this.QLT.BeginInit();
			this.QLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 121D, 116D);
			this.QLT.Name = "QLT";
			this.QLT.SecurityToken = ((uint)(4294967295u));
			this.QLT.TagName = "QLT";
			this.QLT.Val = false;
			this.QLT.EndInit();
			// 
			// TBAT
			// 
			this.TBAT.BeginInit();
			this.TBAT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 120D, 127D);
			this.TBAT.Name = "TBAT";
			this.TBAT.SecurityToken = ((uint)(4294967295u));
			this.TBAT.TagName = "TBAT";
			this.TBAT.Val = 0F;
			this.TBAT.ValDecimalPlaces = ((byte)(0));
			this.TBAT.ValMaximum = 0F;
			this.TBAT.ValMinimum = 0F;
			this.TBAT.ValUnits = null;
			this.TBAT.EndInit();
			// 
			// VBAT
			// 
			this.VBAT.BeginInit();
			this.VBAT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 147D, 108D);
			this.VBAT.Name = "VBAT";
			this.VBAT.SecurityToken = ((uint)(4294967295u));
			this.VBAT.TagName = "VBAT";
			this.VBAT.Val = 0F;
			this.VBAT.ValDecimalPlaces = ((byte)(0));
			this.VBAT.ValMaximum = 0F;
			this.VBAT.ValMinimum = 0F;
			this.VBAT.ValUnits = null;
			this.VBAT.EndInit();
			// 
			// SOCSP
			// 
			this.SOCSP.BeginInit();
			this.SOCSP.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 101D, 131D);
			this.SOCSP.Name = "SOCSP";
			this.SOCSP.SecurityToken = ((uint)(4294967295u));
			this.SOCSP.TagName = "SOCSP";
			this.SOCSP.Val = 0F;
			this.SOCSP.ValDecimalPlaces = ((byte)(0));
			this.SOCSP.ValMaximum = 0F;
			this.SOCSP.ValMinimum = 0F;
			this.SOCSP.ValUnits = null;
			this.SOCSP.EndInit();
			// 
			// fMain
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(228D)), ((float)(204D)));
			this.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(3)), ((byte)(22)), ((byte)(20))));
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.txtVBAT,
			this.txtIBAT,
			this.txtTBAT,
			this.freeText1,
			this.freeText2,
			this.freeText3,
			this.txtStatus,
			this.freeText7,
			this.txtSOCSP,
			this.freeText8,
			this.rectangle1,
			this.rectangle2,
			this.rectangle3,
			this.rectangle4,
			this.rectangle5,
			this.freeText4,
			this.line3,
			this.sButtonNavDemo2,
			this.IALM,
			this.IAVL,
			this.IBAT,
			this.ICHG,
			this.IDIS,
			this.IFLT,
			this.IRUN,
			this.ISTBY,
			this.QLT,
			this.TBAT,
			this.VBAT,
			this.SOCSP});
			this.Size = new System.Drawing.Size(228, 204);

		}
		private NxtControl.GuiFramework.Label txtVBAT;
		private NxtControl.GuiFramework.Label txtIBAT;
		private NxtControl.GuiFramework.Label txtTBAT;
		private NxtControl.GuiFramework.FreeText freeText1;
		private NxtControl.GuiFramework.FreeText freeText2;
		private NxtControl.GuiFramework.FreeText freeText3;
		private NxtControl.GuiFramework.Label txtStatus;
		private NxtControl.GuiFramework.FreeText freeText7;
		private NxtControl.GuiFramework.Label txtSOCSP;
		private NxtControl.GuiFramework.FreeText freeText8;
		private NxtControl.GuiFramework.Rectangle rectangle1;
		private NxtControl.GuiFramework.Rectangle rectangle2;
		private NxtControl.GuiFramework.Rectangle rectangle3;
		private NxtControl.GuiFramework.Rectangle rectangle4;
		private NxtControl.GuiFramework.Rectangle rectangle5;
		private NxtControl.GuiFramework.FreeText freeText4;
		private NxtControl.GuiFramework.Line line3;
		private SE.Agile.Symbols.Broadcaster_v1_0.sButtonNavDemo sButtonNavDemo2;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IALM;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IAVL;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged IBAT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged ICHG;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IDIS;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IFLT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IRUN;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged ISTBY;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged QLT;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged TBAT;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged VBAT;
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValChanged SOCSP;
		#endregion
	}
}
