﻿/*
 * Common Solar Plant alarm profiles.
 */

using System;

using AlarmDefinition =
	HMI.Main.SupportClasses.SolarEventLog.AlarmDefinition;

using EventPriority =
	HMI.Main.SupportClasses.SolarEventLog.EventPriority;

namespace HMI.Main.SupportClasses
{
	public partial class SolarAlarmProfiles
	{
		/* ============================================================= */
		/* PV Array                                                       */
		/* ============================================================= */

		public static readonly AlarmDefinition[] PVArray =
		{
			Alarm(
				0,
				"Data quality lost",
				"Data quality restored"),

			Warning(
				1,
				"Irradiance measurement invalid",
				"Irradiance measurement restored"),

			Warning(
				2,
				"Ambient temperature measurement invalid",
				"Ambient temperature measurement restored"),

			Alarm(
				3,
				"PV module overtemperature",
				"PV module temperature returned to normal"),

			Alarm(
				4,
				"PV DC voltage out of range",
				"PV DC voltage returned to normal"),

			Alarm(
				5,
				"PV DC current invalid",
				"PV DC current restored"),

			Warning(
				6,
				"PV string loss detected",
				"PV strings restored"),

			Warning(
				7,
				"PV array power mismatch",
				"PV array power mismatch cleared"),

			Warning(
				8,
				"Energy generation data invalid",
				"Energy generation data restored"),

			Alarm(
				9,
				"External PV array fault",
				"External PV array fault cleared")
		};

		/* ============================================================= */
		/* DC Combiner                                                    */
		/* ============================================================= */

		public static readonly AlarmDefinition[] DCCombiner =
		{
			Alarm(
				0,
				"Data quality lost",
				"Data quality restored"),

			Alarm(
				1,
				"DC isolator open",
				"DC isolator closed"),

			Alarm(
				2,
				"External DC fault",
				"External DC fault cleared"),

			Alarm(
				3,
				"DC fuse fault",
				"DC fuse fault cleared"),

			Alarm(
				4,
				"DC voltage invalid",
				"DC voltage restored"),

			Alarm(
				5,
				"DC current invalid",
				"DC current restored"),

			Warning(
				6,
				"Surge protection device fault",
				"Surge protection device restored"),

			Warning(
				7,
				"PV string fault detected",
				"PV string fault cleared"),

			Warning(
				8,
				"DC and PV data mismatch",
				"DC and PV data mismatch cleared"),

			Warning(
				9,
				"External DC combiner alarm",
				"External DC combiner alarm cleared")
		};

		/* ============================================================= */
		/* Inverter                                                       */
		/* ============================================================= */

		public static readonly AlarmDefinition[] Inverter =
		{
			Alarm(
				0,
				"Data quality lost",
				"Data quality restored"),

			Alarm(
				1,
				"Inverter communication lost",
				"Inverter communication restored"),

			Alarm(
				2,
				"Upstream DC source fault",
				"Upstream DC source restored"),

			Alarm(
				3,
				"DC input undervoltage",
				"DC input voltage returned to normal"),

			Alarm(
				4,
				"DC input overvoltage",
				"DC input voltage returned to normal"),

			Alarm(
				5,
				"Inverter trip detected",
				"Inverter trip cleared"),

			Warning(
				6,
				"Active power tracking error",
				"Active power tracking restored"),

			Alarm(
				7,
				"AC output voltage out of range",
				"AC output voltage returned to normal"),

			Alarm(
				8,
				"AC output frequency out of range",
				"AC output frequency returned to normal"),

			Warning(
				9,
				"Power factor tracking error",
				"Power factor tracking restored")
		};

		/* ============================================================= */
		/* Own Load                                                       */
		/* ============================================================= */

		public static readonly AlarmDefinition[] OwnLoad =
		{
			Alarm(
				0,
				"Data quality lost",
				"Data quality restored"),

			Alarm(
				1,
				"Active-load data invalid",
				"Active-load data restored"),

			Warning(
				2,
				"Reactive-load data invalid",
				"Reactive-load data restored"),

			Warning(
				3,
				"High-load warning",
				"Load returned below warning limit"),

			Alarm(
				4,
				"Load supply lost",
				"Load supply restored")
		};

		/* ============================================================= */
		/* BESS                                                           */
		/* ============================================================= */

		public static readonly AlarmDefinition[] BESS =
		{
			Alarm(
				0,
				"Data quality lost",
				"Data quality restored"),

			Alarm(
				1,
				"SOC measurement invalid",
				"SOC measurement restored"),

			Alarm(
				2,
				"Battery overtemperature",
				"Battery temperature returned to normal"),

			Alarm(
				3,
				"Battery voltage out of operating range",
				"Battery voltage returned to normal"),

			Warning(
				4,
				"SOC high limit reached",
				"SOC returned below high limit"),

			Warning(
				5,
				"SOC low limit reached",
				"SOC returned above low limit"),

			Alarm(
				6,
				"BESS commands conflict",
				"BESS command conflict cleared"),

			Alarm(
				7,
				"BESS or PCS trip detected",
				"BESS or PCS trip cleared"),

			Warning(
				8,
				"BESS capability limited",
				"BESS capability restored"),

			Alarm(
				9,
				"Battery current too high",
				"Battery current returned to normal")
		};

		/* ============================================================= */
		/* Transformer                                                    */
		/* ============================================================= */

		public static readonly AlarmDefinition[] Transformer =
		{
			Alarm(
				0,
				"Communication or data quality lost",
				"Transformer communication restored"),

			Alarm(
				1,
				"Transformer breaker open or tripped",
				"Transformer breaker restored"),

			Warning(
				2,
				"Transformer load above warning limit",
				"Transformer load returned below warning limit"),

			Alarm(
				3,
				"Transformer severe overload",
				"Transformer severe overload cleared"),

			Warning(
				4,
				"Transformer oil temperature high",
				"Transformer oil temperature returned to normal"),

			Alarm(
				5,
				"Transformer winding overtemperature",
				"Transformer winding temperature returned to normal"),

			Alarm(
				6,
				"Transformer LV voltage out of range",
				"Transformer LV voltage returned to normal"),

			Warning(
				7,
				"Transformer power loss high",
				"Transformer power loss returned to normal")
		};

		/* ============================================================= */
		/* Grid                                                           */
		/* ============================================================= */

		public static readonly AlarmDefinition[] Grid =
		{
			Alarm(
				0,
				"Data quality lost",
				"Data quality restored"),

			Alarm(
				1,
				"Grid or PCC disconnected",
				"Grid or PCC reconnected"),

			Alarm(
				2,
				"Transformer fault detected by grid",
				"Transformer fault indication cleared"),

			Alarm(
				3,
				"Grid undervoltage",
				"Grid voltage returned to normal"),

			Alarm(
				4,
				"Grid overvoltage",
				"Grid voltage returned to normal"),

			Alarm(
				5,
				"Grid underfrequency",
				"Grid frequency returned to normal"),

			Alarm(
				6,
				"Grid overfrequency",
				"Grid frequency returned to normal"),

			Warning(
				7,
				"Grid export limit exceeded",
				"Grid export returned below limit"),

			Warning(
				8,
				"Grid import limit exceeded",
				"Grid import returned below limit"),

			Alarm(
				9,
				"PCC power data invalid",
				"PCC power data restored")
		};

		/* ============================================================= */
		/* PPC                                                            */
		/* ============================================================= */

		public static readonly AlarmDefinition[] PPC =
		{
			Alarm(
				0,
				"PPC data quality lost",
				"PPC data quality restored"),

			Alarm(
				1,
				"Inverter unavailable",
				"Inverter availability restored"),

			Warning(
				2,
				"BESS unavailable",
				"BESS availability restored"),

			Warning(
				3,
				"Own-load data fault",
				"Own-load data restored"),

			Alarm(
				4,
				"Transformer unavailable",
				"Transformer availability restored"),

			Alarm(
				5,
				"Grid unavailable",
				"Grid availability restored"),

			Warning(
				6,
				"Export limit exceeded",
				"Export returned below limit"),

			Warning(
				7,
				"Import limit exceeded",
				"Import returned below limit"),

			Warning(
				8,
				"Plant power mismatch",
				"Plant power mismatch cleared"),

			Warning(
				9,
				"Command capability limited",
				"Command capability restored")
		};

		public SolarAlarmProfiles()
		{
		}

		/* ============================================================= */
		/* Profile lookup                                                 */
		/* ============================================================= */

		public static AlarmDefinition[] GetProfile(
			string equipmentType)
		{
			string type =
				equipmentType == null
					? string.Empty
					: equipmentType
						.Trim()
						.ToUpperInvariant();

			switch (type)
			{
				case "PV":
				case "PVARRAY":
				case "PV ARRAY":
					return PVArray;

				case "DCC":
				case "DCCOMBINER":
				case "DC COMBINER":
					return DCCombiner;

				case "INV":
				case "INVERTER":
					return Inverter;

				case "LOAD":
				case "OWNLOAD":
				case "OWN LOAD":
					return OwnLoad;

				case "BATTERY":
				case "BESS":
					return BESS;

				case "TRF":
				case "TRANSFORMER":
					return Transformer;

				case "GRID":
				case "PCC":
					return Grid;

				case "PPC":
				case "PLANT CONTROLLER":
					return PPC;

				default:
					return new AlarmDefinition[0];
			}
		}

		/* ============================================================= */
		/* Definition helpers                                             */
		/* ============================================================= */

		private static AlarmDefinition Alarm(
			int bit,
			string activeText,
			string clearText)
		{
			return new AlarmDefinition(
				bit,
				activeText,
				clearText,
				EventPriority.Alarm);
		}

		private static AlarmDefinition Warning(
			int bit,
			string activeText,
			string clearText)
		{
			return new AlarmDefinition(
				bit,
				activeText,
				clearText,
				EventPriority.Warning);
		}
	}
}