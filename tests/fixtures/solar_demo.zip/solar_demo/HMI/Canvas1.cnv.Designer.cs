/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 6/30/2026
 * Time: 11:49 AM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;

using NxtControl.GuiFramework;

namespace HMI.Main.Canvases
{
	/// <summary>
	/// Summary description for Canvas1.
	/// </summary>
	partial class Canvas1
	{
		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Canvas1));
			this.pipe1 = new NxtControl.GuiFramework.Pipe();
			this.pipe2 = new NxtControl.GuiFramework.Pipe();
			this.rectangle2 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle3 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle4 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle5 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle6 = new NxtControl.GuiFramework.Rectangle();
			this.pipe3 = new NxtControl.GuiFramework.Pipe();
			this.pipe4 = new NxtControl.GuiFramework.Pipe();
			this.DCC001 = new HMI.Main.Symbols.acDCCombiner_v1_0.sDefault();
			this.PV001 = new HMI.Main.Symbols.acPVArray_v1_0.sDefault();
			// 
			// pipe1
			// 
			this.pipe1.Bounds = new NxtControl.Drawing.RectF(((float)(296D)), ((float)(324D)), ((float)(154D)), ((float)(0D)));
			this.pipe1.InnerColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.pipe1.Name = "pipe1";
			this.pipe1.OuterColor = new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0)));
			this.pipe1.Points.AddRange(new NxtControl.Drawing.PointF[] {
			new NxtControl.Drawing.PointF(296D, 324D),
			new NxtControl.Drawing.PointF(450D, 324D)});
			this.pipe1.Width = 8;
			// 
			// pipe2
			// 
			this.pipe2.Bounds = new NxtControl.Drawing.RectF(((float)(586D)), ((float)(300D)), ((float)(202D)), ((float)(0D)));
			this.pipe2.InnerColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.pipe2.Name = "pipe2";
			this.pipe2.OuterColor = new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0)));
			this.pipe2.Points.AddRange(new NxtControl.Drawing.PointF[] {
			new NxtControl.Drawing.PointF(586D, 300D),
			new NxtControl.Drawing.PointF(788D, 300D)});
			this.pipe2.Width = 8;
			// 
			// rectangle2
			// 
			this.rectangle2.Bounds = new NxtControl.Drawing.RectF(((float)(716D)), ((float)(216D)), ((float)(140D)), ((float)(140D)));
			this.rectangle2.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle2.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle2.ImageBytes = resources.GetString("rectangle2.ImageBytes");
			this.rectangle2.Name = "rectangle2";
			this.rectangle2.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle3
			// 
			this.rectangle3.Bounds = new NxtControl.Drawing.RectF(((float)(714D)), ((float)(564D)), ((float)(160D)), ((float)(160D)));
			this.rectangle3.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle3.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle3.ImageBytes = resources.GetString("rectangle3.ImageBytes");
			this.rectangle3.Name = "rectangle3";
			this.rectangle3.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle4
			// 
			this.rectangle4.Bounds = new NxtControl.Drawing.RectF(((float)(938D)), ((float)(564D)), ((float)(160D)), ((float)(160D)));
			this.rectangle4.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle4.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle4.ImageBytes = resources.GetString("rectangle4.ImageBytes");
			this.rectangle4.Name = "rectangle4";
			this.rectangle4.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle5
			// 
			this.rectangle5.Bounds = new NxtControl.Drawing.RectF(((float)(910D)), ((float)(208D)), ((float)(160D)), ((float)(160D)));
			this.rectangle5.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle5.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle5.ImageBytes = resources.GetString("rectangle5.ImageBytes");
			this.rectangle5.Name = "rectangle5";
			this.rectangle5.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle6
			// 
			this.rectangle6.Bounds = new NxtControl.Drawing.RectF(((float)(1122D)), ((float)(200D)), ((float)(200D)), ((float)(200D)));
			this.rectangle6.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle6.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle6.ImageBytes = resources.GetString("rectangle6.ImageBytes");
			this.rectangle6.Name = "rectangle6";
			this.rectangle6.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// pipe3
			// 
			this.pipe3.Bounds = new NxtControl.Drawing.RectF(((float)(832D)), ((float)(302D)), ((float)(202D)), ((float)(0D)));
			this.pipe3.InnerColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.pipe3.Name = "pipe3";
			this.pipe3.OuterColor = new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0)));
			this.pipe3.Points.AddRange(new NxtControl.Drawing.PointF[] {
			new NxtControl.Drawing.PointF(832D, 302D),
			new NxtControl.Drawing.PointF(1034D, 302D)});
			this.pipe3.Width = 8;
			// 
			// pipe4
			// 
			this.pipe4.Bounds = new NxtControl.Drawing.RectF(((float)(306D)), ((float)(510D)), ((float)(188D)), ((float)(144D)));
			this.pipe4.InnerColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.pipe4.Name = "pipe4";
			this.pipe4.OuterColor = new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0)));
			this.pipe4.Points.AddRange(new NxtControl.Drawing.PointF[] {
			new NxtControl.Drawing.PointF(306D, 654D),
			new NxtControl.Drawing.PointF(494D, 654D),
			new NxtControl.Drawing.PointF(494D, 510D)});
			this.pipe4.Width = 8;
			// 
			// DCC001
			// 
			this.DCC001.BeginInit();
			this.DCC001.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 426D, 204D);
			this.DCC001.Name = "DCC001";
			this.DCC001.SecurityToken = ((uint)(4294967295u));
			this.DCC001.TagName = "852155B2A9F8687F";
			this.DCC001.EndInit();
			// 
			// PV001
			// 
			this.PV001.BeginInit();
			this.PV001.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 102D, 204D);
			this.PV001.Name = "PV001";
			this.PV001.SecurityToken = ((uint)(4294967295u));
			this.PV001.TagName = "B567E00A3BDDC9DA";
			this.PV001.EndInit();
			// 
			// Canvas1
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(1366D)), ((float)(768D)));
			this.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(3)), ((byte)(22)), ((byte)(20))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.DiagonalLeftTop, new NxtControl.Drawing.GradientFillColorBlend(new NxtControl.Drawing.Color[] {
					new NxtControl.Drawing.Color(((byte)(5)), ((byte)(21)), ((byte)(10))),
					new NxtControl.Drawing.Color(((byte)(0)), ((byte)(13)), ((byte)(12)))}, new float[] {
					0F,
					1F})));
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.pipe4,
			this.pipe3,
			this.pipe2,
			this.pipe1,
			this.PV001,
			this.rectangle2,
			this.rectangle3,
			this.rectangle4,
			this.rectangle6,
			this.rectangle5,
			this.DCC001});
			this.Size = new System.Drawing.Size(1366, 768);

		}
		private HMI.Main.Symbols.acPVArray_v1_0.sDefault PV001;
		private NxtControl.GuiFramework.Pipe pipe1;
		private NxtControl.GuiFramework.Pipe pipe2;
		private NxtControl.GuiFramework.Rectangle rectangle2;
		private NxtControl.GuiFramework.Rectangle rectangle3;
		private NxtControl.GuiFramework.Rectangle rectangle4;
		private NxtControl.GuiFramework.Rectangle rectangle5;
		private NxtControl.GuiFramework.Rectangle rectangle6;
		private NxtControl.GuiFramework.Pipe pipe3;
		private NxtControl.GuiFramework.Pipe pipe4;
		private HMI.Main.Symbols.acDCCombiner_v1_0.sDefault DCC001;
		#endregion
	}
}
