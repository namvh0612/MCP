﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/6/2026
 * Time: 9:53 PM
 */

using System;
using NxtControl.GuiFramework;
using HMI.Main.SupportClasses;

using EventPriority =
	HMI.Main.SupportClasses.SolarEventLog.EventPriority;
	
using PowerLinkType =
	HMI.Main.Graphics.sPowerLink.PowerLinkType;

namespace HMI.Main.Canvases
{
	/// <summary>
	/// Solar Plant main control canvas.
	/// Handles alarm words and operational event logging.
	/// </summary>
	public partial class ControlPage :
		NxtControl.GuiFramework.HMICanvas
	{
		private const double SETPOINT_TOLERANCE = 0.01;
		private const double BESS_POWER_TOLERANCE = 0.05;
		private const int MAX_VISIBLE_EVENTS = 12;
		private bool _isReady;
		private SolarEventLog _eventLog;

		public ControlPage()
		{
			try
			{
				InitializeComponent();
				InitializePowerLinks();
				InitializeEventLog();
			}
			catch (Exception exception)
			{
				LogError(
					"Initialize ControlPage",
					exception);
			}
		}

		/* ============================================================= */
		/* Initialization                                                 */
		/* ============================================================= */
		
		private void InitializePowerLinks()
		{
			ConfigurePowerLinks();
			AttachPowerLinkEvents();
			UpdatePowerLinks();
		}
		
		private void ConfigurePowerLinks()
		{
			sPL_PV_DCC.LinkType =
				PowerLinkType.DC;
		
			sPL_DCC_INV.LinkType =
				PowerLinkType.DC;
		
			sPL_INV_AC.LinkType =
				PowerLinkType.AC;
		
			sPL_AC.LinkType =
				PowerLinkType.AC;
		
			SPL_TRF_AC.LinkType =
				PowerLinkType.AC;
		
			sPL_TRF_GRID.LinkType =
				PowerLinkType.AC;
		
			sPL_BD_AC.LinkType =
				PowerLinkType.AC;
		
			sPL_BESS_AC.LinkType =
				PowerLinkType.AC;
		
			sTL_PV.LinkType =
				PowerLinkType.Telemetry;
		
			sTL_DCC.LinkType =
				PowerLinkType.Telemetry;
		
			sTL_INV.LinkType =
				PowerLinkType.Telemetry;
		
			sTL_TRF.LinkType =
				PowerLinkType.Telemetry;
		
			sTL_GRID.LinkType =
				PowerLinkType.Telemetry;
		
			sTL_BD.LinkType =
				PowerLinkType.Telemetry;
		
			sTL_BESS.LinkType =
				PowerLinkType.Telemetry;
		
			sTL_PPC.LinkType =
				PowerLinkType.Telemetry;
		
			sTL_Main.LinkType =
				PowerLinkType.Telemetry;
		}

		private void InitializeEventLog()
		{
			if (!ValidateEventLogControls())
			{
				throw new InvalidOperationException(
					"One or more Event Log controls or pins are missing.");
			}

			_eventLog =
				new SolarEventLog(dataGridView1);
			
			_eventLog.MaxRows = MAX_VISIBLE_EVENTS;

			/*
			 * Read all current values once to establish the baseline.
			 * SolarEventLog will not generate events for this first read.
			 */
			PrimeEventTracking();

			AttachEventHandlers();

			_isReady = true;

			_eventLog.AddEvent(
				"System",
				"Solar Plant event monitoring started",
				EventPriority.Info);
		}

		private bool ValidateEventLogControls()
		{
			return
				dataGridView1 != null &&
				PV_IRR != null &&

				DCC_ALMW != null &&
				INV_ALMW != null &&
				LOAD_ALMW != null &&
				BESS_ALMW != null &&
				TRF_ALMW != null &&
				GRID_ALMW != null &&
				PPC_ALMW != null &&

				INV_ASPCMD != null &&

				BESS_IDIS != null &&
				BESS_ICHG != null &&
				BESS_PBAT != null &&

				PPC_IMPLIM != null &&
				PPC_EXPLIM != null;
		}

		private void PrimeEventTracking()
		{
			UpdateAllAlarmWords();
			UpdateIrradianceState();
			UpdateBessState();
			UpdateBessPower();
			UpdatePpcLimits();
		}

		/* ============================================================= */
		/* Event subscription                                             */
		/* ============================================================= */

		private void AttachEventHandlers()
		{
			DetachEventHandlers();

			PV_IRR.OnValChanged +=
				OnIrradianceChanged;

			DCC_ALMW.OnValChanged +=
				OnAlarmWordChanged;

			INV_ALMW.OnValChanged +=
				OnAlarmWordChanged;

			LOAD_ALMW.OnValChanged +=
				OnAlarmWordChanged;

			BESS_ALMW.OnValChanged +=
				OnAlarmWordChanged;

			TRF_ALMW.OnValChanged +=
				OnAlarmWordChanged;

			GRID_ALMW.OnValChanged +=
				OnAlarmWordChanged;

			PPC_ALMW.OnValChanged +=
				OnAlarmWordChanged;

			BESS_IDIS.OnValChanged +=
				OnBessStateChanged;

			BESS_ICHG.OnValChanged +=
				OnBessStateChanged;

			BESS_PBAT.OnValChanged +=
				OnBessPowerChanged;

			PPC_IMPLIM.OnValChanged +=
				OnPpcLimitChanged;

			PPC_EXPLIM.OnValChanged +=
				OnPpcLimitChanged;
		}

		private void DetachEventHandlers()
		{
			PV_IRR.OnValChanged -=
				OnIrradianceChanged;

			DCC_ALMW.OnValChanged -=
				OnAlarmWordChanged;

			INV_ALMW.OnValChanged -=
				OnAlarmWordChanged;

			LOAD_ALMW.OnValChanged -=
				OnAlarmWordChanged;

			BESS_ALMW.OnValChanged -=
				OnAlarmWordChanged;

			TRF_ALMW.OnValChanged -=
				OnAlarmWordChanged;

			GRID_ALMW.OnValChanged -=
				OnAlarmWordChanged;

			PPC_ALMW.OnValChanged -=
				OnAlarmWordChanged;

			BESS_IDIS.OnValChanged -=
				OnBessStateChanged;

			BESS_ICHG.OnValChanged -=
				OnBessStateChanged;

			BESS_PBAT.OnValChanged -=
				OnBessPowerChanged;

			PPC_IMPLIM.OnValChanged -=
				OnPpcLimitChanged;

			PPC_EXPLIM.OnValChanged -=
				OnPpcLimitChanged;
		}
		
		private void AttachPowerLinkEvents()
		{
			PV001_QLT.OnValChanged -= OnPowerLinkValueChanged;
			PV001_PDC.OnValChanged -= OnPowerLinkValueChanged;
			PV001_IFLT.OnValChanged -= OnPowerLinkValueChanged;
		
			DCC001_QLT.OnValChanged -= OnPowerLinkValueChanged;
			DCC001_PDC.OnValChanged -= OnPowerLinkValueChanged;
			DCC001_IFLT.OnValChanged -= OnPowerLinkValueChanged;
		
			INV001_QLT.OnValChanged -= OnPowerLinkValueChanged;
			INV001_PAC.OnValChanged -= OnPowerLinkValueChanged;
			INV001_IFLT.OnValChanged -= OnPowerLinkValueChanged;
			INV001_IRUN.OnValChanged -= OnPowerLinkValueChanged;
		
			TRF001_QLT.OnValChanged -= OnPowerLinkValueChanged;
			TRF001_PLV.OnValChanged -= OnPowerLinkValueChanged;
			TRF001_PMV.OnValChanged -= OnPowerLinkValueChanged;
			TRF001_IFLT.OnValChanged -= OnPowerLinkValueChanged;
		
			BD001_QLT.OnValChanged -= OnPowerLinkValueChanged;
			BD001_PLOAD.OnValChanged -= OnPowerLinkValueChanged;
		
			BESS01_QLT.OnValChanged -= OnPowerLinkValueChanged;
			BESS01_PBAT.OnValChanged -= OnPowerLinkValueChanged;
			BESS01_IFLT.OnValChanged -= OnPowerLinkValueChanged;
		
			GRID01_QLT.OnValChanged -= OnPowerLinkValueChanged;
			GRID01_IFLT.OnValChanged -= OnPowerLinkValueChanged;
			PPC001_QLT.OnValChanged -= OnPowerLinkValueChanged;
			PPC001_IFLT.OnValChanged -= OnPowerLinkValueChanged;
		
			PV001_QLT.OnValChanged += OnPowerLinkValueChanged;
			PV001_PDC.OnValChanged += OnPowerLinkValueChanged;
			PV001_IFLT.OnValChanged += OnPowerLinkValueChanged;
		
			DCC001_QLT.OnValChanged += OnPowerLinkValueChanged;
			DCC001_PDC.OnValChanged += OnPowerLinkValueChanged;
			DCC001_IFLT.OnValChanged += OnPowerLinkValueChanged;
		
			INV001_QLT.OnValChanged += OnPowerLinkValueChanged;
			INV001_PAC.OnValChanged += OnPowerLinkValueChanged;
			INV001_IFLT.OnValChanged += OnPowerLinkValueChanged;
			INV001_IRUN.OnValChanged += OnPowerLinkValueChanged;
		
			TRF001_QLT.OnValChanged += OnPowerLinkValueChanged;
			TRF001_PLV.OnValChanged += OnPowerLinkValueChanged;
			TRF001_PMV.OnValChanged += OnPowerLinkValueChanged;
			TRF001_IFLT.OnValChanged += OnPowerLinkValueChanged;
		
			BD001_QLT.OnValChanged += OnPowerLinkValueChanged;
			BD001_PLOAD.OnValChanged += OnPowerLinkValueChanged;
		
			BESS01_QLT.OnValChanged += OnPowerLinkValueChanged;
			BESS01_PBAT.OnValChanged += OnPowerLinkValueChanged;
			BESS01_IFLT.OnValChanged += OnPowerLinkValueChanged;
		
			GRID01_QLT.OnValChanged += OnPowerLinkValueChanged;
			GRID01_IFLT.OnValChanged += OnPowerLinkValueChanged;
			PPC001_QLT.OnValChanged += OnPowerLinkValueChanged;
			PPC001_IFLT.OnValChanged += OnPowerLinkValueChanged;
		}
		
		private void OnPowerLinkValueChanged(
			object sender,
			EventArgs e)
		{
			try
			{
				UpdatePowerLinks();
			}
			catch (Exception exception)
			{
				LogError(
					"Update power links",
					exception);
			}
		}

		/* ============================================================= */
		/* Canvas event handlers                                          */
		/* ============================================================= */

		private void OnAlarmWordChanged(
			object sender,
			EventArgs e)
		{
			ExecuteSafe(
				"Update alarm words",
				delegate
				{
					UpdateAllAlarmWords();
				});
		}

		private void OnIrradianceChanged(
			object sender,
			EventArgs e)
		{
			ExecuteSafe(
				"Update irradiance",
				delegate
				{
					UpdateIrradianceState();
				});
		}


		private void OnBessStateChanged(
			object sender,
			EventArgs e)
		{
			ExecuteSafe(
				"Update BESS state",
				delegate
				{
					UpdateBessState();
				});
		}

		private void OnBessPowerChanged(
			object sender,
			EventArgs e)
		{
			ExecuteSafe(
				"Update BESS power",
				delegate
				{
					UpdateBessPower();
				});
		}

		private void OnPpcLimitChanged(
			object sender,
			EventArgs e)
		{
			ExecuteSafe(
				"Update PPC limits",
				delegate
				{
					UpdatePpcLimits();
				});
		}

		/* ============================================================= */
		/* Alarm-word logging                                             */
		/* ============================================================= */

		private void UpdateAllAlarmWords()
		{
			if (_eventLog == null)
				return;

			_eventLog.UpdateAlarmWord(
				"DCC001",
				DCC_ALMW.Val,
				SolarAlarmProfiles.DCCombiner);

			_eventLog.UpdateAlarmWord(
				"INV001",
				INV_ALMW.Val,
				SolarAlarmProfiles.Inverter);

			_eventLog.UpdateAlarmWord(
				"BD001",
				LOAD_ALMW.Val,
				SolarAlarmProfiles.OwnLoad);

			_eventLog.UpdateAlarmWord(
				"BESS01",
				BESS_ALMW.Val,
				SolarAlarmProfiles.BESS);

			_eventLog.UpdateAlarmWord(
				"TRF001",
				TRF_ALMW.Val,
				SolarAlarmProfiles.Transformer);

			_eventLog.UpdateAlarmWord(
				"GRID01",
				GRID_ALMW.Val,
				SolarAlarmProfiles.Grid);

			_eventLog.UpdateAlarmWord(
				"PPC001",
				PPC_ALMW.Val,
				SolarAlarmProfiles.PPC);
		}

		/* ============================================================= */
		/* Irradiance logging                                             */
		/* ============================================================= */

		private void UpdateIrradianceState()
		{
			if (_eventLog == null)
				return;

			double irradiance =
				HmiValueHelper.ToDouble(PV_IRR.Val);

			string state;
			EventPriority priority;

			if (irradiance < 0.0)
			{
				state = "Invalid";
				priority = EventPriority.Alarm;
			}
			else if (irradiance < 400.0)
			{
				state = "Low / Cloudy";
				priority = EventPriority.Warning;
			}
			else
			{
				state = "Normal";
				priority = EventPriority.Info;
			}

			_eventLog.UpdateState(
				"PV001",
				"Irradiance",
				state,
				priority);
		}

		/* ============================================================= */
		/* BESS logging                                                   */
		/* ============================================================= */

		private void UpdateBessState()
		{
			if (_eventLog == null)
				return;

			bool isCharging =
				HmiValueHelper.ToBool(
					BESS_ICHG.Val);

			bool isDischarging =
				HmiValueHelper.ToBool(
					BESS_IDIS.Val);

			string state;
			EventPriority priority;

			if (isCharging &&
				isDischarging)
			{
				state = "Command conflict";
				priority = EventPriority.Alarm;
			}
			else if (isCharging)
			{
				state = "Charging";
				priority = EventPriority.Info;
			}
			else if (isDischarging)
			{
				state = "Discharging";
				priority = EventPriority.Info;
			}
			else
			{
				state = "Standby";
				priority = EventPriority.Info;
			}

			_eventLog.UpdateState(
				"BESS01",
				"Operating state",
				state,
				priority);
		}

		private void UpdateBessPower()
		{
			if (_eventLog == null)
				return;

			_eventLog.UpdateValue(
				"BESS01",
				"Battery power",
				BESS_PBAT.Val,
				"0.00",
				" MW",
				BESS_POWER_TOLERANCE,
				EventPriority.Info);
		}

		/* ============================================================= */
		/* PPC limit logging                                              */
		/* ============================================================= */

		private void UpdatePpcLimits()
		{
			if (_eventLog == null)
				return;

			_eventLog.UpdateValue(
				"PPC001",
				"Export limit",
				PPC_EXPLIM.Val,
				"0.00",
				" MW",
				SETPOINT_TOLERANCE,
				EventPriority.Info);

			_eventLog.UpdateValue(
				"PPC001",
				"Import limit",
				PPC_IMPLIM.Val,
				"0.00",
				" MW",
				SETPOINT_TOLERANCE,
				EventPriority.Info);
		}

		/* ============================================================= */
		/* Public actions                                                 */
		/* ============================================================= */

		public void ClearEventLog()
		{
			if (_eventLog == null)
				return;

			_eventLog.ClearRows();

			_eventLog.AddEvent(
				"System",
				"Event log cleared",
				EventPriority.Info);
		}

		public void ResetEventTracking()
		{
			if (_eventLog == null)
				return;

			_eventLog.ResetTracking();
			PrimeEventTracking();

			_eventLog.AddEvent(
				"System",
				"Event tracking reset",
				EventPriority.Info);
		}

		/* ============================================================= */
		/* Safety and logging                                             */
		/* ============================================================= */

		private void ExecuteSafe(
			string operation,
			Action action)
		{
			if (!_isReady ||
				_eventLog == null ||
				action == null)
			{
				return;
			}

			try
			{
				action();
			}
			catch (Exception exception)
			{
				LogError(
					operation,
					exception);
			}
		}

		private static void LogError(
			string operation,
			Exception exception)
		{
			try
			{
				NxtControl.Services.LoggingService.ErrorFormatted(
					"ControlPage: {0}. Error: {1}. Stack: {2}",
					operation,
					exception != null
						? exception.Message
						: "Unknown error",
					exception != null
						? exception.StackTrace
						: string.Empty);
			}
			catch
			{
				// Prevent logging errors from crashing the HMI.
			}
		}
		
		private void UpdatePowerLinks()
		{
			bool pvQuality =
				HmiValueHelper.ToBool(PV001_QLT.Val && !PV001_IFLT.Val);
		
			bool dccQuality =
				HmiValueHelper.ToBool(DCC001_QLT.Val && !DCC001_IFLT.Val);
		
			bool inverterQuality =
				HmiValueHelper.ToBool(INV001_QLT.Val && INV001_IRUN.Val && !INV001_IFLT.Val);
		
			bool transformerQuality =
				HmiValueHelper.ToBool(TRF001_QLT.Val && !TRF001_IFLT.Val && GRID01_QLT.Val && !GRID01_IFLT.Val);
		
			bool gridQuality =
				HmiValueHelper.ToBool(GRID01_QLT.Val && !GRID01_IFLT.Val);
		
			bool ownLoadQuality =
				HmiValueHelper.ToBool(BD001_QLT.Val);
		
			bool bessQuality =
				HmiValueHelper.ToBool(BESS01_QLT.Val && !BESS01_IFLT.Val);
		
			bool ppcQuality =
				HmiValueHelper.ToBool(PPC001_QLT.Val && !PPC001_IFLT.Val);
			
			bool teleQuality = pvQuality || dccQuality || inverterQuality || transformerQuality || gridQuality || ownLoadQuality || bessQuality || ppcQuality;
		
			sPL_PV_DCC.SetInput(
				pvQuality && dccQuality,
				HmiValueHelper.ToDouble(PV001_PDC.Val));
		
			sPL_DCC_INV.SetInput(
				dccQuality && inverterQuality,
				HmiValueHelper.ToDouble(DCC001_PDC.Val));
		
			sPL_INV_AC.SetInput(
				inverterQuality && transformerQuality,
				HmiValueHelper.ToDouble(INV001_PAC.Val));
		
			sPL_AC.SetInput(
				transformerQuality,
				HmiValueHelper.ToDouble(TRF001_PLV.Val));
		
			SPL_TRF_AC.SetInput(
				transformerQuality,
				HmiValueHelper.ToDouble(TRF001_PLV.Val));
		
			sPL_TRF_GRID.SetInput(
				transformerQuality && gridQuality,
				HmiValueHelper.ToDouble(TRF001_PMV.Val));
		
			sPL_BD_AC.SetInput(
				ownLoadQuality && transformerQuality,
				Math.Abs(
					HmiValueHelper.ToDouble(
						BD001_PLOAD.Val)));
		
			sPL_BESS_AC.SetInput(
				bessQuality && transformerQuality,
				HmiValueHelper.ToDouble(
					BESS01_PBAT.Val));
			
			
		
			/* Telemetry links */
		
			sTL_PV.SetInput(pvQuality, 0.0);
			sTL_DCC.SetInput(dccQuality, 0.0);
			sTL_INV.SetInput(inverterQuality, 0.0);
			sTL_TRF.SetInput(transformerQuality, 0.0);
			sTL_GRID.SetInput(gridQuality, 0.0);
			sTL_BD.SetInput(ownLoadQuality, 0.0);
			sTL_BESS.SetInput(bessQuality, 0.0);
			sTL_PPC.SetInput(teleQuality, 0.0);
		
			sTL_Main.SetInput(
				teleQuality,
				0.0);
		}

		void SNavigation2Click(object sender, EventArgs e)
		{
			this.OpenCanvas("Architecture");
		}
	}
}