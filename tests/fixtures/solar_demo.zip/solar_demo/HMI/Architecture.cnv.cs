﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/27/2026
 * Time: 9:55 AM
 * 
 */

using System;
using NxtControl.GuiFramework;


namespace HMI.Main.Canvases
{
	/// <summary>
	/// Description of Architecture.
	/// </summary>
	public partial class Architecture : NxtControl.GuiFramework.HMICanvas
	{
		public Architecture()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}

		void SNavigation1Click(object sender, EventArgs e)
		{
			this.OpenCanvas("ControlPage");
		}

	}
}
