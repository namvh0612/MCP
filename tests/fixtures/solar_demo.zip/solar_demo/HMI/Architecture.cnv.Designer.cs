﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 5/27/2026
 * Time: 10:47 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;

using NxtControl.GuiFramework;

namespace HMI.Main.Canvases
{
	/// <summary>
	/// Summary description for ArchitectureW.
	/// </summary>
	partial class Architecture
	{
		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Architecture));
			this.txtSubtitle = new NxtControl.GuiFramework.FreeText();
			this.txtLic = new NxtControl.GuiFramework.FreeText();
			this.freeText3 = new NxtControl.GuiFramework.FreeText();
			this.freeText5 = new NxtControl.GuiFramework.FreeText();
			this.freeText4 = new NxtControl.GuiFramework.FreeText();
			this.freeText7 = new NxtControl.GuiFramework.FreeText();
			this.freeText6 = new NxtControl.GuiFramework.FreeText();
			this.freeText2 = new NxtControl.GuiFramework.FreeText();
			this.roundedRectangle6 = new NxtControl.GuiFramework.RoundedRectangle();
			this.roundedRectangle7 = new NxtControl.GuiFramework.RoundedRectangle();
			this.roundedRectangle8 = new NxtControl.GuiFramework.RoundedRectangle();
			this.roundedRectangle9 = new NxtControl.GuiFramework.RoundedRectangle();
			this.roundedRectangle1 = new NxtControl.GuiFramework.RoundedRectangle();
			this.roundedRectangle2 = new NxtControl.GuiFramework.RoundedRectangle();
			this.roundedRectangle3 = new NxtControl.GuiFramework.RoundedRectangle();
			this.roundedRectangle4 = new NxtControl.GuiFramework.RoundedRectangle();
			this.roundedRectangle5 = new NxtControl.GuiFramework.RoundedRectangle();
			this.freeText8 = new NxtControl.GuiFramework.FreeText();
			this.freeText9 = new NxtControl.GuiFramework.FreeText();
			this.group2 = new NxtControl.GuiFramework.Group();
			this.group3 = new NxtControl.GuiFramework.Group();
			this.group4 = new NxtControl.GuiFramework.Group();
			this.rectangle1 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle2 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle3 = new NxtControl.GuiFramework.Rectangle();
			this.group1 = new NxtControl.GuiFramework.Group();
			this.rectangle4 = new NxtControl.GuiFramework.Rectangle();
			this.freeText10 = new NxtControl.GuiFramework.FreeText();
			this.freeText11 = new NxtControl.GuiFramework.FreeText();
			this.freeText12 = new NxtControl.GuiFramework.FreeText();
			this.freeText14 = new NxtControl.GuiFramework.FreeText();
			this.freeText15 = new NxtControl.GuiFramework.FreeText();
			this.rectangle5 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle6 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle7 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle8 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle9 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle10 = new NxtControl.GuiFramework.Rectangle();
			this.freeText16 = new NxtControl.GuiFramework.FreeText();
			this.freeText17 = new NxtControl.GuiFramework.FreeText();
			this.freeText18 = new NxtControl.GuiFramework.FreeText();
			this.freeText19 = new NxtControl.GuiFramework.FreeText();
			this.group6 = new NxtControl.GuiFramework.Group();
			this.group7 = new NxtControl.GuiFramework.Group();
			this.freeText20 = new NxtControl.GuiFramework.FreeText();
			this.freeText21 = new NxtControl.GuiFramework.FreeText();
			this.freeText22 = new NxtControl.GuiFramework.FreeText();
			this.rectangle11 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle12 = new NxtControl.GuiFramework.Rectangle();
			this.label1 = new NxtControl.GuiFramework.Label();
			this.rectangle13 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle14 = new NxtControl.GuiFramework.Rectangle();
			this.roundedRectangle10 = new NxtControl.GuiFramework.RoundedRectangle();
			this.rectangle16 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle17 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle18 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle15 = new NxtControl.GuiFramework.Rectangle();
			this.roundedRectangle11 = new NxtControl.GuiFramework.RoundedRectangle();
			this.roundedRectangle12 = new NxtControl.GuiFramework.RoundedRectangle();
			this.roundedRectangle13 = new NxtControl.GuiFramework.RoundedRectangle();
			this.roundedRectangle14 = new NxtControl.GuiFramework.RoundedRectangle();
			this.label2 = new NxtControl.GuiFramework.Label();
			this.sNavigation1 = new HMI.Main.Graphics.sNavigation();
			this.sNavigation2 = new HMI.Main.Graphics.sNavigation();
			this.label3 = new NxtControl.GuiFramework.Label();
			// 
			// txtSubtitle
			// 
			this.txtSubtitle.Color = new NxtControl.Drawing.Color(((byte)(61)), ((byte)(205)), ((byte)(88)));
			this.txtSubtitle.Font = new NxtControl.Drawing.Font("Century Gothic", 22F, System.Drawing.FontStyle.Regular);
			this.txtSubtitle.Location = new NxtControl.Drawing.PointF(38D, 166.47D);
			this.txtSubtitle.Name = "txtSubtitle";
			this.txtSubtitle.Text = "from field data to operational intelligence";
			// 
			// txtLic
			// 
			this.txtLic.Color = new NxtControl.Drawing.Color(((byte)(78)), ((byte)(78)), ((byte)(78)));
			this.txtLic.Font = new NxtControl.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular);
			this.txtLic.Location = new NxtControl.Drawing.PointF(35D, 1025.7628125D);
			this.txtLic.Name = "txtLic";
			this.txtLic.Text = "©2026 Schneider Electric - Nam VU Hai";
			// 
			// freeText3
			// 
			this.freeText3.Color = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.freeText3.Font = new NxtControl.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Regular);
			this.freeText3.Location = new NxtControl.Drawing.PointF(173.88045851528386D, 371.6775D);
			this.freeText3.Name = "freeText3";
			this.freeText3.Text = "Software & Services";
			// 
			// freeText5
			// 
			this.freeText5.Color = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.freeText5.Font = new NxtControl.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Regular);
			this.freeText5.Location = new NxtControl.Drawing.PointF(173.88045851528386D, 571.98875D);
			this.freeText5.Name = "freeText5";
			this.freeText5.Text = "Edge Computing\r\n& Control\r\n\r\n\r\nEdge Nodes";
			// 
			// freeText4
			// 
			this.freeText4.Color = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.freeText4.Font = new NxtControl.Drawing.Font("Trebuchet MS", 32F, System.Drawing.FontStyle.Bold);
			this.freeText4.Location = new NxtControl.Drawing.PointF(169.70360262008734D, 506.96625D);
			this.freeText4.Name = "freeText4";
			this.freeText4.Text = "Operate";
			// 
			// freeText7
			// 
			this.freeText7.Color = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.freeText7.Font = new NxtControl.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Regular);
			this.freeText7.Location = new NxtControl.Drawing.PointF(173.88045851528386D, 869.83375D);
			this.freeText7.Name = "freeText7";
			this.freeText7.Text = "Intelligence Devices";
			// 
			// freeText6
			// 
			this.freeText6.Color = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.freeText6.Font = new NxtControl.Drawing.Font("Trebuchet MS", 32F, System.Drawing.FontStyle.Bold);
			this.freeText6.Location = new NxtControl.Drawing.PointF(169.70360262008734D, 804.81125D);
			this.freeText6.Name = "freeText6";
			this.freeText6.Text = "Onboard";
			// 
			// freeText2
			// 
			this.freeText2.Color = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.freeText2.Font = new NxtControl.Drawing.Font("Trebuchet MS", 32F, System.Drawing.FontStyle.Bold);
			this.freeText2.Location = new NxtControl.Drawing.PointF(169.70360262008734D, 306.65500000000003D);
			this.freeText2.Name = "freeText2";
			this.freeText2.Text = "Optimize";
			// 
			// roundedRectangle6
			// 
			this.roundedRectangle6.Bounds = new NxtControl.Drawing.RectF(((float)(526.82476806640625D)), ((float)(279.38751220703125D)), ((float)(1063.009765625D)), ((float)(159.58209228515625D)));
			this.roundedRectangle6.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(61)), ((byte)(205)), ((byte)(88))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.HorizontalLeft, new NxtControl.Drawing.GradientFillColorBlend(new NxtControl.Drawing.Color[] {
					new NxtControl.Drawing.Color(((byte)(47)), ((byte)(113)), ((byte)(64))),
					new NxtControl.Drawing.Color(((byte)(61)), ((byte)(205)), ((byte)(88)))}, new float[] {
					0F,
					1F})));
			this.roundedRectangle6.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.roundedRectangle6.Name = "roundedRectangle6";
			this.roundedRectangle6.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// roundedRectangle7
			// 
			this.roundedRectangle7.Bounds = new NxtControl.Drawing.RectF(((float)(526.82476806640625D)), ((float)(457.67498779296875D)), ((float)(1063.009765625D)), ((float)(158.53334045410156D)));
			this.roundedRectangle7.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(61)), ((byte)(205)), ((byte)(88))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.HorizontalLeft, new NxtControl.Drawing.GradientFillColorBlend(new NxtControl.Drawing.Color[] {
					new NxtControl.Drawing.Color(((byte)(47)), ((byte)(113)), ((byte)(64))),
					new NxtControl.Drawing.Color(((byte)(61)), ((byte)(205)), ((byte)(88)))}, new float[] {
					0F,
					1F})));
			this.roundedRectangle7.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.roundedRectangle7.Name = "roundedRectangle7";
			this.roundedRectangle7.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// roundedRectangle8
			// 
			this.roundedRectangle8.Bounds = new NxtControl.Drawing.RectF(((float)(526.82476806640625D)), ((float)(634.91375732421875D)), ((float)(1063.009765625D)), ((float)(128.11959838867188D)));
			this.roundedRectangle8.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(61)), ((byte)(205)), ((byte)(88))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.HorizontalLeft, new NxtControl.Drawing.GradientFillColorBlend(new NxtControl.Drawing.Color[] {
					new NxtControl.Drawing.Color(((byte)(47)), ((byte)(113)), ((byte)(64))),
					new NxtControl.Drawing.Color(((byte)(61)), ((byte)(205)), ((byte)(88)))}, new float[] {
					0F,
					1F})));
			this.roundedRectangle8.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.roundedRectangle8.Name = "roundedRectangle8";
			this.roundedRectangle8.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// roundedRectangle9
			// 
			this.roundedRectangle9.Bounds = new NxtControl.Drawing.RectF(((float)(523.692138671875D)), ((float)(778.42034912109375D)), ((float)(1063.009765625D)), ((float)(172.16709899902344D)));
			this.roundedRectangle9.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(61)), ((byte)(205)), ((byte)(88))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.HorizontalLeft, new NxtControl.Drawing.GradientFillColorBlend(new NxtControl.Drawing.Color[] {
					new NxtControl.Drawing.Color(((byte)(47)), ((byte)(113)), ((byte)(64))),
					new NxtControl.Drawing.Color(((byte)(61)), ((byte)(205)), ((byte)(88)))}, new float[] {
					0F,
					1F})));
			this.roundedRectangle9.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.roundedRectangle9.Name = "roundedRectangle9";
			this.roundedRectangle9.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// roundedRectangle1
			// 
			this.roundedRectangle1.Bounds = new NxtControl.Drawing.RectF(((float)(35D)), ((float)(277.29000854492188D)), ((float)(83.264114379882813D)), ((float)(678.541259765625D)));
			this.roundedRectangle1.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(41)), ((byte)(140)), ((byte)(57))));
			this.roundedRectangle1.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.roundedRectangle1.Name = "roundedRectangle1";
			this.roundedRectangle1.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// roundedRectangle2
			// 
			this.roundedRectangle2.Bounds = new NxtControl.Drawing.RectF(((float)(145.68667602539063D)), ((float)(279.38751220703125D)), ((float)(337.43807983398438D)), ((float)(178.32649230957031D)));
			this.roundedRectangle2.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(61)), ((byte)(205)), ((byte)(88))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.VerticalTop, new NxtControl.Drawing.GradientFillColorBlend(new NxtControl.Drawing.Color[] {
					new NxtControl.Drawing.Color(((byte)(47)), ((byte)(113)), ((byte)(64))),
					new NxtControl.Drawing.Color(((byte)(61)), ((byte)(205)), ((byte)(88)))}, new float[] {
					0F,
					1F})));
			this.roundedRectangle2.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.roundedRectangle2.Name = "roundedRectangle2";
			this.roundedRectangle2.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// roundedRectangle3
			// 
			this.roundedRectangle3.Bounds = new NxtControl.Drawing.RectF(((float)(145.68667602539063D)), ((float)(479.69876098632813D)), ((float)(337.43807983398438D)), ((float)(275.77865600585938D)));
			this.roundedRectangle3.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(61)), ((byte)(205)), ((byte)(88))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.VerticalTop, new NxtControl.Drawing.GradientFillColorBlend(new NxtControl.Drawing.Color[] {
					new NxtControl.Drawing.Color(((byte)(47)), ((byte)(113)), ((byte)(64))),
					new NxtControl.Drawing.Color(((byte)(61)), ((byte)(205)), ((byte)(88)))}, new float[] {
					0F,
					1F})));
			this.roundedRectangle3.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.roundedRectangle3.Name = "roundedRectangle3";
			this.roundedRectangle3.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// roundedRectangle4
			// 
			this.roundedRectangle4.Bounds = new NxtControl.Drawing.RectF(((float)(145.68667602539063D)), ((float)(777.8992919921875D)), ((float)(337.43807983398438D)), ((float)(178.32649230957031D)));
			this.roundedRectangle4.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(61)), ((byte)(205)), ((byte)(88))), new NxtControl.Drawing.GradientFill(NxtControl.Drawing.GradientFillOrientation.VerticalTop, new NxtControl.Drawing.GradientFillColorBlend(new NxtControl.Drawing.Color[] {
					new NxtControl.Drawing.Color(((byte)(47)), ((byte)(113)), ((byte)(64))),
					new NxtControl.Drawing.Color(((byte)(61)), ((byte)(205)), ((byte)(88)))}, new float[] {
					0F,
					1F})));
			this.roundedRectangle4.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.roundedRectangle4.Name = "roundedRectangle4";
			this.roundedRectangle4.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// roundedRectangle5
			// 
			this.roundedRectangle5.Bounds = new NxtControl.Drawing.RectF(((float)(506.48410034179688D)), ((float)(250.02250671386719D)), ((float)(1386.206298828125D)), ((float)(727.83251953125D)));
			this.roundedRectangle5.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(22)), ((byte)(52)), ((byte)(31))));
			this.roundedRectangle5.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.roundedRectangle5.Name = "roundedRectangle5";
			this.roundedRectangle5.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(18)), ((byte)(68)), ((byte)(30))), 1F, NxtControl.Drawing.DashStyle.Solid);
			// 
			// freeText8
			// 
			this.freeText8.Color = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.freeText8.Font = new NxtControl.Drawing.Font("Trebuchet MS", 22F, System.Drawing.FontStyle.Bold);
			this.freeText8.Location = new NxtControl.Drawing.PointF(557.10698689956325D, 328.67875000000004D);
			this.freeText8.Name = "freeText8";
			this.freeText8.Text = "Enterprise Intelligence";
			// 
			// freeText9
			// 
			this.freeText9.Color = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.freeText9.Font = new NxtControl.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular);
			this.freeText9.Location = new NxtControl.Drawing.PointF(558.15120087336243D, 370.62875D);
			this.freeText9.Name = "freeText9";
			this.freeText9.Text = "AVEVA, Geo SCADA, reporting, operational dashboards";
			// 
			// group2
			// 
			this.group2.BeginInit();
			this.group2.Name = "group2";
			this.group2.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.freeText6,
			this.freeText7});
			this.group2.EndInit();
			// 
			// group3
			// 
			this.group3.BeginInit();
			this.group3.Name = "group3";
			this.group3.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.freeText4,
			this.freeText5});
			this.group3.EndInit();
			// 
			// group4
			// 
			this.group4.BeginInit();
			this.group4.Name = "group4";
			this.group4.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.freeText2,
			this.freeText3});
			this.group4.EndInit();
			// 
			// rectangle1
			// 
			this.rectangle1.Bounds = new NxtControl.Drawing.RectF(((float)(53.795852661132813D)), ((float)(485.99124145507813D)), ((float)(45.945415496826172D)), ((float)(260.08999633789063D)));
			this.rectangle1.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle1.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle1.Name = "rectangle1";
			this.rectangle1.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle2
			// 
			this.rectangle2.Bounds = new NxtControl.Drawing.RectF(((float)(1122.0267333984375D)), ((float)(293.021240234375D)), ((float)(164.98580932617188D)), ((float)(135.28875732421875D)));
			this.rectangle2.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle2.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle2.ImageBytes = resources.GetString("rectangle2.ImageBytes");
			this.rectangle2.Name = "rectangle2";
			this.rectangle2.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle3
			// 
			this.rectangle3.Bounds = new NxtControl.Drawing.RectF(((float)(1355.9306640625D)), ((float)(293.021240234375D)), ((float)(164.98580932617188D)), ((float)(135.28875732421875D)));
			this.rectangle3.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle3.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle3.ImageBytes = resources.GetString("rectangle3.ImageBytes");
			this.rectangle3.Name = "rectangle3";
			this.rectangle3.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// group1
			// 
			this.group1.BeginInit();
			this.group1.Name = "group1";
			this.group1.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.freeText8,
			this.freeText9});
			this.group1.EndInit();
			// 
			// rectangle4
			// 
			this.rectangle4.Bounds = new NxtControl.Drawing.RectF(((float)(1243.155517578125D)), ((float)(469.21124267578125D)), ((float)(170.20687866210938D)), ((float)(135.28875732421875D)));
			this.rectangle4.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle4.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle4.ImageBytes = resources.GetString("rectangle4.ImageBytes");
			this.rectangle4.Name = "rectangle4";
			this.rectangle4.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// freeText10
			// 
			this.freeText10.Color = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.freeText10.Font = new NxtControl.Drawing.Font("Trebuchet MS", 22F, System.Drawing.FontStyle.Bold);
			this.freeText10.Location = new NxtControl.Drawing.PointF(558.15120087336243D, 504.86875000000003D);
			this.freeText10.Name = "freeText10";
			this.freeText10.Text = "Edge Operations";
			// 
			// freeText11
			// 
			this.freeText11.Color = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.freeText11.Font = new NxtControl.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular);
			this.freeText11.Location = new NxtControl.Drawing.PointF(559.1954148471616D, 546.81875D);
			this.freeText11.Name = "freeText11";
			this.freeText11.Text = "EAE Soft dPAC, Web HMI, connector faceplates, MQTT pathway";
			// 
			// freeText12
			// 
			this.freeText12.Color = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.freeText12.Font = new NxtControl.Drawing.Font("Trebuchet MS", 22F, System.Drawing.FontStyle.Bold);
			this.freeText12.Location = new NxtControl.Drawing.PointF(558.15120087336243D, 652.7425D);
			this.freeText12.Name = "freeText12";
			this.freeText12.Text = "Edge Nodes";
			// 
			// freeText14
			// 
			this.freeText14.Color = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.freeText14.Font = new NxtControl.Drawing.Font("Trebuchet MS", 22F, System.Drawing.FontStyle.Bold);
			this.freeText14.Location = new NxtControl.Drawing.PointF(558.15120087336243D, 837.3225D);
			this.freeText14.Name = "freeText14";
			this.freeText14.Text = "Onboard Devices";
			// 
			// freeText15
			// 
			this.freeText15.Color = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.freeText15.Font = new NxtControl.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular);
			this.freeText15.Location = new NxtControl.Drawing.PointF(559.1954148471616D, 879.2725D);
			this.freeText15.Name = "freeText15";
			this.freeText15.Text = "Field signals, drives, IO and protected equipment";
			// 
			// rectangle5
			// 
			this.rectangle5.Bounds = new NxtControl.Drawing.RectF(((float)(1143.9552001953125D)), ((float)(662.1812744140625D)), ((float)(222.41757202148438D)), ((float)(75.510002136230469D)));
			this.rectangle5.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle5.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle5.ImageBytes = resources.GetString("rectangle5.ImageBytes");
			this.rectangle5.Name = "rectangle5";
			this.rectangle5.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle6
			// 
			this.rectangle6.Bounds = new NxtControl.Drawing.RectF(((float)(1411.2740478515625D)), ((float)(647.6173095703125D)), ((float)(50.122272491455078D)), ((float)(101.72875213623047D)));
			this.rectangle6.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle6.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle6.ImageBytes = resources.GetString("rectangle6.ImageBytes");
			this.rectangle6.Name = "rectangle6";
			this.rectangle6.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle7
			// 
			this.rectangle7.Bounds = new NxtControl.Drawing.RectF(((float)(980.013671875D)), ((float)(819.4937744140625D)), ((float)(119.04039001464844D)), ((float)(95.436248779296875D)));
			this.rectangle7.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle7.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle7.ImageBytes = resources.GetString("rectangle7.ImageBytes");
			this.rectangle7.Name = "rectangle7";
			this.rectangle7.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle8
			// 
			this.rectangle8.Bounds = new NxtControl.Drawing.RectF(((float)(1170.060546875D)), ((float)(779.6412353515625D)), ((float)(99.200325012207031D)), ((float)(168.8487548828125D)));
			this.rectangle8.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle8.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle8.ImageBytes = resources.GetString("rectangle8.ImageBytes");
			this.rectangle8.Name = "rectangle8";
			this.rectangle8.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle9
			// 
			this.rectangle9.Bounds = new NxtControl.Drawing.RectF(((float)(1320.4273681640625D)), ((float)(814.25D)), ((float)(119.04039001464844D)), ((float)(95.436248779296875D)));
			this.rectangle9.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle9.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle9.ImageBytes = resources.GetString("rectangle9.ImageBytes");
			this.rectangle9.Name = "rectangle9";
			this.rectangle9.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle10
			// 
			this.rectangle10.Bounds = new NxtControl.Drawing.RectF(((float)(1628D)), ((float)(138D)), ((float)(234.94815063476563D)), ((float)(241.21249389648438D)));
			this.rectangle10.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle10.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle10.ImageBytes = resources.GetString("rectangle10.ImageBytes");
			this.rectangle10.Name = "rectangle10";
			this.rectangle10.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// freeText16
			// 
			this.freeText16.Color = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.freeText16.Font = new NxtControl.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
			this.freeText16.Location = new NxtControl.Drawing.PointF(1684D, 176.80375D);
			this.freeText16.Name = "freeText16";
			this.freeText16.Text = "Data Cube";
			// 
			// freeText17
			// 
			this.freeText17.Color = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.freeText17.Font = new NxtControl.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold);
			this.freeText17.Location = new NxtControl.Drawing.PointF(1656D, 259.65500000000003D);
			this.freeText17.Name = "freeText17";
			this.freeText17.Text = "Energy & Industrial";
			// 
			// freeText18
			// 
			this.freeText18.Color = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.freeText18.Font = new NxtControl.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold);
			this.freeText18.Location = new NxtControl.Drawing.PointF(1687D, 279.58125D);
			this.freeText18.Name = "freeText18";
			this.freeText18.Text = "Intelligence";
			// 
			// freeText19
			// 
			this.freeText19.Color = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.freeText19.Font = new NxtControl.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular);
			this.freeText19.Location = new NxtControl.Drawing.PointF(1650D, 427.86875000000003D);
			this.freeText19.Name = "freeText19";
			this.freeText19.Text = "Enterprise Data";
			// 
			// group6
			// 
			this.group6.BeginInit();
			this.group6.Name = "group6";
			this.group6.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.freeText10,
			this.freeText11});
			this.group6.EndInit();
			// 
			// group7
			// 
			this.group7.BeginInit();
			this.group7.Name = "group7";
			this.group7.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.freeText14,
			this.freeText15});
			this.group7.EndInit();
			// 
			// freeText20
			// 
			this.freeText20.Color = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.freeText20.Font = new NxtControl.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular);
			this.freeText20.Location = new NxtControl.Drawing.PointF(1635D, 622D);
			this.freeText20.Name = "freeText20";
			this.freeText20.Text = "Operational Data";
			// 
			// freeText21
			// 
			this.freeText21.Color = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.freeText21.Font = new NxtControl.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular);
			this.freeText21.Location = new NxtControl.Drawing.PointF(1680D, 814.03125D);
			this.freeText21.Name = "freeText21";
			this.freeText21.Text = "Field Data";
			// 
			// freeText22
			// 
			this.freeText22.Color = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.freeText22.Font = new NxtControl.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular);
			this.freeText22.Location = new NxtControl.Drawing.PointF(1646D, 855.98124999999993D);
			this.freeText22.Name = "freeText22";
			this.freeText22.Text = "+3rd party Data";
			// 
			// rectangle11
			// 
			this.rectangle11.Bounds = new NxtControl.Drawing.RectF(((float)(1733D)), ((float)(508D)), ((float)(24.016921997070313D)), ((float)(66.071250915527344D)));
			this.rectangle11.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle11.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle11.ImageBytes = resources.GetString("rectangle11.ImageBytes");
			this.rectangle11.Name = "rectangle11";
			this.rectangle11.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle12
			// 
			this.rectangle12.Bounds = new NxtControl.Drawing.RectF(((float)(1733D)), ((float)(702D)), ((float)(24.016921997070313D)), ((float)(66.071250915527344D)));
			this.rectangle12.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle12.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle12.ImageBytes = resources.GetString("rectangle12.ImageBytes");
			this.rectangle12.Name = "rectangle12";
			this.rectangle12.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// label1
			// 
			this.label1.AngleIgnore = true;
			this.label1.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label1.Bounds = new NxtControl.Drawing.RectF(((float)(558.15118408203125D)), ((float)(699.936279296875D)), ((float)(342.502197265625D)), ((float)(47.193748474121094D)));
			this.label1.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.label1.Font = new NxtControl.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular);
			this.label1.FontScale = true;
			this.label1.Name = "label1";
			this.label1.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label1.Text = "Industrial computation devices runtime and integration gateway";
			this.label1.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.label1.TextAutoSizeHorizontalOffset = 10;
			this.label1.TextColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.label1.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// rectangle13
			// 
			this.rectangle13.Bounds = new NxtControl.Drawing.RectF(((float)(933.0240478515625D)), ((float)(612.8900146484375D)), ((float)(177.51637268066406D)), ((float)(178.28750610351563D)));
			this.rectangle13.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle13.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle13.ImageBytes = resources.GetString("rectangle13.ImageBytes");
			this.rectangle13.Name = "rectangle13";
			this.rectangle13.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle14
			// 
			this.rectangle14.Bounds = new NxtControl.Drawing.RectF(((float)(1533.447021484375D)), ((float)(709.375D)), ((float)(31.326419830322266D)), ((float)(31.462499618530273D)));
			this.rectangle14.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle14.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle14.ImageBytes = resources.GetString("rectangle14.ImageBytes");
			this.rectangle14.Name = "rectangle14";
			this.rectangle14.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// roundedRectangle10
			// 
			this.roundedRectangle10.Bounds = new NxtControl.Drawing.RectF(((float)(1533.447021484375D)), ((float)(656.9375D)), ((float)(31.326419830322266D)), ((float)(31.462499618530273D)));
			this.roundedRectangle10.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.roundedRectangle10.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.roundedRectangle10.ImageBytes = resources.GetString("roundedRectangle10.ImageBytes");
			this.roundedRectangle10.ImagePadding = new NxtControl.Drawing.Padding(20);
			this.roundedRectangle10.Name = "roundedRectangle10";
			this.roundedRectangle10.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle16
			// 
			this.rectangle16.Bounds = new NxtControl.Drawing.RectF(((float)(1487.5015869140625D)), ((float)(819.4937744140625D)), ((float)(76.227622985839844D)), ((float)(40.901248931884766D)));
			this.rectangle16.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle16.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle16.ImageBytes = resources.GetString("rectangle16.ImageBytes");
			this.rectangle16.Name = "rectangle16";
			this.rectangle16.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle17
			// 
			this.rectangle17.Bounds = new NxtControl.Drawing.RectF(((float)(1506.2974853515625D)), ((float)(860.39501953125D)), ((float)(38.635917663574219D)), ((float)(39.852500915527344D)));
			this.rectangle17.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle17.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle17.ImageBytes = resources.GetString("rectangle17.ImageBytes");
			this.rectangle17.Name = "rectangle17";
			this.rectangle17.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle18
			// 
			this.rectangle18.Bounds = new NxtControl.Drawing.RectF(((float)(1502.12060546875D)), ((float)(910.7349853515625D)), ((float)(48.033843994140625D)), ((float)(18.877500534057617D)));
			this.rectangle18.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle18.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle18.ImageBytes = resources.GetString("rectangle18.ImageBytes");
			this.rectangle18.Name = "rectangle18";
			this.rectangle18.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle15
			// 
			this.rectangle15.Bounds = new NxtControl.Drawing.RectF(((float)(1487.5015869140625D)), ((float)(796.4212646484375D)), ((float)(76.227622985839844D)), ((float)(27.267499923706055D)));
			this.rectangle15.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle15.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle15.ImageBytes = resources.GetString("rectangle15.ImageBytes");
			this.rectangle15.Name = "rectangle15";
			this.rectangle15.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// roundedRectangle11
			// 
			this.roundedRectangle11.Bounds = new NxtControl.Drawing.RectF(((float)(1479.14794921875D)), ((float)(791.177490234375D)), ((float)(93.979255676269531D)), ((float)(145.7762451171875D)));
			this.roundedRectangle11.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.roundedRectangle11.Name = "roundedRectangle11";
			this.roundedRectangle11.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(58)), ((byte)(240)), ((byte)(139))), 1F, NxtControl.Drawing.DashStyle.Solid);
			// 
			// roundedRectangle12
			// 
			this.roundedRectangle12.Bounds = new NxtControl.Drawing.RectF(((float)(1525.0933837890625D)), ((float)(645.4012451171875D)), ((float)(48.033843994140625D)), ((float)(108.02124786376953D)));
			this.roundedRectangle12.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.roundedRectangle12.Name = "roundedRectangle12";
			this.roundedRectangle12.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(58)), ((byte)(240)), ((byte)(139))), 1F, NxtControl.Drawing.DashStyle.Solid);
			// 
			// roundedRectangle13
			// 
			this.roundedRectangle13.Bounds = new NxtControl.Drawing.RectF(((float)(1479.14794921875D)), ((float)(791.177490234375D)), ((float)(93.979255676269531D)), ((float)(145.7762451171875D)));
			this.roundedRectangle13.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(61)), ((byte)(205)), ((byte)(88)), ((byte)(30))));
			this.roundedRectangle13.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.roundedRectangle13.Name = "roundedRectangle13";
			this.roundedRectangle13.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// roundedRectangle14
			// 
			this.roundedRectangle14.Bounds = new NxtControl.Drawing.RectF(((float)(1525.0933837890625D)), ((float)(645.4012451171875D)), ((float)(48.033843994140625D)), ((float)(108.02124786376953D)));
			this.roundedRectangle14.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(61)), ((byte)(205)), ((byte)(88)), ((byte)(30))));
			this.roundedRectangle14.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.roundedRectangle14.Name = "roundedRectangle14";
			this.roundedRectangle14.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// label2
			// 
			this.label2.AngleIgnore = true;
			this.label2.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label2.Bounds = new NxtControl.Drawing.RectF(((float)(1734D)), ((float)(1023D)), ((float)(159D)), ((float)(26D)));
			this.label2.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.label2.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.label2.FontScale = true;
			this.label2.Name = "label2";
			this.label2.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label2.Text = "Page architecture";
			this.label2.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.label2.TextAutoSizeHorizontalOffset = 10;
			this.label2.TextColor = new NxtControl.Drawing.Color(((byte)(78)), ((byte)(78)), ((byte)(78)));
			this.label2.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// sNavigation1
			// 
			this.sNavigation1.BeginInit();
			this.sNavigation1.ButtonText = "Dashboard";
			this.sNavigation1.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 1772D, 31D);
			this.sNavigation1.HoverBackgroundColor = new NxtControl.Drawing.Color(((byte)(18)), ((byte)(45)), ((byte)(42)));
			this.sNavigation1.HoverBorderColor = new NxtControl.Drawing.Color(((byte)(54)), ((byte)(91)), ((byte)(84)));
			this.sNavigation1.Name = "sNavigation1";
			this.sNavigation1.OffBackgroundColor = new NxtControl.Drawing.Color(((byte)(12)), ((byte)(35)), ((byte)(33)));
			this.sNavigation1.OffBorderColor = new NxtControl.Drawing.Color(((byte)(37)), ((byte)(64)), ((byte)(61)));
			this.sNavigation1.OnBackgroundColor = new NxtControl.Drawing.Color(((byte)(18)), ((byte)(67)), ((byte)(42)));
			this.sNavigation1.OnBorderColor = new NxtControl.Drawing.Color(((byte)(61)), ((byte)(205)), ((byte)(88)));
			this.sNavigation1.Click += new System.EventHandler(this.SNavigation1Click);
			this.sNavigation1.EndInit();
			// 
			// sNavigation2
			// 
			this.sNavigation2.BeginInit();
			this.sNavigation2.ButtonText = "Architecture";
			this.sNavigation2.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 1636D, 31D);
			this.sNavigation2.HoverBackgroundColor = new NxtControl.Drawing.Color(((byte)(18)), ((byte)(45)), ((byte)(42)));
			this.sNavigation2.HoverBorderColor = new NxtControl.Drawing.Color(((byte)(54)), ((byte)(91)), ((byte)(84)));
			this.sNavigation2.Name = "sNavigation2";
			this.sNavigation2.OffBackgroundColor = new NxtControl.Drawing.Color(((byte)(12)), ((byte)(35)), ((byte)(33)));
			this.sNavigation2.OffBorderColor = new NxtControl.Drawing.Color(((byte)(37)), ((byte)(64)), ((byte)(61)));
			this.sNavigation2.OnBackgroundColor = new NxtControl.Drawing.Color(((byte)(18)), ((byte)(67)), ((byte)(42)));
			this.sNavigation2.OnBorderColor = new NxtControl.Drawing.Color(((byte)(61)), ((byte)(205)), ((byte)(88)));
			this.sNavigation2.Value = true;
			this.sNavigation2.EndInit();
			// 
			// label3
			// 
			this.label3.AngleIgnore = true;
			this.label3.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label3.Bounds = new NxtControl.Drawing.RectF(((float)(32D)), ((float)(31D)), ((float)(1478D)), ((float)(131D)));
			this.label3.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.label3.Font = new NxtControl.Drawing.Font("Century Gothic", 36F, System.Drawing.FontStyle.Regular);
			this.label3.FontScale = true;
			this.label3.Name = "label3";
			this.label3.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label3.Text = "Open Software-defined automation operations that connect control, edge and enterp" +
	"rise";
			this.label3.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.label3.TextAutoSizeHorizontalOffset = 10;
			this.label3.TextColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.label3.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// Architecture
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(1920D)), ((float)(1080D)));
			this.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(2)), ((byte)(12)), ((byte)(12))));
			this.ImageReSizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.txtSubtitle,
			this.roundedRectangle2,
			this.roundedRectangle3,
			this.roundedRectangle4,
			this.roundedRectangle5,
			this.txtLic,
			this.roundedRectangle1,
			this.group2,
			this.group3,
			this.group4,
			this.rectangle1,
			this.rectangle10,
			this.roundedRectangle6,
			this.rectangle2,
			this.rectangle3,
			this.group1,
			this.roundedRectangle7,
			this.rectangle4,
			this.roundedRectangle8,
			this.rectangle5,
			this.rectangle6,
			this.roundedRectangle9,
			this.rectangle7,
			this.rectangle8,
			this.rectangle9,
			this.freeText16,
			this.freeText17,
			this.freeText18,
			this.freeText19,
			this.freeText20,
			this.group6,
			this.group7,
			this.freeText21,
			this.freeText22,
			this.rectangle11,
			this.rectangle12,
			this.freeText12,
			this.label1,
			this.rectangle13,
			this.roundedRectangle11,
			this.rectangle16,
			this.rectangle18,
			this.rectangle15,
			this.rectangle17,
			this.roundedRectangle13,
			this.roundedRectangle12,
			this.roundedRectangle10,
			this.rectangle14,
			this.roundedRectangle14,
			this.label2,
			this.label3,
			this.sNavigation1,
			this.sNavigation2});
			this.Size = new System.Drawing.Size(1920, 1080);
			this.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;

		}

		private NxtControl.GuiFramework.FreeText txtSubtitle;
		private NxtControl.GuiFramework.FreeText txtLic;
		private NxtControl.GuiFramework.FreeText freeText3;
		private NxtControl.GuiFramework.FreeText freeText5;
		private NxtControl.GuiFramework.FreeText freeText4;
		private NxtControl.GuiFramework.FreeText freeText7;
		private NxtControl.GuiFramework.FreeText freeText6;
		private NxtControl.GuiFramework.FreeText freeText2;
		private NxtControl.GuiFramework.RoundedRectangle roundedRectangle6;
		private NxtControl.GuiFramework.RoundedRectangle roundedRectangle7;
		private NxtControl.GuiFramework.RoundedRectangle roundedRectangle8;
		private NxtControl.GuiFramework.RoundedRectangle roundedRectangle9;
		private NxtControl.GuiFramework.RoundedRectangle roundedRectangle1;
		private NxtControl.GuiFramework.RoundedRectangle roundedRectangle2;
		private NxtControl.GuiFramework.RoundedRectangle roundedRectangle3;
		private NxtControl.GuiFramework.RoundedRectangle roundedRectangle4;
		private NxtControl.GuiFramework.RoundedRectangle roundedRectangle5;
		private NxtControl.GuiFramework.Group group1;
		private NxtControl.GuiFramework.FreeText freeText8;
		private NxtControl.GuiFramework.FreeText freeText9;
		private NxtControl.GuiFramework.Group group2;
		private NxtControl.GuiFramework.Group group3;
		private NxtControl.GuiFramework.Group group4;
		private NxtControl.GuiFramework.Rectangle rectangle1;
		private NxtControl.GuiFramework.Rectangle rectangle2;
		private NxtControl.GuiFramework.Rectangle rectangle3;
		private NxtControl.GuiFramework.Rectangle rectangle4;
		private NxtControl.GuiFramework.FreeText freeText10;
		private NxtControl.GuiFramework.FreeText freeText11;
		private NxtControl.GuiFramework.FreeText freeText12;
		private NxtControl.GuiFramework.FreeText freeText14;
		private NxtControl.GuiFramework.FreeText freeText15;
		private NxtControl.GuiFramework.Rectangle rectangle5;
		private NxtControl.GuiFramework.Rectangle rectangle6;
		private NxtControl.GuiFramework.Rectangle rectangle7;
		private NxtControl.GuiFramework.Rectangle rectangle8;
		private NxtControl.GuiFramework.Rectangle rectangle9;
		private NxtControl.GuiFramework.Rectangle rectangle10;
		private NxtControl.GuiFramework.FreeText freeText16;
		private NxtControl.GuiFramework.FreeText freeText17;
		private NxtControl.GuiFramework.FreeText freeText18;
		private NxtControl.GuiFramework.FreeText freeText19;
		private NxtControl.GuiFramework.Group group6;
		private NxtControl.GuiFramework.Group group7;
		private NxtControl.GuiFramework.FreeText freeText20;
		private NxtControl.GuiFramework.FreeText freeText21;
		private NxtControl.GuiFramework.FreeText freeText22;
		private NxtControl.GuiFramework.Rectangle rectangle11;
		private NxtControl.GuiFramework.Rectangle rectangle12;
		private NxtControl.GuiFramework.Label label1;
		private NxtControl.GuiFramework.Rectangle rectangle13;
		private NxtControl.GuiFramework.Rectangle rectangle14;
		private NxtControl.GuiFramework.RoundedRectangle roundedRectangle10;
		private NxtControl.GuiFramework.Rectangle rectangle15;
		private NxtControl.GuiFramework.Rectangle rectangle16;
		private NxtControl.GuiFramework.Rectangle rectangle17;
		private NxtControl.GuiFramework.Rectangle rectangle18;
		private NxtControl.GuiFramework.RoundedRectangle roundedRectangle11;
		private NxtControl.GuiFramework.RoundedRectangle roundedRectangle12;
		private NxtControl.GuiFramework.RoundedRectangle roundedRectangle13;
		private NxtControl.GuiFramework.RoundedRectangle roundedRectangle14;
		private NxtControl.GuiFramework.Label label2;
		private HMI.Main.Graphics.sNavigation sNavigation1;
		private HMI.Main.Graphics.sNavigation sNavigation2;
		private NxtControl.GuiFramework.Label label3;

		#endregion
	}
}
