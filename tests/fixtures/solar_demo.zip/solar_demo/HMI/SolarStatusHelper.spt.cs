﻿/*
 * Common Solar Plant status logic.
 */

using System;

namespace HMI.Main.SupportClasses
{
	public partial class SolarStatusHelper
	{
		public SolarStatusHelper()
		{
		}

		public static bool TryResolvePriorityStatus(
			object quality,
			object fault,
			object alarm,
			out SolarTheme.EquipmentState status)
		{
			if (!HmiValueHelper.ToBool(quality))
			{
				status =
					SolarTheme.EquipmentState.Offline;

				return true;
			}

			if (HmiValueHelper.ToBool(fault))
			{
				status =
					SolarTheme.EquipmentState.Fault;

				return true;
			}

			if (HmiValueHelper.ToBool(alarm))
			{
				status =
					SolarTheme.EquipmentState.Alarm;

				return true;
			}

			status =
				SolarTheme.EquipmentState.Unknown;

			return false;
		}

		public static SolarTheme.EquipmentState ResolveStandard(
			object quality,
			object fault,
			object alarm,
			object active,
			SolarTheme.EquipmentState activeState,
			SolarTheme.EquipmentState fallbackState)
		{
			SolarTheme.EquipmentState priorityStatus;

			if (TryResolvePriorityStatus(
				quality,
				fault,
				alarm,
				out priorityStatus))
			{
				return priorityStatus;
			}

			if (HmiValueHelper.ToBool(active))
			{
				return activeState;
			}

			return fallbackState;
		}

		public static SolarTheme.EquipmentState ResolveRunningAvailable(
			object quality,
			object fault,
			object alarm,
			object running,
			object available)
		{
			SolarTheme.EquipmentState priorityStatus;
		
			if (TryResolvePriorityStatus(
				quality,
				fault,
				alarm,
				out priorityStatus))
			{
				return priorityStatus;
			}
		
			if (HmiValueHelper.ToBool(running))
			{
				return SolarTheme.EquipmentState.Running;
			}
		
			if (HmiValueHelper.ToBool(available))
			{
				return SolarTheme.EquipmentState.Standby;
			}
		
			return SolarTheme.EquipmentState.Unknown;
		}

		public static string GetStatusText(
			SolarTheme.EquipmentState status)
		{
			switch (status)
			{
				case SolarTheme.EquipmentState.Healthy:
					return "Healthy";
		
				case SolarTheme.EquipmentState.Running:
					return "Running";
		
				case SolarTheme.EquipmentState.Standby:
					return "Standby";
		
				case SolarTheme.EquipmentState.Warning:
					return "Warning";
		
				case SolarTheme.EquipmentState.Alarm:
					return "Alarm";
		
				case SolarTheme.EquipmentState.Fault:
					return "Fault";
		
				case SolarTheme.EquipmentState.Offline:
					return "Offline";
		
				default:
					return "Unknown";
			}
		}
	}
}