/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/7/2026
 * Time: 11:33 AM
 */

using System;
using NxtControl.GuiFramework;
using HMI.Main.SupportClasses;

using GuiLabel =
	NxtControl.GuiFramework.Label;

namespace HMI.Main.Faceplates.acDCCombiner_v1_0
{
	public partial class fAlarm :
		NxtControl.GuiFramework.HMIFaceplate
	{
		private sealed class AlarmDefinition
		{
			public readonly int Bit;
			public readonly string Text;
			public readonly SolarTheme.EquipmentState Severity;
			public readonly GuiLabel Label;

			public AlarmDefinition(
				int bit,
				string text,
				SolarTheme.EquipmentState severity,
				GuiLabel label)
			{
				Bit = bit;
				Text = text;
				Severity = severity;
				Label = label;
			}
		}

		private AlarmDefinition[] _alarms;

		public fAlarm()
		{
			InitializeComponent();
			InitializeAlarms();
			AttachEvents();
			UpdateAlarmDisplay();
		}

		private void InitializeAlarms()
		{
			_alarms = new AlarmDefinition[]
			{
				new AlarmDefinition(
					0,
					"Data quality lost",
					SolarTheme.EquipmentState.Fault,
					label1),

				new AlarmDefinition(
					1,
					"DC isolator open",
					SolarTheme.EquipmentState.Fault,
					label2),

				new AlarmDefinition(
					2,
					"External fault",
					SolarTheme.EquipmentState.Fault,
					label3),

				new AlarmDefinition(
					3,
					"Fuse fault",
					SolarTheme.EquipmentState.Fault,
					label4),

				new AlarmDefinition(
					4,
					"DC voltage invalid",
					SolarTheme.EquipmentState.Fault,
					label5),

				new AlarmDefinition(
					5,
					"DC current invalid",
					SolarTheme.EquipmentState.Fault,
					label6),

				new AlarmDefinition(
					6,
					"SPD fault",
					SolarTheme.EquipmentState.Warning,
					label7),

				new AlarmDefinition(
					7,
					"PV string fault",
					SolarTheme.EquipmentState.Warning,
					label8),

				new AlarmDefinition(
					8,
					"DC / PV data mismatch",
					SolarTheme.EquipmentState.Warning,
					label9),

				new AlarmDefinition(
					9,
					"External alarm",
					SolarTheme.EquipmentState.Warning,
					label10)
			};
		}

		private void AttachEvents()
		{
			ALMW.OnValChanged += OnAlarmWordChanged;
			REQ_Fired += REQ_Fired_EventHandler;
		}

		private void OnAlarmWordChanged(
			object sender,
			EventArgs e)
		{
			UpdateAlarmDisplay();
		}

		private void UpdateAlarmDisplay()
		{
			int alarmWord =
				HmiValueHelper.ToInt(ALMW.Val);

			HmiDisplayHelper.DisplayItem[] displayItems =
				new HmiDisplayHelper.DisplayItem[
					_alarms.Length];

			for (int i = 0; i < _alarms.Length; i++)
			{
				AlarmDefinition alarm =
					_alarms[i];

				bool isActive =
					IsBitSet(
						alarmWord,
						alarm.Bit);

				displayItems[i] =
					HmiDisplayHelper.CreateText(
						alarm.Label,
						alarm.Text,
						isActive
							? SolarTheme.GetStatusColor(
								alarm.Severity)
							: SolarTheme.Status.Offline);
			}

			HmiDisplayHelper.DisplayData displayData =
				new HmiDisplayHelper.DisplayData();

			displayData.Items = displayItems;

			HmiDisplayHelper.Apply(displayData);
		}

		private bool IsBitSet(
			int value,
			int bit)
		{
			if (bit < 0 || bit > 31)
				return false;

			return (value & (1 << bit)) != 0;
		}

		private void REQ_Fired_EventHandler(
			object sender,
			HMI.Main.Symbols.acDCCombiner_v1_0.REQEventArgs e)
		{
			Title =
				HmiValueHelper.SafeText(
					e.AssetName,
					"DC Combiner Alarms");
		}
	}
}