/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/3/2026
 * Time: 4:40 PM
 * 
 */
using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region acDCCombiner_v1_0_HMI;

namespace HMI.Main.Symbols.acDCCombiner_v1_0
{
  partial class sDefault
  {

    private HMI.Main.Faceplates.acDCCombiner_v1_0.fMain fMain
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        HMI.Main.Faceplates.acDCCombiner_v1_0.fMain faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (HMI.Main.Faceplates.acDCCombiner_v1_0.fMain)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(HMI.Main.Faceplates.acDCCombiner_v1_0.fMain));
        
        if (faceplate == null)
        {
          faceplate = new HMI.Main.Faceplates.acDCCombiner_v1_0.fMain();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private HMI.Main.Faceplates.acDCCombiner_v1_0.fAlarm fAlarm
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        HMI.Main.Faceplates.acDCCombiner_v1_0.fAlarm faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (HMI.Main.Faceplates.acDCCombiner_v1_0.fAlarm)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(HMI.Main.Faceplates.acDCCombiner_v1_0.fAlarm));
        
        if (faceplate == null)
        {
          faceplate = new HMI.Main.Faceplates.acDCCombiner_v1_0.fAlarm();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    protected override void DoOpenFaceplate(OpenFaceplate openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fMain;

      if ("fAlarm" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fAlarm;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

    public override void DoOpenFaceplate(string openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == openFaceplate)
        hmiFaceplate = fMain;

      if ("fAlarm" == openFaceplate)
        hmiFaceplate = fAlarm;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

  }
}

namespace HMI.Main.Faceplates.acDCCombiner_v1_0
{
  partial class fMain
  {

    private HMI.Main.Faceplates.acDCCombiner_v1_0.fAlarm fAlarm
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        HMI.Main.Faceplates.acDCCombiner_v1_0.fAlarm faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (HMI.Main.Faceplates.acDCCombiner_v1_0.fAlarm)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(HMI.Main.Faceplates.acDCCombiner_v1_0.fAlarm));
        
        if (faceplate == null)
        {
          faceplate = new HMI.Main.Faceplates.acDCCombiner_v1_0.fAlarm();

          faceplate.SetConnectionInfo(this.TagName, this.ConnectionSymbolPath, this.ChannelId, this.ParentType);

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    protected override void DoOpenFaceplate(OpenFaceplate openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fAlarm" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fAlarm;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

    public override void DoOpenFaceplate(string openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fAlarm" == openFaceplate)
        hmiFaceplate = fAlarm;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

  }
}

namespace HMI.Main.Faceplates.acDCCombiner_v1_0
{
  partial class fAlarm
  {

    private HMI.Main.Faceplates.acDCCombiner_v1_0.fMain fMain
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        HMI.Main.Faceplates.acDCCombiner_v1_0.fMain faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (HMI.Main.Faceplates.acDCCombiner_v1_0.fMain)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(HMI.Main.Faceplates.acDCCombiner_v1_0.fMain));
        
        if (faceplate == null)
        {
          faceplate = new HMI.Main.Faceplates.acDCCombiner_v1_0.fMain();

          faceplate.SetConnectionInfo(this.TagName, this.ConnectionSymbolPath, this.ChannelId, this.ParentType);

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    protected override void DoOpenFaceplate(OpenFaceplate openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fMain;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

    public override void DoOpenFaceplate(string openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == openFaceplate)
        hmiFaceplate = fMain;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

  }
}
#endregion acDCCombiner_v1_0_HMI;

#endregion Definitions;


