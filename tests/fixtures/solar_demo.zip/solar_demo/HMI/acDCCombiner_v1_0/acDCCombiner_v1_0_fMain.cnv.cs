/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/3/2026
 * Time: 5:30 PM
 */

using System;
using NxtControl.GuiFramework;
using HMI.Main.SupportClasses;

using GuiLabel =
	NxtControl.GuiFramework.Label;

namespace HMI.Main.Faceplates.acDCCombiner_v1_0
{
	public partial class fMain :
		NxtControl.GuiFramework.HMIFaceplate
	{
		public fMain()
		{
			InitializeComponent();
			AttachEvents();
			UpdateDisplay();
		}

		private void AttachEvents()
		{
			REQ_Fired += REQ_Fired_EventHandler;

			IAVL.OnValChanged += OnDCCombinerValueChanged;
			IALM.OnValChanged += OnDCCombinerValueChanged;
			IFLT.OnValChanged += OnDCCombinerValueChanged;
			QLT.OnValChanged += OnDCCombinerValueChanged;

			IFUSE.OnValChanged += OnDCCombinerValueChanged;
			ISPD.OnValChanged += OnDCCombinerValueChanged;
			IISO.OnValChanged += OnDCCombinerValueChanged;
			STRFLT.OnValChanged += OnDCCombinerValueChanged;
		}

		private void OnDCCombinerValueChanged(
			object sender,
			EventArgs e)
		{
			UpdateDisplay();
		}

		private void UpdateDisplay()
		{
			bool hasValidQuality =
				HmiValueHelper.ToBool(QLT.Val);

			SolarTheme.EquipmentState status =
				SolarStatusHelper.ResolveStandard(
					QLT.Val,
					IFLT.Val,
					IALM.Val,
					IAVL.Val,
					SolarTheme.EquipmentState.Running,
					SolarTheme.EquipmentState.Standby);

			HmiDisplayHelper.DisplayData displayData =
				new HmiDisplayHelper.DisplayData();

			displayData.Status = status;
			displayData.StatusText =
				SolarStatusHelper.GetStatusText(status);

			displayData.StatusLabel = txtStatus;

			displayData.Items =
				hasValidQuality
					? CreateValidDisplayItems()
					: CreateInvalidDisplayItems();

			HmiDisplayHelper.Apply(displayData);
		}

		private HmiDisplayHelper.DisplayItem[]
			CreateValidDisplayItems()
		{
			return new HmiDisplayHelper.DisplayItem[]
			{
				CreateProtectionItem(
					txtFuse,
					IFUSE.Val),

				CreateProtectionItem(
					txtSPD,
					ISPD.Val),

				CreateIsolatorItem(
					txtIsolator,
					IISO.Val),

				CreateStringFaultItem(
					txtStringfault,
					STRFLT.Val)
			};
		}

		private HmiDisplayHelper.DisplayItem[]
			CreateInvalidDisplayItems()
		{
			return new HmiDisplayHelper.DisplayItem[]
			{
				CreateOfflineItem(txtFuse),
				CreateOfflineItem(txtSPD),
				CreateOfflineItem(txtIsolator),
				CreateOfflineItem(txtStringfault)
			};
		}

		private HmiDisplayHelper.DisplayItem
			CreateProtectionItem(
				GuiLabel label,
				object value)
		{
			bool isHealthy =
				HmiValueHelper.ToBool(value);

			return HmiDisplayHelper.CreateText(
				label,
				isHealthy
					? "Normal"
					: "Fault",
				isHealthy
					? SolarTheme.Text.Primary
					: SolarTheme.Status.Fault);
		}

		private HmiDisplayHelper.DisplayItem
			CreateIsolatorItem(
				GuiLabel label,
				object value)
		{
			bool isClosed =
				HmiValueHelper.ToBool(value);

			return HmiDisplayHelper.CreateText(
				label,
				isClosed
					? "Closed"
					: "Open",
				isClosed
					? SolarTheme.Text.Primary
					: SolarTheme.Status.Fault);
		}

		private HmiDisplayHelper.DisplayItem
			CreateStringFaultItem(
				GuiLabel label,
				object value)
		{
			int faultCount =
				HmiValueHelper.ToInt(value);

			return HmiDisplayHelper.CreateText(
				label,
				GetStringFaultText(faultCount),
				faultCount > 0
					? SolarTheme.Status.Warning
					: SolarTheme.Text.Primary);
		}

		private HmiDisplayHelper.DisplayItem
			CreateOfflineItem(
				GuiLabel label)
		{
			return HmiDisplayHelper.CreateText(
				label,
				"Offline",
				SolarTheme.Status.Offline);
		}

		private string GetStringFaultText(
			int faultCount)
		{
			if (faultCount <= 0)
			{
				return "Normal";
			}

			if (faultCount == 1)
			{
				return "1 fault";
			}

			return faultCount.ToString()
				+ " faults";
		}

		private void REQ_Fired_EventHandler(
			object sender,
			HMI.Main.Symbols.acDCCombiner_v1_0.REQEventArgs e)
		{
			Title =
				HmiValueHelper.SafeText(
					e.AssetName,
					"DC Combiner");

			UpdateDisplay();
		}
	}
}