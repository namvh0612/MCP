/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/3/2026
 * Time: 4:40 PM
 */

using System;
using NxtControl.GuiFramework;
using HMI.Main.SupportClasses;

namespace HMI.Main.Symbols.acDCCombiner_v1_0
{
	public partial class sDefault :
		NxtControl.GuiFramework.HMISymbol
	{
		private bool _isRectBtnHovered;

		private SolarTheme.EquipmentState _currentStatus =
			SolarTheme.EquipmentState.Offline;

		public sDefault()
		{
			InitializeComponent();
			AttachEvents();
			UpdateDisplay();
		}

		private void AttachEvents()
		{
			REQ_Fired += REQ_Fired_EventHandler;

			IAVL.OnValChanged += OnDCCombinerValueChanged;
			IALM.OnValChanged += OnDCCombinerValueChanged;
			IFLT.OnValChanged += OnDCCombinerValueChanged;
			QLT.OnValChanged += OnDCCombinerValueChanged;

			VDC.OnValChanged += OnDCCombinerValueChanged;
			IDC.OnValChanged += OnDCCombinerValueChanged;
			PDC.OnValChanged += OnDCCombinerValueChanged;

			IFUSE.OnValChanged += OnDCCombinerValueChanged;
			ISPD.OnValChanged += OnDCCombinerValueChanged;
		}

		private void OnDCCombinerValueChanged(
			object sender,
			EventArgs e)
		{
			UpdateDisplay();
		}

		private void UpdateDisplay()
		{
			bool hasValidQuality =
				HmiValueHelper.ToBool(QLT.Val);

			_currentStatus =
				SolarStatusHelper.ResolveStandard(
					QLT.Val,
					IFLT.Val,
					IALM.Val,
					IAVL.Val,
					SolarTheme.EquipmentState.Running,
					SolarTheme.EquipmentState.Standby);

			HmiDisplayHelper.DisplayData displayData =
				new HmiDisplayHelper.DisplayData();

			displayData.Status = _currentStatus;
			displayData.StatusText =
				SolarStatusHelper.GetStatusText(
					_currentStatus);

			displayData.StatusLabel = txtStatus;
			displayData.StatusIndicator = indStatus;
			displayData.CardBorder = rectBtn;
			displayData.CardBackground = rectBase;
			displayData.IsHovered = _isRectBtnHovered;

			displayData.Items =
				hasValidQuality
					? CreateValidDisplayItems()
					: CreateInvalidDisplayItems();

			HmiDisplayHelper.Apply(displayData);
		}

		private HmiDisplayHelper.DisplayItem[]
			CreateValidDisplayItems()
		{
			bool protectionHealthy =
				IsProtectionHealthy();

			return new HmiDisplayHelper.DisplayItem[]
			{
				HmiDisplayHelper.CreateValue(
					txtVDC,
					VDC.Val,
					"0",
					" V",
					SolarTheme.Text.Primary),

				HmiDisplayHelper.CreateValue(
					txtIDC,
					IDC.Val,
					"0",
					" A",
					SolarTheme.Text.Primary),

				HmiDisplayHelper.CreateValue(
					txtPDC,
					PDC.Val,
					"0.00",
					" MW",
					SolarTheme.Text.Primary),

				HmiDisplayHelper.CreateText(
					txtProtection,
					protectionHealthy
						? "Normal"
						: "Fault",
					protectionHealthy
						? SolarTheme.Text.Primary
						: SolarTheme.Status.Fault)
			};
		}

		private HmiDisplayHelper.DisplayItem[]
			CreateInvalidDisplayItems()
		{
			return new HmiDisplayHelper.DisplayItem[]
			{
				HmiDisplayHelper.CreateText(
					txtVDC,
					"00 V",
					SolarTheme.Status.Offline),

				HmiDisplayHelper.CreateText(
					txtIDC,
					"00 A",
					SolarTheme.Status.Offline),

				HmiDisplayHelper.CreateText(
					txtPDC,
					"0.00 MW",
					SolarTheme.Status.Offline),

				HmiDisplayHelper.CreateText(
					txtProtection,
					"Offline",
					SolarTheme.Status.Offline)
			};
		}

		private bool IsProtectionHealthy()
		{
			return HmiValueHelper.ToBool(IFUSE.Val)
				&& HmiValueHelper.ToBool(ISPD.Val);
		}

		private void UpdateCardVisual()
		{
			HmiDisplayHelper.ApplyStatusCard(
				rectBtn,
				rectBase,
				_currentStatus,
				_isRectBtnHovered);
		}

		private void RectBtnMouseEnter(
			object sender,
			EventArgs e)
		{
			_isRectBtnHovered = true;
			UpdateCardVisual();
		}

		private void RectBtnMouseLeave(
			object sender,
			EventArgs e)
		{
			_isRectBtnHovered = false;
			UpdateCardVisual();
		}

		private void REQ_Fired_EventHandler(
			object sender,
			REQEventArgs e)
		{
			lblSymbol.Text =
				HmiValueHelper.SafeText(
					e.AssetName,
					"DC Combiner");
		}
	}
}