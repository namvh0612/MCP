/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/3/2026
 * Time: 5:30 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using NxtControl.GuiFramework;

namespace HMI.Main.Faceplates.acDCCombiner_v1_0
{
	/// <summary>
	/// Summary description for fMain.
	/// </summary>
	partial class fMain
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fMain));
			this.txtFuse = new NxtControl.GuiFramework.Label();
			this.txtSPD = new NxtControl.GuiFramework.Label();
			this.txtIsolator = new NxtControl.GuiFramework.Label();
			this.freeText1 = new NxtControl.GuiFramework.FreeText();
			this.freeText2 = new NxtControl.GuiFramework.FreeText();
			this.freeText3 = new NxtControl.GuiFramework.FreeText();
			this.freeText7 = new NxtControl.GuiFramework.FreeText();
			this.IALM = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IAVL = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IDC = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.IFLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IFUSE = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IISO = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.ISPD = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.PDC = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.QLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.STRFLT = new SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged();
			this.VDC = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.txtStringfault = new NxtControl.GuiFramework.Label();
			this.freeText8 = new NxtControl.GuiFramework.FreeText();
			this.txtStatus = new NxtControl.GuiFramework.Label();
			this.rectangle1 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle2 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle3 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle4 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle5 = new NxtControl.GuiFramework.Rectangle();
			this.freeText4 = new NxtControl.GuiFramework.FreeText();
			this.sButtonNavDemo1 = new SE.Agile.Symbols.Broadcaster_v1_0.sButtonNavDemo();
			this.line3 = new NxtControl.GuiFramework.Line();
			// 
			// txtFuse
			// 
			this.txtFuse.AngleIgnore = true;
			this.txtFuse.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtFuse.Bounds = new NxtControl.Drawing.RectF(((float)(120D)), ((float)(47D)), ((float)(92D)), ((float)(14D)));
			this.txtFuse.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtFuse.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtFuse.FontScale = true;
			this.txtFuse.Name = "txtFuse";
			this.txtFuse.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtFuse.Text = "Normal";
			this.txtFuse.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtFuse.TextAutoSizeHorizontalOffset = 10;
			this.txtFuse.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtFuse.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// txtSPD
			// 
			this.txtSPD.AngleIgnore = true;
			this.txtSPD.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtSPD.Bounds = new NxtControl.Drawing.RectF(((float)(120D)), ((float)(77D)), ((float)(92D)), ((float)(14D)));
			this.txtSPD.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtSPD.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtSPD.FontScale = true;
			this.txtSPD.Name = "txtSPD";
			this.txtSPD.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtSPD.Text = "Normal";
			this.txtSPD.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtSPD.TextAutoSizeHorizontalOffset = 10;
			this.txtSPD.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtSPD.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// txtIsolator
			// 
			this.txtIsolator.AngleIgnore = true;
			this.txtIsolator.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtIsolator.Bounds = new NxtControl.Drawing.RectF(((float)(120D)), ((float)(107D)), ((float)(92D)), ((float)(14D)));
			this.txtIsolator.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtIsolator.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtIsolator.FontScale = true;
			this.txtIsolator.Name = "txtIsolator";
			this.txtIsolator.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtIsolator.Text = "Closed";
			this.txtIsolator.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtIsolator.TextAutoSizeHorizontalOffset = 10;
			this.txtIsolator.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtIsolator.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText1
			// 
			this.freeText1.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText1.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText1.Location = new NxtControl.Drawing.PointF(40D, 45D);
			this.freeText1.Name = "freeText1";
			this.freeText1.Text = "Fuse";
			// 
			// freeText2
			// 
			this.freeText2.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText2.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText2.Location = new NxtControl.Drawing.PointF(40D, 75D);
			this.freeText2.Name = "freeText2";
			this.freeText2.Text = "SPD";
			// 
			// freeText3
			// 
			this.freeText3.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText3.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText3.Location = new NxtControl.Drawing.PointF(40D, 105D);
			this.freeText3.Name = "freeText3";
			this.freeText3.Text = "Isolator";
			// 
			// freeText7
			// 
			this.freeText7.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText7.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText7.Location = new NxtControl.Drawing.PointF(40D, 15D);
			this.freeText7.Name = "freeText7";
			this.freeText7.Text = "Status";
			// 
			// IALM
			// 
			this.IALM.BeginInit();
			this.IALM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 4D, 108D);
			this.IALM.Name = "IALM";
			this.IALM.SecurityToken = ((uint)(4294967295u));
			this.IALM.TagName = "IALM";
			this.IALM.Val = false;
			this.IALM.EndInit();
			// 
			// IAVL
			// 
			this.IAVL.BeginInit();
			this.IAVL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 109D, 144D);
			this.IAVL.Name = "IAVL";
			this.IAVL.SecurityToken = ((uint)(4294967295u));
			this.IAVL.TagName = "IAVL";
			this.IAVL.Val = false;
			this.IAVL.EndInit();
			// 
			// IDC
			// 
			this.IDC.BeginInit();
			this.IDC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 84D, 141D);
			this.IDC.Name = "IDC";
			this.IDC.SecurityToken = ((uint)(4294967295u));
			this.IDC.TagName = "IDC";
			this.IDC.Val = 0F;
			this.IDC.ValDecimalPlaces = ((byte)(0));
			this.IDC.ValMaximum = 0F;
			this.IDC.ValMinimum = 0F;
			this.IDC.ValUnits = null;
			this.IDC.EndInit();
			// 
			// IFLT
			// 
			this.IFLT.BeginInit();
			this.IFLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 110D, 129D);
			this.IFLT.Name = "IFLT";
			this.IFLT.SecurityToken = ((uint)(4294967295u));
			this.IFLT.TagName = "IFLT";
			this.IFLT.Val = false;
			this.IFLT.EndInit();
			// 
			// IFUSE
			// 
			this.IFUSE.BeginInit();
			this.IFUSE.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 105D, 155D);
			this.IFUSE.Name = "IFUSE";
			this.IFUSE.SecurityToken = ((uint)(4294967295u));
			this.IFUSE.TagName = "IFUSE";
			this.IFUSE.Val = false;
			this.IFUSE.EndInit();
			// 
			// IISO
			// 
			this.IISO.BeginInit();
			this.IISO.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 140D, 161D);
			this.IISO.Name = "IISO";
			this.IISO.SecurityToken = ((uint)(4294967295u));
			this.IISO.TagName = "IISO";
			this.IISO.Val = false;
			this.IISO.EndInit();
			// 
			// ISPD
			// 
			this.ISPD.BeginInit();
			this.ISPD.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 79D, 151D);
			this.ISPD.Name = "ISPD";
			this.ISPD.SecurityToken = ((uint)(4294967295u));
			this.ISPD.TagName = "ISPD";
			this.ISPD.Val = false;
			this.ISPD.EndInit();
			// 
			// PDC
			// 
			this.PDC.BeginInit();
			this.PDC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 89D, 164D);
			this.PDC.Name = "PDC";
			this.PDC.SecurityToken = ((uint)(4294967295u));
			this.PDC.TagName = "PDC";
			this.PDC.Val = 0F;
			this.PDC.ValDecimalPlaces = ((byte)(0));
			this.PDC.ValMaximum = 0F;
			this.PDC.ValMinimum = 0F;
			this.PDC.ValUnits = null;
			this.PDC.EndInit();
			// 
			// QLT
			// 
			this.QLT.BeginInit();
			this.QLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 97D, 168D);
			this.QLT.Name = "QLT";
			this.QLT.SecurityToken = ((uint)(4294967295u));
			this.QLT.TagName = "QLT";
			this.QLT.Val = false;
			this.QLT.EndInit();
			// 
			// STRFLT
			// 
			this.STRFLT.BeginInit();
			this.STRFLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 117D, 147D);
			this.STRFLT.Name = "STRFLT";
			this.STRFLT.SecurityToken = ((uint)(4294967295u));
			this.STRFLT.TagName = "STRFLT";
			this.STRFLT.Val = ((short)(0));
			this.STRFLT.ValMaximum = ((short)(0));
			this.STRFLT.ValMinimum = ((short)(0));
			this.STRFLT.ValUnits = null;
			this.STRFLT.EndInit();
			// 
			// VDC
			// 
			this.VDC.BeginInit();
			this.VDC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 130D, 162D);
			this.VDC.Name = "VDC";
			this.VDC.SecurityToken = ((uint)(4294967295u));
			this.VDC.TagName = "VDC";
			this.VDC.Val = 0F;
			this.VDC.ValDecimalPlaces = ((byte)(0));
			this.VDC.ValMaximum = 0F;
			this.VDC.ValMinimum = 0F;
			this.VDC.ValUnits = null;
			this.VDC.EndInit();
			// 
			// txtStringfault
			// 
			this.txtStringfault.AngleIgnore = true;
			this.txtStringfault.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtStringfault.Bounds = new NxtControl.Drawing.RectF(((float)(120D)), ((float)(139D)), ((float)(92D)), ((float)(14D)));
			this.txtStringfault.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtStringfault.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtStringfault.FontScale = true;
			this.txtStringfault.Name = "txtStringfault";
			this.txtStringfault.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtStringfault.Text = "1 fault";
			this.txtStringfault.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtStringfault.TextAutoSizeHorizontalOffset = 10;
			this.txtStringfault.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtStringfault.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText8
			// 
			this.freeText8.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText8.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText8.Location = new NxtControl.Drawing.PointF(40D, 137D);
			this.freeText8.Name = "freeText8";
			this.freeText8.Text = "Strings";
			// 
			// txtStatus
			// 
			this.txtStatus.AngleIgnore = true;
			this.txtStatus.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtStatus.Bounds = new NxtControl.Drawing.RectF(((float)(120D)), ((float)(17D)), ((float)(92D)), ((float)(14D)));
			this.txtStatus.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtStatus.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtStatus.FontScale = true;
			this.txtStatus.Name = "txtStatus";
			this.txtStatus.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fAlarm", NxtControl.GuiFramework.MouseButtonType.Click));
			this.txtStatus.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtStatus.Text = "Healthy";
			this.txtStatus.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtStatus.TextAutoSizeHorizontalOffset = 10;
			this.txtStatus.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtStatus.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// rectangle1
			// 
			this.rectangle1.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(16D)), ((float)(16D)), ((float)(16D)));
			this.rectangle1.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle1.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle1.ImageBytes = resources.GetString("rectangle1.ImageBytes");
			this.rectangle1.Name = "rectangle1";
			this.rectangle1.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle2
			// 
			this.rectangle2.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(46D)), ((float)(16D)), ((float)(16D)));
			this.rectangle2.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle2.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle2.ImageBytes = resources.GetString("rectangle2.ImageBytes");
			this.rectangle2.Name = "rectangle2";
			this.rectangle2.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle3
			// 
			this.rectangle3.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(76D)), ((float)(16D)), ((float)(16D)));
			this.rectangle3.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle3.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle3.ImageBytes = resources.GetString("rectangle3.ImageBytes");
			this.rectangle3.Name = "rectangle3";
			this.rectangle3.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle4
			// 
			this.rectangle4.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(106D)), ((float)(16D)), ((float)(16D)));
			this.rectangle4.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle4.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle4.ImageBytes = resources.GetString("rectangle4.ImageBytes");
			this.rectangle4.Name = "rectangle4";
			this.rectangle4.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle5
			// 
			this.rectangle5.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(138D)), ((float)(16D)), ((float)(16D)));
			this.rectangle5.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle5.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle5.ImageBytes = resources.GetString("rectangle5.ImageBytes");
			this.rectangle5.Name = "rectangle5";
			this.rectangle5.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// freeText4
			// 
			this.freeText4.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText4.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Italic);
			this.freeText4.Location = new NxtControl.Drawing.PointF(14D, 175D);
			this.freeText4.Name = "freeText4";
			this.freeText4.Text = "Connector Info.";
			// 
			// sButtonNavDemo1
			// 
			this.sButtonNavDemo1.BeginInit();
			this.sButtonNavDemo1.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 198D, 176D);
			this.sButtonNavDemo1.Name = "sButtonNavDemo1";
			this.sButtonNavDemo1.SecurityToken = ((uint)(4294967295u));
			this.sButtonNavDemo1.TagName = "DCCombiner.Broadcaster_v1_0";
			this.sButtonNavDemo1.EndInit();
			// 
			// line3
			// 
			this.line3.EndPoint = new NxtControl.Drawing.PointF(227D, 165D);
			this.line3.Name = "line3";
			this.line3.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(20)), ((byte)(54)), ((byte)(45))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line3.StartPoint = new NxtControl.Drawing.PointF(1D, 165D);
			// 
			// fMain
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(228D)), ((float)(204D)));
			this.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(3)), ((byte)(22)), ((byte)(20))));
			this.FaceplateClose = NxtControl.GuiFramework.CloseFaceplateBehavior.Automatic;
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.txtFuse,
			this.txtSPD,
			this.txtIsolator,
			this.freeText1,
			this.freeText2,
			this.freeText3,
			this.txtStatus,
			this.freeText7,
			this.IALM,
			this.IAVL,
			this.IDC,
			this.IFLT,
			this.IFUSE,
			this.IISO,
			this.ISPD,
			this.PDC,
			this.QLT,
			this.STRFLT,
			this.VDC,
			this.txtStringfault,
			this.freeText8,
			this.rectangle1,
			this.rectangle2,
			this.rectangle3,
			this.rectangle4,
			this.rectangle5,
			this.freeText4,
			this.sButtonNavDemo1,
			this.line3});
			this.Size = new System.Drawing.Size(228, 204);

		}
		private NxtControl.GuiFramework.Label txtFuse;
		private NxtControl.GuiFramework.Label txtSPD;
		private NxtControl.GuiFramework.Label txtIsolator;
		private NxtControl.GuiFramework.FreeText freeText1;
		private NxtControl.GuiFramework.FreeText freeText2;
		private NxtControl.GuiFramework.FreeText freeText3;
		private NxtControl.GuiFramework.Label txtStatus;
		private NxtControl.GuiFramework.FreeText freeText7;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IALM;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IAVL;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged IDC;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IFLT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IFUSE;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IISO;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged ISPD;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged PDC;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged QLT;
		private SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged STRFLT;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged VDC;
		private NxtControl.GuiFramework.Label txtStringfault;
		private NxtControl.GuiFramework.FreeText freeText8;
		private NxtControl.GuiFramework.Rectangle rectangle1;
		private NxtControl.GuiFramework.Rectangle rectangle2;
		private NxtControl.GuiFramework.Rectangle rectangle3;
		private NxtControl.GuiFramework.Rectangle rectangle4;
		private NxtControl.GuiFramework.Rectangle rectangle5;
		private NxtControl.GuiFramework.FreeText freeText4;
		private SE.Agile.Symbols.Broadcaster_v1_0.sButtonNavDemo sButtonNavDemo1;
		private NxtControl.GuiFramework.Line line3;
		#endregion
	}
}
