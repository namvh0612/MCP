/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/3/2026
 * Time: 4:40 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.acDCCombiner_v1_0
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sDefault
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(sDefault));
			this.rectangle1 = new NxtControl.GuiFramework.Rectangle();
			this.lblSymbol = new NxtControl.GuiFramework.Label();
			this.txtStatus = new NxtControl.GuiFramework.Label();
			this.indStatus = new NxtControl.GuiFramework.Ellipse();
			this.txtVDC = new NxtControl.GuiFramework.Label();
			this.freeText4 = new NxtControl.GuiFramework.FreeText();
			this.txtIDC = new NxtControl.GuiFramework.Label();
			this.freeText5 = new NxtControl.GuiFramework.FreeText();
			this.txtPDC = new NxtControl.GuiFramework.Label();
			this.freeText6 = new NxtControl.GuiFramework.FreeText();
			this.line1 = new NxtControl.GuiFramework.Line();
			this.line2 = new NxtControl.GuiFramework.Line();
			this.line3 = new NxtControl.GuiFramework.Line();
			this.rectBase = new NxtControl.GuiFramework.RoundedRectangle();
			this.rectBtn = new NxtControl.GuiFramework.RoundedRectangle();
			this.IAVL = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IDC = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.IFLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IFUSE = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.ISPD = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.QLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.VDC = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.IALM = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.txtProtection = new NxtControl.GuiFramework.Label();
			this.freeText12 = new NxtControl.GuiFramework.FreeText();
			this.line4 = new NxtControl.GuiFramework.Line();
			this.PDC = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			// 
			// rectangle1
			// 
			this.rectangle1.Bounds = new NxtControl.Drawing.RectF(((float)(10D)), ((float)(45D)), ((float)(220D)), ((float)(220D)));
			this.rectangle1.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle1.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle1.ImageBytes = resources.GetString("rectangle1.ImageBytes");
			this.rectangle1.Name = "rectangle1";
			this.rectangle1.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// lblSymbol
			// 
			this.lblSymbol.AngleIgnore = true;
			this.lblSymbol.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.lblSymbol.Bounds = new NxtControl.Drawing.RectF(((float)(11D)), ((float)(12D)), ((float)(141D)), ((float)(24D)));
			this.lblSymbol.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.lblSymbol.Font = new NxtControl.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
			this.lblSymbol.FontScale = true;
			this.lblSymbol.Name = "lblSymbol";
			this.lblSymbol.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.lblSymbol.Text = "Combiner";
			this.lblSymbol.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.lblSymbol.TextAutoSizeHorizontalOffset = 10;
			this.lblSymbol.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.lblSymbol.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// txtStatus
			// 
			this.txtStatus.AngleIgnore = true;
			this.txtStatus.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtStatus.Bounds = new NxtControl.Drawing.RectF(((float)(175D)), ((float)(16D)), ((float)(53D)), ((float)(16D)));
			this.txtStatus.Brush = new NxtControl.Drawing.Brush(true);
			this.txtStatus.Font = new NxtControl.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular);
			this.txtStatus.FontScale = true;
			this.txtStatus.Name = "txtStatus";
			this.txtStatus.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtStatus.Text = "Running";
			this.txtStatus.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.txtStatus.TextAutoSizeHorizontalOffset = 10;
			this.txtStatus.TextColor = new NxtControl.Drawing.Color(((byte)(120)), ((byte)(249)), ((byte)(141)));
			this.txtStatus.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// indStatus
			// 
			this.indStatus.Bounds = new NxtControl.Drawing.RectF(((float)(163D)), ((float)(19D)), ((float)(10D)), ((float)(10D)));
			this.indStatus.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(120)), ((byte)(249)), ((byte)(141))));
			this.indStatus.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.indStatus.Name = "indStatus";
			this.indStatus.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// txtVDC
			// 
			this.txtVDC.AngleIgnore = true;
			this.txtVDC.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtVDC.Bounds = new NxtControl.Drawing.RectF(((float)(131D)), ((float)(287D)), ((float)(96D)), ((float)(20D)));
			this.txtVDC.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtVDC.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtVDC.FontScale = true;
			this.txtVDC.Name = "txtVDC";
			this.txtVDC.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtVDC.Text = "800 V";
			this.txtVDC.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtVDC.TextAutoSizeHorizontalOffset = 10;
			this.txtVDC.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtVDC.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText4
			// 
			this.freeText4.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText4.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText4.Location = new NxtControl.Drawing.PointF(11D, 288D);
			this.freeText4.Name = "freeText4";
			this.freeText4.Text = "DC Bus";
			// 
			// txtIDC
			// 
			this.txtIDC.AngleIgnore = true;
			this.txtIDC.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtIDC.Bounds = new NxtControl.Drawing.RectF(((float)(131D)), ((float)(319D)), ((float)(96D)), ((float)(20D)));
			this.txtIDC.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtIDC.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtIDC.FontScale = true;
			this.txtIDC.Name = "txtIDC";
			this.txtIDC.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtIDC.Text = "4915 A";
			this.txtIDC.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtIDC.TextAutoSizeHorizontalOffset = 10;
			this.txtIDC.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtIDC.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText5
			// 
			this.freeText5.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText5.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText5.Location = new NxtControl.Drawing.PointF(11D, 320D);
			this.freeText5.Name = "freeText5";
			this.freeText5.Text = "DC Current";
			// 
			// txtPDC
			// 
			this.txtPDC.AngleIgnore = true;
			this.txtPDC.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtPDC.Bounds = new NxtControl.Drawing.RectF(((float)(131D)), ((float)(351D)), ((float)(96D)), ((float)(20D)));
			this.txtPDC.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtPDC.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtPDC.FontScale = true;
			this.txtPDC.Name = "txtPDC";
			this.txtPDC.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtPDC.Text = "9.12 MW";
			this.txtPDC.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtPDC.TextAutoSizeHorizontalOffset = 10;
			this.txtPDC.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtPDC.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText6
			// 
			this.freeText6.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText6.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText6.Location = new NxtControl.Drawing.PointF(11D, 352D);
			this.freeText6.Name = "freeText6";
			this.freeText6.Text = "DC Power";
			// 
			// line1
			// 
			this.line1.EndPoint = new NxtControl.Drawing.PointF(239D, 281D);
			this.line1.Name = "line1";
			this.line1.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(20)), ((byte)(54)), ((byte)(45))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line1.StartPoint = new NxtControl.Drawing.PointF(2D, 281D);
			// 
			// line2
			// 
			this.line2.EndPoint = new NxtControl.Drawing.PointF(239D, 313D);
			this.line2.Name = "line2";
			this.line2.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(20)), ((byte)(54)), ((byte)(45))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line2.StartPoint = new NxtControl.Drawing.PointF(2D, 313D);
			// 
			// line3
			// 
			this.line3.EndPoint = new NxtControl.Drawing.PointF(239D, 345D);
			this.line3.Name = "line3";
			this.line3.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(20)), ((byte)(54)), ((byte)(45))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line3.StartPoint = new NxtControl.Drawing.PointF(2D, 345D);
			// 
			// rectBase
			// 
			this.rectBase.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(240D)), ((float)(412D)));
			this.rectBase.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(3)), ((byte)(22)), ((byte)(20))));
			this.rectBase.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectBase.Name = "rectBase";
			this.rectBase.Pen = new NxtControl.Drawing.Pen("Transparent");
			this.rectBase.Radius = 10D;
			// 
			// rectBtn
			// 
			this.rectBtn.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(240D)), ((float)(412D)));
			this.rectBtn.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("Transparent"));
			this.rectBtn.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectBtn.Name = "rectBtn";
			this.rectBtn.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fMain", NxtControl.GuiFramework.MouseButtonType.Click));
			this.rectBtn.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(28)), ((byte)(78)), ((byte)(71))), 1F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Flat, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Round, null);
			this.rectBtn.Radius = 10D;
			this.rectBtn.MouseEnter += new System.EventHandler(this.RectBtnMouseEnter);
			this.rectBtn.MouseLeave += new System.EventHandler(this.RectBtnMouseLeave);
			// 
			// IAVL
			// 
			this.IAVL.BeginInit();
			this.IAVL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 182D, 246D);
			this.IAVL.Name = "IAVL";
			this.IAVL.SecurityToken = ((uint)(4294967295u));
			this.IAVL.TagName = "IAVL";
			this.IAVL.Val = false;
			this.IAVL.EndInit();
			// 
			// IDC
			// 
			this.IDC.BeginInit();
			this.IDC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 160D, 278D);
			this.IDC.Name = "IDC";
			this.IDC.SecurityToken = ((uint)(4294967295u));
			this.IDC.TagName = "IDC";
			this.IDC.Val = 0F;
			this.IDC.ValDecimalPlaces = ((byte)(0));
			this.IDC.ValMaximum = 0F;
			this.IDC.ValMinimum = 0F;
			this.IDC.ValUnits = null;
			this.IDC.EndInit();
			// 
			// IFLT
			// 
			this.IFLT.BeginInit();
			this.IFLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 211D, 281D);
			this.IFLT.Name = "IFLT";
			this.IFLT.SecurityToken = ((uint)(4294967295u));
			this.IFLT.TagName = "IFLT";
			this.IFLT.Val = false;
			this.IFLT.EndInit();
			// 
			// IFUSE
			// 
			this.IFUSE.BeginInit();
			this.IFUSE.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 128D, 265D);
			this.IFUSE.Name = "IFUSE";
			this.IFUSE.SecurityToken = ((uint)(4294967295u));
			this.IFUSE.TagName = "IFUSE";
			this.IFUSE.Val = false;
			this.IFUSE.EndInit();
			// 
			// ISPD
			// 
			this.ISPD.BeginInit();
			this.ISPD.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 131D, 288D);
			this.ISPD.Name = "ISPD";
			this.ISPD.SecurityToken = ((uint)(4294967295u));
			this.ISPD.TagName = "ISPD";
			this.ISPD.Val = false;
			this.ISPD.EndInit();
			// 
			// QLT
			// 
			this.QLT.BeginInit();
			this.QLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 104D, 308D);
			this.QLT.Name = "QLT";
			this.QLT.SecurityToken = ((uint)(4294967295u));
			this.QLT.TagName = "QLT";
			this.QLT.Val = false;
			this.QLT.EndInit();
			// 
			// VDC
			// 
			this.VDC.BeginInit();
			this.VDC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 131D, 297D);
			this.VDC.Name = "VDC";
			this.VDC.SecurityToken = ((uint)(4294967295u));
			this.VDC.TagName = "VDC";
			this.VDC.Val = 0F;
			this.VDC.ValDecimalPlaces = ((byte)(0));
			this.VDC.ValMaximum = 0F;
			this.VDC.ValMinimum = 0F;
			this.VDC.ValUnits = null;
			this.VDC.EndInit();
			// 
			// IALM
			// 
			this.IALM.BeginInit();
			this.IALM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 205D, 265D);
			this.IALM.Name = "IALM";
			this.IALM.SecurityToken = ((uint)(4294967295u));
			this.IALM.TagName = "IALM";
			this.IALM.Val = false;
			this.IALM.EndInit();
			// 
			// txtProtection
			// 
			this.txtProtection.AngleIgnore = true;
			this.txtProtection.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtProtection.Bounds = new NxtControl.Drawing.RectF(((float)(131D)), ((float)(382D)), ((float)(96D)), ((float)(20D)));
			this.txtProtection.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtProtection.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtProtection.FontScale = true;
			this.txtProtection.Name = "txtProtection";
			this.txtProtection.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtProtection.Text = "Normal";
			this.txtProtection.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtProtection.TextAutoSizeHorizontalOffset = 10;
			this.txtProtection.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtProtection.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText12
			// 
			this.freeText12.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText12.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText12.Location = new NxtControl.Drawing.PointF(11D, 383D);
			this.freeText12.Name = "freeText12";
			this.freeText12.Text = "Protection";
			// 
			// line4
			// 
			this.line4.EndPoint = new NxtControl.Drawing.PointF(239D, 376D);
			this.line4.Name = "line4";
			this.line4.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(20)), ((byte)(54)), ((byte)(45))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line4.StartPoint = new NxtControl.Drawing.PointF(2D, 376D);
			// 
			// PDC
			// 
			this.PDC.BeginInit();
			this.PDC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 235D, 144D);
			this.PDC.Name = "PDC";
			this.PDC.SecurityToken = ((uint)(4294967295u));
			this.PDC.TagName = "PDC";
			this.PDC.Val = 0F;
			this.PDC.ValDecimalPlaces = ((byte)(0));
			this.PDC.ValMaximum = 0F;
			this.PDC.ValMinimum = 0F;
			this.PDC.ValUnits = null;
			this.PDC.EndInit();
			// 
			// sDefault
			// 
			this.AnchorPoint = new NxtControl.Drawing.PointF(-289D, -53D);
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.rectBase,
			this.rectangle1,
			this.lblSymbol,
			this.txtStatus,
			this.indStatus,
			this.IAVL,
			this.IDC,
			this.IFLT,
			this.IFUSE,
			this.ISPD,
			this.QLT,
			this.VDC,
			this.IALM,
			this.txtVDC,
			this.freeText4,
			this.txtIDC,
			this.freeText5,
			this.txtPDC,
			this.freeText6,
			this.line1,
			this.line2,
			this.line3,
			this.txtProtection,
			this.freeText12,
			this.line4,
			this.PDC,
			this.rectBtn});
			this.SymbolSize = new System.Drawing.Size(758, 600);

		}
		private NxtControl.GuiFramework.Rectangle rectangle1;
		private NxtControl.GuiFramework.Label lblSymbol;
		private NxtControl.GuiFramework.Label txtStatus;
		private NxtControl.GuiFramework.Ellipse indStatus;
		private NxtControl.GuiFramework.Label txtVDC;
		private NxtControl.GuiFramework.FreeText freeText4;
		private NxtControl.GuiFramework.Label txtIDC;
		private NxtControl.GuiFramework.FreeText freeText5;
		private NxtControl.GuiFramework.Label txtPDC;
		private NxtControl.GuiFramework.FreeText freeText6;
		private NxtControl.GuiFramework.Line line1;
		private NxtControl.GuiFramework.Line line2;
		private NxtControl.GuiFramework.Line line3;
		private NxtControl.GuiFramework.RoundedRectangle rectBase;
		private NxtControl.GuiFramework.RoundedRectangle rectBtn;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IAVL;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged IDC;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IFLT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IFUSE;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged ISPD;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged QLT;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged VDC;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IALM;
		private NxtControl.GuiFramework.Label txtProtection;
		private NxtControl.GuiFramework.FreeText freeText12;
		private NxtControl.GuiFramework.Line line4;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged PDC;
		#endregion
	}
}