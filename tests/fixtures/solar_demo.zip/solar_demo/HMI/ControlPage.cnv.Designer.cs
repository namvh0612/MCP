/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/6/2026
 * Time: 9:53 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;

using NxtControl.GuiFramework;

namespace HMI.Main.Canvases
{
	/// <summary>
	/// Summary description for ControlPage.
	/// </summary>
	partial class ControlPage
	{
		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ControlPage));
			this.DCC001 = new HMI.Main.Symbols.acDCCombiner_v1_0.sDefault();
			this.INV001 = new HMI.Main.Symbols.acInverter_v1_0.sDefault();
			this.TRA001 = new HMI.Main.Symbols.acTransformer_v1_0.sDefault();
			this.BD001 = new HMI.Main.Symbols.acOwnLoad_v1_0.sDefault();
			this.GRID01 = new HMI.Main.Symbols.acGrid_v1_0.sDefault();
			this.PV001 = new HMI.Main.Symbols.acPVArray_v1_0.sDefault();
			this.PPC001 = new HMI.Main.Symbols.acPPC_v1_0.sDefault();
			this.BESS01 = new HMI.Main.Symbols.acBESS1_v1_0.sDefault();
			this.freeText1 = new NxtControl.GuiFramework.FreeText();
			this.freeText2 = new NxtControl.GuiFramework.FreeText();
			this.PV001_1 = new HMI.Main.Symbols.acPVArray_v1_0.sIrradiance();
			this.PV001_2 = new HMI.Main.Symbols.acPVArray_v1_0.sPvDcPwr();
			this.INV001_1 = new HMI.Main.Symbols.acInverter_v1_0.sAcPwr();
			this.GRID01_1 = new HMI.Main.Symbols.acGrid_v1_0.sGridPanel();
			this.PPC001_1 = new HMI.Main.Symbols.acPPC_v1_0.sPR();
			this.PPC001_2 = new HMI.Main.Symbols.acPPC_v1_0.sAvail();
			this.rectBtn = new NxtControl.GuiFramework.RoundedRectangle();
			this.roundedRectangle1 = new NxtControl.GuiFramework.RoundedRectangle();
			this.freeText3 = new NxtControl.GuiFramework.FreeText();
			this.SIM001 = new HMI.Main.Symbols.acSimLogic_v1_0.sControl();
			this.Mqtt_SoftdPAC = new SE.Agile.Symbols.MQTT_Connection_v1_0.sDemo();
			this.freeText4 = new NxtControl.GuiFramework.FreeText();
			this.SIM001_1 = new HMI.Main.Symbols.acSimLogic_v1_0.sSimulation();
			this.rectangle1 = new NxtControl.GuiFramework.Rectangle();
			this.roundedRectangle2 = new NxtControl.GuiFramework.RoundedRectangle();
			this.freeText5 = new NxtControl.GuiFramework.FreeText();
			this.freeText6 = new NxtControl.GuiFramework.FreeText();
			this.dataGridView1 = new NxtControl.GuiFramework.DataGridView();
			this.PV_IRR = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.DCC_ALMW = new SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged();
			this.INV_ALMW = new SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged();
			this.LOAD_ALMW = new SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged();
			this.BESS_ALMW = new SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged();
			this.TRF_ALMW = new SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged();
			this.GRID_ALMW = new SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged();
			this.PPC_ALMW = new SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged();
			this.INV_ASPCMD = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValChanged();
			this.BESS_IDIS = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.BESS_ICHG = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.BESS_PBAT = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.PPC_IMPLIM = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValChanged();
			this.PPC_EXPLIM = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValChanged();
			this.sPL_DCC_INV = new HMI.Main.Graphics.sPowerLink();
			this.sPL_PV_DCC = new HMI.Main.Graphics.sPowerLink();
			this.sPL_TRF_GRID = new HMI.Main.Graphics.sPowerLink();
			this.sTL_DCC = new HMI.Main.Graphics.sPowerLink();
			this.sTL_PV = new HMI.Main.Graphics.sPowerLink();
			this.sTL_BD = new HMI.Main.Graphics.sPowerLink();
			this.sTL_INV = new HMI.Main.Graphics.sPowerLink();
			this.sTL_TRF = new HMI.Main.Graphics.sPowerLink();
			this.sTL_BESS = new HMI.Main.Graphics.sPowerLink();
			this.sTL_GRID = new HMI.Main.Graphics.sPowerLink();
			this.sPL_INV_AC = new HMI.Main.Graphics.sPowerLink();
			this.sPL_AC = new HMI.Main.Graphics.sPowerLink();
			this.SPL_TRF_AC = new HMI.Main.Graphics.sPowerLink();
			this.sPL_BD_AC = new HMI.Main.Graphics.sPowerLink();
			this.sPL_BESS_AC = new HMI.Main.Graphics.sPowerLink();
			this.sTL_Main = new HMI.Main.Graphics.sPowerLink();
			this.sTL_PPC = new HMI.Main.Graphics.sPowerLink();
			this.BD001_QLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.BESS01_QLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.DCC001_QLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.GRID01_QLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.INV001_QLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.INV001_PAC = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.DCC001_PDC = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.BESS01_PBAT = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.BD001_PLOAD = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.PPC001_QLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.PV001_PDC = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.PV001_QLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.TRF001_QLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.TRF001_PMV = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.TRF001_PLV = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.line1 = new NxtControl.GuiFramework.Line();
			this.label1 = new NxtControl.GuiFramework.Label();
			this.line2 = new NxtControl.GuiFramework.Line();
			this.label2 = new NxtControl.GuiFramework.Label();
			this.line3 = new NxtControl.GuiFramework.Line();
			this.label3 = new NxtControl.GuiFramework.Label();
			this.line4 = new NxtControl.GuiFramework.Line();
			this.label4 = new NxtControl.GuiFramework.Label();
			this.TRF001_IFLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.PV001_IFLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.PPC001_IFLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.GRID01_IFLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.INV001_IRUN = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.INV001_IFLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.DCC001_IFLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.BESS01_IFLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.roundedRectangle3 = new NxtControl.GuiFramework.RoundedRectangle();
			this.sNavigation1 = new HMI.Main.Graphics.sNavigation();
			this.sNavigation2 = new HMI.Main.Graphics.sNavigation();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
			// 
			// DCC001
			// 
			this.DCC001.BeginInit();
			this.DCC001.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 48D, 245D);
			this.DCC001.Name = "DCC001";
			this.DCC001.SecurityToken = ((uint)(4294967295u));
			this.DCC001.TagName = "852155B2A9F8687F";
			this.DCC001.EndInit();
			// 
			// INV001
			// 
			this.INV001.BeginInit();
			this.INV001.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 397D, 245D);
			this.INV001.Name = "INV001";
			this.INV001.SecurityToken = ((uint)(4294967295u));
			this.INV001.TagName = "5E480FF9B2E2F1AF";
			this.INV001.EndInit();
			// 
			// TRA001
			// 
			this.TRA001.BeginInit();
			this.TRA001.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 746D, 245D);
			this.TRA001.Name = "TRA001";
			this.TRA001.SecurityToken = ((uint)(4294967295u));
			this.TRA001.TagName = "CDD00681371A006B";
			this.TRA001.EndInit();
			// 
			// BD001
			// 
			this.BD001.BeginInit();
			this.BD001.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 397D, 758D);
			this.BD001.Name = "BD001";
			this.BD001.SecurityToken = ((uint)(4294967295u));
			this.BD001.TagName = "33CEE1A0B9E70BC4";
			this.BD001.EndInit();
			// 
			// GRID01
			// 
			this.GRID01.BeginInit();
			this.GRID01.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 1096D, 245D);
			this.GRID01.Name = "GRID01";
			this.GRID01.SecurityToken = ((uint)(4294967295u));
			this.GRID01.TagName = "E36D42F6A0F6E534";
			this.GRID01.EndInit();
			// 
			// PV001
			// 
			this.PV001.BeginInit();
			this.PV001.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 48D, 758D);
			this.PV001.Name = "PV001";
			this.PV001.SecurityToken = ((uint)(4294967295u));
			this.PV001.TagName = "B567E00A3BDDC9DA";
			this.PV001.EndInit();
			// 
			// PPC001
			// 
			this.PPC001.BeginInit();
			this.PPC001.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 1096D, 758D);
			this.PPC001.Name = "PPC001";
			this.PPC001.SecurityToken = ((uint)(4294967295u));
			this.PPC001.TagName = "0CF0789E63BFF5DF";
			this.PPC001.EndInit();
			// 
			// BESS01
			// 
			this.BESS01.BeginInit();
			this.BESS01.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 746D, 758D);
			this.BESS01.Name = "BESS01";
			this.BESS01.SecurityToken = ((uint)(4294967295u));
			this.BESS01.TagName = "7AFB420086732019";
			this.BESS01.EndInit();
			// 
			// freeText1
			// 
			this.freeText1.Color = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.freeText1.Font = new NxtControl.Drawing.Font("Century Gothic", 34F, System.Drawing.FontStyle.Regular);
			this.freeText1.Location = new NxtControl.Drawing.PointF(127D, 23D);
			this.freeText1.Name = "freeText1";
			this.freeText1.Text = "Solar Plant System";
			// 
			// freeText2
			// 
			this.freeText2.Color = new NxtControl.Drawing.Color(((byte)(61)), ((byte)(205)), ((byte)(88)));
			this.freeText2.Font = new NxtControl.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular);
			this.freeText2.Location = new NxtControl.Drawing.PointF(137D, 82D);
			this.freeText2.Name = "freeText2";
			this.freeText2.Text = "powered by EcoStruxure Automation Expert";
			// 
			// PV001_1
			// 
			this.PV001_1.BeginInit();
			this.PV001_1.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 32D, 123D);
			this.PV001_1.Name = "PV001_1";
			this.PV001_1.SecurityToken = ((uint)(4294967295u));
			this.PV001_1.TagName = "B567E00A3BDDC9DA";
			this.PV001_1.EndInit();
			// 
			// PV001_2
			// 
			this.PV001_2.BeginInit();
			this.PV001_2.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 299D, 123D);
			this.PV001_2.Name = "PV001_2";
			this.PV001_2.SecurityToken = ((uint)(4294967295u));
			this.PV001_2.TagName = "B567E00A3BDDC9DA";
			this.PV001_2.EndInit();
			// 
			// INV001_1
			// 
			this.INV001_1.BeginInit();
			this.INV001_1.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 565D, 123D);
			this.INV001_1.Name = "INV001_1";
			this.INV001_1.SecurityToken = ((uint)(4294967295u));
			this.INV001_1.TagName = "5E480FF9B2E2F1AF";
			this.INV001_1.EndInit();
			// 
			// GRID01_1
			// 
			this.GRID01_1.BeginInit();
			this.GRID01_1.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 833D, 123D);
			this.GRID01_1.Name = "GRID01_1";
			this.GRID01_1.SecurityToken = ((uint)(4294967295u));
			this.GRID01_1.TagName = "E36D42F6A0F6E534";
			this.GRID01_1.EndInit();
			// 
			// PPC001_1
			// 
			this.PPC001_1.BeginInit();
			this.PPC001_1.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 1101D, 123D);
			this.PPC001_1.Name = "PPC001_1";
			this.PPC001_1.SecurityToken = ((uint)(4294967295u));
			this.PPC001_1.TagName = "0CF0789E63BFF5DF";
			this.PPC001_1.EndInit();
			// 
			// PPC001_2
			// 
			this.PPC001_2.BeginInit();
			this.PPC001_2.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 1367D, 123D);
			this.PPC001_2.Name = "PPC001_2";
			this.PPC001_2.SecurityToken = ((uint)(4294967295u));
			this.PPC001_2.TagName = "0CF0789E63BFF5DF";
			this.PPC001_2.EndInit();
			// 
			// rectBtn
			// 
			this.rectBtn.Bounds = new NxtControl.Drawing.RectF(((float)(1370D)), ((float)(227D)), ((float)(518D)), ((float)(312D)));
			this.rectBtn.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(5)), ((byte)(22)), ((byte)(21))));
			this.rectBtn.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectBtn.Name = "rectBtn";
			this.rectBtn.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(29)), ((byte)(61)), ((byte)(57))), 1F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Flat, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Round, null);
			this.rectBtn.Radius = 10D;
			// 
			// roundedRectangle1
			// 
			this.roundedRectangle1.Bounds = new NxtControl.Drawing.RectF(((float)(32D)), ((float)(227D)), ((float)(1321D)), ((float)(827D)));
			this.roundedRectangle1.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(2)), ((byte)(15)), ((byte)(13))));
			this.roundedRectangle1.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.roundedRectangle1.Name = "roundedRectangle1";
			this.roundedRectangle1.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(29)), ((byte)(61)), ((byte)(57))), 1F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Flat, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Round, null);
			this.roundedRectangle1.Radius = 10D;
			// 
			// freeText3
			// 
			this.freeText3.Color = new NxtControl.Drawing.Color(((byte)(61)), ((byte)(205)), ((byte)(88)));
			this.freeText3.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText3.Location = new NxtControl.Drawing.PointF(1386D, 245D);
			this.freeText3.Name = "freeText3";
			this.freeText3.Text = "PRESENTER CONSOLE";
			// 
			// SIM001
			// 
			this.SIM001.BeginInit();
			this.SIM001.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 1384D, 320D);
			this.SIM001.Name = "SIM001";
			this.SIM001.SecurityToken = ((uint)(4294967295u));
			this.SIM001.TagName = "99DC20F463F219CC";
			this.SIM001.EndInit();
			// 
			// Mqtt_SoftdPAC
			// 
			this.Mqtt_SoftdPAC.BeginInit();
			this.Mqtt_SoftdPAC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 1636D, 123D);
			this.Mqtt_SoftdPAC.Name = "Mqtt_SoftdPAC";
			this.Mqtt_SoftdPAC.SecurityToken = ((uint)(4294967295u));
			this.Mqtt_SoftdPAC.TagName = "21AE916B2E7BCE45";
			this.Mqtt_SoftdPAC.EndInit();
			// 
			// freeText4
			// 
			this.freeText4.Color = new NxtControl.Drawing.Color(((byte)(238)), ((byte)(243)), ((byte)(241)));
			this.freeText4.Font = new NxtControl.Drawing.Font("Century Gothic", 22F, System.Drawing.FontStyle.Bold);
			this.freeText4.Location = new NxtControl.Drawing.PointF(1385D, 264D);
			this.freeText4.Name = "freeText4";
			this.freeText4.Text = "Scenario Control";
			// 
			// SIM001_1
			// 
			this.SIM001_1.BeginInit();
			this.SIM001_1.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 1767D, 241D);
			this.SIM001_1.Name = "SIM001_1";
			this.SIM001_1.SecurityToken = ((uint)(4294967295u));
			this.SIM001_1.TagName = "99DC20F463F219CC";
			this.SIM001_1.EndInit();
			// 
			// rectangle1
			// 
			this.rectangle1.Bounds = new NxtControl.Drawing.RectF(((float)(32D)), ((float)(23D)), ((float)(80D)), ((float)(80D)));
			this.rectangle1.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle1.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle1.ImageBytes = resources.GetString("rectangle1.ImageBytes");
			this.rectangle1.Name = "rectangle1";
			this.rectangle1.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// roundedRectangle2
			// 
			this.roundedRectangle2.Bounds = new NxtControl.Drawing.RectF(((float)(1370D)), ((float)(561D)), ((float)(518D)), ((float)(493D)));
			this.roundedRectangle2.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(5)), ((byte)(22)), ((byte)(21))));
			this.roundedRectangle2.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.roundedRectangle2.Name = "roundedRectangle2";
			this.roundedRectangle2.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(29)), ((byte)(61)), ((byte)(57))), 1F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Flat, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Round, null);
			this.roundedRectangle2.Radius = 10D;
			// 
			// freeText5
			// 
			this.freeText5.Color = new NxtControl.Drawing.Color(((byte)(61)), ((byte)(205)), ((byte)(88)));
			this.freeText5.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText5.Location = new NxtControl.Drawing.PointF(1386D, 578D);
			this.freeText5.Name = "freeText5";
			this.freeText5.Text = "EVENT DATA";
			// 
			// freeText6
			// 
			this.freeText6.Color = new NxtControl.Drawing.Color(((byte)(238)), ((byte)(243)), ((byte)(241)));
			this.freeText6.Font = new NxtControl.Drawing.Font("Century Gothic", 22F, System.Drawing.FontStyle.Bold);
			this.freeText6.Location = new NxtControl.Drawing.PointF(1386D, 597D);
			this.freeText6.Name = "freeText6";
			this.freeText6.Text = "System Log";
			// 
			// dataGridView1
			// 
			this.dataGridView1.Font = new NxtControl.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular);
			this.dataGridView1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(22)))), ((int)(((byte)(21)))));
			this.dataGridView1.Location = new System.Drawing.Point(1384, 657);
			this.dataGridView1.Name = "dataGridView1";
			this.dataGridView1.Size = new System.Drawing.Size(489, 381);
			this.dataGridView1.TabIndex = 0;
			this.dataGridView1.Text = "dataGridView1";
			// 
			// PV_IRR
			// 
			this.PV_IRR.BeginInit();
			this.PV_IRR.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 996D, 710D);
			this.PV_IRR.Name = "PV_IRR";
			this.PV_IRR.SecurityToken = ((uint)(4294967295u));
			this.PV_IRR.TagName = "B567E00A3BDDC9DA.IRR";
			this.PV_IRR.Val = 0F;
			this.PV_IRR.ValDecimalPlaces = ((byte)(0));
			this.PV_IRR.ValMaximum = 0F;
			this.PV_IRR.ValMinimum = 0F;
			this.PV_IRR.ValUnits = null;
			this.PV_IRR.EndInit();
			// 
			// DCC_ALMW
			// 
			this.DCC_ALMW.BeginInit();
			this.DCC_ALMW.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 482D, 372D);
			this.DCC_ALMW.Name = "DCC_ALMW";
			this.DCC_ALMW.SecurityToken = ((uint)(4294967295u));
			this.DCC_ALMW.TagName = "852155B2A9F8687F.ALMW";
			this.DCC_ALMW.Val = ((short)(0));
			this.DCC_ALMW.ValMaximum = ((short)(0));
			this.DCC_ALMW.ValMinimum = ((short)(0));
			this.DCC_ALMW.ValUnits = null;
			this.DCC_ALMW.EndInit();
			// 
			// INV_ALMW
			// 
			this.INV_ALMW.BeginInit();
			this.INV_ALMW.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 764D, 434D);
			this.INV_ALMW.Name = "INV_ALMW";
			this.INV_ALMW.SecurityToken = ((uint)(4294967295u));
			this.INV_ALMW.TagName = "5E480FF9B2E2F1AF.ALMW";
			this.INV_ALMW.Val = ((short)(0));
			this.INV_ALMW.ValMaximum = ((short)(0));
			this.INV_ALMW.ValMinimum = ((short)(0));
			this.INV_ALMW.ValUnits = null;
			this.INV_ALMW.EndInit();
			// 
			// LOAD_ALMW
			// 
			this.LOAD_ALMW.BeginInit();
			this.LOAD_ALMW.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 800D, 406D);
			this.LOAD_ALMW.Name = "LOAD_ALMW";
			this.LOAD_ALMW.SecurityToken = ((uint)(4294967295u));
			this.LOAD_ALMW.TagName = "33CEE1A0B9E70BC4.ALMW";
			this.LOAD_ALMW.Val = ((short)(0));
			this.LOAD_ALMW.ValMaximum = ((short)(0));
			this.LOAD_ALMW.ValMinimum = ((short)(0));
			this.LOAD_ALMW.ValUnits = null;
			this.LOAD_ALMW.EndInit();
			// 
			// BESS_ALMW
			// 
			this.BESS_ALMW.BeginInit();
			this.BESS_ALMW.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 606D, 362D);
			this.BESS_ALMW.Name = "BESS_ALMW";
			this.BESS_ALMW.SecurityToken = ((uint)(4294967295u));
			this.BESS_ALMW.TagName = "7AFB420086732019.ALMW";
			this.BESS_ALMW.Val = ((short)(0));
			this.BESS_ALMW.ValMaximum = ((short)(0));
			this.BESS_ALMW.ValMinimum = ((short)(0));
			this.BESS_ALMW.ValUnits = null;
			this.BESS_ALMW.EndInit();
			// 
			// TRF_ALMW
			// 
			this.TRF_ALMW.BeginInit();
			this.TRF_ALMW.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 906D, 468D);
			this.TRF_ALMW.Name = "TRF_ALMW";
			this.TRF_ALMW.SecurityToken = ((uint)(4294967295u));
			this.TRF_ALMW.TagName = "CDD00681371A006B.ALMW";
			this.TRF_ALMW.Val = ((short)(0));
			this.TRF_ALMW.ValMaximum = ((short)(0));
			this.TRF_ALMW.ValMinimum = ((short)(0));
			this.TRF_ALMW.ValUnits = null;
			this.TRF_ALMW.EndInit();
			// 
			// GRID_ALMW
			// 
			this.GRID_ALMW.BeginInit();
			this.GRID_ALMW.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 812D, 326D);
			this.GRID_ALMW.Name = "GRID_ALMW";
			this.GRID_ALMW.SecurityToken = ((uint)(4294967295u));
			this.GRID_ALMW.TagName = "E36D42F6A0F6E534.ALMW";
			this.GRID_ALMW.Val = ((short)(0));
			this.GRID_ALMW.ValMaximum = ((short)(0));
			this.GRID_ALMW.ValMinimum = ((short)(0));
			this.GRID_ALMW.ValUnits = null;
			this.GRID_ALMW.EndInit();
			// 
			// PPC_ALMW
			// 
			this.PPC_ALMW.BeginInit();
			this.PPC_ALMW.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 826D, 390D);
			this.PPC_ALMW.Name = "PPC_ALMW";
			this.PPC_ALMW.SecurityToken = ((uint)(4294967295u));
			this.PPC_ALMW.TagName = "0CF0789E63BFF5DF.ALMW";
			this.PPC_ALMW.Val = ((short)(0));
			this.PPC_ALMW.ValMaximum = ((short)(0));
			this.PPC_ALMW.ValMinimum = ((short)(0));
			this.PPC_ALMW.ValUnits = null;
			this.PPC_ALMW.EndInit();
			// 
			// INV_ASPCMD
			// 
			this.INV_ASPCMD.BeginInit();
			this.INV_ASPCMD.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 624D, 436D);
			this.INV_ASPCMD.Name = "INV_ASPCMD";
			this.INV_ASPCMD.SecurityToken = ((uint)(4294967295u));
			this.INV_ASPCMD.TagName = "5E480FF9B2E2F1AF.ASP";
			this.INV_ASPCMD.Val = 0F;
			this.INV_ASPCMD.ValDecimalPlaces = ((byte)(0));
			this.INV_ASPCMD.ValMaximum = 0F;
			this.INV_ASPCMD.ValMinimum = 0F;
			this.INV_ASPCMD.ValUnits = null;
			this.INV_ASPCMD.EndInit();
			// 
			// BESS_IDIS
			// 
			this.BESS_IDIS.BeginInit();
			this.BESS_IDIS.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 1268D, 564D);
			this.BESS_IDIS.Name = "BESS_IDIS";
			this.BESS_IDIS.SecurityToken = ((uint)(4294967295u));
			this.BESS_IDIS.TagName = "7AFB420086732019.IDIS";
			this.BESS_IDIS.Val = false;
			this.BESS_IDIS.EndInit();
			// 
			// BESS_ICHG
			// 
			this.BESS_ICHG.BeginInit();
			this.BESS_ICHG.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 666D, 614D);
			this.BESS_ICHG.Name = "BESS_ICHG";
			this.BESS_ICHG.SecurityToken = ((uint)(4294967295u));
			this.BESS_ICHG.TagName = "7AFB420086732019.ICHG";
			this.BESS_ICHG.Val = false;
			this.BESS_ICHG.EndInit();
			// 
			// BESS_PBAT
			// 
			this.BESS_PBAT.BeginInit();
			this.BESS_PBAT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 576D, 802D);
			this.BESS_PBAT.Name = "BESS_PBAT";
			this.BESS_PBAT.SecurityToken = ((uint)(4294967295u));
			this.BESS_PBAT.TagName = "7AFB420086732019.PBAT";
			this.BESS_PBAT.Val = 0F;
			this.BESS_PBAT.ValDecimalPlaces = ((byte)(0));
			this.BESS_PBAT.ValMaximum = 0F;
			this.BESS_PBAT.ValMinimum = 0F;
			this.BESS_PBAT.ValUnits = null;
			this.BESS_PBAT.EndInit();
			// 
			// PPC_IMPLIM
			// 
			this.PPC_IMPLIM.BeginInit();
			this.PPC_IMPLIM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 528D, 538D);
			this.PPC_IMPLIM.Name = "PPC_IMPLIM";
			this.PPC_IMPLIM.SecurityToken = ((uint)(4294967295u));
			this.PPC_IMPLIM.TagName = "0CF0789E63BFF5DF.IMPLIM";
			this.PPC_IMPLIM.Val = 0F;
			this.PPC_IMPLIM.ValDecimalPlaces = ((byte)(0));
			this.PPC_IMPLIM.ValMaximum = 0F;
			this.PPC_IMPLIM.ValMinimum = 0F;
			this.PPC_IMPLIM.ValUnits = null;
			this.PPC_IMPLIM.EndInit();
			// 
			// PPC_EXPLIM
			// 
			this.PPC_EXPLIM.BeginInit();
			this.PPC_EXPLIM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 1050D, 560D);
			this.PPC_EXPLIM.Name = "PPC_EXPLIM";
			this.PPC_EXPLIM.SecurityToken = ((uint)(4294967295u));
			this.PPC_EXPLIM.TagName = "0CF0789E63BFF5DF.EXPLIM";
			this.PPC_EXPLIM.Val = 0F;
			this.PPC_EXPLIM.ValDecimalPlaces = ((byte)(0));
			this.PPC_EXPLIM.ValMaximum = 0F;
			this.PPC_EXPLIM.ValMinimum = 0F;
			this.PPC_EXPLIM.ValUnits = null;
			this.PPC_EXPLIM.EndInit();
			// 
			// sPL_DCC_INV
			// 
			this.sPL_DCC_INV.BeginInit();
			this.sPL_DCC_INV.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 288D, 450D);
			this.sPL_DCC_INV.LinkDescription = "DCC001 -> INV001";
			this.sPL_DCC_INV.LinkType = HMI.Main.Graphics.sPowerLink.PowerLinkType.DC;
			this.sPL_DCC_INV.Name = "sPL_DCC_INV";
			this.sPL_DCC_INV.ShowEndNodes = true;
			this.sPL_DCC_INV.EndInit();
			// 
			// sPL_PV_DCC
			// 
			this.sPL_PV_DCC.BeginInit();
			this.sPL_PV_DCC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 138D, 658D);
			this.sPL_PV_DCC.EndX = 15D;
			this.sPL_PV_DCC.LinkDescription = "PV001 -> DCC001";
			this.sPL_PV_DCC.LinkType = HMI.Main.Graphics.sPowerLink.PowerLinkType.DC;
			this.sPL_PV_DCC.Name = "sPL_PV_DCC";
			this.sPL_PV_DCC.ShowEndNodes = true;
			this.sPL_PV_DCC.StartY = 114D;
			this.sPL_PV_DCC.EndInit();
			// 
			// sPL_TRF_GRID
			// 
			this.sPL_TRF_GRID.BeginInit();
			this.sPL_TRF_GRID.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 987D, 450D);
			this.sPL_TRF_GRID.LinkDescription = "TRF001 -> GRID01";
			this.sPL_TRF_GRID.LinkType = HMI.Main.Graphics.sPowerLink.PowerLinkType.AC;
			this.sPL_TRF_GRID.Name = "sPL_TRF_GRID";
			this.sPL_TRF_GRID.ShowEndNodes = true;
			this.sPL_TRF_GRID.EndInit();
			// 
			// sTL_DCC
			// 
			this.sTL_DCC.BeginInit();
			this.sTL_DCC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 161D, 658D);
			this.sTL_DCC.EndX = 15D;
			this.sTL_DCC.LinkDescription = "DCC001 Tele";
			this.sTL_DCC.LinkType = HMI.Main.Graphics.sPowerLink.PowerLinkType.Telemetry;
			this.sTL_DCC.MidX = 40D;
			this.sTL_DCC.MidY = 80D;
			this.sTL_DCC.Name = "sTL_DCC";
			this.sTL_DCC.StartY = 80D;
			this.sTL_DCC.EndInit();
			// 
			// sTL_PV
			// 
			this.sTL_PV.BeginInit();
			this.sTL_PV.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 161D, 722D);
			this.sTL_PV.EndX = 15D;
			this.sTL_PV.EndY = 50D;
			this.sTL_PV.LinkDescription = "PV001 Tele";
			this.sTL_PV.LinkType = HMI.Main.Graphics.sPowerLink.PowerLinkType.Telemetry;
			this.sTL_PV.Name = "sTL_PV";
			this.sTL_PV.EndInit();
			// 
			// sTL_BD
			// 
			this.sTL_BD.BeginInit();
			this.sTL_BD.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 479D, 722D);
			this.sTL_BD.EndX = 15D;
			this.sTL_BD.EndY = 50D;
			this.sTL_BD.LinkDescription = "BD001 Tele";
			this.sTL_BD.LinkType = HMI.Main.Graphics.sPowerLink.PowerLinkType.Telemetry;
			this.sTL_BD.Name = "sTL_BD";
			this.sTL_BD.EndInit();
			// 
			// sTL_INV
			// 
			this.sTL_INV.BeginInit();
			this.sTL_INV.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 574D, 658D);
			this.sTL_INV.EndX = 15D;
			this.sTL_INV.EndY = 80D;
			this.sTL_INV.LinkDescription = "INV001 Tele";
			this.sTL_INV.LinkType = HMI.Main.Graphics.sPowerLink.PowerLinkType.Telemetry;
			this.sTL_INV.Name = "sTL_INV";
			this.sTL_INV.EndInit();
			// 
			// sTL_TRF
			// 
			this.sTL_TRF.BeginInit();
			this.sTL_TRF.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 917D, 658D);
			this.sTL_TRF.EndX = 15D;
			this.sTL_TRF.EndY = 80D;
			this.sTL_TRF.LinkDescription = "TRF001 Tele";
			this.sTL_TRF.LinkType = HMI.Main.Graphics.sPowerLink.PowerLinkType.Telemetry;
			this.sTL_TRF.Name = "sTL_TRF";
			this.sTL_TRF.EndInit();
			// 
			// sTL_BESS
			// 
			this.sTL_BESS.BeginInit();
			this.sTL_BESS.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 828D, 722D);
			this.sTL_BESS.EndX = 15D;
			this.sTL_BESS.EndY = 50D;
			this.sTL_BESS.LinkDescription = "BESS001 Tele";
			this.sTL_BESS.LinkType = HMI.Main.Graphics.sPowerLink.PowerLinkType.Telemetry;
			this.sTL_BESS.Name = "sTL_BESS";
			this.sTL_BESS.EndInit();
			// 
			// sTL_GRID
			// 
			this.sTL_GRID.BeginInit();
			this.sTL_GRID.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 1209D, 658D);
			this.sTL_GRID.EndX = 15D;
			this.sTL_GRID.EndY = 80D;
			this.sTL_GRID.LinkDescription = "GRID01 Tele";
			this.sTL_GRID.LinkType = HMI.Main.Graphics.sPowerLink.PowerLinkType.Telemetry;
			this.sTL_GRID.Name = "sTL_GRID";
			this.sTL_GRID.EndInit();
			// 
			// sPL_INV_AC
			// 
			this.sPL_INV_AC.BeginInit();
			this.sPL_INV_AC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 510D, 658D);
			this.sPL_INV_AC.EndX = 15D;
			this.sPL_INV_AC.EndY = 59D;
			this.sPL_INV_AC.LinkDescription = "INV001 -> AC Bus";
			this.sPL_INV_AC.LinkType = HMI.Main.Graphics.sPowerLink.PowerLinkType.AC;
			this.sPL_INV_AC.Name = "sPL_INV_AC";
			this.sPL_INV_AC.ShowEndNodes = true;
			this.sPL_INV_AC.EndInit();
			// 
			// sPL_AC
			// 
			this.sPL_AC.BeginInit();
			this.sPL_AC.AnimationEnabled = false;
			this.sPL_AC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 510D, 702D);
			this.sPL_AC.EndX = 394D;
			this.sPL_AC.LinkDescription = "INV001 -> AC Bus";
			this.sPL_AC.LinkType = HMI.Main.Graphics.sPowerLink.PowerLinkType.AC;
			this.sPL_AC.Name = "sPL_AC";
			this.sPL_AC.ShowEndNodes = true;
			this.sPL_AC.EndInit();
			// 
			// SPL_TRF_AC
			// 
			this.SPL_TRF_AC.BeginInit();
			this.SPL_TRF_AC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 859D, 658D);
			this.SPL_TRF_AC.EndX = 15D;
			this.SPL_TRF_AC.EndY = 59D;
			this.SPL_TRF_AC.LinkDescription = "TRF001 -> AC Bus";
			this.SPL_TRF_AC.LinkType = HMI.Main.Graphics.sPowerLink.PowerLinkType.AC;
			this.SPL_TRF_AC.Name = "SPL_TRF_AC";
			this.SPL_TRF_AC.ReverseFlow = true;
			this.SPL_TRF_AC.ShowEndNodes = true;
			this.SPL_TRF_AC.EndInit();
			// 
			// sPL_BD_AC
			// 
			this.sPL_BD_AC.BeginInit();
			this.sPL_BD_AC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 539D, 703D);
			this.sPL_BD_AC.EndX = 15D;
			this.sPL_BD_AC.EndY = 69D;
			this.sPL_BD_AC.LinkDescription = "BD001 -> AC Bus";
			this.sPL_BD_AC.LinkType = HMI.Main.Graphics.sPowerLink.PowerLinkType.AC;
			this.sPL_BD_AC.Name = "sPL_BD_AC";
			this.sPL_BD_AC.ShowEndNodes = true;
			this.sPL_BD_AC.EndInit();
			// 
			// sPL_BESS_AC
			// 
			this.sPL_BESS_AC.BeginInit();
			this.sPL_BESS_AC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 889D, 703D);
			this.sPL_BESS_AC.EndX = 15D;
			this.sPL_BESS_AC.EndY = 69D;
			this.sPL_BESS_AC.LinkDescription = "BESS001 -> AC Bus";
			this.sPL_BESS_AC.LinkType = HMI.Main.Graphics.sPowerLink.PowerLinkType.AC;
			this.sPL_BESS_AC.Name = "sPL_BESS_AC";
			this.sPL_BESS_AC.ReverseFlow = true;
			this.sPL_BESS_AC.ShowEndNodes = true;
			this.sPL_BESS_AC.EndInit();
			// 
			// sTL_Main
			// 
			this.sTL_Main.BeginInit();
			this.sTL_Main.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 161D, 722D);
			this.sTL_Main.EndX = 15D;
			this.sTL_Main.LinkDescription = "DCC001 Tele";
			this.sTL_Main.LinkType = HMI.Main.Graphics.sPowerLink.PowerLinkType.Telemetry;
			this.sTL_Main.MidX = 40D;
			this.sTL_Main.MidY = 80D;
			this.sTL_Main.Name = "sTL_Main";
			this.sTL_Main.StartX = 1063D;
			this.sTL_Main.EndInit();
			// 
			// sTL_PPC
			// 
			this.sTL_PPC.BeginInit();
			this.sTL_PPC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 1209D, 722D);
			this.sTL_PPC.EndX = 15D;
			this.sTL_PPC.EndY = 50D;
			this.sTL_PPC.LinkDescription = "PPC Tele";
			this.sTL_PPC.LinkType = HMI.Main.Graphics.sPowerLink.PowerLinkType.Telemetry;
			this.sTL_PPC.Name = "sTL_PPC";
			this.sTL_PPC.EndInit();
			// 
			// BD001_QLT
			// 
			this.BD001_QLT.BeginInit();
			this.BD001_QLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 541D, 887D);
			this.BD001_QLT.Name = "BD001_QLT";
			this.BD001_QLT.SecurityToken = ((uint)(4294967295u));
			this.BD001_QLT.TagName = "33CEE1A0B9E70BC4.QLT";
			this.BD001_QLT.Val = false;
			this.BD001_QLT.EndInit();
			// 
			// BESS01_QLT
			// 
			this.BESS01_QLT.BeginInit();
			this.BESS01_QLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 427D, 741D);
			this.BESS01_QLT.Name = "BESS01_QLT";
			this.BESS01_QLT.SecurityToken = ((uint)(4294967295u));
			this.BESS01_QLT.TagName = "7AFB420086732019.QLT";
			this.BESS01_QLT.Val = false;
			this.BESS01_QLT.EndInit();
			// 
			// DCC001_QLT
			// 
			this.DCC001_QLT.BeginInit();
			this.DCC001_QLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 639D, 807D);
			this.DCC001_QLT.Name = "DCC001_QLT";
			this.DCC001_QLT.SecurityToken = ((uint)(4294967295u));
			this.DCC001_QLT.TagName = "852155B2A9F8687F.QLT";
			this.DCC001_QLT.Val = false;
			this.DCC001_QLT.EndInit();
			// 
			// GRID01_QLT
			// 
			this.GRID01_QLT.BeginInit();
			this.GRID01_QLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 657D, 917D);
			this.GRID01_QLT.Name = "GRID01_QLT";
			this.GRID01_QLT.SecurityToken = ((uint)(4294967295u));
			this.GRID01_QLT.TagName = "E36D42F6A0F6E534.QLT";
			this.GRID01_QLT.Val = false;
			this.GRID01_QLT.EndInit();
			// 
			// INV001_QLT
			// 
			this.INV001_QLT.BeginInit();
			this.INV001_QLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 680D, 810D);
			this.INV001_QLT.Name = "INV001_QLT";
			this.INV001_QLT.SecurityToken = ((uint)(4294967295u));
			this.INV001_QLT.TagName = "5E480FF9B2E2F1AF.QLT";
			this.INV001_QLT.Val = false;
			this.INV001_QLT.EndInit();
			// 
			// INV001_PAC
			// 
			this.INV001_PAC.BeginInit();
			this.INV001_PAC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 691D, 623D);
			this.INV001_PAC.Name = "INV001_PAC";
			this.INV001_PAC.SecurityToken = ((uint)(4294967295u));
			this.INV001_PAC.TagName = "5E480FF9B2E2F1AF.PAC";
			this.INV001_PAC.Val = 0F;
			this.INV001_PAC.ValDecimalPlaces = ((byte)(0));
			this.INV001_PAC.ValMaximum = 0F;
			this.INV001_PAC.ValMinimum = 0F;
			this.INV001_PAC.ValUnits = null;
			this.INV001_PAC.EndInit();
			// 
			// DCC001_PDC
			// 
			this.DCC001_PDC.BeginInit();
			this.DCC001_PDC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 316D, 611D);
			this.DCC001_PDC.Name = "DCC001_PDC";
			this.DCC001_PDC.SecurityToken = ((uint)(4294967295u));
			this.DCC001_PDC.TagName = "852155B2A9F8687F.PDC";
			this.DCC001_PDC.Val = 0F;
			this.DCC001_PDC.ValDecimalPlaces = ((byte)(0));
			this.DCC001_PDC.ValMaximum = 0F;
			this.DCC001_PDC.ValMinimum = 0F;
			this.DCC001_PDC.ValUnits = null;
			this.DCC001_PDC.EndInit();
			// 
			// BESS01_PBAT
			// 
			this.BESS01_PBAT.BeginInit();
			this.BESS01_PBAT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 729D, 740D);
			this.BESS01_PBAT.Name = "BESS01_PBAT";
			this.BESS01_PBAT.SecurityToken = ((uint)(4294967295u));
			this.BESS01_PBAT.TagName = "7AFB420086732019.PBAT";
			this.BESS01_PBAT.Val = 0F;
			this.BESS01_PBAT.ValDecimalPlaces = ((byte)(0));
			this.BESS01_PBAT.ValMaximum = 0F;
			this.BESS01_PBAT.ValMinimum = 0F;
			this.BESS01_PBAT.ValUnits = null;
			this.BESS01_PBAT.EndInit();
			// 
			// BD001_PLOAD
			// 
			this.BD001_PLOAD.BeginInit();
			this.BD001_PLOAD.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 676D, 740D);
			this.BD001_PLOAD.Name = "BD001_PLOAD";
			this.BD001_PLOAD.SecurityToken = ((uint)(4294967295u));
			this.BD001_PLOAD.TagName = "33CEE1A0B9E70BC4.LOADP";
			this.BD001_PLOAD.Val = 0F;
			this.BD001_PLOAD.ValDecimalPlaces = ((byte)(0));
			this.BD001_PLOAD.ValMaximum = 0F;
			this.BD001_PLOAD.ValMinimum = 0F;
			this.BD001_PLOAD.ValUnits = null;
			this.BD001_PLOAD.EndInit();
			// 
			// PPC001_QLT
			// 
			this.PPC001_QLT.BeginInit();
			this.PPC001_QLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 1019D, 844D);
			this.PPC001_QLT.Name = "PPC001_QLT";
			this.PPC001_QLT.SecurityToken = ((uint)(4294967295u));
			this.PPC001_QLT.TagName = "0CF0789E63BFF5DF.QLT";
			this.PPC001_QLT.Val = false;
			this.PPC001_QLT.EndInit();
			// 
			// PV001_PDC
			// 
			this.PV001_PDC.BeginInit();
			this.PV001_PDC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 344D, 784D);
			this.PV001_PDC.Name = "PV001_PDC";
			this.PV001_PDC.SecurityToken = ((uint)(4294967295u));
			this.PV001_PDC.TagName = "B567E00A3BDDC9DA.PDC";
			this.PV001_PDC.Val = 0F;
			this.PV001_PDC.ValDecimalPlaces = ((byte)(0));
			this.PV001_PDC.ValMaximum = 0F;
			this.PV001_PDC.ValMinimum = 0F;
			this.PV001_PDC.ValUnits = null;
			this.PV001_PDC.EndInit();
			// 
			// PV001_QLT
			// 
			this.PV001_QLT.BeginInit();
			this.PV001_QLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 323D, 803D);
			this.PV001_QLT.Name = "PV001_QLT";
			this.PV001_QLT.SecurityToken = ((uint)(4294967295u));
			this.PV001_QLT.TagName = "B567E00A3BDDC9DA.QLT";
			this.PV001_QLT.Val = false;
			this.PV001_QLT.EndInit();
			// 
			// TRF001_QLT
			// 
			this.TRF001_QLT.BeginInit();
			this.TRF001_QLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 330D, 643D);
			this.TRF001_QLT.Name = "TRF001_QLT";
			this.TRF001_QLT.SecurityToken = ((uint)(4294967295u));
			this.TRF001_QLT.TagName = "CDD00681371A006B.QLT";
			this.TRF001_QLT.Val = false;
			this.TRF001_QLT.EndInit();
			// 
			// TRF001_PMV
			// 
			this.TRF001_PMV.BeginInit();
			this.TRF001_PMV.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 379D, 643D);
			this.TRF001_PMV.Name = "TRF001_PMV";
			this.TRF001_PMV.SecurityToken = ((uint)(4294967295u));
			this.TRF001_PMV.TagName = "CDD00681371A006B.PMV";
			this.TRF001_PMV.Val = 0F;
			this.TRF001_PMV.ValDecimalPlaces = ((byte)(0));
			this.TRF001_PMV.ValMaximum = 0F;
			this.TRF001_PMV.ValMinimum = 0F;
			this.TRF001_PMV.ValUnits = null;
			this.TRF001_PMV.EndInit();
			// 
			// TRF001_PLV
			// 
			this.TRF001_PLV.BeginInit();
			this.TRF001_PLV.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 301D, 630D);
			this.TRF001_PLV.Name = "TRF001_PLV";
			this.TRF001_PLV.SecurityToken = ((uint)(4294967295u));
			this.TRF001_PLV.TagName = "CDD00681371A006B.PLV";
			this.TRF001_PLV.Val = 0F;
			this.TRF001_PLV.ValDecimalPlaces = ((byte)(0));
			this.TRF001_PLV.ValMaximum = 0F;
			this.TRF001_PLV.ValMinimum = 0F;
			this.TRF001_PLV.ValUnits = null;
			this.TRF001_PLV.EndInit();
			// 
			// line1
			// 
			this.line1.EndPoint = new NxtControl.Drawing.PointF(100D, 1030D);
			this.line1.Name = "line1";
			this.line1.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(216)), ((byte)(178)), ((byte)(50))), 2F, NxtControl.Drawing.DashStyle.Solid);
			this.line1.StartPoint = new NxtControl.Drawing.PointF(50D, 1030D);
			// 
			// label1
			// 
			this.label1.AngleIgnore = true;
			this.label1.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label1.Bounds = new NxtControl.Drawing.RectF(((float)(112D)), ((float)(1017D)), ((float)(89D)), ((float)(26D)));
			this.label1.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.label1.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.label1.FontScale = true;
			this.label1.Name = "label1";
			this.label1.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label1.Text = "DC Power";
			this.label1.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.label1.TextAutoSizeHorizontalOffset = 10;
			this.label1.TextColor = new NxtControl.Drawing.Color(((byte)(238)), ((byte)(243)), ((byte)(241)));
			this.label1.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// line2
			// 
			this.line2.EndPoint = new NxtControl.Drawing.PointF(281D, 1030D);
			this.line2.Name = "line2";
			this.line2.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(226)), ((byte)(104)), ((byte)(43))), 2F, NxtControl.Drawing.DashStyle.Solid);
			this.line2.StartPoint = new NxtControl.Drawing.PointF(231D, 1030D);
			// 
			// label2
			// 
			this.label2.AngleIgnore = true;
			this.label2.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label2.Bounds = new NxtControl.Drawing.RectF(((float)(293D)), ((float)(1017D)), ((float)(89D)), ((float)(26D)));
			this.label2.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.label2.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.label2.FontScale = true;
			this.label2.Name = "label2";
			this.label2.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label2.Text = "AC Power";
			this.label2.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.label2.TextAutoSizeHorizontalOffset = 10;
			this.label2.TextColor = new NxtControl.Drawing.Color(((byte)(238)), ((byte)(243)), ((byte)(241)));
			this.label2.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// line3
			// 
			this.line3.EndPoint = new NxtControl.Drawing.PointF(462D, 1030D);
			this.line3.Name = "line3";
			this.line3.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(45)), ((byte)(128)), ((byte)(112))), 2F, NxtControl.Drawing.DashStyle.Dash);
			this.line3.StartPoint = new NxtControl.Drawing.PointF(412D, 1030D);
			// 
			// label3
			// 
			this.label3.AngleIgnore = true;
			this.label3.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label3.Bounds = new NxtControl.Drawing.RectF(((float)(474D)), ((float)(1017D)), ((float)(89D)), ((float)(26D)));
			this.label3.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.label3.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.label3.FontScale = true;
			this.label3.Name = "label3";
			this.label3.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label3.Text = "Telemetry";
			this.label3.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.label3.TextAutoSizeHorizontalOffset = 10;
			this.label3.TextColor = new NxtControl.Drawing.Color(((byte)(238)), ((byte)(243)), ((byte)(241)));
			this.label3.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// line4
			// 
			this.line4.EndPoint = new NxtControl.Drawing.PointF(643D, 1030D);
			this.line4.Name = "line4";
			this.line4.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(73)), ((byte)(84)), ((byte)(81))), 2F, NxtControl.Drawing.DashStyle.Solid);
			this.line4.StartPoint = new NxtControl.Drawing.PointF(593D, 1030D);
			// 
			// label4
			// 
			this.label4.AngleIgnore = true;
			this.label4.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label4.Bounds = new NxtControl.Drawing.RectF(((float)(655D)), ((float)(1017D)), ((float)(174D)), ((float)(26D)));
			this.label4.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.label4.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.label4.FontScale = true;
			this.label4.Name = "label4";
			this.label4.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label4.Text = "Inactive / Offline";
			this.label4.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.label4.TextAutoSizeHorizontalOffset = 10;
			this.label4.TextColor = new NxtControl.Drawing.Color(((byte)(238)), ((byte)(243)), ((byte)(241)));
			this.label4.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// TRF001_IFLT
			// 
			this.TRF001_IFLT.BeginInit();
			this.TRF001_IFLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 636D, 525D);
			this.TRF001_IFLT.Name = "TRF001_IFLT";
			this.TRF001_IFLT.SecurityToken = ((uint)(4294967295u));
			this.TRF001_IFLT.TagName = "CDD00681371A006B.IFLT";
			this.TRF001_IFLT.Val = false;
			this.TRF001_IFLT.EndInit();
			// 
			// PV001_IFLT
			// 
			this.PV001_IFLT.BeginInit();
			this.PV001_IFLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 340D, 511D);
			this.PV001_IFLT.Name = "PV001_IFLT";
			this.PV001_IFLT.SecurityToken = ((uint)(4294967295u));
			this.PV001_IFLT.TagName = "B567E00A3BDDC9DA.IFLT";
			this.PV001_IFLT.Val = false;
			this.PV001_IFLT.EndInit();
			// 
			// PPC001_IFLT
			// 
			this.PPC001_IFLT.BeginInit();
			this.PPC001_IFLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 340D, 532D);
			this.PPC001_IFLT.Name = "PPC001_IFLT";
			this.PPC001_IFLT.SecurityToken = ((uint)(4294967295u));
			this.PPC001_IFLT.TagName = "0CF0789E63BFF5DF.IFLT";
			this.PPC001_IFLT.Val = false;
			this.PPC001_IFLT.EndInit();
			// 
			// GRID01_IFLT
			// 
			this.GRID01_IFLT.BeginInit();
			this.GRID01_IFLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 332D, 512D);
			this.GRID01_IFLT.Name = "GRID01_IFLT";
			this.GRID01_IFLT.SecurityToken = ((uint)(4294967295u));
			this.GRID01_IFLT.TagName = "E36D42F6A0F6E534.IFLT";
			this.GRID01_IFLT.Val = false;
			this.GRID01_IFLT.EndInit();
			// 
			// INV001_IRUN
			// 
			this.INV001_IRUN.BeginInit();
			this.INV001_IRUN.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 345D, 610D);
			this.INV001_IRUN.Name = "INV001_IRUN";
			this.INV001_IRUN.SecurityToken = ((uint)(4294967295u));
			this.INV001_IRUN.TagName = "5E480FF9B2E2F1AF.IRUN";
			this.INV001_IRUN.Val = false;
			this.INV001_IRUN.EndInit();
			// 
			// INV001_IFLT
			// 
			this.INV001_IFLT.BeginInit();
			this.INV001_IFLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 374D, 566D);
			this.INV001_IFLT.Name = "INV001_IFLT";
			this.INV001_IFLT.SecurityToken = ((uint)(4294967295u));
			this.INV001_IFLT.TagName = "5E480FF9B2E2F1AF.IFLT";
			this.INV001_IFLT.Val = false;
			this.INV001_IFLT.EndInit();
			// 
			// DCC001_IFLT
			// 
			this.DCC001_IFLT.BeginInit();
			this.DCC001_IFLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 325D, 546D);
			this.DCC001_IFLT.Name = "DCC001_IFLT";
			this.DCC001_IFLT.SecurityToken = ((uint)(4294967295u));
			this.DCC001_IFLT.TagName = "852155B2A9F8687F.IFLT";
			this.DCC001_IFLT.Val = false;
			this.DCC001_IFLT.EndInit();
			// 
			// BESS01_IFLT
			// 
			this.BESS01_IFLT.BeginInit();
			this.BESS01_IFLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 316D, 525D);
			this.BESS01_IFLT.Name = "BESS01_IFLT";
			this.BESS01_IFLT.SecurityToken = ((uint)(4294967295u));
			this.BESS01_IFLT.TagName = "7AFB420086732019.IFLT";
			this.BESS01_IFLT.Val = false;
			this.BESS01_IFLT.EndInit();
			// 
			// roundedRectangle3
			// 
			this.roundedRectangle3.Bounds = new NxtControl.Drawing.RectF(((float)(1831D)), ((float)(577D)), ((float)(40D)), ((float)(40D)));
			this.roundedRectangle3.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(12)), ((byte)(35)), ((byte)(33))));
			this.roundedRectangle3.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.roundedRectangle3.ImageBytes = resources.GetString("roundedRectangle3.ImageBytes");
			this.roundedRectangle3.Name = "roundedRectangle3";
			this.roundedRectangle3.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(37)), ((byte)(64)), ((byte)(61))), 1F, NxtControl.Drawing.DashStyle.Solid);
			this.roundedRectangle3.Radius = 8D;
			// 
			// sNavigation1
			// 
			this.sNavigation1.BeginInit();
			this.sNavigation1.ButtonText = "Dashboard";
			this.sNavigation1.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 1772D, 31D);
			this.sNavigation1.HoverBackgroundColor = new NxtControl.Drawing.Color(((byte)(18)), ((byte)(45)), ((byte)(42)));
			this.sNavigation1.HoverBorderColor = new NxtControl.Drawing.Color(((byte)(54)), ((byte)(91)), ((byte)(84)));
			this.sNavigation1.Name = "sNavigation1";
			this.sNavigation1.OffBackgroundColor = new NxtControl.Drawing.Color(((byte)(12)), ((byte)(35)), ((byte)(33)));
			this.sNavigation1.OffBorderColor = new NxtControl.Drawing.Color(((byte)(37)), ((byte)(64)), ((byte)(61)));
			this.sNavigation1.OnBackgroundColor = new NxtControl.Drawing.Color(((byte)(18)), ((byte)(67)), ((byte)(42)));
			this.sNavigation1.OnBorderColor = new NxtControl.Drawing.Color(((byte)(61)), ((byte)(205)), ((byte)(88)));
			this.sNavigation1.Value = true;
			this.sNavigation1.EndInit();
			// 
			// sNavigation2
			// 
			this.sNavigation2.BeginInit();
			this.sNavigation2.ButtonText = "Architecture";
			this.sNavigation2.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 1636D, 31D);
			this.sNavigation2.HoverBackgroundColor = new NxtControl.Drawing.Color(((byte)(18)), ((byte)(45)), ((byte)(42)));
			this.sNavigation2.HoverBorderColor = new NxtControl.Drawing.Color(((byte)(54)), ((byte)(91)), ((byte)(84)));
			this.sNavigation2.Name = "sNavigation2";
			this.sNavigation2.OffBackgroundColor = new NxtControl.Drawing.Color(((byte)(12)), ((byte)(35)), ((byte)(33)));
			this.sNavigation2.OffBorderColor = new NxtControl.Drawing.Color(((byte)(37)), ((byte)(64)), ((byte)(61)));
			this.sNavigation2.OnBackgroundColor = new NxtControl.Drawing.Color(((byte)(18)), ((byte)(67)), ((byte)(42)));
			this.sNavigation2.OnBorderColor = new NxtControl.Drawing.Color(((byte)(61)), ((byte)(205)), ((byte)(88)));
			this.sNavigation2.Click += new System.EventHandler(this.SNavigation2Click);
			this.sNavigation2.EndInit();
			// 
			// ControlPage
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(1920D)), ((float)(1080D)));
			this.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(2)), ((byte)(12)), ((byte)(12))));
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.roundedRectangle1,
			this.rectBtn,
			this.freeText1,
			this.freeText2,
			this.PV001_1,
			this.PV001_2,
			this.INV001_1,
			this.GRID01_1,
			this.PPC001_1,
			this.PPC001_2,
			this.PPC001,
			this.DCC001,
			this.PV001,
			this.BESS01,
			this.BD001,
			this.INV001,
			this.TRA001,
			this.GRID01,
			this.freeText3,
			this.SIM001,
			this.Mqtt_SoftdPAC,
			this.freeText4,
			this.SIM001_1,
			this.rectangle1,
			this.roundedRectangle2,
			this.freeText5,
			this.freeText6,
			this.dataGridView1,
			this.PV_IRR,
			this.DCC_ALMW,
			this.INV_ALMW,
			this.LOAD_ALMW,
			this.BESS_ALMW,
			this.TRF_ALMW,
			this.GRID_ALMW,
			this.PPC_ALMW,
			this.INV_ASPCMD,
			this.BESS_IDIS,
			this.BESS_ICHG,
			this.BESS_PBAT,
			this.PPC_IMPLIM,
			this.PPC_EXPLIM,
			this.sPL_DCC_INV,
			this.sPL_PV_DCC,
			this.sPL_TRF_GRID,
			this.sTL_DCC,
			this.sTL_PV,
			this.sTL_BD,
			this.sTL_INV,
			this.sTL_TRF,
			this.sTL_BESS,
			this.sTL_GRID,
			this.sTL_Main,
			this.sTL_PPC,
			this.BD001_QLT,
			this.BESS01_QLT,
			this.DCC001_QLT,
			this.GRID01_QLT,
			this.INV001_QLT,
			this.INV001_PAC,
			this.DCC001_PDC,
			this.BESS01_PBAT,
			this.BD001_PLOAD,
			this.PPC001_QLT,
			this.PV001_PDC,
			this.PV001_QLT,
			this.TRF001_QLT,
			this.TRF001_PMV,
			this.TRF001_PLV,
			this.line2,
			this.label2,
			this.line3,
			this.label3,
			this.line4,
			this.label4,
			this.line1,
			this.label1,
			this.TRF001_IFLT,
			this.PV001_IFLT,
			this.PPC001_IFLT,
			this.GRID01_IFLT,
			this.INV001_IRUN,
			this.INV001_IFLT,
			this.DCC001_IFLT,
			this.BESS01_IFLT,
			this.roundedRectangle3,
			this.sNavigation1,
			this.sNavigation2,
			this.sPL_INV_AC,
			this.SPL_TRF_AC,
			this.sPL_BESS_AC,
			this.sPL_BD_AC,
			this.sPL_AC});
			this.Size = new System.Drawing.Size(1920, 1080);
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();

		}
		private HMI.Main.Symbols.acDCCombiner_v1_0.sDefault DCC001;
		private HMI.Main.Symbols.acInverter_v1_0.sDefault INV001;
		private HMI.Main.Symbols.acTransformer_v1_0.sDefault TRA001;
		private HMI.Main.Symbols.acOwnLoad_v1_0.sDefault BD001;
		private HMI.Main.Symbols.acGrid_v1_0.sDefault GRID01;
		private HMI.Main.Symbols.acPVArray_v1_0.sDefault PV001;
		private HMI.Main.Symbols.acPPC_v1_0.sDefault PPC001;
		private HMI.Main.Symbols.acBESS1_v1_0.sDefault BESS01;
		private NxtControl.GuiFramework.FreeText freeText1;
		private NxtControl.GuiFramework.FreeText freeText2;
		private HMI.Main.Symbols.acPVArray_v1_0.sIrradiance PV001_1;
		private HMI.Main.Symbols.acPVArray_v1_0.sPvDcPwr PV001_2;
		private HMI.Main.Symbols.acInverter_v1_0.sAcPwr INV001_1;
		private HMI.Main.Symbols.acGrid_v1_0.sGridPanel GRID01_1;
		private HMI.Main.Symbols.acPPC_v1_0.sPR PPC001_1;
		private HMI.Main.Symbols.acPPC_v1_0.sAvail PPC001_2;
		private NxtControl.GuiFramework.RoundedRectangle rectBtn;
		private NxtControl.GuiFramework.RoundedRectangle roundedRectangle1;
		private NxtControl.GuiFramework.FreeText freeText3;
		private HMI.Main.Symbols.acSimLogic_v1_0.sControl SIM001;
		private SE.Agile.Symbols.MQTT_Connection_v1_0.sDemo Mqtt_SoftdPAC;
		private NxtControl.GuiFramework.FreeText freeText4;
		private HMI.Main.Symbols.acSimLogic_v1_0.sSimulation SIM001_1;
		private NxtControl.GuiFramework.Rectangle rectangle1;
		private NxtControl.GuiFramework.RoundedRectangle roundedRectangle2;
		private NxtControl.GuiFramework.FreeText freeText5;
		private NxtControl.GuiFramework.FreeText freeText6;
		private NxtControl.GuiFramework.DataGridView dataGridView1;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged PV_IRR;
		private SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged DCC_ALMW;
		private SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged INV_ALMW;
		private SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged LOAD_ALMW;
		private SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged BESS_ALMW;
		private SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged TRF_ALMW;
		private SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged GRID_ALMW;
		private SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged PPC_ALMW;
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValChanged INV_ASPCMD;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged BESS_IDIS;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged BESS_ICHG;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged BESS_PBAT;
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValChanged PPC_IMPLIM;
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValChanged PPC_EXPLIM;
		private HMI.Main.Graphics.sPowerLink sPL_DCC_INV;
		private HMI.Main.Graphics.sPowerLink sPL_PV_DCC;
		private HMI.Main.Graphics.sPowerLink sPL_TRF_GRID;
		private HMI.Main.Graphics.sPowerLink sTL_DCC;
		private HMI.Main.Graphics.sPowerLink sTL_PV;
		private HMI.Main.Graphics.sPowerLink sTL_BD;
		private HMI.Main.Graphics.sPowerLink sTL_INV;
		private HMI.Main.Graphics.sPowerLink sTL_TRF;
		private HMI.Main.Graphics.sPowerLink sTL_BESS;
		private HMI.Main.Graphics.sPowerLink sTL_GRID;
		private HMI.Main.Graphics.sPowerLink sPL_INV_AC;
		private HMI.Main.Graphics.sPowerLink sPL_AC;
		private HMI.Main.Graphics.sPowerLink SPL_TRF_AC;
		private HMI.Main.Graphics.sPowerLink sPL_BD_AC;
		private HMI.Main.Graphics.sPowerLink sPL_BESS_AC;
		private HMI.Main.Graphics.sPowerLink sTL_Main;
		private HMI.Main.Graphics.sPowerLink sTL_PPC;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged BD001_QLT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged BESS01_QLT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged DCC001_QLT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged GRID01_QLT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged INV001_QLT;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged INV001_PAC;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged DCC001_PDC;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged BESS01_PBAT;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged BD001_PLOAD;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged PPC001_QLT;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged PV001_PDC;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged PV001_QLT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged TRF001_QLT;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged TRF001_PMV;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged TRF001_PLV;
		private NxtControl.GuiFramework.Line line1;
		private NxtControl.GuiFramework.Label label1;
		private NxtControl.GuiFramework.Line line2;
		private NxtControl.GuiFramework.Label label2;
		private NxtControl.GuiFramework.Line line3;
		private NxtControl.GuiFramework.Label label3;
		private NxtControl.GuiFramework.Line line4;
		private NxtControl.GuiFramework.Label label4;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged TRF001_IFLT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged PV001_IFLT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged PPC001_IFLT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged GRID01_IFLT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged INV001_IRUN;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged INV001_IFLT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged DCC001_IFLT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged BESS01_IFLT;
		private NxtControl.GuiFramework.RoundedRectangle roundedRectangle3;
		private HMI.Main.Graphics.sNavigation sNavigation1;
		private HMI.Main.Graphics.sNavigation sNavigation2;
		#endregion
	}
}
