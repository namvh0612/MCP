﻿/*
 * Common Solar Plant event log controller.
 */

using System;
using System.Collections.Generic;
using System.Windows.Forms;
using HMI.Main.SupportClasses;

using GuiDataGridView =
	NxtControl.GuiFramework.DataGridView;

using GuiColor =
	NxtControl.Drawing.Color;

namespace HMI.Main.SupportClasses
{
	public partial class SolarEventLog
	{
		private const int DEFAULT_MAX_ROWS = 200;
		private const double DEFAULT_TOLERANCE = 0.001;

		private readonly object _syncRoot =
			new object();

		private readonly Dictionary<string, int>
			_previousAlarmWords =
				new Dictionary<string, int>();

		private readonly Dictionary<string, string>
			_previousStates =
				new Dictionary<string, string>();

		private readonly Dictionary<string, bool>
			_previousBoolValues =
				new Dictionary<string, bool>();

		private readonly Dictionary<string, double>
			_previousRealValues =
				new Dictionary<string, double>();

		private GuiDataGridView _grid;

		public int MaxRows
		{
			get;
			set;
		}

		public enum EventPriority
		{
			Info,
			Warning,
			Alarm
		}

		public sealed class AlarmDefinition
		{
			public readonly int Bit;
			public readonly string ActiveText;
			public readonly string ClearText;
			public readonly EventPriority Priority;

			public AlarmDefinition(
				int bit,
				string activeText,
				string clearText,
				EventPriority priority)
			{
				Bit = bit;
				ActiveText = activeText;
				ClearText = clearText;
				Priority = priority;
			}
		}

		public SolarEventLog()
		{
			MaxRows = DEFAULT_MAX_ROWS;
		}

		public SolarEventLog(
			GuiDataGridView grid)
			: this()
		{
			Initialize(grid);
		}

		public void Initialize(
			GuiDataGridView grid)
		{
			_grid = grid;

			ResetTracking();
			ConfigureGrid();
		}

		/* ============================================================= */
		/* Grid configuration                                            */
		/* ============================================================= */

		private void ConfigureGrid()
		{
			if (_grid == null)
				return;

			try
			{
				_grid.Columns.Clear();

				_grid.AutoGenerateColumns = false;
				_grid.AllowUserToAddRows = false;
				_grid.AllowUserToDeleteRows = false;
				_grid.AllowUserToResizeRows = false;
				_grid.AllowUserToOrderColumns = false;
				_grid.ReadOnly = true;
				_grid.MultiSelect = false;
				_grid.RowHeadersVisible = false;
				_grid.EnableHeadersVisualStyles = false;
				_grid.ShowCellToolTips = true;

				_grid.SelectionMode =
					DataGridViewSelectionMode.FullRowSelect;

				_grid.BorderStyle =
					BorderStyle.None;

				_grid.CellBorderStyle =
					DataGridViewCellBorderStyle.SingleHorizontal;

				_grid.ColumnHeadersBorderStyle =
					DataGridViewHeaderBorderStyle.Single;

				_grid.ScrollBars =
					ScrollBars.None;

				_grid.AutoSizeRowsMode =
					DataGridViewAutoSizeRowsMode.None;

				_grid.BackgroundColor =
					SolarTheme.Surface.MainBoard;

				_grid.GridColor =
					SolarTheme.Border.Divider;

				_grid.DefaultCellStyle.BackColor =
					SolarTheme.Surface.MainBoard;

				_grid.DefaultCellStyle.ForeColor =
					SolarTheme.Text.Primary;

				_grid.DefaultCellStyle.SelectionBackColor =
					SolarTheme.Surface.Hover;

				_grid.DefaultCellStyle.SelectionForeColor =
					SolarTheme.Text.Primary;

				_grid.AlternatingRowsDefaultCellStyle.BackColor =
					SolarTheme.Surface.Panel;

				_grid.ColumnHeadersDefaultCellStyle.BackColor =
					SolarTheme.Surface.RaisedPanel;

				_grid.ColumnHeadersDefaultCellStyle.ForeColor =
					SolarTheme.Text.Heading;

				_grid.ColumnHeadersDefaultCellStyle.SelectionBackColor =
					SolarTheme.Surface.RaisedPanel;

				_grid.ColumnHeadersDefaultCellStyle.SelectionForeColor =
					SolarTheme.Text.Heading;

				_grid.RowTemplate.Height = 28;
				_grid.ColumnHeadersHeight = 32;

				_grid.Columns.Add(
					"Timestamp",
					"Timestamp");

				_grid.Columns.Add(
					"Source",
					"Source");

				_grid.Columns.Add(
					"Event",
					"Event");

				_grid.Columns.Add(
					"Priority",
					"Priority");

				_grid.Columns["Timestamp"].Width = 90;
				_grid.Columns["Source"].Width = 60;
				_grid.Columns["Priority"].Width = 82;

				_grid.Columns["Event"].AutoSizeMode =
					DataGridViewAutoSizeColumnMode.Fill;

				for (int i = 0;
					i < _grid.Columns.Count;
					i++)
				{
					_grid.Columns[i].SortMode =
						DataGridViewColumnSortMode.NotSortable;
				}
			}
			catch (Exception exception)
			{
				LogError(
					"Configure grid",
					exception);
			}
		}

		/* ============================================================= */
		/* Alarm word                                                    */
		/* ============================================================= */

		public void UpdateAlarmWord(
			string source,
			object value,
			AlarmDefinition[] definitions)
		{
			if (definitions == null)
				return;

			string safeSource =
				NormalizeText(
					source,
					"System");

			string key =
				safeSource + "|ALMW";

			int currentWord =
				HmiValueHelper.ToInt(value);

			lock (_syncRoot)
			{
				int previousWord;

				if (!_previousAlarmWords.TryGetValue(
					key,
					out previousWord))
				{
					_previousAlarmWords[key] =
						currentWord;

					return;
				}

				int changedBits =
					previousWord ^ currentWord;

				if (changedBits == 0)
					return;

				_previousAlarmWords[key] =
					currentWord;

				for (int i = 0;
					i < definitions.Length;
					i++)
				{
					AlarmDefinition definition =
						definitions[i];

					if (definition == null)
						continue;

					int mask =
						1 << definition.Bit;

					if ((changedBits & mask) == 0)
						continue;

					bool isActive =
						(currentWord & mask) != 0;

					AddEvent(
						safeSource,
						isActive
							? definition.ActiveText
							: definition.ClearText,
						isActive
							? definition.Priority
							: EventPriority.Info);
				}
			}
		}

		/* ============================================================= */
		/* State                                                         */
		/* ============================================================= */

		public void UpdateState(
			string source,
			string stateName,
			string state)
		{
			UpdateState(
				source,
				stateName,
				state,
				EventPriority.Info);
		}

		public void UpdateState(
			string source,
			string stateName,
			string state,
			EventPriority priority)
		{
			string safeSource =
				NormalizeText(
					source,
					"System");

			string safeName =
				NormalizeText(
					stateName,
					"State");

			string currentState =
				NormalizeText(
					state,
					"Unknown");

			string key =
				safeSource
				+ "|STATE|"
				+ safeName;

			lock (_syncRoot)
			{
				string previousState;

				if (!_previousStates.TryGetValue(
					key,
					out previousState))
				{
					_previousStates[key] =
						currentState;

					return;
				}

				if (previousState == currentState)
					return;

				_previousStates[key] =
					currentState;

				AddEvent(
					safeSource,
					safeName
						+ " changed to "
						+ currentState,
					priority);
			}
		}

		/* ============================================================= */
		/* Boolean                                                       */
		/* ============================================================= */

		public void UpdateBoolean(
			string source,
			string keyName,
			object value,
			string trueEvent,
			string falseEvent,
			EventPriority truePriority,
			EventPriority falsePriority)
		{
			string safeSource =
				NormalizeText(
					source,
					"System");

			string safeKey =
				NormalizeText(
					keyName,
					"Boolean");

			string key =
				safeSource
				+ "|BOOL|"
				+ safeKey;

			bool currentValue =
				HmiValueHelper.ToBool(value);

			lock (_syncRoot)
			{
				bool previousValue;

				if (!_previousBoolValues.TryGetValue(
					key,
					out previousValue))
				{
					_previousBoolValues[key] =
						currentValue;

					return;
				}

				if (previousValue == currentValue)
					return;

				_previousBoolValues[key] =
					currentValue;

				AddEvent(
					safeSource,
					currentValue
						? trueEvent
						: falseEvent,
					currentValue
						? truePriority
						: falsePriority);
			}
		}

		public void UpdatePulse(
			string source,
			string keyName,
			object value,
			string eventText,
			EventPriority priority)
		{
			string safeSource =
				NormalizeText(
					source,
					"System");

			string safeKey =
				NormalizeText(
					keyName,
					"Pulse");

			string key =
				safeSource
				+ "|PULSE|"
				+ safeKey;

			bool currentValue =
				HmiValueHelper.ToBool(value);

			lock (_syncRoot)
			{
				bool previousValue;

				if (!_previousBoolValues.TryGetValue(
					key,
					out previousValue))
				{
					_previousBoolValues[key] =
						currentValue;

					return;
				}

				_previousBoolValues[key] =
					currentValue;

				if (currentValue && !previousValue)
				{
					AddEvent(
						safeSource,
						eventText,
						priority);
				}
			}
		}

		/* ============================================================= */
		/* Numeric value                                                  */
		/* ============================================================= */

		public void UpdateValue(
			string source,
			string valueName,
			object value,
			string format,
			string unit)
		{
			UpdateValue(
				source,
				valueName,
				value,
				format,
				unit,
				DEFAULT_TOLERANCE,
				EventPriority.Info);
		}

		public void UpdateValue(
			string source,
			string valueName,
			object value,
			string format,
			string unit,
			double tolerance,
			EventPriority priority)
		{
			double currentValue;

			if (!HmiValueHelper.TryToDouble(
				value,
				out currentValue))
			{
				return;
			}

			string safeSource =
				NormalizeText(
					source,
					"System");

			string safeName =
				NormalizeText(
					valueName,
					"Value");

			string key =
				safeSource
				+ "|VALUE|"
				+ safeName;

			double safeTolerance =
				Math.Abs(tolerance);

			lock (_syncRoot)
			{
				double previousValue;

				if (!_previousRealValues.TryGetValue(
					key,
					out previousValue))
				{
					_previousRealValues[key] =
						currentValue;

					return;
				}

				if (Math.Abs(
					currentValue - previousValue)
					< safeTolerance)
				{
					return;
				}

				_previousRealValues[key] =
					currentValue;

				AddEvent(
					safeSource,
					safeName
						+ " updated to "
						+ FormatValue(
							currentValue,
							format,
							unit),
					priority);
			}
		}

		/* ============================================================= */
		/* Direct log                                                     */
		/* ============================================================= */

		public void AddEvent(
			string source,
			string eventText,
			EventPriority priority)
		{
			try
			{
				if (_grid == null ||
					_grid.IsDisposed)
				{
					return;
				}

				if (_grid.InvokeRequired)
				{
					_grid.BeginInvoke(
						new MethodInvoker(
							delegate
							{
								AddEvent(
									source,
									eventText,
									priority);
							}));

					return;
				}

				string safeSource =
					NormalizeText(
						source,
						"System");

				string safeEvent =
					NormalizeText(
						eventText,
						"--");

				string priorityText =
					priority
						.ToString()
						.ToUpperInvariant();

				string timestamp =
					DateTime.Now.ToString(
						"dd/MM HH:mm:ss");

				_grid.Rows.Insert(
					0,
					timestamp,
					safeSource,
					safeEvent,
					priorityText);

				DataGridViewRow row =
					_grid.Rows[0];

				row.DefaultCellStyle.BackColor =
					SolarTheme.Surface.MainBoard;

				row.DefaultCellStyle.ForeColor =
					SolarTheme.Text.Primary;

				row.Cells["Event"].ToolTipText =
					safeEvent;

				GuiColor priorityColor =
					GetPriorityColor(priority);

				row.Cells["Priority"].Style.ForeColor =
					priorityColor;

				row.Cells["Priority"]
					.Style.SelectionForeColor =
						priorityColor;

				int rowLimit =
					MaxRows > 0
						? MaxRows
						: DEFAULT_MAX_ROWS;

				while (_grid.Rows.Count > rowLimit)
				{
					_grid.Rows.RemoveAt(
						_grid.Rows.Count - 1);
				}
			}
			catch (Exception exception)
			{
				LogError(
					"Add event",
					exception);
			}
		}

		public void ClearRows()
		{
			try
			{
				if (_grid == null ||
					_grid.IsDisposed)
				{
					return;
				}

				if (_grid.InvokeRequired)
				{
					_grid.BeginInvoke(
						new MethodInvoker(
							delegate
							{
								ClearRows();
							}));

					return;
				}

				_grid.Rows.Clear();
			}
			catch (Exception exception)
			{
				LogError(
					"Clear rows",
					exception);
			}
		}

		public void ResetTracking()
		{
			lock (_syncRoot)
			{
				_previousAlarmWords.Clear();
				_previousStates.Clear();
				_previousBoolValues.Clear();
				_previousRealValues.Clear();
			}
		}

		/* ============================================================= */
		/* Helpers                                                        */
		/* ============================================================= */

		private static string FormatValue(
			double value,
			string format,
			string unit)
		{
			string safeFormat =
				string.IsNullOrEmpty(format)
					? "0.##"
					: format;

			string safeUnit =
				unit ?? string.Empty;

			try
			{
				return value.ToString(safeFormat)
					+ safeUnit;
			}
			catch
			{
				return value.ToString()
					+ safeUnit;
			}
		}

		private static string NormalizeText(
			string value,
			string fallback)
		{
			return string.IsNullOrEmpty(value)
				? fallback
				: value;
		}

		private static GuiColor GetPriorityColor(
			EventPriority priority)
		{
			switch (priority)
			{
				case EventPriority.Alarm:
					return SolarTheme.Status.Fault;

				case EventPriority.Warning:
					return SolarTheme.Status.Warning;

				default:
					return SolarTheme.Status.Healthy;
			}
		}

		private static void LogError(
			string operation,
			Exception exception)
		{
			try
			{
				NxtControl.Services.LoggingService.ErrorFormatted(
					"SolarEventLog: {0}. Error: {1}",
					operation,
					exception != null
						? exception.Message
						: "Unknown error");
			}
			catch
			{
				// Prevent logging errors from crashing HMI.
			}
		}
	}
}