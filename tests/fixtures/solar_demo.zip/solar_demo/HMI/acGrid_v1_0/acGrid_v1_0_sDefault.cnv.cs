/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/15/2026
 * Time: 10:35 PM
 */

using System;
using NxtControl.GuiFramework;
using NxtControl.Drawing;
using HMI.Main.SupportClasses;

namespace HMI.Main.Symbols.acGrid_v1_0
{
	public partial class sDefault :
		NxtControl.GuiFramework.HMISymbol
	{
		private const double POWER_DEADBAND = 0.001;
		private const double MIN_GRID_VOLTAGE = 9000.0;
		private const double MAX_GRID_VOLTAGE = 11000.0;
		private const double MIN_GRID_FREQUENCY = 49.0;
		private const double MAX_GRID_FREQUENCY = 51.0;

		private bool _isRectBtnHovered;

		private GridVisualStatus _currentStatus =
			GridVisualStatus.Offline;

		private enum GridVisualStatus
		{
			Offline,
			Fault,
			Alarm,
			Connected,
			Disconnected
		}

		private enum PowerFlow
		{
			Offline,
			Disconnected,
			Invalid,
			Export,
			Import,
			Idle
		}

		public sDefault()
		{
			InitializeComponent();
			AttachEvents();
			UpdateDisplay();
		}

		private void AttachEvents()
		{
			REQ_Fired += REQ_Fired_EventHandler;

			ICONN.OnValChanged += OnValueChanged;
			IALM.OnValChanged += OnValueChanged;
			IFLT.OnValChanged += OnValueChanged;
			QLT.OnValChanged += OnValueChanged;

			PEXP.OnValChanged += OnValueChanged;
			PIMP.OnValChanged += OnValueChanged;
			VMV.OnValChanged += OnValueChanged;
			FRQ.OnValChanged += OnValueChanged;
		}

		private void OnValueChanged(
			object sender,
			EventArgs e)
		{
			UpdateDisplay();
		}

		private void UpdateDisplay()
		{
			_currentStatus = ResolveStatus();

			PowerFlow powerFlow =
				ResolvePowerFlow();

			SolarTheme.EquipmentState equipmentState =
				GetEquipmentState(_currentStatus);

			Color statusColor =
				GetStatusColor(_currentStatus);

			HmiDisplayHelper.DisplayData displayData =
				new HmiDisplayHelper.DisplayData();

			displayData.Status = equipmentState;
			displayData.StatusIndicator = indStatus;
			displayData.CardBorder = rectBtn;
			displayData.CardBackground = rectBase;
			displayData.IsHovered = _isRectBtnHovered;

			displayData.Items =
				new HmiDisplayHelper.DisplayItem[]
				{
					HmiDisplayHelper.CreateText(
						txtStatus,
						GetStatusText(_currentStatus),
						statusColor),

					HmiDisplayHelper.CreateText(
						txtPower,
						GetPowerText(powerFlow),
						GetPowerColor(powerFlow)),

					HmiDisplayHelper.CreateText(
						txtVMV,
						GetVoltageText(),
						GetVoltageColor()),

					HmiDisplayHelper.CreateValue(
						txtFRQ,
						FRQ.Val,
						"0.00",
						" Hz",
						GetFrequencyColor())
				};

			HmiDisplayHelper.Apply(displayData);

			indStatus.BrushColor = statusColor;
			UpdateCardVisual();
		}

		private GridVisualStatus ResolveStatus()
		{
			if (!HmiValueHelper.ToBool(QLT.Val))
			{
				return GridVisualStatus.Offline;
			}

			if (HmiValueHelper.ToBool(IFLT.Val))
			{
				return GridVisualStatus.Fault;
			}

			if (HmiValueHelper.ToBool(IALM.Val))
			{
				return GridVisualStatus.Alarm;
			}

			if (HmiValueHelper.ToBool(ICONN.Val))
			{
				return GridVisualStatus.Connected;
			}

			return GridVisualStatus.Disconnected;
		}

		private SolarTheme.EquipmentState GetEquipmentState(
			GridVisualStatus status)
		{
			switch (status)
			{
				case GridVisualStatus.Fault:
					return SolarTheme.EquipmentState.Fault;

				case GridVisualStatus.Alarm:
					return SolarTheme.EquipmentState.Alarm;

				case GridVisualStatus.Connected:
					return SolarTheme.EquipmentState.Running;

				case GridVisualStatus.Disconnected:
					return SolarTheme.EquipmentState.Standby;

				case GridVisualStatus.Offline:
				default:
					return SolarTheme.EquipmentState.Offline;
			}
		}

		private string GetStatusText(
			GridVisualStatus status)
		{
			switch (status)
			{
				case GridVisualStatus.Fault:
					return "Fault";

				case GridVisualStatus.Alarm:
					return "Alarm";

				case GridVisualStatus.Connected:
					return "Connected";

				case GridVisualStatus.Disconnected:
					return "Disconnected";

				case GridVisualStatus.Offline:
				default:
					return "Offline";
			}
		}

		private Color GetStatusColor(
			GridVisualStatus status)
		{
			return SolarTheme.GetStatusColor(
				GetEquipmentState(status));
		}

		private PowerFlow ResolvePowerFlow()
		{
			if (!HmiValueHelper.ToBool(QLT.Val))
			{
				return PowerFlow.Offline;
			}
			
			if (!HmiValueHelper.ToBool(ICONN.Val))
			{
				return PowerFlow.Disconnected;
			}

			double exportPower =
				HmiValueHelper.ToDouble(PEXP.Val);

			double importPower =
				HmiValueHelper.ToDouble(PIMP.Val);

			if (exportPower < -POWER_DEADBAND ||
				importPower < -POWER_DEADBAND)
			{
				return PowerFlow.Invalid;
			}

			if (exportPower > POWER_DEADBAND &&
				importPower > POWER_DEADBAND)
			{
				return PowerFlow.Invalid;
			}

			if (exportPower > POWER_DEADBAND)
			{
				return PowerFlow.Export;
			}

			if (importPower > POWER_DEADBAND)
			{
				return PowerFlow.Import;
			}

			return PowerFlow.Idle;
		}

		private string GetPowerText(
			PowerFlow powerFlow)
		{
			switch (powerFlow)
			{
				case PowerFlow.Export:
					return HmiValueHelper
						.ToDouble(PEXP.Val)
						.ToString("0.00")
						+ " MW Export";

				case PowerFlow.Import:
					return HmiValueHelper
						.ToDouble(PIMP.Val)
						.ToString("0.00")
						+ " MW Import";

				case PowerFlow.Invalid:
					return "Invalid";

				case PowerFlow.Offline:
					return "0.00 MW Offline";

				case PowerFlow.Idle:
					return "0.00 MW Idle";
					
				case PowerFlow.Disconnected:
					return "Disconnected";

				default:
					return "0.00 MW";
			}
		}

		private Color GetPowerColor(
			PowerFlow powerFlow)
		{
			switch (powerFlow)
			{
				case PowerFlow.Export:
					return SolarTheme.Status.Healthy;

				case PowerFlow.Import:
					return SolarTheme.Flow.AcPower;

				case PowerFlow.Invalid:
					return SolarTheme.Status.Fault;

				case PowerFlow.Idle:
					return SolarTheme.Text.Muted;
				
				case PowerFlow.Disconnected:
					return SolarTheme.Status.Standby;

				case PowerFlow.Offline:
				default:
					return SolarTheme.Status.Offline;
			}
		}

		private string GetVoltageText()
		{
			double voltageKv =
				HmiValueHelper.ToDouble(VMV.Val)
				/ 1000.0;

			return voltageKv.ToString("0.0")
				+ " kV";
		}

		private Color GetVoltageColor()
		{
			if (!HasOnlineMeasurements())
			{
				return SolarTheme.Status.Offline;
			}

			return HmiValueHelper.IsInRange(
				HmiValueHelper.ToDouble(VMV.Val),
				MIN_GRID_VOLTAGE,
				MAX_GRID_VOLTAGE)
					? SolarTheme.Text.Primary
					: SolarTheme.Status.Fault;
		}

		private Color GetFrequencyColor()
		{
			if (!HasOnlineMeasurements())
			{
				return SolarTheme.Status.Offline;
			}

			return HmiValueHelper.IsInRange(
				HmiValueHelper.ToDouble(FRQ.Val),
				MIN_GRID_FREQUENCY,
				MAX_GRID_FREQUENCY)
					? SolarTheme.Text.Primary
					: SolarTheme.Status.Fault;
		}

		private bool HasOnlineMeasurements()
		{
			return HmiValueHelper.ToBool(QLT.Val)
				&& HmiValueHelper.ToBool(ICONN.Val);
		}

		private void UpdateCardVisual()
		{
			HmiDisplayHelper.ApplyStatusCard(
				rectBtn,
				rectBase,
				GetEquipmentState(_currentStatus),
				_isRectBtnHovered);
		}

		private void RectBtnMouseEnter(
			object sender,
			EventArgs e)
		{
			_isRectBtnHovered = true;
			UpdateCardVisual();
		}

		private void RectBtnMouseLeave(
			object sender,
			EventArgs e)
		{
			_isRectBtnHovered = false;
			UpdateCardVisual();
		}

		private void REQ_Fired_EventHandler(
			object sender,
			REQEventArgs e)
		{
			lblSymbol.Text =
				HmiValueHelper.SafeText(
					e.AssetName,
					"Grid");
		}
	}
}