/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/15/2026
 * Time: 11:05 PM
 */

using System;
using NxtControl.GuiFramework;
using NxtControl.Drawing;
using HMI.Main.SupportClasses;

namespace HMI.Main.Faceplates.acGrid_v1_0
{
	public partial class fMain :
		NxtControl.GuiFramework.HMIFaceplate
	{
		private const double REACTIVE_POWER_DEADBAND = 0.001;

		private GridVisualStatus _currentStatus =
			GridVisualStatus.Offline;

		private enum GridVisualStatus
		{
			Offline,
			Fault,
			Alarm,
			Connected,
			Disconnected
		}

		public fMain()
		{
			InitializeComponent();
			AttachEvents();
			UpdateDisplay();
		}

		private void AttachEvents()
		{
			REQ_Fired += REQ_Fired_EventHandler;

			ICONN.OnValChanged += OnGridValueChanged;
			IALM.OnValChanged += OnGridValueChanged;
			IFLT.OnValChanged += OnGridValueChanged;
			QLT.OnValChanged += OnGridValueChanged;

			QGRID.OnValChanged += OnGridValueChanged;
			PF.OnValChanged += OnGridValueChanged;
			EEXP.OnValChanged += OnGridValueChanged;
			EIMP.OnValChanged += OnGridValueChanged;
		}

		private void OnGridValueChanged(
			object sender,
			EventArgs e)
		{
			UpdateDisplay();
		}

		private void UpdateDisplay()
		{
			_currentStatus = ResolveStatus();

			Color valueColor =
				GetValueColor(_currentStatus);

			HmiDisplayHelper.DisplayData displayData =
				new HmiDisplayHelper.DisplayData();

			displayData.Status =
				GetEquipmentState(_currentStatus);

			displayData.Items =
				new HmiDisplayHelper.DisplayItem[]
				{
					HmiDisplayHelper.CreateText(
						txtStatus,
						GetStatusText(_currentStatus),
						GetStatusColor(_currentStatus)),

					HmiDisplayHelper.CreateValue(
						txtQGRID,
						QGRID.Val,
						"0.00",
						" MVAr",
						valueColor),

					HmiDisplayHelper.CreateText(
						txtPF,
						GetPowerFactorText(
							PF.Val,
							QGRID.Val),
						valueColor),

					HmiDisplayHelper.CreateValue(
						txtEEXP,
						EEXP.Val,
						"0.00",
						" MWh",
						valueColor),

					HmiDisplayHelper.CreateValue(
						txtEIMP,
						EIMP.Val,
						"0.00",
						" MWh",
						valueColor)
				};

			HmiDisplayHelper.Apply(displayData);
		}

		private GridVisualStatus ResolveStatus()
		{
			if (!HmiValueHelper.ToBool(QLT.Val))
			{
				return GridVisualStatus.Offline;
			}

			if (HmiValueHelper.ToBool(IFLT.Val))
			{
				return GridVisualStatus.Fault;
			}

			if (HmiValueHelper.ToBool(IALM.Val))
			{
				return GridVisualStatus.Alarm;
			}

			if (HmiValueHelper.ToBool(ICONN.Val))
			{
				return GridVisualStatus.Connected;
			}

			return GridVisualStatus.Disconnected;
		}

		private SolarTheme.EquipmentState GetEquipmentState(
			GridVisualStatus status)
		{
			switch (status)
			{
				case GridVisualStatus.Fault:
					return SolarTheme.EquipmentState.Fault;

				case GridVisualStatus.Alarm:
					return SolarTheme.EquipmentState.Alarm;

				case GridVisualStatus.Connected:
					return SolarTheme.EquipmentState.Running;

				case GridVisualStatus.Disconnected:
					return SolarTheme.EquipmentState.Standby;

				case GridVisualStatus.Offline:
				default:
					return SolarTheme.EquipmentState.Offline;
			}
		}

		private string GetStatusText(
			GridVisualStatus status)
		{
			switch (status)
			{
				case GridVisualStatus.Fault:
					return "Fault";

				case GridVisualStatus.Alarm:
					return "Alarm";

				case GridVisualStatus.Connected:
					return "Connected";

				case GridVisualStatus.Disconnected:
					return "Disconnected";

				case GridVisualStatus.Offline:
				default:
					return "Offline";
			}
		}

		private Color GetStatusColor(
			GridVisualStatus status)
		{
			return SolarTheme.GetStatusColor(
				GetEquipmentState(status));
		}

		private Color GetValueColor(
			GridVisualStatus status)
		{
			switch (status)
			{
				case GridVisualStatus.Fault:
					return SolarTheme.Status.Fault;

				case GridVisualStatus.Disconnected:
					return SolarTheme.Status.Standby;
				
				case GridVisualStatus.Offline:
					return SolarTheme.Status.Offline;

				default:
					return SolarTheme.Text.Primary;
			}
		}

		private string GetPowerFactorText(
			object powerFactorValue,
			object reactivePowerValue)
		{
			double powerFactor =
				Math.Abs(
					HmiValueHelper.ToDouble(
						powerFactorValue));

			powerFactor =
				HmiValueHelper.Clamp(
					powerFactor,
					0.0,
					1.0);

			return powerFactor.ToString("0.00")
				+ GetLeadLag(reactivePowerValue);
		}

		private string GetLeadLag(
			object reactivePowerValue)
		{
			double reactivePower =
				HmiValueHelper.ToDouble(
					reactivePowerValue);

			if (reactivePower >
				REACTIVE_POWER_DEADBAND)
			{
				return " Lag";
			}

			if (reactivePower <
				-REACTIVE_POWER_DEADBAND)
			{
				return " Lead";
			}

			return " Unity";
		}

		private void REQ_Fired_EventHandler(
			object sender,
			HMI.Main.Symbols.acGrid_v1_0.REQEventArgs e)
		{
			Title =
				HmiValueHelper.SafeText(
					e.AssetName,
					"Grid");

			UpdateDisplay();
		}
	}
}