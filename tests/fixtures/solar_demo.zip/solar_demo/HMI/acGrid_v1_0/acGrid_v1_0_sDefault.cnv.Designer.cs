/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/15/2026
 * Time: 10:35 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.acGrid_v1_0
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sDefault
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(sDefault));
			this.rectangle1 = new NxtControl.GuiFramework.Rectangle();
			this.lblSymbol = new NxtControl.GuiFramework.Label();
			this.txtStatus = new NxtControl.GuiFramework.Label();
			this.indStatus = new NxtControl.GuiFramework.Ellipse();
			this.txtPower = new NxtControl.GuiFramework.Label();
			this.freeText5 = new NxtControl.GuiFramework.FreeText();
			this.txtVMV = new NxtControl.GuiFramework.Label();
			this.freeText6 = new NxtControl.GuiFramework.FreeText();
			this.line2 = new NxtControl.GuiFramework.Line();
			this.line3 = new NxtControl.GuiFramework.Line();
			this.txtFRQ = new NxtControl.GuiFramework.Label();
			this.freeText12 = new NxtControl.GuiFramework.FreeText();
			this.line4 = new NxtControl.GuiFramework.Line();
			this.rectBtn = new NxtControl.GuiFramework.RoundedRectangle();
			this.rectBase = new NxtControl.GuiFramework.RoundedRectangle();
			this.PIMP = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.FRQ = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.IFLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IALM = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.ICONN = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.PEXP = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.QLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.VMV = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			// 
			// rectangle1
			// 
			this.rectangle1.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(53D)), ((float)(240D)), ((float)(240D)));
			this.rectangle1.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle1.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle1.ImageBytes = resources.GetString("rectangle1.ImageBytes");
			this.rectangle1.Name = "rectangle1";
			this.rectangle1.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// lblSymbol
			// 
			this.lblSymbol.AngleIgnore = true;
			this.lblSymbol.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.lblSymbol.Bounds = new NxtControl.Drawing.RectF(((float)(11D)), ((float)(12D)), ((float)(141D)), ((float)(24D)));
			this.lblSymbol.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.lblSymbol.Font = new NxtControl.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
			this.lblSymbol.FontScale = true;
			this.lblSymbol.Name = "lblSymbol";
			this.lblSymbol.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.lblSymbol.Text = "Grid";
			this.lblSymbol.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.lblSymbol.TextAutoSizeHorizontalOffset = 10;
			this.lblSymbol.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.lblSymbol.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// txtStatus
			// 
			this.txtStatus.AngleIgnore = true;
			this.txtStatus.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtStatus.Bounds = new NxtControl.Drawing.RectF(((float)(154D)), ((float)(16D)), ((float)(78D)), ((float)(16D)));
			this.txtStatus.Brush = new NxtControl.Drawing.Brush(true);
			this.txtStatus.Font = new NxtControl.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular);
			this.txtStatus.FontScale = true;
			this.txtStatus.Name = "txtStatus";
			this.txtStatus.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtStatus.Text = "Connected";
			this.txtStatus.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.txtStatus.TextAutoSizeHorizontalOffset = 10;
			this.txtStatus.TextColor = new NxtControl.Drawing.Color(((byte)(120)), ((byte)(249)), ((byte)(141)));
			this.txtStatus.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// indStatus
			// 
			this.indStatus.Bounds = new NxtControl.Drawing.RectF(((float)(144D)), ((float)(19D)), ((float)(10D)), ((float)(10D)));
			this.indStatus.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(120)), ((byte)(249)), ((byte)(141))));
			this.indStatus.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.indStatus.Name = "indStatus";
			this.indStatus.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// txtPower
			// 
			this.txtPower.AngleIgnore = true;
			this.txtPower.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtPower.Bounds = new NxtControl.Drawing.RectF(((float)(104D)), ((float)(319D)), ((float)(123D)), ((float)(20D)));
			this.txtPower.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtPower.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtPower.FontScale = true;
			this.txtPower.Name = "txtPower";
			this.txtPower.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtPower.Text = "3.91 MW Export";
			this.txtPower.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtPower.TextAutoSizeHorizontalOffset = 10;
			this.txtPower.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtPower.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText5
			// 
			this.freeText5.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText5.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText5.Location = new NxtControl.Drawing.PointF(11D, 320D);
			this.freeText5.Name = "freeText5";
			this.freeText5.Text = "Grid Power";
			// 
			// txtVMV
			// 
			this.txtVMV.AngleIgnore = true;
			this.txtVMV.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtVMV.Bounds = new NxtControl.Drawing.RectF(((float)(131D)), ((float)(351D)), ((float)(96D)), ((float)(20D)));
			this.txtVMV.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtVMV.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtVMV.FontScale = true;
			this.txtVMV.Name = "txtVMV";
			this.txtVMV.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtVMV.Text = "10.0 kV";
			this.txtVMV.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtVMV.TextAutoSizeHorizontalOffset = 10;
			this.txtVMV.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtVMV.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText6
			// 
			this.freeText6.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText6.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText6.Location = new NxtControl.Drawing.PointF(11D, 352D);
			this.freeText6.Name = "freeText6";
			this.freeText6.Text = "Grid Voltage";
			// 
			// line2
			// 
			this.line2.EndPoint = new NxtControl.Drawing.PointF(239D, 313D);
			this.line2.Name = "line2";
			this.line2.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(20)), ((byte)(54)), ((byte)(45))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line2.StartPoint = new NxtControl.Drawing.PointF(2D, 313D);
			// 
			// line3
			// 
			this.line3.EndPoint = new NxtControl.Drawing.PointF(239D, 345D);
			this.line3.Name = "line3";
			this.line3.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(20)), ((byte)(54)), ((byte)(45))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line3.StartPoint = new NxtControl.Drawing.PointF(2D, 345D);
			// 
			// txtFRQ
			// 
			this.txtFRQ.AngleIgnore = true;
			this.txtFRQ.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtFRQ.Bounds = new NxtControl.Drawing.RectF(((float)(131D)), ((float)(382D)), ((float)(96D)), ((float)(20D)));
			this.txtFRQ.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtFRQ.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtFRQ.FontScale = true;
			this.txtFRQ.Name = "txtFRQ";
			this.txtFRQ.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtFRQ.Text = "49.98 Hz";
			this.txtFRQ.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtFRQ.TextAutoSizeHorizontalOffset = 10;
			this.txtFRQ.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtFRQ.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText12
			// 
			this.freeText12.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText12.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText12.Location = new NxtControl.Drawing.PointF(11D, 383D);
			this.freeText12.Name = "freeText12";
			this.freeText12.Text = "Frequency";
			// 
			// line4
			// 
			this.line4.EndPoint = new NxtControl.Drawing.PointF(239D, 376D);
			this.line4.Name = "line4";
			this.line4.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(20)), ((byte)(54)), ((byte)(45))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line4.StartPoint = new NxtControl.Drawing.PointF(2D, 376D);
			// 
			// rectBtn
			// 
			this.rectBtn.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(240D)), ((float)(412D)));
			this.rectBtn.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("Transparent"));
			this.rectBtn.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectBtn.Name = "rectBtn";
			this.rectBtn.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fMain", NxtControl.GuiFramework.MouseButtonType.Click));
			this.rectBtn.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(28)), ((byte)(78)), ((byte)(71))), 1F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Flat, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Round, null);
			this.rectBtn.Radius = 10D;
			this.rectBtn.MouseEnter += new System.EventHandler(this.RectBtnMouseEnter);
			this.rectBtn.MouseLeave += new System.EventHandler(this.RectBtnMouseLeave);
			// 
			// rectBase
			// 
			this.rectBase.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(240D)), ((float)(412D)));
			this.rectBase.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(3)), ((byte)(22)), ((byte)(20))));
			this.rectBase.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectBase.Name = "rectBase";
			this.rectBase.Pen = new NxtControl.Drawing.Pen("Transparent");
			this.rectBase.Radius = 10D;
			// 
			// PIMP
			// 
			this.PIMP.BeginInit();
			this.PIMP.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 63D, 208D);
			this.PIMP.Name = "PIMP";
			this.PIMP.SecurityToken = ((uint)(4294967295u));
			this.PIMP.TagName = "PIMP";
			this.PIMP.Val = 0F;
			this.PIMP.ValDecimalPlaces = ((byte)(0));
			this.PIMP.ValMaximum = 0F;
			this.PIMP.ValMinimum = 0F;
			this.PIMP.ValUnits = null;
			this.PIMP.EndInit();
			// 
			// FRQ
			// 
			this.FRQ.BeginInit();
			this.FRQ.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 62D, 152D);
			this.FRQ.Name = "FRQ";
			this.FRQ.SecurityToken = ((uint)(4294967295u));
			this.FRQ.TagName = "FRQ";
			this.FRQ.Val = 0F;
			this.FRQ.ValDecimalPlaces = ((byte)(0));
			this.FRQ.ValMaximum = 0F;
			this.FRQ.ValMinimum = 0F;
			this.FRQ.ValUnits = null;
			this.FRQ.EndInit();
			// 
			// IFLT
			// 
			this.IFLT.BeginInit();
			this.IFLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 82D, 189D);
			this.IFLT.Name = "IFLT";
			this.IFLT.SecurityToken = ((uint)(4294967295u));
			this.IFLT.TagName = "IFLT";
			this.IFLT.Val = false;
			this.IFLT.EndInit();
			// 
			// IALM
			// 
			this.IALM.BeginInit();
			this.IALM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 82D, 161D);
			this.IALM.Name = "IALM";
			this.IALM.SecurityToken = ((uint)(4294967295u));
			this.IALM.TagName = "IALM";
			this.IALM.Val = false;
			this.IALM.EndInit();
			// 
			// ICONN
			// 
			this.ICONN.BeginInit();
			this.ICONN.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 157D, 165D);
			this.ICONN.Name = "ICONN";
			this.ICONN.SecurityToken = ((uint)(4294967295u));
			this.ICONN.TagName = "ICONN";
			this.ICONN.Val = false;
			this.ICONN.EndInit();
			// 
			// PEXP
			// 
			this.PEXP.BeginInit();
			this.PEXP.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 191D, 206D);
			this.PEXP.Name = "PEXP";
			this.PEXP.SecurityToken = ((uint)(4294967295u));
			this.PEXP.TagName = "PEXP";
			this.PEXP.Val = 0F;
			this.PEXP.ValDecimalPlaces = ((byte)(0));
			this.PEXP.ValMaximum = 0F;
			this.PEXP.ValMinimum = 0F;
			this.PEXP.ValUnits = null;
			this.PEXP.EndInit();
			// 
			// QLT
			// 
			this.QLT.BeginInit();
			this.QLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 152D, 289D);
			this.QLT.Name = "QLT";
			this.QLT.SecurityToken = ((uint)(4294967295u));
			this.QLT.TagName = "QLT";
			this.QLT.Val = false;
			this.QLT.EndInit();
			// 
			// VMV
			// 
			this.VMV.BeginInit();
			this.VMV.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 47D, 224D);
			this.VMV.Name = "VMV";
			this.VMV.SecurityToken = ((uint)(4294967295u));
			this.VMV.TagName = "VMV";
			this.VMV.Val = 0F;
			this.VMV.ValDecimalPlaces = ((byte)(0));
			this.VMV.ValMaximum = 0F;
			this.VMV.ValMinimum = 0F;
			this.VMV.ValUnits = null;
			this.VMV.EndInit();
			// 
			// sDefault
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.rectBase,
			this.rectangle1,
			this.lblSymbol,
			this.txtStatus,
			this.indStatus,
			this.txtPower,
			this.freeText5,
			this.txtVMV,
			this.freeText6,
			this.line2,
			this.line3,
			this.txtFRQ,
			this.freeText12,
			this.line4,
			this.PIMP,
			this.FRQ,
			this.IFLT,
			this.IALM,
			this.ICONN,
			this.PEXP,
			this.QLT,
			this.VMV,
			this.rectBtn});
			this.SymbolSize = new System.Drawing.Size(584, 520);

		}
		private NxtControl.GuiFramework.Rectangle rectangle1;
		private NxtControl.GuiFramework.Label lblSymbol;
		private NxtControl.GuiFramework.Label txtStatus;
		private NxtControl.GuiFramework.Ellipse indStatus;
		private NxtControl.GuiFramework.Label txtPower;
		private NxtControl.GuiFramework.FreeText freeText5;
		private NxtControl.GuiFramework.Label txtVMV;
		private NxtControl.GuiFramework.FreeText freeText6;
		private NxtControl.GuiFramework.Line line2;
		private NxtControl.GuiFramework.Line line3;
		private NxtControl.GuiFramework.Label txtFRQ;
		private NxtControl.GuiFramework.FreeText freeText12;
		private NxtControl.GuiFramework.Line line4;
		private NxtControl.GuiFramework.RoundedRectangle rectBtn;
		private NxtControl.GuiFramework.RoundedRectangle rectBase;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged PIMP;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged FRQ;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IFLT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IALM;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged ICONN;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged PEXP;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged QLT;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged VMV;
		#endregion
	}
}