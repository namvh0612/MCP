/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/15/2026
 * Time: 11:05 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using NxtControl.GuiFramework;

namespace HMI.Main.Faceplates.acGrid_v1_0
{
	/// <summary>
	/// Summary description for fMain.
	/// </summary>
	partial class fMain
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fMain));
			this.txtQGRID = new NxtControl.GuiFramework.Label();
			this.txtPF = new NxtControl.GuiFramework.Label();
			this.txtEEXP = new NxtControl.GuiFramework.Label();
			this.freeText1 = new NxtControl.GuiFramework.FreeText();
			this.freeText2 = new NxtControl.GuiFramework.FreeText();
			this.freeText3 = new NxtControl.GuiFramework.FreeText();
			this.txtStatus = new NxtControl.GuiFramework.Label();
			this.freeText7 = new NxtControl.GuiFramework.FreeText();
			this.txtEIMP = new NxtControl.GuiFramework.Label();
			this.freeText8 = new NxtControl.GuiFramework.FreeText();
			this.rectangle1 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle2 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle3 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle4 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle5 = new NxtControl.GuiFramework.Rectangle();
			this.freeText4 = new NxtControl.GuiFramework.FreeText();
			this.line3 = new NxtControl.GuiFramework.Line();
			this.sButtonNavDemo1 = new SE.Agile.Symbols.Broadcaster_v1_0.sButtonNavDemo();
			this.QGRID = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.PF = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.EEXP = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.EIMP = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.IALM = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.ICONN = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IFLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.QLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			// 
			// txtQGRID
			// 
			this.txtQGRID.AngleIgnore = true;
			this.txtQGRID.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtQGRID.Bounds = new NxtControl.Drawing.RectF(((float)(129D)), ((float)(47D)), ((float)(83D)), ((float)(14D)));
			this.txtQGRID.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtQGRID.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtQGRID.FontScale = true;
			this.txtQGRID.Name = "txtQGRID";
			this.txtQGRID.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtQGRID.Text = "0.25 MVAr";
			this.txtQGRID.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtQGRID.TextAutoSizeHorizontalOffset = 10;
			this.txtQGRID.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtQGRID.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// txtPF
			// 
			this.txtPF.AngleIgnore = true;
			this.txtPF.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtPF.Bounds = new NxtControl.Drawing.RectF(((float)(129D)), ((float)(77D)), ((float)(83D)), ((float)(14D)));
			this.txtPF.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtPF.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtPF.FontScale = true;
			this.txtPF.Name = "txtPF";
			this.txtPF.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtPF.Text = "0.99 Lag";
			this.txtPF.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtPF.TextAutoSizeHorizontalOffset = 10;
			this.txtPF.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtPF.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// txtEEXP
			// 
			this.txtEEXP.AngleIgnore = true;
			this.txtEEXP.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtEEXP.Bounds = new NxtControl.Drawing.RectF(((float)(120D)), ((float)(107D)), ((float)(92D)), ((float)(14D)));
			this.txtEEXP.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtEEXP.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtEEXP.FontScale = true;
			this.txtEEXP.Name = "txtEEXP";
			this.txtEEXP.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtEEXP.Text = "18.42 MWh";
			this.txtEEXP.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtEEXP.TextAutoSizeHorizontalOffset = 10;
			this.txtEEXP.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtEEXP.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText1
			// 
			this.freeText1.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText1.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText1.Location = new NxtControl.Drawing.PointF(40D, 45D);
			this.freeText1.Name = "freeText1";
			this.freeText1.Text = "Reactive Pwr";
			// 
			// freeText2
			// 
			this.freeText2.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText2.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText2.Location = new NxtControl.Drawing.PointF(40D, 75D);
			this.freeText2.Name = "freeText2";
			this.freeText2.Text = "Power Factor";
			// 
			// freeText3
			// 
			this.freeText3.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText3.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText3.Location = new NxtControl.Drawing.PointF(40D, 105D);
			this.freeText3.Name = "freeText3";
			this.freeText3.Text = "Export Today";
			// 
			// txtStatus
			// 
			this.txtStatus.AngleIgnore = true;
			this.txtStatus.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtStatus.Bounds = new NxtControl.Drawing.RectF(((float)(120D)), ((float)(17D)), ((float)(92D)), ((float)(14D)));
			this.txtStatus.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtStatus.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtStatus.FontScale = true;
			this.txtStatus.Name = "txtStatus";
			this.txtStatus.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fAlarm", NxtControl.GuiFramework.MouseButtonType.Click));
			this.txtStatus.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtStatus.Text = "Healthy";
			this.txtStatus.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtStatus.TextAutoSizeHorizontalOffset = 10;
			this.txtStatus.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtStatus.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText7
			// 
			this.freeText7.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText7.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText7.Location = new NxtControl.Drawing.PointF(40D, 15D);
			this.freeText7.Name = "freeText7";
			this.freeText7.Text = "Status";
			// 
			// txtEIMP
			// 
			this.txtEIMP.AngleIgnore = true;
			this.txtEIMP.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtEIMP.Bounds = new NxtControl.Drawing.RectF(((float)(120D)), ((float)(139D)), ((float)(92D)), ((float)(14D)));
			this.txtEIMP.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtEIMP.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtEIMP.FontScale = true;
			this.txtEIMP.Name = "txtEIMP";
			this.txtEIMP.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtEIMP.Text = "0.64 MWh";
			this.txtEIMP.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtEIMP.TextAutoSizeHorizontalOffset = 10;
			this.txtEIMP.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtEIMP.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText8
			// 
			this.freeText8.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText8.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText8.Location = new NxtControl.Drawing.PointF(40D, 137D);
			this.freeText8.Name = "freeText8";
			this.freeText8.Text = "Import Today";
			// 
			// rectangle1
			// 
			this.rectangle1.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(16D)), ((float)(16D)), ((float)(16D)));
			this.rectangle1.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle1.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle1.ImageBytes = resources.GetString("rectangle1.ImageBytes");
			this.rectangle1.Name = "rectangle1";
			this.rectangle1.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle2
			// 
			this.rectangle2.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(46D)), ((float)(16D)), ((float)(16D)));
			this.rectangle2.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle2.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle2.ImageBytes = resources.GetString("rectangle2.ImageBytes");
			this.rectangle2.Name = "rectangle2";
			this.rectangle2.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle3
			// 
			this.rectangle3.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(76D)), ((float)(16D)), ((float)(16D)));
			this.rectangle3.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle3.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle3.ImageBytes = resources.GetString("rectangle3.ImageBytes");
			this.rectangle3.Name = "rectangle3";
			this.rectangle3.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle4
			// 
			this.rectangle4.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(106D)), ((float)(16D)), ((float)(16D)));
			this.rectangle4.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle4.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle4.ImageBytes = resources.GetString("rectangle4.ImageBytes");
			this.rectangle4.Name = "rectangle4";
			this.rectangle4.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle5
			// 
			this.rectangle5.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(138D)), ((float)(16D)), ((float)(16D)));
			this.rectangle5.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle5.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle5.ImageBytes = resources.GetString("rectangle5.ImageBytes");
			this.rectangle5.Name = "rectangle5";
			this.rectangle5.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// freeText4
			// 
			this.freeText4.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText4.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Italic);
			this.freeText4.Location = new NxtControl.Drawing.PointF(14D, 175D);
			this.freeText4.Name = "freeText4";
			this.freeText4.Text = "Connector Info.";
			// 
			// line3
			// 
			this.line3.EndPoint = new NxtControl.Drawing.PointF(227D, 165D);
			this.line3.Name = "line3";
			this.line3.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(20)), ((byte)(54)), ((byte)(45))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line3.StartPoint = new NxtControl.Drawing.PointF(1D, 165D);
			// 
			// sButtonNavDemo1
			// 
			this.sButtonNavDemo1.BeginInit();
			this.sButtonNavDemo1.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 198D, 176D);
			this.sButtonNavDemo1.Name = "sButtonNavDemo1";
			this.sButtonNavDemo1.SecurityToken = ((uint)(4294967295u));
			this.sButtonNavDemo1.TagName = "Grid.Broadcaster_v1_0";
			this.sButtonNavDemo1.EndInit();
			// 
			// QGRID
			// 
			this.QGRID.BeginInit();
			this.QGRID.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 88D, 129D);
			this.QGRID.Name = "QGRID";
			this.QGRID.SecurityToken = ((uint)(4294967295u));
			this.QGRID.TagName = "QGRID";
			this.QGRID.Val = 0F;
			this.QGRID.ValDecimalPlaces = ((byte)(0));
			this.QGRID.ValMaximum = 0F;
			this.QGRID.ValMinimum = 0F;
			this.QGRID.ValUnits = null;
			this.QGRID.EndInit();
			// 
			// PF
			// 
			this.PF.BeginInit();
			this.PF.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 111D, 111D);
			this.PF.Name = "PF";
			this.PF.SecurityToken = ((uint)(4294967295u));
			this.PF.TagName = "PF";
			this.PF.Val = 0F;
			this.PF.ValDecimalPlaces = ((byte)(0));
			this.PF.ValMaximum = 0F;
			this.PF.ValMinimum = 0F;
			this.PF.ValUnits = null;
			this.PF.EndInit();
			// 
			// EEXP
			// 
			this.EEXP.BeginInit();
			this.EEXP.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 81D, 44D);
			this.EEXP.Name = "EEXP";
			this.EEXP.SecurityToken = ((uint)(4294967295u));
			this.EEXP.TagName = "EEXP";
			this.EEXP.Val = 0F;
			this.EEXP.ValDecimalPlaces = ((byte)(0));
			this.EEXP.ValMaximum = 0F;
			this.EEXP.ValMinimum = 0F;
			this.EEXP.ValUnits = null;
			this.EEXP.EndInit();
			// 
			// EIMP
			// 
			this.EIMP.BeginInit();
			this.EIMP.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 101D, 45D);
			this.EIMP.Name = "EIMP";
			this.EIMP.SecurityToken = ((uint)(4294967295u));
			this.EIMP.TagName = "EIMP";
			this.EIMP.Val = 0F;
			this.EIMP.ValDecimalPlaces = ((byte)(0));
			this.EIMP.ValMaximum = 0F;
			this.EIMP.ValMinimum = 0F;
			this.EIMP.ValUnits = null;
			this.EIMP.EndInit();
			// 
			// IALM
			// 
			this.IALM.BeginInit();
			this.IALM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 57D, 91D);
			this.IALM.Name = "IALM";
			this.IALM.SecurityToken = ((uint)(4294967295u));
			this.IALM.TagName = "IALM";
			this.IALM.Val = false;
			this.IALM.EndInit();
			// 
			// ICONN
			// 
			this.ICONN.BeginInit();
			this.ICONN.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 100D, 93D);
			this.ICONN.Name = "ICONN";
			this.ICONN.SecurityToken = ((uint)(4294967295u));
			this.ICONN.TagName = "ICONN";
			this.ICONN.Val = false;
			this.ICONN.EndInit();
			// 
			// IFLT
			// 
			this.IFLT.BeginInit();
			this.IFLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 144D, 102D);
			this.IFLT.Name = "IFLT";
			this.IFLT.SecurityToken = ((uint)(4294967295u));
			this.IFLT.TagName = "IFLT";
			this.IFLT.Val = false;
			this.IFLT.EndInit();
			// 
			// QLT
			// 
			this.QLT.BeginInit();
			this.QLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 55D, 161D);
			this.QLT.Name = "QLT";
			this.QLT.SecurityToken = ((uint)(4294967295u));
			this.QLT.TagName = "QLT";
			this.QLT.Val = false;
			this.QLT.EndInit();
			// 
			// fMain
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(228D)), ((float)(204D)));
			this.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(3)), ((byte)(22)), ((byte)(20))));
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.txtQGRID,
			this.txtPF,
			this.txtEEXP,
			this.freeText1,
			this.freeText2,
			this.freeText3,
			this.txtStatus,
			this.freeText7,
			this.txtEIMP,
			this.freeText8,
			this.rectangle1,
			this.rectangle2,
			this.rectangle3,
			this.rectangle4,
			this.rectangle5,
			this.freeText4,
			this.line3,
			this.sButtonNavDemo1,
			this.QGRID,
			this.PF,
			this.EEXP,
			this.EIMP,
			this.IALM,
			this.ICONN,
			this.IFLT,
			this.QLT});
			this.Size = new System.Drawing.Size(228, 204);

		}
		private NxtControl.GuiFramework.Label txtQGRID;
		private NxtControl.GuiFramework.Label txtPF;
		private NxtControl.GuiFramework.Label txtEEXP;
		private NxtControl.GuiFramework.FreeText freeText1;
		private NxtControl.GuiFramework.FreeText freeText2;
		private NxtControl.GuiFramework.FreeText freeText3;
		private NxtControl.GuiFramework.Label txtStatus;
		private NxtControl.GuiFramework.FreeText freeText7;
		private NxtControl.GuiFramework.Label txtEIMP;
		private NxtControl.GuiFramework.FreeText freeText8;
		private NxtControl.GuiFramework.Rectangle rectangle1;
		private NxtControl.GuiFramework.Rectangle rectangle2;
		private NxtControl.GuiFramework.Rectangle rectangle3;
		private NxtControl.GuiFramework.Rectangle rectangle4;
		private NxtControl.GuiFramework.Rectangle rectangle5;
		private NxtControl.GuiFramework.FreeText freeText4;
		private SE.Agile.Symbols.Broadcaster_v1_0.sButtonNavDemo sButtonNavDemo1;
		private NxtControl.GuiFramework.Line line3;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged QGRID;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged PF;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged EEXP;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged EIMP;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IALM;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged ICONN;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IFLT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged QLT;
		#endregion
	}
}
