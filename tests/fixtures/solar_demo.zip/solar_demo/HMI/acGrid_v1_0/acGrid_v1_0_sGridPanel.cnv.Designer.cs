/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/24/2026
 * Time: 10:29 AM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.acGrid_v1_0
{
	/// <summary>
	/// Summary description for sGridPanle.
	/// </summary>
	partial class sGridPanel
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(sGridPanel));
			this.PIMP = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.PEXP = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.IFLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.QLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.ICONN = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IALM = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.rectBtn = new NxtControl.GuiFramework.RoundedRectangle();
			this.txtData = new NxtControl.GuiFramework.Label();
			this.txtLabel = new NxtControl.GuiFramework.Label();
			this.roundedRectangle1 = new NxtControl.GuiFramework.RoundedRectangle();
			this.symExp = new NxtControl.GuiFramework.Rectangle();
			this.symImp = new NxtControl.GuiFramework.Rectangle();
			this.groupData = new NxtControl.GuiFramework.Group();
			// 
			// PIMP
			// 
			this.PIMP.BeginInit();
			this.PIMP.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 107D, 122D);
			this.PIMP.Name = "PIMP";
			this.PIMP.SecurityToken = ((uint)(4294967295u));
			this.PIMP.TagName = "PIMP";
			this.PIMP.Val = 0F;
			this.PIMP.ValDecimalPlaces = ((byte)(0));
			this.PIMP.ValMaximum = 0F;
			this.PIMP.ValMinimum = 0F;
			this.PIMP.ValUnits = null;
			this.PIMP.EndInit();
			// 
			// PEXP
			// 
			this.PEXP.BeginInit();
			this.PEXP.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 106D, 110D);
			this.PEXP.Name = "PEXP";
			this.PEXP.SecurityToken = ((uint)(4294967295u));
			this.PEXP.TagName = "PEXP";
			this.PEXP.Val = 0F;
			this.PEXP.ValDecimalPlaces = ((byte)(0));
			this.PEXP.ValMaximum = 0F;
			this.PEXP.ValMinimum = 0F;
			this.PEXP.ValUnits = null;
			this.PEXP.EndInit();
			// 
			// IFLT
			// 
			this.IFLT.BeginInit();
			this.IFLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 114D, 115D);
			this.IFLT.Name = "IFLT";
			this.IFLT.SecurityToken = ((uint)(4294967295u));
			this.IFLT.TagName = "IFLT";
			this.IFLT.Val = false;
			this.IFLT.EndInit();
			// 
			// QLT
			// 
			this.QLT.BeginInit();
			this.QLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 77D, 134D);
			this.QLT.Name = "QLT";
			this.QLT.SecurityToken = ((uint)(4294967295u));
			this.QLT.TagName = "QLT";
			this.QLT.Val = false;
			this.QLT.EndInit();
			// 
			// ICONN
			// 
			this.ICONN.BeginInit();
			this.ICONN.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 102D, 103D);
			this.ICONN.Name = "ICONN";
			this.ICONN.SecurityToken = ((uint)(4294967295u));
			this.ICONN.TagName = "ICONN";
			this.ICONN.Val = false;
			this.ICONN.EndInit();
			// 
			// IALM
			// 
			this.IALM.BeginInit();
			this.IALM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 138D, 123D);
			this.IALM.Name = "IALM";
			this.IALM.SecurityToken = ((uint)(4294967295u));
			this.IALM.TagName = "IALM";
			this.IALM.Val = false;
			this.IALM.EndInit();
			// 
			// rectBtn
			// 
			this.rectBtn.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(252D)), ((float)(87D)));
			this.rectBtn.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(8)), ((byte)(28)), ((byte)(27))));
			this.rectBtn.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectBtn.Name = "rectBtn";
			this.rectBtn.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(37)), ((byte)(64)), ((byte)(61))), 1F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Flat, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Round, null);
			this.rectBtn.Radius = 10D;
			// 
			// txtData
			// 
			this.txtData.AngleIgnore = true;
			this.txtData.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtData.Bounds = new NxtControl.Drawing.RectF(((float)(12D)), ((float)(44D)), ((float)(200D)), ((float)(26D)));
			this.txtData.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtData.Font = new NxtControl.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Bold);
			this.txtData.FontScale = true;
			this.txtData.Name = "txtData";
			this.txtData.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtData.Text = "4.00 MW";
			this.txtData.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.txtData.TextAutoSizeHorizontalOffset = 10;
			this.txtData.TextColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.txtData.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// txtLabel
			// 
			this.txtLabel.AngleIgnore = true;
			this.txtLabel.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtLabel.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(12D)), ((float)(200D)), ((float)(26D)));
			this.txtLabel.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtLabel.Font = new NxtControl.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular);
			this.txtLabel.FontScale = true;
			this.txtLabel.Name = "txtLabel";
			this.txtLabel.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtLabel.Text = "Grid Import";
			this.txtLabel.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.txtLabel.TextAutoSizeHorizontalOffset = 10;
			this.txtLabel.TextColor = new NxtControl.Drawing.Color(((byte)(210)), ((byte)(210)), ((byte)(210)));
			this.txtLabel.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// roundedRectangle1
			// 
			this.roundedRectangle1.Bounds = new NxtControl.Drawing.RectF(((float)(212D)), ((float)(8D)), ((float)(30D)), ((float)(30D)));
			this.roundedRectangle1.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(8)), ((byte)(28)), ((byte)(27))));
			this.roundedRectangle1.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.roundedRectangle1.Name = "roundedRectangle1";
			this.roundedRectangle1.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(37)), ((byte)(64)), ((byte)(61))), 1F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Flat, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Round, null);
			this.roundedRectangle1.Radius = 10D;
			// 
			// symExp
			// 
			this.symExp.Bounds = new NxtControl.Drawing.RectF(((float)(215D)), ((float)(11D)), ((float)(24D)), ((float)(24D)));
			this.symExp.Brush = new NxtControl.Drawing.Brush(true);
			this.symExp.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.symExp.ImageBytes = resources.GetString("symExp.ImageBytes");
			this.symExp.Name = "symExp";
			this.symExp.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// symImp
			// 
			this.symImp.Bounds = new NxtControl.Drawing.RectF(((float)(215D)), ((float)(11D)), ((float)(24D)), ((float)(24D)));
			this.symImp.Brush = new NxtControl.Drawing.Brush(true);
			this.symImp.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.symImp.ImageBytes = resources.GetString("symImp.ImageBytes");
			this.symImp.Name = "symImp";
			this.symImp.Pen = new NxtControl.Drawing.Pen("Transparent");
			this.symImp.Visible = false;
			// 
			// groupData
			// 
			this.groupData.BeginInit();
			this.groupData.Name = "groupData";
			this.groupData.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.rectBtn,
			this.txtData,
			this.txtLabel,
			this.roundedRectangle1,
			this.symExp,
			this.symImp});
			this.groupData.MouseEnter += new System.EventHandler(this.GroupDataMouseEnter);
			this.groupData.MouseLeave += new System.EventHandler(this.GroupDataMouseLeave);
			this.groupData.EndInit();
			// 
			// sGridPanel
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.PIMP,
			this.PEXP,
			this.IFLT,
			this.QLT,
			this.ICONN,
			this.IALM,
			this.groupData});
			this.SymbolSize = new System.Drawing.Size(400, 168);

		}
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged PIMP;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged PEXP;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IFLT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged QLT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged ICONN;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IALM;
		private NxtControl.GuiFramework.RoundedRectangle rectBtn;
		private NxtControl.GuiFramework.Label txtData;
		private NxtControl.GuiFramework.Label txtLabel;
		private NxtControl.GuiFramework.RoundedRectangle roundedRectangle1;
		private NxtControl.GuiFramework.Rectangle symExp;
		private NxtControl.GuiFramework.Rectangle symImp;
		private NxtControl.GuiFramework.Group groupData;
		#endregion
	}
}
