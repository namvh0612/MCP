/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/24/2026
 * Time: 10:29 AM
 */

using System;
using NxtControl.GuiFramework;
using NxtControl.Drawing;
using HMI.Main.SupportClasses;

namespace HMI.Main.Symbols.acGrid_v1_0
{
	public partial class sGridPanel :
		NxtControl.GuiFramework.HMISymbol
	{
		private const double POWER_DEADBAND = 0.001;

		private bool _isRectBtnHovered;

		private PowerFlow _powerFlow =
			PowerFlow.Offline;

		private SolarTheme.EquipmentState _currentStatus =
			SolarTheme.EquipmentState.Offline;

		private enum PowerFlow
		{
			Offline,
			Disconnected,
			Invalid,
			Export,
			Import,
			Idle
		}

		public sGridPanel()
		{
			InitializeComponent();
			AttachEvents();
			UpdateDisplay();
		}

		private void AttachEvents()
		{
			ICONN.OnValChanged += OnValueChanged;
			IALM.OnValChanged += OnValueChanged;
			IFLT.OnValChanged += OnValueChanged;
			QLT.OnValChanged += OnValueChanged;

			PEXP.OnValChanged += OnValueChanged;
			PIMP.OnValChanged += OnValueChanged;
		}

		private void OnValueChanged(
			object sender,
			EventArgs e)
		{
			UpdateDisplay();
		}

		private void UpdateDisplay()
		{
			_currentStatus = ResolveStatus();
			_powerFlow = ResolvePowerFlow();

			HmiDisplayHelper.DisplayData displayData =
				new HmiDisplayHelper.DisplayData();

			displayData.Status = _currentStatus;
			displayData.CardBorder = rectBtn;
			displayData.CardBackground = rectBtn;
			displayData.IsHovered = _isRectBtnHovered;

			displayData.Items =
				new HmiDisplayHelper.DisplayItem[]
				{
					HmiDisplayHelper.CreateText(
						txtLabel,
						GetPowerTitle(_powerFlow),
						SolarTheme.Text.Secondary),

					HmiDisplayHelper.CreateText(
						txtData,
						GetPowerText(_powerFlow),
						GetDisplayColor())
				};

			HmiDisplayHelper.Apply(displayData);

			UpdateFlowSymbols();
			UpdateCardVisual();
		}

		private SolarTheme.EquipmentState ResolveStatus()
		{
			return SolarStatusHelper.ResolveStandard(
				QLT.Val,
				IFLT.Val,
				IALM.Val,
				ICONN.Val,
				SolarTheme.EquipmentState.Running,
				SolarTheme.EquipmentState.Standby);
		}

		private PowerFlow ResolvePowerFlow()
		{
			
			if (!HmiValueHelper.ToBool(QLT.Val))
			{
				return PowerFlow.Offline;
			}
			
			if (!HmiValueHelper.ToBool(ICONN.Val))
			{
				return PowerFlow.Disconnected;
			}
			
			double exportPower =
				HmiValueHelper.ToDouble(PEXP.Val);

			double importPower =
				HmiValueHelper.ToDouble(PIMP.Val);

			if (exportPower < -POWER_DEADBAND ||
				importPower < -POWER_DEADBAND)
			{
				return PowerFlow.Invalid;
			}

			if (exportPower > POWER_DEADBAND &&
				importPower > POWER_DEADBAND)
			{
				return PowerFlow.Invalid;
			}

			if (exportPower > POWER_DEADBAND)
			{
				return PowerFlow.Export;
			}

			if (importPower > POWER_DEADBAND)
			{
				return PowerFlow.Import;
			}

			return PowerFlow.Idle;
		}

		private string GetPowerText(
			PowerFlow powerFlow)
		{
			switch (powerFlow)
			{
				case PowerFlow.Export:
					return HmiValueHelper
						.ToDouble(PEXP.Val)
						.ToString("0.00")
						+ " MW";

				case PowerFlow.Import:
					return HmiValueHelper
						.ToDouble(PIMP.Val)
						.ToString("0.00")
						+ " MW";

				case PowerFlow.Invalid:
					return "Invalid";

				case PowerFlow.Offline:
					return "Offline";
					
				case PowerFlow.Disconnected:
					return "Disconnect";

				case PowerFlow.Idle:
					return "0.00 MW";

				default:
					return "--";
			}
		}

		private string GetPowerTitle(
			PowerFlow powerFlow)
		{
			switch (powerFlow)
			{
				case PowerFlow.Export:
					return "Grid Export";

				case PowerFlow.Import:
					return "Grid Import";

				default:
					return "Grid Power";
			}
		}

		private Color GetDisplayColor()
		{
			switch (_currentStatus)
			{
				case SolarTheme.EquipmentState.Fault:
					return SolarTheme.Status.Fault;
		
				case SolarTheme.EquipmentState.Warning:
					return SolarTheme.Status.Warning;
		
				case SolarTheme.EquipmentState.Offline:
				case SolarTheme.EquipmentState.Standby:
					return SolarTheme.Status.Offline;
			}
		
			if (_powerFlow == PowerFlow.Invalid)
			{
				return SolarTheme.Status.Fault;
			}
		
			return SolarTheme.Text.Primary;
		}

		private Color GetPowerColor(
			PowerFlow powerFlow)
		{
			switch (powerFlow)
			{
				case PowerFlow.Import:
					return SolarTheme.Flow.AcPower;
		
				case PowerFlow.Invalid:
					return SolarTheme.Status.Fault;
		
				case PowerFlow.Offline:
					return SolarTheme.Status.Offline;
					
				case PowerFlow.Disconnected:
					return SolarTheme.Status.Standby;
		
				case PowerFlow.Export:
				case PowerFlow.Idle:
				default:
					return SolarTheme.Border.Normal;
			}
		}

		private void UpdateFlowSymbols()
		{
			symExp.Visible =
				_powerFlow != PowerFlow.Import;

			symImp.Visible =
				_powerFlow == PowerFlow.Import;
		}

		private void UpdateCardVisual()
		{
			HmiDisplayHelper.ApplyStatusCard(
				rectBtn,
				rectBtn,
				_currentStatus,
				_isRectBtnHovered);

			if (_currentStatus ==
				SolarTheme.EquipmentState.Running)
			{
				switch (_powerFlow)
				{
					case PowerFlow.Invalid:
						rectBtn.PenColor =
							SolarTheme.Status.Fault;
						break;
			
					case PowerFlow.Import:
						rectBtn.PenColor =
							SolarTheme.Flow.AcPower;
						break;
			
					default:
						rectBtn.PenColor =
							SolarTheme.Border.Normal;
						break;
				}
}
			
			roundedRectangle1.BrushColor =
				_isRectBtnHovered
					? SolarTheme.Surface.RaisedPanel
					: SolarTheme.Surface.Panel;
		
			roundedRectangle1.PenColor =
				_isRectBtnHovered
					? SolarTheme.Border.Hover
					: SolarTheme.Border.Normal;
		
			roundedRectangle1.PenWidth =
				_isRectBtnHovered
					? SolarTheme.Pen.Panel
					: SolarTheme.Pen.Normal;
		}

		private void GroupDataMouseEnter(
			object sender,
			EventArgs e)
		{
			_isRectBtnHovered = true;
			UpdateCardVisual();
		}

		private void GroupDataMouseLeave(
			object sender,
			EventArgs e)
		{
			_isRectBtnHovered = false;
			UpdateCardVisual();
		}
	}
}