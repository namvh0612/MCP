﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/27/2026
 * Time: 10:26 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using NxtControl.GuiFramework;

namespace HMI.Main.Graphics
{
	/// <summary>
	/// Summary description for sNavigation.
	/// </summary>
	partial class sNavigation
	{
		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.buttonDefault = new NxtControl.GuiFramework.RoundedRectangle();
			// 
			// buttonDefault
			// 
			this.buttonDefault.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(116D)), ((float)(30D)));
			this.buttonDefault.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(12)), ((byte)(35)), ((byte)(33))));
			this.buttonDefault.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.buttonDefault.Name = "buttonDefault";
			this.buttonDefault.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(37)), ((byte)(64)), ((byte)(61))), 1F, NxtControl.Drawing.DashStyle.Solid);
			this.buttonDefault.Text = "PageName";
			this.buttonDefault.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleCenter;
			this.buttonDefault.TextColor = new NxtControl.Drawing.Color(((byte)(238)), ((byte)(243)), ((byte)(241)));
			// 
			// sNavigation
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.buttonDefault});
			this.SymbolSize = new System.Drawing.Size(600, 400);

		}
		private NxtControl.GuiFramework.RoundedRectangle buttonDefault;
		#endregion
	}
}
