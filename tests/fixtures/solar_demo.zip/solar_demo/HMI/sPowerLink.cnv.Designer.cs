/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/26/2026
 */

using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;

using NxtControl.GuiFramework;

namespace HMI.Main.Graphics
{
	/// <summary>
	/// Designer definition for sPowerLink.
	/// </summary>
	partial class sPowerLink
	{
		#region Component Designer generated code

		/// <summary>
		/// Required method for Designer support.
		/// </summary>
		private void InitializeComponent()
		{
			this.connectionLine1 = new NxtControl.GuiFramework.Line();
			this.connectionLine2 = new NxtControl.GuiFramework.Line();
			this.connectionLine3 = new NxtControl.GuiFramework.Line();
			this.powerLine1 = new NxtControl.GuiFramework.Line();
			this.powerLine2 = new NxtControl.GuiFramework.Line();
			this.powerLine3 = new NxtControl.GuiFramework.Line();
			this.startNode = new NxtControl.GuiFramework.Ellipse();
			this.endNode = new NxtControl.GuiFramework.Ellipse();
			this.flowMarker = new NxtControl.GuiFramework.Ellipse();
			this.QLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.PWR = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			// 
			// connectionLine1
			// 
			this.connectionLine1.EndPoint = new NxtControl.Drawing.PointF(123D, 15D);
			this.connectionLine1.Name = "connectionLine1";
			this.connectionLine1.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(45)), ((byte)(128)), ((byte)(112))), 2F, NxtControl.Drawing.DashStyle.Dash);
			this.connectionLine1.StartPoint = new NxtControl.Drawing.PointF(15D, 15D);
			// 
			// connectionLine2
			// 
			this.connectionLine2.EndPoint = new NxtControl.Drawing.PointF(123D, 15D);
			this.connectionLine2.Name = "connectionLine2";
			this.connectionLine2.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(45)), ((byte)(128)), ((byte)(112))), 2F, NxtControl.Drawing.DashStyle.Dash);
			this.connectionLine2.StartPoint = new NxtControl.Drawing.PointF(123D, 15D);
			this.connectionLine2.Visible = false;
			// 
			// connectionLine3
			// 
			this.connectionLine3.EndPoint = new NxtControl.Drawing.PointF(123D, 15D);
			this.connectionLine3.Name = "connectionLine3";
			this.connectionLine3.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(45)), ((byte)(128)), ((byte)(112))), 2F, NxtControl.Drawing.DashStyle.Dash);
			this.connectionLine3.StartPoint = new NxtControl.Drawing.PointF(123D, 15D);
			this.connectionLine3.Visible = false;
			// 
			// powerLine1
			// 
			this.powerLine1.EndPoint = new NxtControl.Drawing.PointF(123D, 15D);
			this.powerLine1.Name = "powerLine1";
			this.powerLine1.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(216)), ((byte)(178)), ((byte)(50))), 6F, NxtControl.Drawing.DashStyle.Solid);
			this.powerLine1.StartPoint = new NxtControl.Drawing.PointF(15D, 15D);
			this.powerLine1.Visible = false;
			// 
			// powerLine2
			// 
			this.powerLine2.EndPoint = new NxtControl.Drawing.PointF(123D, 15D);
			this.powerLine2.Name = "powerLine2";
			this.powerLine2.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(216)), ((byte)(178)), ((byte)(50))), 6F, NxtControl.Drawing.DashStyle.Solid);
			this.powerLine2.StartPoint = new NxtControl.Drawing.PointF(123D, 15D);
			this.powerLine2.Visible = false;
			// 
			// powerLine3
			// 
			this.powerLine3.EndPoint = new NxtControl.Drawing.PointF(123D, 15D);
			this.powerLine3.Name = "powerLine3";
			this.powerLine3.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(216)), ((byte)(178)), ((byte)(50))), 6F, NxtControl.Drawing.DashStyle.Solid);
			this.powerLine3.StartPoint = new NxtControl.Drawing.PointF(123D, 15D);
			this.powerLine3.Visible = false;
			// 
			// startNode
			// 
			this.startNode.Bounds = new NxtControl.Drawing.RectF(((float)(8D)), ((float)(8D)), ((float)(14D)), ((float)(14D)));
			this.startNode.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(45)), ((byte)(128)), ((byte)(112))));
			this.startNode.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.startNode.Name = "startNode";
			this.startNode.Pen = new NxtControl.Drawing.Pen("Transparent");
			this.startNode.Visible = false;
			// 
			// endNode
			// 
			this.endNode.Bounds = new NxtControl.Drawing.RectF(((float)(116D)), ((float)(8D)), ((float)(14D)), ((float)(14D)));
			this.endNode.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(45)), ((byte)(128)), ((byte)(112))));
			this.endNode.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.endNode.Name = "endNode";
			this.endNode.Pen = new NxtControl.Drawing.Pen("Transparent");
			this.endNode.Visible = false;
			// 
			// flowMarker
			// 
			this.flowMarker.Bounds = new NxtControl.Drawing.RectF(((float)(11D)), ((float)(11D)), ((float)(8D)), ((float)(8D)));
			this.flowMarker.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(255)), ((byte)(229)), ((byte)(128))));
			this.flowMarker.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.flowMarker.Name = "flowMarker";
			this.flowMarker.Pen = new NxtControl.Drawing.Pen("Transparent");
			this.flowMarker.Visible = false;
			// 
			// QLT
			// 
			this.QLT.BeginInit();
			this.QLT.Name = "QLT";
			this.QLT.SecurityToken = ((uint)(4294967295u));
			this.QLT.Val = false;
			this.QLT.EndInit();
			// 
			// PWR
			// 
			this.PWR.BeginInit();
			this.PWR.Name = "PWR";
			this.PWR.SecurityToken = ((uint)(4294967295u));
			this.PWR.Val = 0F;
			this.PWR.ValDecimalPlaces = ((byte)(2));
			this.PWR.ValMaximum = 0F;
			this.PWR.ValMinimum = 0F;
			this.PWR.ValUnits = "MW";
			this.PWR.EndInit();
			// 
			// sPowerLink
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.connectionLine1,
			this.connectionLine2,
			this.connectionLine3,
			this.powerLine1,
			this.powerLine2,
			this.powerLine3,
			this.startNode,
			this.endNode,
			this.flowMarker,
			this.QLT,
			this.PWR});
			this.SymbolSize = new System.Drawing.Size(138, 30);

		}

		private NxtControl.GuiFramework.Line
			connectionLine1;

		private NxtControl.GuiFramework.Line
			connectionLine2;

		private NxtControl.GuiFramework.Line
			connectionLine3;

		private NxtControl.GuiFramework.Line
			powerLine1;

		private NxtControl.GuiFramework.Line
			powerLine2;

		private NxtControl.GuiFramework.Line
			powerLine3;

		private NxtControl.GuiFramework.Ellipse
			startNode;

		private NxtControl.GuiFramework.Ellipse
			endNode;

		private NxtControl.GuiFramework.Ellipse
			flowMarker;

		private SE.Agile.Symbols
			.HMI_Indication_Bool_v1_0
			.sValChanged QLT;

		private SE.Agile.Symbols
			.HMI_Indication_Real_v1_0
			.sValChanged PWR;

		#endregion
	}
}
