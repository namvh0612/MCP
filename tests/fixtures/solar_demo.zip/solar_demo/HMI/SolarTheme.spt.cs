﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/25/2026
 * Time: 8:43 PM
 */

using System;
using NxtControl.Drawing;

namespace HMI.Main.SupportClasses
{
	public partial class SolarTheme
	{
		public SolarTheme()
		{
		}

		private static Color RGB(
			byte red,
			byte green,
			byte blue)
		{
			return new Color(red, green, blue);
		}

		/* ============================= */
		/* Surface / Brush               */
		/* ============================= */

		public static class Surface
		{
			public static readonly Color Page =
				SolarTheme.RGB(2, 12, 12);

			public static readonly Color Header =
				SolarTheme.RGB(3, 16, 15);

			public static readonly Color MainBoard =
				SolarTheme.RGB(5, 22, 21);

			public static readonly Color Panel =
				SolarTheme.RGB(8, 28, 27);

			public static readonly Color RaisedPanel =
				SolarTheme.RGB(12, 35, 33);

			public static readonly Color Disabled =
				SolarTheme.RGB(17, 27, 27);

			public static readonly Color Hover =
				SolarTheme.RGB(18, 45, 42);

			public static readonly Color Selected =
				SolarTheme.RGB(18, 67, 42);

			public static readonly Color Warning =
				SolarTheme.RGB(65, 51, 16);

			public static readonly Color Fault =
				SolarTheme.RGB(70, 25, 29);
		}

		/* ============================= */
		/* Border / Pen                  */
		/* ============================= */

		public static class Border
		{
			public static readonly Color MainBoard =
				SolarTheme.RGB(29, 61, 57);

			public static readonly Color Normal =
				SolarTheme.RGB(37, 64, 61);

			public static readonly Color Divider =
				SolarTheme.RGB(42, 70, 66);

			public static readonly Color Disabled =
				SolarTheme.RGB(46, 56, 54);

			public static readonly Color Hover =
				SolarTheme.RGB(54, 91, 84);

			public static readonly Color Selected =
				SolarTheme.RGB(61, 205, 88);

			public static readonly Color Warning =
				SolarTheme.RGB(161, 129, 31);

			public static readonly Color Fault =
				SolarTheme.RGB(160, 57, 63);
		}

		/* ============================= */
		/* Text / Icon                   */
		/* ============================= */

		public static class Text
		{
			public static readonly Color Primary =
				SolarTheme.RGB(238, 243, 241);

			public static readonly Color Heading =
				SolarTheme.RGB(210, 220, 216);

			public static readonly Color Secondary =
				SolarTheme.RGB(174, 187, 182);

			public static readonly Color Label =
				SolarTheme.RGB(132, 148, 143);

			public static readonly Color Muted =
				SolarTheme.RGB(92, 108, 104);

			public static readonly Color Accent =
				SolarTheme.RGB(84, 176, 103);

			public static readonly Color Icon =
				SolarTheme.RGB(194, 205, 201);
		}

		/* ============================= */
		/* Status                        */
		/* ============================= */

		public static class Status
		{
			public static readonly Color Healthy =
				SolarTheme.RGB(61, 205, 88);
		
			public static readonly Color Running =
				SolarTheme.RGB(61, 205, 88);
		
			public static readonly Color Standby =
				SolarTheme.RGB(117, 129, 124);
		
			public static readonly Color Offline =
				SolarTheme.RGB(73, 84, 81);
		
			public static readonly Color Unknown =
				SolarTheme.RGB(92, 108, 104);
		
			public static readonly Color Warning =
				SolarTheme.RGB(255, 200, 61);
		
			public static readonly Color Alarm =
				SolarTheme.RGB(232, 86, 92);
		
			public static readonly Color Fault =
				SolarTheme.RGB(232, 86, 92);
		
			public static readonly Color Info =
				SolarTheme.RGB(66, 180, 230);
		}

		/* ============================= */
		/* Progress bar                  */
		/* ============================= */

		public static class Progress
		{
			public static readonly Color Track =
				SolarTheme.RGB(17, 27, 27);

			public static readonly Color Fill =
				SolarTheme.RGB(69, 166, 96);

			public static readonly Color Warning =
				SolarTheme.RGB(255, 200, 61);

			public static readonly Color Fault =
				SolarTheme.RGB(232, 86, 92);
		}

		/* ============================= */
		/* Process flow                  */
		/* ============================= */

		public static class Flow
		{
			public static readonly Color DcPower =
				SolarTheme.RGB(216, 178, 50);

			public static readonly Color AcPower =
				SolarTheme.RGB(226, 104, 43);

			public static readonly Color Telemetry =
				SolarTheme.RGB(45, 128, 112);

			public static readonly Color ControlSetpoint =
				SolarTheme.RGB(92, 158, 119);

			public static readonly Color Inactive =
				SolarTheme.RGB(73, 84, 81);
		}

		/* ============================= */
		/* Pen widths                    */
		/* ============================= */

		public static class Pen
		{
			public const float None = 0.0F;
			public const float Divider = 0.5F;
			public const float Normal = 1.0F;
			public const float Panel = 1.5F;
			public const float Status = 1.5F;
			public const float Selected = 2.0F;
			public const float Signal = 1.5F;
			public const float InactiveFlow = 2.0F;
			public const float PowerFlow = 3.5F;
		}

		/* ============================= */
		/* State helper                  */
		/* ============================= */

		public enum EquipmentState
		{
			Unknown = 0,
			Healthy = 1,
			Running = 2,
			Standby = 3,
			Warning = 4,
			Fault = 5,
			Offline = 6,
			Alarm = 7
		}
		public static Color GetStatusColor(
			EquipmentState state)
		{
			switch (state)
			{
				case EquipmentState.Healthy:
					return Status.Healthy;
		
				case EquipmentState.Running:
					return Status.Running;
		
				case EquipmentState.Standby:
					return Status.Standby;
		
				case EquipmentState.Warning:
					return Status.Warning;
		
				case EquipmentState.Alarm:
					return Status.Alarm;
		
				case EquipmentState.Fault:
					return Status.Fault;
		
				case EquipmentState.Offline:
					return Status.Offline;
		
				default:
					return Status.Unknown;
			}
		}
		
		public static Color GetStatusBrush(
			EquipmentState state)
		{
			switch (state)
			{
				case EquipmentState.Warning:
					return Surface.Warning;

				case EquipmentState.Alarm:
				case EquipmentState.Fault:
					return Surface.Fault;

				case EquipmentState.Offline:
				case EquipmentState.Unknown:
					return Surface.Disabled;

				default:
					return Surface.MainBoard;
			}
		}

		public static Color GetStatusBorder(
			EquipmentState state)
		{
			switch (state)
			{
				case EquipmentState.Warning:
					return Border.Warning;
					
				case EquipmentState.Alarm:
				case EquipmentState.Fault:
					return Border.Fault;

				case EquipmentState.Offline:
				case EquipmentState.Unknown:
					return Border.Disabled;

				default:
					return Border.Normal;
			}
		}

		public static float GetStatusPenWidth(
			EquipmentState state)
		{
			switch (state)
			{
				case EquipmentState.Warning:
				case EquipmentState.Alarm:
				case EquipmentState.Fault:
					return Pen.Status;

				default:
					return Pen.Normal;
			}
		}
	}
}