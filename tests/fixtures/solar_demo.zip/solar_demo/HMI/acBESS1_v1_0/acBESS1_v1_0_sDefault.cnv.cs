/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/14/2026
 * Time: 2:58 PM
 */

using System;
using NxtControl.GuiFramework;
using NxtControl.Drawing;
using HMI.Main.SupportClasses;

namespace HMI.Main.Symbols.acBESS1_v1_0
{
	public partial class sDefault :
		NxtControl.GuiFramework.HMISymbol
	{
		private const double POWER_DEADBAND = 0.001;
		private const double SOC_LOW_LIMIT = 20.0;

		private bool _isRectBtnHovered;

		private BessVisualStatus _currentStatus =
			BessVisualStatus.Offline;

		private enum BessVisualStatus
		{
			Offline,
			Fault,
			Alarm,
			Charging,
			Discharging,
			Standby,
			Available,
			Unknown
		}

		public sDefault()
		{
			InitializeComponent();
			AttachEvents();
			UpdateDisplay();
		}

		private void AttachEvents()
		{
			REQ_Fired += REQ_Fired_EventHandler;

			IAVL.OnValChanged += OnValueChanged;
			IRUN.OnValChanged += OnValueChanged;
			ICHG.OnValChanged += OnValueChanged;
			IDIS.OnValChanged += OnValueChanged;
			ISTBY.OnValChanged += OnValueChanged;

			IALM.OnValChanged += OnValueChanged;
			IFLT.OnValChanged += OnValueChanged;
			QLT.OnValChanged += OnValueChanged;

			SOC.OnValChanged += OnValueChanged;
			PBAT.OnValChanged += OnValueChanged;
			MODE.OnValChanged += OnValueChanged;
		}

		private void OnValueChanged(
			object sender,
			EventArgs e)
		{
			UpdateDisplay();
		}

		private void UpdateDisplay()
		{
			_currentStatus = ResolveStatus();

			float soc =
				(float)HmiValueHelper.Clamp(
					HmiValueHelper.ToDouble(SOC.Val),
					0.0,
					100.0);

			SolarTheme.EquipmentState equipmentState =
				GetEquipmentState(_currentStatus);

			Color statusColor =
				GetStatusColor(_currentStatus);

			Color modeColor =
				_currentStatus == BessVisualStatus.Offline
					? SolarTheme.Status.Offline
					: SolarTheme.Text.Primary;

			HmiDisplayHelper.DisplayData displayData =
				new HmiDisplayHelper.DisplayData();

			displayData.Status = equipmentState;
			displayData.StatusIndicator = indStatus;
			displayData.CardBorder = rectBtn;
			displayData.CardBackground = rectBase;
			displayData.IsHovered = _isRectBtnHovered;

			displayData.Items =
				new HmiDisplayHelper.DisplayItem[]
				{
					HmiDisplayHelper.CreateText(
						txtStatus,
						GetStatusText(_currentStatus),
						statusColor),

					HmiDisplayHelper.CreateText(
						txtSOC,
						soc.ToString("0.00") + "%",
						GetSocTextColor(soc)),

					HmiDisplayHelper.CreateText(
						txtMODE,
						GetModeText(MODE.Val),
						modeColor),

					HmiDisplayHelper.CreateText(
						txtPower,
						GetPowerText(PBAT.Val),
						GetPowerColor(PBAT.Val))
				};

			HmiDisplayHelper.Apply(displayData);

			progressBarSOC.FillPercent = soc;
			progressBarSOC.BrushColor =
				GetSocColor(soc);

			indStatus.BrushColor = statusColor;

			UpdateCardVisual();
		}

		private BessVisualStatus ResolveStatus()
		{
			if (!HmiValueHelper.ToBool(QLT.Val))
			{
				return BessVisualStatus.Offline;
			}

			if (HmiValueHelper.ToBool(IFLT.Val))
			{
				return BessVisualStatus.Fault;
			}

			if (HmiValueHelper.ToBool(IALM.Val))
			{
				return BessVisualStatus.Alarm;
			}

			if (HmiValueHelper.ToBool(ICHG.Val))
			{
				return BessVisualStatus.Charging;
			}

			if (HmiValueHelper.ToBool(IDIS.Val))
			{
				return BessVisualStatus.Discharging;
			}

			if (HmiValueHelper.ToBool(ISTBY.Val))
			{
				return BessVisualStatus.Standby;
			}

			if (HmiValueHelper.ToBool(IAVL.Val))
			{
				return BessVisualStatus.Available;
			}

			return BessVisualStatus.Unknown;
		}

		private SolarTheme.EquipmentState GetEquipmentState(
			BessVisualStatus status)
		{
			switch (status)
			{
				case BessVisualStatus.Fault:
					return SolarTheme.EquipmentState.Fault;

				case BessVisualStatus.Alarm:
					return SolarTheme.EquipmentState.Alarm;
				
				case BessVisualStatus.Unknown:
					return SolarTheme.EquipmentState.Unknown;

				case BessVisualStatus.Charging:
				case BessVisualStatus.Discharging:
					return SolarTheme.EquipmentState.Running;

				case BessVisualStatus.Available:
					return SolarTheme.EquipmentState.Healthy;

				case BessVisualStatus.Standby:
					return SolarTheme.EquipmentState.Standby;

				case BessVisualStatus.Offline:
					return SolarTheme.EquipmentState.Offline;
					
				default:
					return SolarTheme.EquipmentState.Unknown;
			}
		}

		private string GetStatusText(
			BessVisualStatus status)
		{
			switch (status)
			{
				case BessVisualStatus.Fault:
					return "Fault";

				case BessVisualStatus.Alarm:
					return "Alarm";

				case BessVisualStatus.Charging:
					return "Charge";

				case BessVisualStatus.Discharging:
					return "Discharge";

				case BessVisualStatus.Standby:
					return "Standby";

				case BessVisualStatus.Available:
					return "Available";

				case BessVisualStatus.Unknown:
					return "Unknown";
				
				case BessVisualStatus.Offline:
					return "Offline";
				
				default:
					return "Unknown";
			}
		}

		private Color GetStatusColor(
			BessVisualStatus status)
		{
			switch (status)
			{
				case BessVisualStatus.Fault:
					return SolarTheme.Status.Fault;

				case BessVisualStatus.Alarm:
					return SolarTheme.Status.Warning;

				case BessVisualStatus.Charging:
					return SolarTheme.Status.Healthy;

				case BessVisualStatus.Discharging:
					return SolarTheme.Flow.AcPower;

				case BessVisualStatus.Standby:
					return SolarTheme.Status.Standby;

				case BessVisualStatus.Available:
					return SolarTheme.Status.Healthy;
				
				case BessVisualStatus.Unknown:
					return SolarTheme.Status.Unknown;
				
				case BessVisualStatus.Offline:
					return SolarTheme.Status.Offline;
				
				default:
					return SolarTheme.Status.Unknown;
			}
		}

		private Color GetSocColor(double soc)
		{
			if (_currentStatus == BessVisualStatus.Offline)
			{
				return SolarTheme.Status.Offline;
			}

			if (_currentStatus == BessVisualStatus.Fault)
			{
				return SolarTheme.Status.Fault;
			}

			if (soc <= SOC_LOW_LIMIT)
			{
				return SolarTheme.Status.Warning;
			}

			if (_currentStatus ==
				BessVisualStatus.Discharging)
			{
				return SolarTheme.Flow.AcPower;
			}

			if (_currentStatus ==
				BessVisualStatus.Standby)
			{
				return SolarTheme.Status.Standby;
			}

			return SolarTheme.Progress.Fill;
		}

		private Color GetSocTextColor(double soc)
		{
			if (_currentStatus == BessVisualStatus.Offline)
			{
				return SolarTheme.Status.Offline;
			}

			if (_currentStatus == BessVisualStatus.Fault)
			{
				return SolarTheme.Status.Fault;
			}

			if (soc <= SOC_LOW_LIMIT)
			{
				return SolarTheme.Status.Warning;
			}

			return SolarTheme.Text.Primary;
		}

		private string GetPowerText(object value)
		{
			double power =
				HmiValueHelper.ToDouble(value);

			if (power > POWER_DEADBAND)
			{
				return "+"
					+ power.ToString("0.00")
					+ " MW Discharge";
			}

			if (power < -POWER_DEADBAND)
			{
				return power.ToString("0.00")
					+ " MW Charge";
			}

			return "0.00 MW Standby";
		}

		private Color GetPowerColor(object value)
		{
			double power =
				HmiValueHelper.ToDouble(value);

			if (_currentStatus == BessVisualStatus.Offline)
			{
				return SolarTheme.Status.Offline;
			}

			if (_currentStatus == BessVisualStatus.Fault)
			{
				return SolarTheme.Status.Fault;
			}

			if (power > POWER_DEADBAND)
			{
				return SolarTheme.Flow.AcPower;
			}

			if (power < -POWER_DEADBAND)
			{
				return SolarTheme.Status.Healthy;
			}

			return SolarTheme.Text.Muted;
		}

		private string GetModeText(object value)
		{
			return "Auto";
			switch (HmiValueHelper.ToInt(value))
			{
				case 0:
					return "Off";

				case 1:
					return "Auto";

				case 2:
					return "Manual";

				default:
					return "Unknown";
			}
		}

		private void UpdateCardVisual()
		{
			HmiDisplayHelper.ApplyStatusCard(
				rectBtn,
				rectBase,
				GetEquipmentState(_currentStatus),
				_isRectBtnHovered);

			if (_currentStatus ==
				BessVisualStatus.Discharging)
			{
				rectBtn.PenColor =
					_isRectBtnHovered
						? SolarTheme.Flow.AcPower
						: SolarTheme.Border.Warning;
			}
		}

		private void RectBtnMouseEnter(
			object sender,
			EventArgs e)
		{
			_isRectBtnHovered = true;
			UpdateCardVisual();
		}

		private void RectBtnMouseLeave(
			object sender,
			EventArgs e)
		{
			_isRectBtnHovered = false;
			UpdateCardVisual();
		}

		private void REQ_Fired_EventHandler(
			object sender,
			REQEventArgs e)
		{
			lblSymbol.Text =
				HmiValueHelper.SafeText(
					e.AssetName,
					"BESS");
		}
	}
}