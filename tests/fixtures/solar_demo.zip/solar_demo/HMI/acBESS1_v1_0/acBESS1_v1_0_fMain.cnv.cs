/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/14/2026
 * Time: 9:11 PM
 */

using System;
using NxtControl.GuiFramework;
using NxtControl.Drawing;
using HMI.Main.SupportClasses;

namespace HMI.Main.Faceplates.acBESS1_v1_0
{
	public partial class fMain :
		NxtControl.GuiFramework.HMIFaceplate
	{
		private const double MIN_BATTERY_VOLTAGE = 600.0;
		private const double MAX_BATTERY_VOLTAGE = 900.0;
		private const double MAX_BATTERY_TEMPERATURE = 55.0;

		private BessVisualStatus _currentStatus =
			BessVisualStatus.Offline;

		private enum BessVisualStatus
		{
			Offline,
			Fault,
			Alarm,
			Charging,
			Discharging,
			Standby,
			Available,
			Unknown
		}

		public fMain()
		{
			InitializeComponent();
			AttachEvents();
			UpdateDisplay();
		}

		private void AttachEvents()
		{
			REQ_Fired += REQ_Fired_EventHandler;

			IAVL.OnValChanged += OnBessValueChanged;
			IRUN.OnValChanged += OnBessValueChanged;
			ICHG.OnValChanged += OnBessValueChanged;
			IDIS.OnValChanged += OnBessValueChanged;
			ISTBY.OnValChanged += OnBessValueChanged;

			IALM.OnValChanged += OnBessValueChanged;
			IFLT.OnValChanged += OnBessValueChanged;
			QLT.OnValChanged += OnBessValueChanged;

			VBAT.OnValChanged += OnBessValueChanged;
			IBAT.OnValChanged += OnBessValueChanged;
			TBAT.OnValChanged += OnBessValueChanged;
			SOCSP.OnValChanged += OnBessValueChanged;
		}

		private void OnBessValueChanged(
			object sender,
			EventArgs e)
		{
			UpdateDisplay();
		}

		private void UpdateDisplay()
		{
			_currentStatus = ResolveStatus();

			HmiDisplayHelper.DisplayData displayData =
				new HmiDisplayHelper.DisplayData();

			displayData.Status =
				GetEquipmentState(_currentStatus);

			displayData.Items =
				new HmiDisplayHelper.DisplayItem[]
				{
					HmiDisplayHelper.CreateText(
						txtStatus,
						GetStatusText(_currentStatus),
						GetStatusColor(_currentStatus)),

					HmiDisplayHelper.CreateValue(
						txtVBAT,
						VBAT.Val,
						"0",
						" V",
						GetValidatedValueColor(
							IsVoltageValid(VBAT.Val),
							false)),

					HmiDisplayHelper.CreateText(
						txtIBAT,
						GetSignedCurrentText(IBAT.Val),
						GetCurrentColor()),

					HmiDisplayHelper.CreateValue(
						txtTBAT,
						TBAT.Val,
						"0",
						" °C",
						GetValidatedValueColor(
							IsTemperatureValid(TBAT.Val),
							true)),

					HmiDisplayHelper.CreateValue(
						txtSOCSP,
						SOCSP.Val,
						"0",
						" %",
						GetValidatedValueColor(
							IsSocSetpointValid(
								SOCSP.Val),
							false))
				};

			HmiDisplayHelper.Apply(displayData);
		}

		private BessVisualStatus ResolveStatus()
		{
			if (!HmiValueHelper.ToBool(QLT.Val))
			{
				return BessVisualStatus.Offline;
			}

			if (HmiValueHelper.ToBool(IFLT.Val))
			{
				return BessVisualStatus.Fault;
			}

			if (HmiValueHelper.ToBool(IALM.Val))
			{
				return BessVisualStatus.Alarm;
			}

			if (HmiValueHelper.ToBool(ICHG.Val))
			{
				return BessVisualStatus.Charging;
			}

			if (HmiValueHelper.ToBool(IDIS.Val))
			{
				return BessVisualStatus.Discharging;
			}

			if (HmiValueHelper.ToBool(ISTBY.Val))
			{
				return BessVisualStatus.Standby;
			}

			if (HmiValueHelper.ToBool(IAVL.Val))
			{
				return BessVisualStatus.Available;
			}

			return BessVisualStatus.Standby;
		}

		private SolarTheme.EquipmentState GetEquipmentState(
			BessVisualStatus status)
		{
			switch (status)
			{
				case BessVisualStatus.Fault:
					return SolarTheme.EquipmentState.Fault;

				case BessVisualStatus.Alarm:
					return SolarTheme.EquipmentState.Alarm;
				
				case BessVisualStatus.Unknown:
					return SolarTheme.EquipmentState.Unknown;

				case BessVisualStatus.Charging:
				case BessVisualStatus.Discharging:
					return SolarTheme.EquipmentState.Running;

				case BessVisualStatus.Available:
					return SolarTheme.EquipmentState.Healthy;

				case BessVisualStatus.Standby:
					return SolarTheme.EquipmentState.Standby;

				case BessVisualStatus.Offline:
					return SolarTheme.EquipmentState.Offline;
					
				default:
					return SolarTheme.EquipmentState.Unknown;
			}
		}

		private string GetStatusText(
			BessVisualStatus status)
		{
			switch (status)
			{
				case BessVisualStatus.Fault:
					return "Fault";

				case BessVisualStatus.Alarm:
					return "Alarm";

				case BessVisualStatus.Charging:
					return "Charging";

				case BessVisualStatus.Discharging:
					return "Discharging";

				case BessVisualStatus.Standby:
					return "Standby";

				case BessVisualStatus.Available:
					return "Available";

				case BessVisualStatus.Unknown:
					return "Unknown";
				
				case BessVisualStatus.Offline:
					return "Offline";
				
				default:
					return "Unknown";
			}
		}

		private Color GetStatusColor(
			BessVisualStatus status)
		{
			switch (status)
			{
				case BessVisualStatus.Fault:
					return SolarTheme.Status.Fault;

				case BessVisualStatus.Alarm:
					return SolarTheme.Status.Warning;

				case BessVisualStatus.Charging:
					return SolarTheme.Status.Healthy;

				case BessVisualStatus.Discharging:
					return SolarTheme.Flow.AcPower;

				case BessVisualStatus.Standby:
					return SolarTheme.Status.Standby;

				case BessVisualStatus.Available:
					return SolarTheme.Status.Healthy;
				
				case BessVisualStatus.Unknown:
					return SolarTheme.Status.Unknown;
				
				case BessVisualStatus.Offline:
					return SolarTheme.Status.Offline;
				
				default:
					return SolarTheme.Status.Unknown;
			}
		}

		private Color GetValidatedValueColor(
			bool isValid,
			bool useWarning)
		{
			if (_currentStatus ==
				BessVisualStatus.Offline)
			{
				return SolarTheme.Status.Offline;
			}

			if (_currentStatus ==
				BessVisualStatus.Fault)
			{
				return SolarTheme.Status.Fault;
			}

			if (!isValid)
			{
				return useWarning
					? SolarTheme.Status.Warning
					: SolarTheme.Status.Fault;
			}

			return SolarTheme.Text.Primary;
		}

		private Color GetCurrentColor()
		{
			if (_currentStatus ==
				BessVisualStatus.Offline)
			{
				return SolarTheme.Status.Offline;
			}

			if (_currentStatus ==
				BessVisualStatus.Fault)
			{
				return SolarTheme.Status.Fault;
			}

			switch (_currentStatus)
			{
				case BessVisualStatus.Charging:
					return SolarTheme.Status.Healthy;

				case BessVisualStatus.Discharging:
					return SolarTheme.Flow.AcPower;

				case BessVisualStatus.Standby:
					return SolarTheme.Text.Muted;

				default:
					return SolarTheme.Text.Primary;
			}
		}

		private bool IsVoltageValid(object value)
		{
			double voltage =
				HmiValueHelper.ToDouble(value);

			return HmiValueHelper.IsInRange(
				voltage,
				MIN_BATTERY_VOLTAGE,
				MAX_BATTERY_VOLTAGE);
		}

		private bool IsTemperatureValid(object value)
		{
			double temperature =
				HmiValueHelper.ToDouble(value);

			return temperature <
				MAX_BATTERY_TEMPERATURE;
		}

		private bool IsSocSetpointValid(object value)
		{
			double setpoint =
				HmiValueHelper.ToDouble(value);

			return HmiValueHelper.IsInRange(
				setpoint,
				0.0,
				100.0);
		}

		private string GetSignedCurrentText(object value)
		{
			double current =
				HmiValueHelper.ToDouble(value);

			if (current > 0.0)
			{
				return "+"
					+ current.ToString("0")
					+ " A";
			}

			return current.ToString("0")
				+ " A";
		}

		private void REQ_Fired_EventHandler(
			object sender,
			HMI.Main.Symbols.acBESS1_v1_0.REQEventArgs e)
		{
			Title =
				HmiValueHelper.SafeText(
					e.AssetName,
					"BESS");

			UpdateDisplay();
		}
	}
}