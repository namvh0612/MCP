/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/14/2026
 * Time: 2:58 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.acBESS1_v1_0
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sDefault
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(sDefault));
			this.rectangle1 = new NxtControl.GuiFramework.Rectangle();
			this.lblSymbol = new NxtControl.GuiFramework.Label();
			this.txtStatus = new NxtControl.GuiFramework.Label();
			this.indStatus = new NxtControl.GuiFramework.Ellipse();
			this.txtMODE = new NxtControl.GuiFramework.Label();
			this.freeText4 = new NxtControl.GuiFramework.FreeText();
			this.txtPower = new NxtControl.GuiFramework.Label();
			this.freeText5 = new NxtControl.GuiFramework.FreeText();
			this.line1 = new NxtControl.GuiFramework.Line();
			this.line2 = new NxtControl.GuiFramework.Line();
			this.rectBtn = new NxtControl.GuiFramework.RoundedRectangle();
			this.rectBase = new NxtControl.GuiFramework.RoundedRectangle();
			this.progressBarSOC = new NxtControl.GuiFramework.RoundedRectangle();
			this.txtSOC = new NxtControl.GuiFramework.Label();
			this.IALM = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IAVL = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.ICHG = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IDIS = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IFLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IRUN = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.PBAT = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.ISTBY = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.QLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.SOC = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.MODE = new SE.Agile.Symbols.HMI_Control_Integer_v1_0.sValChanged();
			// 
			// rectangle1
			// 
			this.rectangle1.Bounds = new NxtControl.Drawing.RectF(((float)(5D)), ((float)(20D)), ((float)(220D)), ((float)(171D)));
			this.rectangle1.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle1.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle1.ImageBytes = resources.GetString("rectangle1.ImageBytes");
			this.rectangle1.Name = "rectangle1";
			this.rectangle1.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// lblSymbol
			// 
			this.lblSymbol.AngleIgnore = true;
			this.lblSymbol.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.lblSymbol.Bounds = new NxtControl.Drawing.RectF(((float)(11D)), ((float)(12D)), ((float)(141D)), ((float)(24D)));
			this.lblSymbol.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.lblSymbol.Font = new NxtControl.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
			this.lblSymbol.FontScale = true;
			this.lblSymbol.Name = "lblSymbol";
			this.lblSymbol.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.lblSymbol.Text = "BESS";
			this.lblSymbol.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.lblSymbol.TextAutoSizeHorizontalOffset = 10;
			this.lblSymbol.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.lblSymbol.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// txtStatus
			// 
			this.txtStatus.AngleIgnore = true;
			this.txtStatus.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtStatus.Bounds = new NxtControl.Drawing.RectF(((float)(163D)), ((float)(16D)), ((float)(69D)), ((float)(16D)));
			this.txtStatus.Brush = new NxtControl.Drawing.Brush(true);
			this.txtStatus.Font = new NxtControl.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular);
			this.txtStatus.FontScale = true;
			this.txtStatus.Name = "txtStatus";
			this.txtStatus.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtStatus.Text = "Discharge";
			this.txtStatus.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.txtStatus.TextAutoSizeHorizontalOffset = 10;
			this.txtStatus.TextColor = new NxtControl.Drawing.Color(((byte)(120)), ((byte)(249)), ((byte)(141)));
			this.txtStatus.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// indStatus
			// 
			this.indStatus.Bounds = new NxtControl.Drawing.RectF(((float)(149D)), ((float)(19D)), ((float)(10D)), ((float)(10D)));
			this.indStatus.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(120)), ((byte)(249)), ((byte)(141))));
			this.indStatus.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.indStatus.Name = "indStatus";
			this.indStatus.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// txtMODE
			// 
			this.txtMODE.AngleIgnore = true;
			this.txtMODE.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtMODE.Bounds = new NxtControl.Drawing.RectF(((float)(131D)), ((float)(185D)), ((float)(96D)), ((float)(20D)));
			this.txtMODE.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtMODE.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtMODE.FontScale = true;
			this.txtMODE.Name = "txtMODE";
			this.txtMODE.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtMODE.Text = "Auto";
			this.txtMODE.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtMODE.TextAutoSizeHorizontalOffset = 10;
			this.txtMODE.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtMODE.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText4
			// 
			this.freeText4.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText4.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText4.Location = new NxtControl.Drawing.PointF(11D, 186D);
			this.freeText4.Name = "freeText4";
			this.freeText4.Text = "Battery Mode";
			// 
			// txtPower
			// 
			this.txtPower.AngleIgnore = true;
			this.txtPower.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtPower.Bounds = new NxtControl.Drawing.RectF(((float)(79D)), ((float)(217D)), ((float)(148D)), ((float)(20D)));
			this.txtPower.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtPower.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtPower.FontScale = true;
			this.txtPower.Name = "txtPower";
			this.txtPower.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtPower.Text = "+0.25 MW Discharge";
			this.txtPower.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtPower.TextAutoSizeHorizontalOffset = 10;
			this.txtPower.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtPower.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText5
			// 
			this.freeText5.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText5.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText5.Location = new NxtControl.Drawing.PointF(11D, 218D);
			this.freeText5.Name = "freeText5";
			this.freeText5.Text = "Power";
			// 
			// line1
			// 
			this.line1.EndPoint = new NxtControl.Drawing.PointF(239D, 177D);
			this.line1.Name = "line1";
			this.line1.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(20)), ((byte)(54)), ((byte)(45))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line1.StartPoint = new NxtControl.Drawing.PointF(2D, 177D);
			// 
			// line2
			// 
			this.line2.EndPoint = new NxtControl.Drawing.PointF(239D, 209D);
			this.line2.Name = "line2";
			this.line2.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(20)), ((byte)(54)), ((byte)(45))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line2.StartPoint = new NxtControl.Drawing.PointF(2D, 209D);
			// 
			// rectBtn
			// 
			this.rectBtn.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(240D)), ((float)(250D)));
			this.rectBtn.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("Transparent"));
			this.rectBtn.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectBtn.Name = "rectBtn";
			this.rectBtn.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fMain", NxtControl.GuiFramework.MouseButtonType.Click));
			this.rectBtn.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(28)), ((byte)(78)), ((byte)(71))), 1F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Flat, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Round, null);
			this.rectBtn.Radius = 10D;
			this.rectBtn.MouseEnter += new System.EventHandler(this.RectBtnMouseEnter);
			this.rectBtn.MouseLeave += new System.EventHandler(this.RectBtnMouseLeave);
			// 
			// rectBase
			// 
			this.rectBase.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(240D)), ((float)(250D)));
			this.rectBase.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(3)), ((byte)(22)), ((byte)(20))));
			this.rectBase.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectBase.Name = "rectBase";
			this.rectBase.Pen = new NxtControl.Drawing.Pen("Transparent");
			this.rectBase.Radius = 10D;
			// 
			// progressBarSOC
			// 
			this.progressBarSOC.Bounds = new NxtControl.Drawing.RectF(((float)(52D)), ((float)(79D)), ((float)(124D)), ((float)(48D)));
			this.progressBarSOC.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(120)), ((byte)(249)), ((byte)(141))));
			this.progressBarSOC.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.progressBarSOC.Name = "progressBarSOC";
			this.progressBarSOC.Pen = new NxtControl.Drawing.Pen("Transparent");
			this.progressBarSOC.Radius = 10D;
			// 
			// txtSOC
			// 
			this.txtSOC.AngleIgnore = true;
			this.txtSOC.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtSOC.Bounds = new NxtControl.Drawing.RectF(((float)(53D)), ((float)(88D)), ((float)(123D)), ((float)(30D)));
			this.txtSOC.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtSOC.Font = new NxtControl.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
			this.txtSOC.FontScale = true;
			this.txtSOC.Name = "txtSOC";
			this.txtSOC.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtSOC.Text = "69.00%";
			this.txtSOC.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleCenter;
			this.txtSOC.TextAutoSizeHorizontalOffset = 10;
			this.txtSOC.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtSOC.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// IALM
			// 
			this.IALM.BeginInit();
			this.IALM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 61D, 89D);
			this.IALM.Name = "IALM";
			this.IALM.SecurityToken = ((uint)(4294967295u));
			this.IALM.TagName = "IALM";
			this.IALM.Val = false;
			this.IALM.EndInit();
			// 
			// IAVL
			// 
			this.IAVL.BeginInit();
			this.IAVL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 154D, 142D);
			this.IAVL.Name = "IAVL";
			this.IAVL.SecurityToken = ((uint)(4294967295u));
			this.IAVL.TagName = "IAVL";
			this.IAVL.Val = false;
			this.IAVL.EndInit();
			// 
			// ICHG
			// 
			this.ICHG.BeginInit();
			this.ICHG.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 131D, 191D);
			this.ICHG.Name = "ICHG";
			this.ICHG.SecurityToken = ((uint)(4294967295u));
			this.ICHG.TagName = "ICHG";
			this.ICHG.Val = false;
			this.ICHG.EndInit();
			// 
			// IDIS
			// 
			this.IDIS.BeginInit();
			this.IDIS.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 128D, 184D);
			this.IDIS.Name = "IDIS";
			this.IDIS.SecurityToken = ((uint)(4294967295u));
			this.IDIS.TagName = "IDIS";
			this.IDIS.Val = false;
			this.IDIS.EndInit();
			// 
			// IFLT
			// 
			this.IFLT.BeginInit();
			this.IFLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 138D, 171D);
			this.IFLT.Name = "IFLT";
			this.IFLT.SecurityToken = ((uint)(4294967295u));
			this.IFLT.TagName = "IFLT";
			this.IFLT.Val = false;
			this.IFLT.EndInit();
			// 
			// IRUN
			// 
			this.IRUN.BeginInit();
			this.IRUN.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 106D, 170D);
			this.IRUN.Name = "IRUN";
			this.IRUN.SecurityToken = ((uint)(4294967295u));
			this.IRUN.TagName = "IRUN";
			this.IRUN.Val = false;
			this.IRUN.EndInit();
			// 
			// PBAT
			// 
			this.PBAT.BeginInit();
			this.PBAT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 100D, 182D);
			this.PBAT.Name = "PBAT";
			this.PBAT.SecurityToken = ((uint)(4294967295u));
			this.PBAT.TagName = "PBAT";
			this.PBAT.Val = 0F;
			this.PBAT.ValDecimalPlaces = ((byte)(0));
			this.PBAT.ValMaximum = 0F;
			this.PBAT.ValMinimum = 0F;
			this.PBAT.ValUnits = null;
			this.PBAT.EndInit();
			// 
			// ISTBY
			// 
			this.ISTBY.BeginInit();
			this.ISTBY.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 122D, 166D);
			this.ISTBY.Name = "ISTBY";
			this.ISTBY.SecurityToken = ((uint)(4294967295u));
			this.ISTBY.TagName = "ISTBY";
			this.ISTBY.Val = false;
			this.ISTBY.EndInit();
			// 
			// QLT
			// 
			this.QLT.BeginInit();
			this.QLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 68D, 222D);
			this.QLT.Name = "QLT";
			this.QLT.SecurityToken = ((uint)(4294967295u));
			this.QLT.TagName = "QLT";
			this.QLT.Val = false;
			this.QLT.EndInit();
			// 
			// SOC
			// 
			this.SOC.BeginInit();
			this.SOC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 71D, 181D);
			this.SOC.Name = "SOC";
			this.SOC.SecurityToken = ((uint)(4294967295u));
			this.SOC.TagName = "SOC";
			this.SOC.Val = 0F;
			this.SOC.ValDecimalPlaces = ((byte)(0));
			this.SOC.ValMaximum = 0F;
			this.SOC.ValMinimum = 0F;
			this.SOC.ValUnits = null;
			this.SOC.EndInit();
			// 
			// MODE
			// 
			this.MODE.BeginInit();
			this.MODE.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 99D, 166D);
			this.MODE.Name = "MODE";
			this.MODE.SecurityToken = ((uint)(4294967295u));
			this.MODE.TagName = "MODE";
			this.MODE.Val = ((short)(0));
			this.MODE.ValMaximum = ((short)(0));
			this.MODE.ValMinimum = ((short)(0));
			this.MODE.ValUnits = null;
			this.MODE.EndInit();
			// 
			// sDefault
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.rectBase,
			this.rectangle1,
			this.lblSymbol,
			this.txtStatus,
			this.indStatus,
			this.txtMODE,
			this.freeText4,
			this.txtPower,
			this.freeText5,
			this.line1,
			this.line2,
			this.progressBarSOC,
			this.txtSOC,
			this.IALM,
			this.IAVL,
			this.ICHG,
			this.IDIS,
			this.IFLT,
			this.IRUN,
			this.PBAT,
			this.ISTBY,
			this.QLT,
			this.SOC,
			this.MODE,
			this.rectBtn});
			this.SymbolSize = new System.Drawing.Size(600, 400);

		}
		private NxtControl.GuiFramework.Rectangle rectangle1;
		private NxtControl.GuiFramework.Label lblSymbol;
		private NxtControl.GuiFramework.Label txtStatus;
		private NxtControl.GuiFramework.Ellipse indStatus;
		private NxtControl.GuiFramework.Label txtMODE;
		private NxtControl.GuiFramework.FreeText freeText4;
		private NxtControl.GuiFramework.Label txtPower;
		private NxtControl.GuiFramework.FreeText freeText5;
		private NxtControl.GuiFramework.Line line1;
		private NxtControl.GuiFramework.Line line2;
		private NxtControl.GuiFramework.RoundedRectangle rectBtn;
		private NxtControl.GuiFramework.RoundedRectangle rectBase;
		private NxtControl.GuiFramework.RoundedRectangle progressBarSOC;
		private NxtControl.GuiFramework.Label txtSOC;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IALM;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IAVL;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged ICHG;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IDIS;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IFLT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IRUN;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged PBAT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged ISTBY;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged QLT;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged SOC;
		private SE.Agile.Symbols.HMI_Control_Integer_v1_0.sValChanged MODE;
		#endregion
	}
}