/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/26/2026
 *
 * Reusable Solar Plant power link with configurable geometry.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;

using NxtControl.GuiFramework;
using NxtControl.Drawing;

using HMI.Main.SupportClasses;

using AnimationTimer =
	System.Windows.Forms.Timer;

namespace HMI.Main.Graphics
{
	/// <summary>
	/// Reusable animated Solar Plant power link.
	///
	/// Telemetry:
	///     Thin dashed connection. The colour follows QLT.
	///
	/// AC/DC with QLT = FALSE or ABS(PWR) <= PowerDeadband:
	///     Solid inactive connection in a dark colour.
	///
	/// QLT = TRUE and ABS(PWR) > PowerDeadband:
	///     Solid animated power flow.
	///
	/// Positive PWR:
	///     Start point to end point.
	///
	/// Negative PWR:
	///     End point to start point.
	///
	/// All geometry coordinates are local to this Graphic.
	/// </summary>
	public partial class sPowerLink :
		NxtControl.GuiFramework.GraphicSymbol
	{
		private const int ANIMATION_INTERVAL = 100;

		private const double DEFAULT_START_X = 15.0;
		private const double DEFAULT_START_Y = 15.0;
		private const double DEFAULT_END_X = 123.0;
		private const double DEFAULT_END_Y = 15.0;
		private const double DEFAULT_MID_X = 69.0;
		private const double DEFAULT_MID_Y = 69.0;

		private const double MINIMUM_COORDINATE = 15.0;
		private const double MINIMUM_PATH_LENGTH = 0.001;
		private const double POINT_TOLERANCE = 0.001;

		private const double NODE_SIZE = 14.0;
		private const double MARKER_SIZE = 8.0;
		private const double SYMBOL_PADDING = 15.0;

		private const int MINIMUM_SYMBOL_WIDTH = 30;
		private const int MINIMUM_SYMBOL_HEIGHT = 30;

		private const float CONNECTION_WIDTH = 2.0F;
		private const float POWER_WIDTH = 6.0F;

		private const int MAXIMUM_SEGMENTS = 3;

		private static readonly Color COLOR_QUALITY =
			new Color(45, 128, 112);

		private static readonly Color COLOR_DC_MARKER =
			new Color(255, 229, 128);

		private static readonly Color COLOR_AC_MARKER =
			new Color(255, 184, 128);

		private static readonly Color COLOR_TELEMETRY_MARKER =
			new Color(112, 191, 174);
		
		private bool _useCanvasInput;
		private bool _canvasQuality;
		private double _canvasPower;


		public enum PowerLinkType
		{
			Auto = 0,
			DC = 1,
			AC = 2,
			Telemetry = 3
		}

		public enum PowerLinkGeometry
		{
			Straight = 0,
			HorizontalThenVertical = 1,
			VerticalThenHorizontal = 2,
			ViaMidX = 3,
			ViaMidY = 4
		}

		private sealed class PathPoint
		{
			public readonly double X;
			public readonly double Y;

			public PathPoint(
				double x,
				double y)
			{
				X = x;
				Y = y;
			}
		}
		
		public void SetInput(
			bool quality,
			double power)
		{
			_useCanvasInput = true;
			_canvasQuality = quality;
			_canvasPower = power;
		
			SafeUpdateVisual();
		}
		
		public void UseBoundInputs()
		{
			_useCanvasInput = false;
			SafeUpdateVisual();
		}
		
		private bool ReadQuality()
		{
			if (_useCanvasInput)
				return _canvasQuality;
		
			return QLT != null &&
				ToBool(QLT.Val);
		}
		
		private double ReadPower()
		{
			if (_useCanvasInput)
				return _canvasPower;
		
			return PWR != null
				? ToDouble(PWR.Val)
				: 0.0;
		}

		private AnimationTimer _animationTimer;

		private NxtControl.GuiFramework.Line[]
			_connectionSegments;

		private NxtControl.GuiFramework.Line[]
			_powerSegments;

		private bool[] _activeSegments;

		private PathPoint[] _pathPoints =
			new PathPoint[0];

		private double[] _segmentLengths =
			new double[0];

		private double _totalPathLength;
		private double _markerPosition;

		private PowerLinkType _linkType =
			PowerLinkType.Auto;

		private PowerLinkGeometry _geometry =
			PowerLinkGeometry.Straight;

		private string _linkDescription =
			string.Empty;

		private bool _reverseFlow;
		private bool _animationEnabled = true;
		private bool _showEndNodes;
		private bool _autoSizeToPath = true;

		private double _powerDeadband = 0.01;
		private double _powerScale = 5.0;

		private double _startX =
			DEFAULT_START_X;

		private double _startY =
			DEFAULT_START_Y;

		private double _endX =
			DEFAULT_END_X;

		private double _endY =
			DEFAULT_END_Y;

		private double _midX =
			DEFAULT_MID_X;

		private double _midY =
			DEFAULT_MID_Y;

		/* ============================================================= */
		/* Link configuration                                            */
		/* ============================================================= */

		[Category("Power Link")]
		[Description(
			"Auto detects DC, AC or Telemetry from LinkDescription.")]
		[DefaultValue(PowerLinkType.Auto)]
		public PowerLinkType LinkType
		{
			get
			{
				return _linkType;
			}
			set
			{
				_linkType = value;
				SafeUpdateVisual();
			}
		}

		[Category("Power Link")]
		[Description(
			"Description of the connected equipment, for example PV001 -> DCC001.")]
		[DefaultValue("")]
		public string LinkDescription
		{
			get
			{
				return _linkDescription;
			}
			set
			{
				_linkDescription =
					value ?? string.Empty;

				SafeUpdateVisual();
			}
		}

		[Category("Power Link")]
		[Description(
			"Reverse the visual flow direction without changing the PWR sign.")]
		[DefaultValue(false)]
		public bool ReverseFlow
		{
			get
			{
				return _reverseFlow;
			}
			set
			{
				_reverseFlow = value;
				SafeUpdateVisual();
			}
		}

		[Category("Power Link")]
		[Description(
			"Enable or disable the moving power marker.")]
		[DefaultValue(true)]
		public bool AnimationEnabled
		{
			get
			{
				return _animationEnabled;
			}
			set
			{
				_animationEnabled = value;
				SafeUpdateVisual();
			}
		}

		[Category("Power Link")]
		[Description(
			"Show circular start and end nodes. Disabled by default to avoid bright dots where links meet.")]
		[DefaultValue(false)]
		public bool ShowEndNodes
		{
			get
			{
				return _showEndNodes;
			}
			set
			{
				_showEndNodes = value;
				SafeUpdateVisual();
			}
		}

		[Category("Power Link")]
		[Description(
			"Absolute power below this value is treated as zero.")]
		[DefaultValue(0.01D)]
		public double PowerDeadband
		{
			get
			{
				return _powerDeadband;
			}
			set
			{
				_powerDeadband =
					Math.Abs(value);

				SafeUpdateVisual();
			}
		}

		[Category("Power Link")]
		[Description(
			"Power corresponding to maximum animation speed.")]
		[DefaultValue(5.0D)]
		public double PowerScale
		{
			get
			{
				return _powerScale;
			}
			set
			{
				double scale =
					Math.Abs(value);

				_powerScale =
					scale > 0.001
						? scale
						: 0.001;
			}
		}

		/* ============================================================= */
		/* Geometry configuration                                        */
		/* ============================================================= */

		[Category("Power Link Geometry")]
		[Description(
			"Path geometry between the configured start and end points.")]
		[DefaultValue(PowerLinkGeometry.Straight)]
		public PowerLinkGeometry Geometry
		{
			get
			{
				return _geometry;
			}
			set
			{
				_geometry = value;
				SafeUpdateVisual();
			}
		}

		[Category("Power Link Geometry")]
		[Description(
			"Local X coordinate of the start point.")]
		[DefaultValue(DEFAULT_START_X)]
		public double StartX
		{
			get
			{
				return _startX;
			}
			set
			{
				SetCoordinate(
					ref _startX,
					value);
			}
		}

		[Category("Power Link Geometry")]
		[Description(
			"Local Y coordinate of the start point.")]
		[DefaultValue(DEFAULT_START_Y)]
		public double StartY
		{
			get
			{
				return _startY;
			}
			set
			{
				SetCoordinate(
					ref _startY,
					value);
			}
		}

		[Category("Power Link Geometry")]
		[Description(
			"Local X coordinate of the end point.")]
		[DefaultValue(DEFAULT_END_X)]
		public double EndX
		{
			get
			{
				return _endX;
			}
			set
			{
				SetCoordinate(
					ref _endX,
					value);
			}
		}

		[Category("Power Link Geometry")]
		[Description(
			"Local Y coordinate of the end point.")]
		[DefaultValue(DEFAULT_END_Y)]
		public double EndY
		{
			get
			{
				return _endY;
			}
			set
			{
				SetCoordinate(
					ref _endY,
					value);
			}
		}

		[Category("Power Link Geometry")]
		[Description(
			"Intermediate X coordinate used by ViaMidX geometry.")]
		[DefaultValue(DEFAULT_MID_X)]
		public double MidX
		{
			get
			{
				return _midX;
			}
			set
			{
				SetCoordinate(
					ref _midX,
					value);
			}
		}

		[Category("Power Link Geometry")]
		[Description(
			"Intermediate Y coordinate used by ViaMidY geometry.")]
		[DefaultValue(DEFAULT_MID_Y)]
		public double MidY
		{
			get
			{
				return _midY;
			}
			set
			{
				SetCoordinate(
					ref _midY,
					value);
			}
		}

		[Category("Power Link Geometry")]
		[Description(
			"Automatically expands SymbolSize so that every configured point remains inside the Graphic.")]
		[DefaultValue(true)]
		public bool AutoSizeToPath
		{
			get
			{
				return _autoSizeToPath;
			}
			set
			{
				_autoSizeToPath = value;
				SafeUpdateVisual();
			}
		}

		/* ============================================================= */
		/* Constructor                                                    */
		/* ============================================================= */

		public sPowerLink()
		{
			try
			{
				InitializeComponent();
				InitializeSegments();
				InitializeAnimation();
				AttachEvents();
				UpdateGeometry();
				UpdateVisual();
			}
			catch (Exception exception)
			{
				LogError(
					"Initialize sPowerLink",
					exception);
			}
		}

		private void InitializeSegments()
		{
			_connectionSegments =
				new NxtControl.GuiFramework.Line[]
				{
					connectionLine1,
					connectionLine2,
					connectionLine3
				};

			_powerSegments =
				new NxtControl.GuiFramework.Line[]
				{
					powerLine1,
					powerLine2,
					powerLine3
				};

			_activeSegments =
				new bool[MAXIMUM_SEGMENTS];
		}

		private void InitializeAnimation()
		{
			_animationTimer =
				new AnimationTimer();

			_animationTimer.Interval =
				ANIMATION_INTERVAL;

			_animationTimer.Tick +=
				OnAnimationTick;
		}

		private void AttachEvents()
		{
			if (QLT != null)
			{
				QLT.OnValChanged -=
					OnInputValueChanged;

				QLT.OnValChanged +=
					OnInputValueChanged;
			}

			if (PWR != null)
			{
				PWR.OnValChanged -=
					OnInputValueChanged;

				PWR.OnValChanged +=
					OnInputValueChanged;
			}
		}

		/* ============================================================= */
		/* Input handling                                                 */
		/* ============================================================= */

		private void OnInputValueChanged(
			object sender,
			EventArgs e)
		{
			SafeUpdateVisual();
		}

		private void SetCoordinate(
			ref double target,
			double value)
		{
			double coordinate =
				SanitizeCoordinate(value);

			if (Math.Abs(target - coordinate) <
				POINT_TOLERANCE)
			{
				return;
			}

			target = coordinate;
			SafeUpdateVisual();
		}

		private static double SanitizeCoordinate(
			double value)
		{
			if (double.IsNaN(value) ||
				double.IsInfinity(value))
			{
				return MINIMUM_COORDINATE;
			}

			if (value < MINIMUM_COORDINATE)
			{
				return MINIMUM_COORDINATE;
			}

			return value;
		}

		private void SafeUpdateVisual()
		{
			try
			{
				if (_connectionSegments == null ||
					_powerSegments == null)
				{
					return;
				}

				UpdateGeometry();
				UpdateVisual();
			}
			catch (Exception exception)
			{
				LogError(
					"Update power link",
					exception);
			}
		}

		/* ============================================================= */
		/* Geometry                                                       */
		/* ============================================================= */

		private void UpdateGeometry()
		{
			_pathPoints =
				BuildPathPoints();

			UpdateSegmentGeometry();
			UpdateNodeGeometry();
			UpdatePathLengths();

			if (_autoSizeToPath)
			{
				UpdateSymbolSize();
			}

			UpdateMarkerPosition();
		}

		private PathPoint[] BuildPathPoints()
		{
			List<PathPoint> points =
				new List<PathPoint>();

			AddPathPoint(
				points,
				_startX,
				_startY);

			switch (_geometry)
			{
				case PowerLinkGeometry
					.HorizontalThenVertical:

					AddPathPoint(
						points,
						_endX,
						_startY);
					break;

				case PowerLinkGeometry
					.VerticalThenHorizontal:

					AddPathPoint(
						points,
						_startX,
						_endY);
					break;

				case PowerLinkGeometry.ViaMidX:
					AddPathPoint(
						points,
						_midX,
						_startY);

					AddPathPoint(
						points,
						_midX,
						_endY);
					break;

				case PowerLinkGeometry.ViaMidY:
					AddPathPoint(
						points,
						_startX,
						_midY);

					AddPathPoint(
						points,
						_endX,
						_midY);
					break;
			}

			AddPathPoint(
				points,
				_endX,
				_endY);

			return points.ToArray();
		}

		private static void AddPathPoint(
			List<PathPoint> points,
			double x,
			double y)
		{
			if (points == null)
				return;

			if (points.Count > 0)
			{
				PathPoint previous =
					points[points.Count - 1];

				if (Math.Abs(previous.X - x) <
						POINT_TOLERANCE &&
					Math.Abs(previous.Y - y) <
						POINT_TOLERANCE)
				{
					return;
				}
			}

			points.Add(
				new PathPoint(x, y));
		}

		private void UpdateSegmentGeometry()
		{
			for (int i = 0;
				i < MAXIMUM_SEGMENTS;
				i++)
			{
				bool isActive =
					_pathPoints != null &&
					i < (_pathPoints.Length - 1);

				_activeSegments[i] =
					isActive;

				if (!isActive)
				{
					_connectionSegments[i].Visible =
						false;

					_powerSegments[i].Visible =
						false;

					continue;
				}

				PathPoint start =
					_pathPoints[i];

				PathPoint end =
					_pathPoints[i + 1];

				PointF startPoint =
					new PointF(
						start.X,
						start.Y);

				PointF endPoint =
					new PointF(
						end.X,
						end.Y);

				_connectionSegments[i].StartPoint =
					startPoint;

				_connectionSegments[i].EndPoint =
					endPoint;

				_powerSegments[i].StartPoint =
					startPoint;

				_powerSegments[i].EndPoint =
					endPoint;
			}
		}

		private void UpdateNodeGeometry()
		{
			if (_pathPoints == null ||
				_pathPoints.Length == 0)
			{
				return;
			}

			PathPoint first =
				_pathPoints[0];

			PathPoint last =
				_pathPoints[
					_pathPoints.Length - 1];

			startNode.Bounds =
				CreateCenteredBounds(
					first.X,
					first.Y,
					NODE_SIZE);

			endNode.Bounds =
				CreateCenteredBounds(
					last.X,
					last.Y,
					NODE_SIZE);
		}

		private void UpdatePathLengths()
		{
			if (_pathPoints == null ||
				_pathPoints.Length < 2)
			{
				_segmentLengths =
					new double[0];

				_totalPathLength = 0.0;
				return;
			}

			_segmentLengths =
				new double[
					_pathPoints.Length - 1];

			_totalPathLength = 0.0;

			for (int i = 0;
				i < _segmentLengths.Length;
				i++)
			{
				PathPoint start =
					_pathPoints[i];

				PathPoint end =
					_pathPoints[i + 1];

				double deltaX =
					end.X - start.X;

				double deltaY =
					end.Y - start.Y;

				double length =
					Math.Sqrt(
						(deltaX * deltaX) +
						(deltaY * deltaY));

				_segmentLengths[i] =
					length;

				_totalPathLength +=
					length;
			}
		}

		private void UpdateSymbolSize()
		{
			if (_pathPoints == null ||
				_pathPoints.Length == 0)
			{
				return;
			}

			double maximumX = 0.0;
			double maximumY = 0.0;

			for (int i = 0;
				i < _pathPoints.Length;
				i++)
			{
				if (_pathPoints[i].X > maximumX)
				{
					maximumX =
						_pathPoints[i].X;
				}

				if (_pathPoints[i].Y > maximumY)
				{
					maximumY =
						_pathPoints[i].Y;
				}
			}

			int width =
				(int)Math.Ceiling(
					maximumX +
					SYMBOL_PADDING);

			int height =
				(int)Math.Ceiling(
					maximumY +
					SYMBOL_PADDING);

			if (width < MINIMUM_SYMBOL_WIDTH)
			{
				width =
					MINIMUM_SYMBOL_WIDTH;
			}

			if (height < MINIMUM_SYMBOL_HEIGHT)
			{
				height =
					MINIMUM_SYMBOL_HEIGHT;
			}

			this.SymbolSize =
				new System.Drawing.Size(
					width,
					height);
		}

		private static RectF CreateCenteredBounds(
			double centerX,
			double centerY,
			double size)
		{
			return new RectF(
				(float)(
					centerX -
					(size / 2.0)),
				(float)(
					centerY -
					(size / 2.0)),
				(float)size,
				(float)size);
		}

		/* ============================================================= */
		/* Visual state                                                   */
		/* ============================================================= */

		private void UpdateVisual()
		{
			bool quality = ReadQuality();
			double power = ReadPower();

			PowerLinkType resolvedType =
				ResolveLinkType();

			bool powerActive =
				IsPowerActive(
					quality,
					power,
					resolvedType);

			bool isTelemetry =
				resolvedType ==
					PowerLinkType.Telemetry;

			Color connectionColor =
				quality
					? COLOR_QUALITY
					: SolarTheme.Status.Offline;

			Color flowColor =
				GetFlowColor(
					resolvedType);

			Color powerColor =
				powerActive
					? flowColor
					: SolarTheme.Flow.Inactive;

			Color nodeColor =
				isTelemetry
					? connectionColor
					: powerColor;

			for (int i = 0;
				i < MAXIMUM_SEGMENTS;
				i++)
			{
				bool segmentActive =
					_activeSegments != null &&
					_activeSegments[i];

				_connectionSegments[i].Visible =
					segmentActive &&
					isTelemetry;

				_connectionSegments[i].Pen =
					new Pen(
						connectionColor,
						CONNECTION_WIDTH,
						DashStyle.Dash);

				_powerSegments[i].Visible =
					segmentActive &&
					!isTelemetry;

				_powerSegments[i].Pen =
					new Pen(
						powerColor,
						POWER_WIDTH,
						DashStyle.Solid);
			}

			startNode.Visible =
				_showEndNodes;

			endNode.Visible =
				_showEndNodes;

			startNode.BrushColor =
				nodeColor;

			endNode.BrushColor =
				nodeColor;

			flowMarker.BrushColor =
				GetMarkerColor(
					resolvedType);

			UpdateAnimationState(
				powerActive);
		}

		private bool IsPowerActive(
			bool quality,
			double power,
			PowerLinkType linkType)
		{
			if (!quality)
				return false;

			if (_totalPathLength <=
				MINIMUM_PATH_LENGTH)
			{
				return false;
			}

			if (linkType ==
				PowerLinkType.Telemetry)
			{
				return false;
			}

			return Math.Abs(power) >
				_powerDeadband;
		}

		/* ============================================================= */
		/* Type detection                                                 */
		/* ============================================================= */

		private PowerLinkType ResolveLinkType()
		{
			if (_linkType !=
				PowerLinkType.Auto)
			{
				return _linkType;
			}

			string description =
				(_linkDescription ?? string.Empty)
					.ToUpperInvariant();

			if (ContainsAny(
				description,
				new string[]
				{
					"PPC",
					"QLT",
					"QUALITY",
					"COMM",
					"TELEMETRY",
					"CONTROL"
				}))
			{
				return PowerLinkType.Telemetry;
			}

			if (ContainsAny(
				description,
				new string[]
				{
					"PV",
					"DCC",
					"COMBINER",
					"DC BUS",
					"DC POWER"
				}))
			{
				return PowerLinkType.DC;
			}

			if (ContainsAny(
				description,
				new string[]
				{
					"AC",
					"INV",
					"INVERTER",
					"BESS",
					"GRID",
					"TRF",
					"TRANSFORMER",
					"OWN LOAD",
					"BD001"
				}))
			{
				return PowerLinkType.AC;
			}

			return PowerLinkType.DC;
		}

		private static bool ContainsAny(
			string source,
			string[] values)
		{
			if (string.IsNullOrEmpty(source) ||
				values == null)
			{
				return false;
			}

			for (int i = 0;
				i < values.Length;
				i++)
			{
				if (source.IndexOf(
					values[i],
					StringComparison.OrdinalIgnoreCase)
					>= 0)
				{
					return true;
				}
			}

			return false;
		}

		private static Color GetFlowColor(
			PowerLinkType linkType)
		{
			switch (linkType)
			{
				case PowerLinkType.AC:
					return SolarTheme.Flow.AcPower;

				case PowerLinkType.Telemetry:
					return COLOR_QUALITY;

				case PowerLinkType.DC:
				default:
					return SolarTheme.Flow.DcPower;
			}
		}

		private static Color GetMarkerColor(
			PowerLinkType linkType)
		{
			switch (linkType)
			{
				case PowerLinkType.AC:
					return COLOR_AC_MARKER;

				case PowerLinkType.Telemetry:
					return COLOR_TELEMETRY_MARKER;

				case PowerLinkType.DC:
				default:
					return COLOR_DC_MARKER;
			}
		}

		/* ============================================================= */
		/* Animation                                                      */
		/* ============================================================= */

		private void UpdateAnimationState(
			bool powerActive)
		{
			bool shouldAnimate =
				powerActive &&
				_animationEnabled &&
				_totalPathLength >
					MINIMUM_PATH_LENGTH;

			flowMarker.Visible =
				shouldAnimate;

			if (_animationTimer == null)
				return;

			if (shouldAnimate)
			{
				if (!_animationTimer.Enabled)
				{
					_animationTimer.Start();
				}
			}
			else
			{
				if (_animationTimer.Enabled)
				{
					_animationTimer.Stop();
				}

				_markerPosition = 0.0;
				UpdateMarkerPosition();
			}
		}

		private void OnAnimationTick(
			object sender,
			EventArgs e)
		{
			try
			{
				bool quality =
					ReadQuality();

				double power =
					ReadPower();

				PowerLinkType resolvedType =
					ResolveLinkType();

				if (!_animationEnabled ||
					!IsPowerActive(
						quality,
						power,
						resolvedType))
				{
					UpdateVisual();
					return;
				}

				double ratio =
					Math.Abs(power) /
					_powerScale;

				if (ratio > 1.0)
					ratio = 1.0;

				double pixelStep =
					2.0 + (4.0 * ratio);

				double positionStep =
					pixelStep /
					_totalPathLength;

				bool forward =
					power > 0.0;

				if (_reverseFlow)
				{
					forward = !forward;
				}

				_markerPosition +=
					forward
						? positionStep
						: -positionStep;

				if (_markerPosition > 1.0)
				{
					_markerPosition -= 1.0;
				}
				else if (_markerPosition < 0.0)
				{
					_markerPosition += 1.0;
				}

				UpdateMarkerPosition();
			}
			catch (Exception exception)
			{
				LogError(
					"Animate power link",
					exception);
			}
		}

		private void UpdateMarkerPosition()
		{
			if (flowMarker == null ||
				_pathPoints == null ||
				_pathPoints.Length < 2 ||
				_segmentLengths == null ||
				_totalPathLength <=
					MINIMUM_PATH_LENGTH)
			{
				return;
			}

			double targetDistance =
				_totalPathLength *
				_markerPosition;

			double traversedDistance = 0.0;

			for (int i = 0;
				i < _segmentLengths.Length;
				i++)
			{
				double segmentLength =
					_segmentLengths[i];

				bool isLastSegment =
					i ==
					(_segmentLengths.Length - 1);

				if (targetDistance <=
						(traversedDistance +
							segmentLength) ||
					isLastSegment)
				{
					double localDistance =
						targetDistance -
						traversedDistance;

					double localRatio =
						segmentLength >
							MINIMUM_PATH_LENGTH
							? localDistance /
								segmentLength
							: 0.0;

					if (localRatio < 0.0)
						localRatio = 0.0;

					if (localRatio > 1.0)
						localRatio = 1.0;

					PathPoint start =
						_pathPoints[i];

					PathPoint end =
						_pathPoints[i + 1];

					double markerCenterX =
						start.X +
						((end.X - start.X) *
							localRatio);

					double markerCenterY =
						start.Y +
						((end.Y - start.Y) *
							localRatio);

					flowMarker.Bounds =
						CreateCenteredBounds(
							markerCenterX,
							markerCenterY,
							MARKER_SIZE);

					return;
				}

				traversedDistance +=
					segmentLength;
			}
		}

		/* ============================================================= */
		/* Conversion helpers                                             */
		/* ============================================================= */

		private static bool ToBool(
			object value)
		{
			try
			{
				return Convert.ToBoolean(value);
			}
			catch
			{
				return false;
			}
		}

		private static double ToDouble(
			object value)
		{
			try
			{
				double result =
					Convert.ToDouble(value);

				if (double.IsNaN(result) ||
					double.IsInfinity(result))
				{
					return 0.0;
				}

				return result;
			}
			catch
			{
				return 0.0;
			}
		}

		private static void LogError(
			string operation,
			Exception exception)
		{
			try
			{
				NxtControl.Services.LoggingService.ErrorFormatted(
					"sPowerLink: {0}. Error: {1}",
					operation,
					exception != null
						? exception.Message
						: "Unknown error");
			}
			catch
			{
				// Prevent animation errors from crashing the HMI.
			}
		}
	}
}
