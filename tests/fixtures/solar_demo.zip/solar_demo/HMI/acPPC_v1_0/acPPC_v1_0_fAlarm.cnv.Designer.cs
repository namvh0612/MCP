/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/16/2026
 * Time: 4:39 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using NxtControl.GuiFramework;

namespace HMI.Main.Faceplates.acPPC_v1_0
{
	/// <summary>
	/// Summary description for fAlarm.
	/// </summary>
	partial class fAlarm
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new NxtControl.GuiFramework.Label();
			this.label2 = new NxtControl.GuiFramework.Label();
			this.label3 = new NxtControl.GuiFramework.Label();
			this.label4 = new NxtControl.GuiFramework.Label();
			this.label5 = new NxtControl.GuiFramework.Label();
			this.label6 = new NxtControl.GuiFramework.Label();
			this.label7 = new NxtControl.GuiFramework.Label();
			this.label8 = new NxtControl.GuiFramework.Label();
			this.label9 = new NxtControl.GuiFramework.Label();
			this.label10 = new NxtControl.GuiFramework.Label();
			this.ALMW = new SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged();
			// 
			// label1
			// 
			this.label1.AngleIgnore = true;
			this.label1.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label1.Bounds = new NxtControl.Drawing.RectF(((float)(23D)), ((float)(19D)), ((float)(188D)), ((float)(26D)));
			this.label1.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.label1.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.label1.FontScale = true;
			this.label1.Name = "label1";
			this.label1.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label1.Text = "Label";
			this.label1.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.label1.TextAutoSizeHorizontalOffset = 10;
			this.label1.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.label1.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// label2
			// 
			this.label2.AngleIgnore = true;
			this.label2.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label2.Bounds = new NxtControl.Drawing.RectF(((float)(23D)), ((float)(56D)), ((float)(188D)), ((float)(26D)));
			this.label2.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.label2.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.label2.FontScale = true;
			this.label2.Name = "label2";
			this.label2.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label2.Text = "Label";
			this.label2.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.label2.TextAutoSizeHorizontalOffset = 10;
			this.label2.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.label2.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// label3
			// 
			this.label3.AngleIgnore = true;
			this.label3.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label3.Bounds = new NxtControl.Drawing.RectF(((float)(23D)), ((float)(93D)), ((float)(188D)), ((float)(26D)));
			this.label3.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.label3.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.label3.FontScale = true;
			this.label3.Name = "label3";
			this.label3.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label3.Text = "Label";
			this.label3.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.label3.TextAutoSizeHorizontalOffset = 10;
			this.label3.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.label3.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// label4
			// 
			this.label4.AngleIgnore = true;
			this.label4.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label4.Bounds = new NxtControl.Drawing.RectF(((float)(23D)), ((float)(130D)), ((float)(188D)), ((float)(26D)));
			this.label4.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.label4.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.label4.FontScale = true;
			this.label4.Name = "label4";
			this.label4.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label4.Text = "Label";
			this.label4.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.label4.TextAutoSizeHorizontalOffset = 10;
			this.label4.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.label4.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// label5
			// 
			this.label5.AngleIgnore = true;
			this.label5.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label5.Bounds = new NxtControl.Drawing.RectF(((float)(23D)), ((float)(167D)), ((float)(188D)), ((float)(26D)));
			this.label5.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.label5.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.label5.FontScale = true;
			this.label5.Name = "label5";
			this.label5.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label5.Text = "Label";
			this.label5.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.label5.TextAutoSizeHorizontalOffset = 10;
			this.label5.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.label5.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// label6
			// 
			this.label6.AngleIgnore = true;
			this.label6.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label6.Bounds = new NxtControl.Drawing.RectF(((float)(23D)), ((float)(204D)), ((float)(188D)), ((float)(26D)));
			this.label6.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.label6.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.label6.FontScale = true;
			this.label6.Name = "label6";
			this.label6.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label6.Text = "Label";
			this.label6.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.label6.TextAutoSizeHorizontalOffset = 10;
			this.label6.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.label6.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// label7
			// 
			this.label7.AngleIgnore = true;
			this.label7.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label7.Bounds = new NxtControl.Drawing.RectF(((float)(23D)), ((float)(241D)), ((float)(188D)), ((float)(26D)));
			this.label7.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.label7.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.label7.FontScale = true;
			this.label7.Name = "label7";
			this.label7.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label7.Text = "Label";
			this.label7.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.label7.TextAutoSizeHorizontalOffset = 10;
			this.label7.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.label7.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// label8
			// 
			this.label8.AngleIgnore = true;
			this.label8.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label8.Bounds = new NxtControl.Drawing.RectF(((float)(23D)), ((float)(278D)), ((float)(188D)), ((float)(26D)));
			this.label8.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.label8.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.label8.FontScale = true;
			this.label8.Name = "label8";
			this.label8.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label8.Text = "Label";
			this.label8.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.label8.TextAutoSizeHorizontalOffset = 10;
			this.label8.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.label8.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// label9
			// 
			this.label9.AngleIgnore = true;
			this.label9.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label9.Bounds = new NxtControl.Drawing.RectF(((float)(23D)), ((float)(315D)), ((float)(188D)), ((float)(26D)));
			this.label9.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.label9.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.label9.FontScale = true;
			this.label9.Name = "label9";
			this.label9.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label9.Text = "Label";
			this.label9.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.label9.TextAutoSizeHorizontalOffset = 10;
			this.label9.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.label9.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// label10
			// 
			this.label10.AngleIgnore = true;
			this.label10.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label10.Bounds = new NxtControl.Drawing.RectF(((float)(23D)), ((float)(348D)), ((float)(188D)), ((float)(26D)));
			this.label10.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.label10.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.label10.FontScale = true;
			this.label10.Name = "label10";
			this.label10.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label10.Text = "Label";
			this.label10.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.label10.TextAutoSizeHorizontalOffset = 10;
			this.label10.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.label10.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// ALMW
			// 
			this.ALMW.BeginInit();
			this.ALMW.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 93D, 95D);
			this.ALMW.Name = "ALMW";
			this.ALMW.SecurityToken = ((uint)(4294967295u));
			this.ALMW.TagName = "ALMW";
			this.ALMW.Val = ((short)(0));
			this.ALMW.ValMaximum = ((short)(0));
			this.ALMW.ValMinimum = ((short)(0));
			this.ALMW.ValUnits = null;
			this.ALMW.EndInit();
			// 
			// fAlarm
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(227D)), ((float)(400D)));
			this.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(3)), ((byte)(22)), ((byte)(20))));
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.label1,
			this.label2,
			this.label3,
			this.label4,
			this.label5,
			this.label6,
			this.label7,
			this.label8,
			this.label9,
			this.label10,
			this.ALMW});
			this.Size = new System.Drawing.Size(227, 400);

		}
		private NxtControl.GuiFramework.Label label1;
		private NxtControl.GuiFramework.Label label2;
		private NxtControl.GuiFramework.Label label3;
		private NxtControl.GuiFramework.Label label4;
		private NxtControl.GuiFramework.Label label5;
		private NxtControl.GuiFramework.Label label6;
		private NxtControl.GuiFramework.Label label7;
		private NxtControl.GuiFramework.Label label8;
		private NxtControl.GuiFramework.Label label9;
		private NxtControl.GuiFramework.Label label10;
		private SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged ALMW;
		#endregion
	}
}
