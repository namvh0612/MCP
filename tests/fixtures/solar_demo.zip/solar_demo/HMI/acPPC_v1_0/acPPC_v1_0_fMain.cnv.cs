/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/16/2026
 * Time: 3:52 PM
 */

using System;
using NxtControl.GuiFramework;
using NxtControl.Drawing;
using HMI.Main.SupportClasses;

namespace HMI.Main.Faceplates.acPPC_v1_0
{
	public partial class fMain :
		NxtControl.GuiFramework.HMIFaceplate
	{
		private const double POWER_DEADBAND = 0.001;
		private const double CURTAILMENT_THRESHOLD = 0.1;
		private const double AVAILABILITY_WARNING_LIMIT = 95.0;
		private const double PERFORMANCE_WARNING_LIMIT = 70.0;

		private PpcVisualStatus _currentStatus =
			PpcVisualStatus.Offline;

		private enum PpcVisualStatus
		{
			Offline,
			Fault,
			Alarm,
			Running,
			Exporting,
			Importing,
			Curtailing,
			Standby,
			Unknown
		}

		public fMain()
		{
			InitializeComponent();
			AttachEvents();
			UpdateDisplay();
		}

		private void AttachEvents()
		{
			REQ_Fired += REQ_Fired_EventHandler;

			IAVL.OnValChanged += OnPpcValueChanged;
			IRUN.OnValChanged += OnPpcValueChanged;
			IALM.OnValChanged += OnPpcValueChanged;
			IFLT.OnValChanged += OnPpcValueChanged;
			QLT.OnValChanged += OnPpcValueChanged;
			ISTA.OnValChanged += OnPpcValueChanged;

			EXPLIM.OnValChanged += OnPpcValueChanged;
			IMPLIM.OnValChanged += OnPpcValueChanged;
			RMPUP.OnValChanged += OnPpcValueChanged;
			RMPDN.OnValChanged += OnPpcValueChanged;

			PNET.OnValChanged += OnPpcValueChanged;
			QNET.OnValChanged += OnPpcValueChanged;
			CURT.OnValChanged += OnPpcValueChanged;
			EGEN.OnValChanged += OnPpcValueChanged;
			AVL.OnValChanged += OnPpcValueChanged;
			PR.OnValChanged += OnPpcValueChanged;
		}

		private void OnPpcValueChanged(
			object sender,
			EventArgs e)
		{
			UpdateDisplay();
		}

		private void UpdateDisplay()
		{
			_currentStatus = ResolveStatus();

			Color defaultValueColor =
				GetDefaultValueColor();

			HmiDisplayHelper.DisplayData displayData =
				new HmiDisplayHelper.DisplayData();

			displayData.Status =
				GetEquipmentState(_currentStatus);

			displayData.Items =
				new HmiDisplayHelper.DisplayItem[]
				{
					HmiDisplayHelper.CreateText(
						txtStatus,
						GetStatusText(_currentStatus),
						GetStatusColor(_currentStatus)),

					HmiDisplayHelper.CreateValue(
						txtEXPLIM,
						EXPLIM.Val,
						"0.00",
						" MW",
						defaultValueColor),

					HmiDisplayHelper.CreateValue(
						txtIMPLIM,
						IMPLIM.Val,
						"0.00",
						" MW",
						defaultValueColor),

					HmiDisplayHelper.CreateValue(
						txtRMPUP,
						RMPUP.Val,
						"0.00",
						" MW/m",
						defaultValueColor),

					HmiDisplayHelper.CreateValue(
						txtRMPDN,
						RMPDN.Val,
						"0.00",
						" MW/m",
						defaultValueColor),

					HmiDisplayHelper.CreateText(
						txtPNET,
						GetSignedValueText(
							PNET.Val,
							"0.00",
							" MW"),
						GetActiveBalanceColor()),

					HmiDisplayHelper.CreateText(
						txtQNET,
						GetSignedValueText(
							QNET.Val,
							"0.00",
							" MVAr"),
						defaultValueColor),

					HmiDisplayHelper.CreateValue(
						txtCURT,
						CURT.Val,
						"0.0",
						" %",
						GetCurtailmentColor()),

					HmiDisplayHelper.CreateValue(
						txtEGEN,
						EGEN.Val,
						"0.00",
						" MWh",
						defaultValueColor),

					HmiDisplayHelper.CreateValue(
						txtAVL,
						AVL.Val,
						"0.0",
						" %",
						GetAvailabilityColor()),

					HmiDisplayHelper.CreateValue(
						txtPR,
						PR.Val,
						"0.0",
						" %",
						GetPerformanceColor())
				};

			HmiDisplayHelper.Apply(displayData);
		}

		private PpcVisualStatus ResolveStatus()
		{
			if (!HmiValueHelper.ToBool(QLT.Val))
			{
				return PpcVisualStatus.Offline;
			}

			if (HmiValueHelper.ToBool(IFLT.Val))
			{
				return PpcVisualStatus.Fault;
			}

			if (HmiValueHelper.ToBool(IALM.Val))
			{
				return PpcVisualStatus.Alarm;
			}

			switch (HmiValueHelper.ToInt(ISTA.Val))
			{
				case 5:
					return PpcVisualStatus.Exporting;

				case 6:
					return PpcVisualStatus.Importing;

				case 7:
					return PpcVisualStatus.Curtailing;

				case 4:
					return PpcVisualStatus.Running;

				case 3:
					return PpcVisualStatus.Standby;
			}

			if (HmiValueHelper.ToBool(IRUN.Val))
			{
				return PpcVisualStatus.Running;
			}

			return PpcVisualStatus.Standby;
		}

		private SolarTheme.EquipmentState GetEquipmentState(
			PpcVisualStatus status)
		{
			switch (status)
			{
				case PpcVisualStatus.Fault:
					return SolarTheme.EquipmentState.Fault;

				case PpcVisualStatus.Alarm:
					return SolarTheme.EquipmentState.Warning;

				case PpcVisualStatus.Running:
				case PpcVisualStatus.Exporting:
				case PpcVisualStatus.Importing:
				case PpcVisualStatus.Curtailing:
					return SolarTheme.EquipmentState.Running;

				case PpcVisualStatus.Standby:
					return SolarTheme.EquipmentState.Standby;
				
				case PpcVisualStatus.Unknown:
					return SolarTheme.EquipmentState.Unknown;
				
				case PpcVisualStatus.Offline:
					return SolarTheme.EquipmentState.Offline;
				
				default:
					return SolarTheme.EquipmentState.Unknown;
			}
		}

		private string GetStatusText(
			PpcVisualStatus status)
		{
			switch (status)
			{
				case PpcVisualStatus.Fault:
					return "Fault";

				case PpcVisualStatus.Alarm:
					return "Alarm";

				case PpcVisualStatus.Running:
					return "Normal";

				case PpcVisualStatus.Exporting:
					return "Exporting";

				case PpcVisualStatus.Importing:
					return "Importing";

				case PpcVisualStatus.Curtailing:
					return "Curtailing";

				case PpcVisualStatus.Standby:
					return "Standby";

				case PpcVisualStatus.Unknown:
					return "Unknown";
				
				case PpcVisualStatus.Offline:
					return "Offline";
				
				default:
					return "Unknown";
			}
		}

		private Color GetStatusColor(
			PpcVisualStatus status)
		{
			switch (status)
			{
				case PpcVisualStatus.Fault:
					return SolarTheme.Status.Fault;

				case PpcVisualStatus.Alarm:
					return SolarTheme.Status.Warning;

				case PpcVisualStatus.Importing:
				case PpcVisualStatus.Curtailing:
					return SolarTheme.Flow.AcPower;

				case PpcVisualStatus.Running:
				case PpcVisualStatus.Exporting:
					return SolarTheme.Status.Healthy;

				case PpcVisualStatus.Standby:
					return SolarTheme.Status.Standby;
				
				case PpcVisualStatus.Unknown:
					return SolarTheme.Status.Unknown;
				
				case PpcVisualStatus.Offline:
					return SolarTheme.Status.Offline;
				
				default:
					return SolarTheme.Status.Unknown;
			}
		}

		private Color GetDefaultValueColor()
		{
			if (_currentStatus ==
				PpcVisualStatus.Offline)
			{
				return SolarTheme.Status.Offline;
			}

			if (_currentStatus ==
				PpcVisualStatus.Fault)
			{
				return SolarTheme.Status.Fault;
			}

			return SolarTheme.Text.Primary;
		}

		private string GetSignedValueText(
			object value,
			string format,
			string unit)
		{
			double number =
				HmiValueHelper.ToDouble(value);

			if (number > POWER_DEADBAND)
			{
				return "+"
					+ number.ToString(format)
					+ unit;
			}

			if (number < -POWER_DEADBAND)
			{
				return number.ToString(format)
					+ unit;
			}

			return 0.0.ToString(format)
				+ unit;
		}

		private Color GetActiveBalanceColor()
		{
			Color unavailableColor =
				GetUnavailableValueColor();

			if (unavailableColor != null)
			{
				return unavailableColor;
			}

			double power =
				HmiValueHelper.ToDouble(PNET.Val);

			if (power < -POWER_DEADBAND)
			{
				return SolarTheme.Flow.AcPower;
			}

			return SolarTheme.Text.Primary;
		}

		private Color GetCurtailmentColor()
		{
			Color unavailableColor =
				GetUnavailableValueColor();

			if (unavailableColor != null)
			{
				return unavailableColor;
			}

			return HmiValueHelper.ToDouble(CURT.Val)
				> CURTAILMENT_THRESHOLD
					? SolarTheme.Flow.AcPower
					: SolarTheme.Text.Primary;
		}

		private Color GetAvailabilityColor()
		{
			Color unavailableColor =
				GetUnavailableValueColor();

			if (unavailableColor != null)
			{
				return unavailableColor;
			}

			return HmiValueHelper.ToDouble(AVL.Val)
				< AVAILABILITY_WARNING_LIMIT
					? SolarTheme.Status.Warning
					: SolarTheme.Text.Primary;
		}

		private Color GetPerformanceColor()
		{
			Color unavailableColor =
				GetUnavailableValueColor();

			if (unavailableColor != null)
			{
				return unavailableColor;
			}

			return HmiValueHelper.ToDouble(PR.Val)
				< PERFORMANCE_WARNING_LIMIT
					? SolarTheme.Status.Warning
					: SolarTheme.Text.Primary;
		}

		private Color GetUnavailableValueColor()
		{
			if (_currentStatus ==
				PpcVisualStatus.Offline)
			{
				return SolarTheme.Status.Offline;
			}

			if (_currentStatus ==
				PpcVisualStatus.Fault)
			{
				return SolarTheme.Status.Fault;
			}

			return null;
		}

		private void REQ_Fired_EventHandler(
			object sender,
			HMI.Main.Symbols.acPPC_v1_0.REQEventArgs e)
		{
			Title =
				HmiValueHelper.SafeText(
					e.AssetName,
					"PPC");

			UpdateDisplay();
		}
	}
}