/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/16/2026
 * Time: 3:52 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using NxtControl.GuiFramework;

namespace HMI.Main.Faceplates.acPPC_v1_0
{
	/// <summary>
	/// Summary description for fMain.
	/// </summary>
	partial class fMain
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fMain));
			this.freeText1 = new NxtControl.GuiFramework.FreeText();
			this.txtStatus = new NxtControl.GuiFramework.Label();
			this.freeText7 = new NxtControl.GuiFramework.FreeText();
			this.rectangle1 = new NxtControl.GuiFramework.Rectangle();
			this.txtEXPLIM = new NxtControl.GuiFramework.Label();
			this.freeText5 = new NxtControl.GuiFramework.FreeText();
			this.rectangle4 = new NxtControl.GuiFramework.Rectangle();
			this.txtIMPLIM = new NxtControl.GuiFramework.Label();
			this.freeText2 = new NxtControl.GuiFramework.FreeText();
			this.rectangle2 = new NxtControl.GuiFramework.Rectangle();
			this.txtRMPUP = new NxtControl.GuiFramework.Label();
			this.freeText3 = new NxtControl.GuiFramework.FreeText();
			this.rectangle3 = new NxtControl.GuiFramework.Rectangle();
			this.txtRMPDN = new NxtControl.GuiFramework.Label();
			this.freeText4 = new NxtControl.GuiFramework.FreeText();
			this.rectangle5 = new NxtControl.GuiFramework.Rectangle();
			this.txtPNET = new NxtControl.GuiFramework.Label();
			this.freeText6 = new NxtControl.GuiFramework.FreeText();
			this.rectangle6 = new NxtControl.GuiFramework.Rectangle();
			this.txtQNET = new NxtControl.GuiFramework.Label();
			this.freeText8 = new NxtControl.GuiFramework.FreeText();
			this.rectangle7 = new NxtControl.GuiFramework.Rectangle();
			this.txtCURT = new NxtControl.GuiFramework.Label();
			this.freeText9 = new NxtControl.GuiFramework.FreeText();
			this.rectangle8 = new NxtControl.GuiFramework.Rectangle();
			this.line3 = new NxtControl.GuiFramework.Line();
			this.txtEGEN = new NxtControl.GuiFramework.Label();
			this.freeText11 = new NxtControl.GuiFramework.FreeText();
			this.rectangle10 = new NxtControl.GuiFramework.Rectangle();
			this.txtAVL = new NxtControl.GuiFramework.Label();
			this.freeText12 = new NxtControl.GuiFramework.FreeText();
			this.rectangle11 = new NxtControl.GuiFramework.Rectangle();
			this.txtPR = new NxtControl.GuiFramework.Label();
			this.freeText13 = new NxtControl.GuiFramework.FreeText();
			this.rectangle12 = new NxtControl.GuiFramework.Rectangle();
			this.sButtonNavDemo1 = new SE.Agile.Symbols.Broadcaster_v1_0.sButtonNavDemo();
			this.EXPLIM = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValChanged();
			this.IMPLIM = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValChanged();
			this.RMPDN = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValChanged();
			this.RMPUP = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValChanged();
			this.CURT = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.EGEN = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.QNET = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.PNET = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.PR = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.QLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.ISTA = new SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged();
			this.IRUN = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IFLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IAVL = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IALM = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.AVL = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.ALMW = new SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged();
			// 
			// freeText1
			// 
			this.freeText1.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText1.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Italic);
			this.freeText1.Location = new NxtControl.Drawing.PointF(14D, 355D);
			this.freeText1.Name = "freeText1";
			this.freeText1.Text = "Connector Info.";
			// 
			// txtStatus
			// 
			this.txtStatus.AngleIgnore = true;
			this.txtStatus.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtStatus.Bounds = new NxtControl.Drawing.RectF(((float)(130D)), ((float)(11D)), ((float)(82D)), ((float)(26D)));
			this.txtStatus.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtStatus.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtStatus.FontScale = true;
			this.txtStatus.Name = "txtStatus";
			this.txtStatus.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fAlarm", NxtControl.GuiFramework.MouseButtonType.Click));
			this.txtStatus.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtStatus.Text = "Normal";
			this.txtStatus.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtStatus.TextAutoSizeHorizontalOffset = 10;
			this.txtStatus.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtStatus.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText7
			// 
			this.freeText7.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText7.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText7.Location = new NxtControl.Drawing.PointF(40D, 15D);
			this.freeText7.Name = "freeText7";
			this.freeText7.Text = "Status";
			// 
			// rectangle1
			// 
			this.rectangle1.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(16D)), ((float)(16D)), ((float)(16D)));
			this.rectangle1.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle1.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle1.ImageBytes = resources.GetString("rectangle1.ImageBytes");
			this.rectangle1.Name = "rectangle1";
			this.rectangle1.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// txtEXPLIM
			// 
			this.txtEXPLIM.AngleIgnore = true;
			this.txtEXPLIM.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtEXPLIM.Bounds = new NxtControl.Drawing.RectF(((float)(130D)), ((float)(41D)), ((float)(82D)), ((float)(26D)));
			this.txtEXPLIM.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtEXPLIM.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtEXPLIM.FontScale = true;
			this.txtEXPLIM.Name = "txtEXPLIM";
			this.txtEXPLIM.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fAlarm", NxtControl.GuiFramework.MouseButtonType.Click));
			this.txtEXPLIM.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtEXPLIM.Text = "4.00 MW";
			this.txtEXPLIM.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtEXPLIM.TextAutoSizeHorizontalOffset = 10;
			this.txtEXPLIM.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtEXPLIM.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText5
			// 
			this.freeText5.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText5.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText5.Location = new NxtControl.Drawing.PointF(40D, 45D);
			this.freeText5.Name = "freeText5";
			this.freeText5.Text = "Export Limit";
			// 
			// rectangle4
			// 
			this.rectangle4.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(46D)), ((float)(16D)), ((float)(16D)));
			this.rectangle4.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle4.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle4.ImageBytes = resources.GetString("rectangle4.ImageBytes");
			this.rectangle4.Name = "rectangle4";
			this.rectangle4.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// txtIMPLIM
			// 
			this.txtIMPLIM.AngleIgnore = true;
			this.txtIMPLIM.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtIMPLIM.Bounds = new NxtControl.Drawing.RectF(((float)(130D)), ((float)(71D)), ((float)(82D)), ((float)(26D)));
			this.txtIMPLIM.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtIMPLIM.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtIMPLIM.FontScale = true;
			this.txtIMPLIM.Name = "txtIMPLIM";
			this.txtIMPLIM.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fAlarm", NxtControl.GuiFramework.MouseButtonType.Click));
			this.txtIMPLIM.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtIMPLIM.Text = "1.50 MW";
			this.txtIMPLIM.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtIMPLIM.TextAutoSizeHorizontalOffset = 10;
			this.txtIMPLIM.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtIMPLIM.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText2
			// 
			this.freeText2.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText2.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText2.Location = new NxtControl.Drawing.PointF(40D, 75D);
			this.freeText2.Name = "freeText2";
			this.freeText2.Text = "Import Limit";
			// 
			// rectangle2
			// 
			this.rectangle2.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(76D)), ((float)(16D)), ((float)(16D)));
			this.rectangle2.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle2.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle2.ImageBytes = resources.GetString("rectangle2.ImageBytes");
			this.rectangle2.Name = "rectangle2";
			this.rectangle2.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// txtRMPUP
			// 
			this.txtRMPUP.AngleIgnore = true;
			this.txtRMPUP.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtRMPUP.Bounds = new NxtControl.Drawing.RectF(((float)(130D)), ((float)(101D)), ((float)(82D)), ((float)(26D)));
			this.txtRMPUP.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtRMPUP.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtRMPUP.FontScale = true;
			this.txtRMPUP.Name = "txtRMPUP";
			this.txtRMPUP.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fAlarm", NxtControl.GuiFramework.MouseButtonType.Click));
			this.txtRMPUP.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtRMPUP.Text = "0.50 MW/m";
			this.txtRMPUP.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtRMPUP.TextAutoSizeHorizontalOffset = 10;
			this.txtRMPUP.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtRMPUP.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText3
			// 
			this.freeText3.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText3.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText3.Location = new NxtControl.Drawing.PointF(40D, 105D);
			this.freeText3.Name = "freeText3";
			this.freeText3.Text = "Ramp Up";
			// 
			// rectangle3
			// 
			this.rectangle3.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(106D)), ((float)(16D)), ((float)(16D)));
			this.rectangle3.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle3.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle3.ImageBytes = resources.GetString("rectangle3.ImageBytes");
			this.rectangle3.Name = "rectangle3";
			this.rectangle3.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// txtRMPDN
			// 
			this.txtRMPDN.AngleIgnore = true;
			this.txtRMPDN.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtRMPDN.Bounds = new NxtControl.Drawing.RectF(((float)(130D)), ((float)(131D)), ((float)(82D)), ((float)(26D)));
			this.txtRMPDN.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtRMPDN.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtRMPDN.FontScale = true;
			this.txtRMPDN.Name = "txtRMPDN";
			this.txtRMPDN.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fAlarm", NxtControl.GuiFramework.MouseButtonType.Click));
			this.txtRMPDN.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtRMPDN.Text = "0.50 MW/m";
			this.txtRMPDN.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtRMPDN.TextAutoSizeHorizontalOffset = 10;
			this.txtRMPDN.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtRMPDN.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText4
			// 
			this.freeText4.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText4.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText4.Location = new NxtControl.Drawing.PointF(40D, 135D);
			this.freeText4.Name = "freeText4";
			this.freeText4.Text = "Ramp Down";
			// 
			// rectangle5
			// 
			this.rectangle5.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(136D)), ((float)(16D)), ((float)(16D)));
			this.rectangle5.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle5.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle5.ImageBytes = resources.GetString("rectangle5.ImageBytes");
			this.rectangle5.Name = "rectangle5";
			this.rectangle5.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// txtPNET
			// 
			this.txtPNET.AngleIgnore = true;
			this.txtPNET.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtPNET.Bounds = new NxtControl.Drawing.RectF(((float)(130D)), ((float)(161D)), ((float)(82D)), ((float)(26D)));
			this.txtPNET.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtPNET.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtPNET.FontScale = true;
			this.txtPNET.Name = "txtPNET";
			this.txtPNET.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fAlarm", NxtControl.GuiFramework.MouseButtonType.Click));
			this.txtPNET.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtPNET.Text = "+4.00 MW";
			this.txtPNET.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtPNET.TextAutoSizeHorizontalOffset = 10;
			this.txtPNET.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtPNET.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText6
			// 
			this.freeText6.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText6.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText6.Location = new NxtControl.Drawing.PointF(40D, 165D);
			this.freeText6.Name = "freeText6";
			this.freeText6.Text = "AC Balance";
			// 
			// rectangle6
			// 
			this.rectangle6.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(166D)), ((float)(16D)), ((float)(16D)));
			this.rectangle6.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle6.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle6.ImageBytes = resources.GetString("rectangle6.ImageBytes");
			this.rectangle6.Name = "rectangle6";
			this.rectangle6.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// txtQNET
			// 
			this.txtQNET.AngleIgnore = true;
			this.txtQNET.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtQNET.Bounds = new NxtControl.Drawing.RectF(((float)(130D)), ((float)(191D)), ((float)(82D)), ((float)(26D)));
			this.txtQNET.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtQNET.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtQNET.FontScale = true;
			this.txtQNET.Name = "txtQNET";
			this.txtQNET.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fAlarm", NxtControl.GuiFramework.MouseButtonType.Click));
			this.txtQNET.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtQNET.Text = "0.18 MVAr";
			this.txtQNET.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtQNET.TextAutoSizeHorizontalOffset = 10;
			this.txtQNET.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtQNET.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText8
			// 
			this.freeText8.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText8.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText8.Location = new NxtControl.Drawing.PointF(40D, 195D);
			this.freeText8.Name = "freeText8";
			this.freeText8.Text = "Q Balance";
			// 
			// rectangle7
			// 
			this.rectangle7.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(196D)), ((float)(16D)), ((float)(16D)));
			this.rectangle7.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle7.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle7.ImageBytes = resources.GetString("rectangle7.ImageBytes");
			this.rectangle7.Name = "rectangle7";
			this.rectangle7.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// txtCURT
			// 
			this.txtCURT.AngleIgnore = true;
			this.txtCURT.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtCURT.Bounds = new NxtControl.Drawing.RectF(((float)(130D)), ((float)(221D)), ((float)(82D)), ((float)(26D)));
			this.txtCURT.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtCURT.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtCURT.FontScale = true;
			this.txtCURT.Name = "txtCURT";
			this.txtCURT.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fAlarm", NxtControl.GuiFramework.MouseButtonType.Click));
			this.txtCURT.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtCURT.Text = "8.5 %";
			this.txtCURT.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtCURT.TextAutoSizeHorizontalOffset = 10;
			this.txtCURT.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtCURT.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText9
			// 
			this.freeText9.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText9.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText9.Location = new NxtControl.Drawing.PointF(40D, 225D);
			this.freeText9.Name = "freeText9";
			this.freeText9.Text = "Curtailment";
			// 
			// rectangle8
			// 
			this.rectangle8.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(226D)), ((float)(16D)), ((float)(16D)));
			this.rectangle8.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle8.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle8.ImageBytes = resources.GetString("rectangle8.ImageBytes");
			this.rectangle8.Name = "rectangle8";
			this.rectangle8.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// line3
			// 
			this.line3.EndPoint = new NxtControl.Drawing.PointF(228D, 344D);
			this.line3.Name = "line3";
			this.line3.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(20)), ((byte)(54)), ((byte)(45))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line3.StartPoint = new NxtControl.Drawing.PointF(2D, 344D);
			// 
			// txtEGEN
			// 
			this.txtEGEN.AngleIgnore = true;
			this.txtEGEN.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtEGEN.Bounds = new NxtControl.Drawing.RectF(((float)(130D)), ((float)(251D)), ((float)(82D)), ((float)(26D)));
			this.txtEGEN.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtEGEN.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtEGEN.FontScale = true;
			this.txtEGEN.Name = "txtEGEN";
			this.txtEGEN.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fAlarm", NxtControl.GuiFramework.MouseButtonType.Click));
			this.txtEGEN.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtEGEN.Text = "18.42 MWh";
			this.txtEGEN.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtEGEN.TextAutoSizeHorizontalOffset = 10;
			this.txtEGEN.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtEGEN.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText11
			// 
			this.freeText11.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText11.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText11.Location = new NxtControl.Drawing.PointF(40D, 255D);
			this.freeText11.Name = "freeText11";
			this.freeText11.Text = "Energy Gen";
			// 
			// rectangle10
			// 
			this.rectangle10.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(256D)), ((float)(16D)), ((float)(16D)));
			this.rectangle10.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle10.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle10.ImageBytes = resources.GetString("rectangle10.ImageBytes");
			this.rectangle10.Name = "rectangle10";
			this.rectangle10.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// txtAVL
			// 
			this.txtAVL.AngleIgnore = true;
			this.txtAVL.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtAVL.Bounds = new NxtControl.Drawing.RectF(((float)(130D)), ((float)(281D)), ((float)(82D)), ((float)(26D)));
			this.txtAVL.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtAVL.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtAVL.FontScale = true;
			this.txtAVL.Name = "txtAVL";
			this.txtAVL.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fAlarm", NxtControl.GuiFramework.MouseButtonType.Click));
			this.txtAVL.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtAVL.Text = "99.2 %";
			this.txtAVL.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtAVL.TextAutoSizeHorizontalOffset = 10;
			this.txtAVL.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtAVL.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText12
			// 
			this.freeText12.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText12.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText12.Location = new NxtControl.Drawing.PointF(40D, 285D);
			this.freeText12.Name = "freeText12";
			this.freeText12.Text = "Availability";
			// 
			// rectangle11
			// 
			this.rectangle11.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(286D)), ((float)(16D)), ((float)(16D)));
			this.rectangle11.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle11.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle11.ImageBytes = resources.GetString("rectangle11.ImageBytes");
			this.rectangle11.Name = "rectangle11";
			this.rectangle11.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// txtPR
			// 
			this.txtPR.AngleIgnore = true;
			this.txtPR.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtPR.Bounds = new NxtControl.Drawing.RectF(((float)(130D)), ((float)(311D)), ((float)(82D)), ((float)(26D)));
			this.txtPR.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtPR.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtPR.FontScale = true;
			this.txtPR.Name = "txtPR";
			this.txtPR.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fAlarm", NxtControl.GuiFramework.MouseButtonType.Click));
			this.txtPR.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtPR.Text = "86.4 %";
			this.txtPR.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtPR.TextAutoSizeHorizontalOffset = 10;
			this.txtPR.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtPR.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText13
			// 
			this.freeText13.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText13.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText13.Location = new NxtControl.Drawing.PointF(40D, 315D);
			this.freeText13.Name = "freeText13";
			this.freeText13.Text = "Performance";
			// 
			// rectangle12
			// 
			this.rectangle12.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(316D)), ((float)(16D)), ((float)(16D)));
			this.rectangle12.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle12.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle12.ImageBytes = resources.GetString("rectangle12.ImageBytes");
			this.rectangle12.Name = "rectangle12";
			this.rectangle12.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// sButtonNavDemo1
			// 
			this.sButtonNavDemo1.BeginInit();
			this.sButtonNavDemo1.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 198D, 356D);
			this.sButtonNavDemo1.Name = "sButtonNavDemo1";
			this.sButtonNavDemo1.SecurityToken = ((uint)(4294967295u));
			this.sButtonNavDemo1.TagName = "Plant.Broadcaster_v1_0";
			this.sButtonNavDemo1.EndInit();
			// 
			// EXPLIM
			// 
			this.EXPLIM.BeginInit();
			this.EXPLIM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 83D, 202D);
			this.EXPLIM.Name = "EXPLIM";
			this.EXPLIM.SecurityToken = ((uint)(4294967295u));
			this.EXPLIM.TagName = "EXPLIM";
			this.EXPLIM.Val = 0F;
			this.EXPLIM.ValDecimalPlaces = ((byte)(0));
			this.EXPLIM.ValMaximum = 0F;
			this.EXPLIM.ValMinimum = 0F;
			this.EXPLIM.ValUnits = null;
			this.EXPLIM.EndInit();
			// 
			// IMPLIM
			// 
			this.IMPLIM.BeginInit();
			this.IMPLIM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 68D, 196D);
			this.IMPLIM.Name = "IMPLIM";
			this.IMPLIM.SecurityToken = ((uint)(4294967295u));
			this.IMPLIM.TagName = "IMPLIM";
			this.IMPLIM.Val = 0F;
			this.IMPLIM.ValDecimalPlaces = ((byte)(0));
			this.IMPLIM.ValMaximum = 0F;
			this.IMPLIM.ValMinimum = 0F;
			this.IMPLIM.ValUnits = null;
			this.IMPLIM.EndInit();
			// 
			// RMPDN
			// 
			this.RMPDN.BeginInit();
			this.RMPDN.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 22D, 213D);
			this.RMPDN.Name = "RMPDN";
			this.RMPDN.SecurityToken = ((uint)(4294967295u));
			this.RMPDN.TagName = "RMPDN";
			this.RMPDN.Val = 0F;
			this.RMPDN.ValDecimalPlaces = ((byte)(0));
			this.RMPDN.ValMaximum = 0F;
			this.RMPDN.ValMinimum = 0F;
			this.RMPDN.ValUnits = null;
			this.RMPDN.EndInit();
			// 
			// RMPUP
			// 
			this.RMPUP.BeginInit();
			this.RMPUP.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 47D, 219D);
			this.RMPUP.Name = "RMPUP";
			this.RMPUP.SecurityToken = ((uint)(4294967295u));
			this.RMPUP.TagName = "RMPUP";
			this.RMPUP.Val = 0F;
			this.RMPUP.ValDecimalPlaces = ((byte)(0));
			this.RMPUP.ValMaximum = 0F;
			this.RMPUP.ValMinimum = 0F;
			this.RMPUP.ValUnits = null;
			this.RMPUP.EndInit();
			// 
			// CURT
			// 
			this.CURT.BeginInit();
			this.CURT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 110D, 74D);
			this.CURT.Name = "CURT";
			this.CURT.SecurityToken = ((uint)(4294967295u));
			this.CURT.TagName = "CURT";
			this.CURT.Val = 0F;
			this.CURT.ValDecimalPlaces = ((byte)(0));
			this.CURT.ValMaximum = 0F;
			this.CURT.ValMinimum = 0F;
			this.CURT.ValUnits = null;
			this.CURT.EndInit();
			// 
			// EGEN
			// 
			this.EGEN.BeginInit();
			this.EGEN.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 107D, 94D);
			this.EGEN.Name = "EGEN";
			this.EGEN.SecurityToken = ((uint)(4294967295u));
			this.EGEN.TagName = "EGEN";
			this.EGEN.Val = 0F;
			this.EGEN.ValDecimalPlaces = ((byte)(0));
			this.EGEN.ValMaximum = 0F;
			this.EGEN.ValMinimum = 0F;
			this.EGEN.ValUnits = null;
			this.EGEN.EndInit();
			// 
			// QNET
			// 
			this.QNET.BeginInit();
			this.QNET.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 146D, 226D);
			this.QNET.Name = "QNET";
			this.QNET.SecurityToken = ((uint)(4294967295u));
			this.QNET.TagName = "QNET";
			this.QNET.Val = 0F;
			this.QNET.ValDecimalPlaces = ((byte)(0));
			this.QNET.ValMaximum = 0F;
			this.QNET.ValMinimum = 0F;
			this.QNET.ValUnits = null;
			this.QNET.EndInit();
			// 
			// PNET
			// 
			this.PNET.BeginInit();
			this.PNET.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 79D, 220D);
			this.PNET.Name = "PNET";
			this.PNET.SecurityToken = ((uint)(4294967295u));
			this.PNET.TagName = "PNET";
			this.PNET.Val = 0F;
			this.PNET.ValDecimalPlaces = ((byte)(0));
			this.PNET.ValMaximum = 0F;
			this.PNET.ValMinimum = 0F;
			this.PNET.ValUnits = null;
			this.PNET.EndInit();
			// 
			// PR
			// 
			this.PR.BeginInit();
			this.PR.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 102D, 221D);
			this.PR.Name = "PR";
			this.PR.SecurityToken = ((uint)(4294967295u));
			this.PR.TagName = "PR";
			this.PR.Val = 0F;
			this.PR.ValDecimalPlaces = ((byte)(0));
			this.PR.ValMaximum = 0F;
			this.PR.ValMinimum = 0F;
			this.PR.ValUnits = null;
			this.PR.EndInit();
			// 
			// QLT
			// 
			this.QLT.BeginInit();
			this.QLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 123D, 193D);
			this.QLT.Name = "QLT";
			this.QLT.SecurityToken = ((uint)(4294967295u));
			this.QLT.TagName = "QLT";
			this.QLT.Val = false;
			this.QLT.EndInit();
			// 
			// ISTA
			// 
			this.ISTA.BeginInit();
			this.ISTA.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 110D, 172D);
			this.ISTA.Name = "ISTA";
			this.ISTA.SecurityToken = ((uint)(4294967295u));
			this.ISTA.TagName = "ISTA";
			this.ISTA.Val = ((short)(0));
			this.ISTA.ValMaximum = ((short)(0));
			this.ISTA.ValMinimum = ((short)(0));
			this.ISTA.ValUnits = null;
			this.ISTA.EndInit();
			// 
			// IRUN
			// 
			this.IRUN.BeginInit();
			this.IRUN.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 41D, 150D);
			this.IRUN.Name = "IRUN";
			this.IRUN.SecurityToken = ((uint)(4294967295u));
			this.IRUN.TagName = "IRUN";
			this.IRUN.Val = false;
			this.IRUN.EndInit();
			// 
			// IFLT
			// 
			this.IFLT.BeginInit();
			this.IFLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 133D, 146D);
			this.IFLT.Name = "IFLT";
			this.IFLT.SecurityToken = ((uint)(4294967295u));
			this.IFLT.TagName = "IFLT";
			this.IFLT.Val = false;
			this.IFLT.EndInit();
			// 
			// IAVL
			// 
			this.IAVL.BeginInit();
			this.IAVL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 88D, 138D);
			this.IAVL.Name = "IAVL";
			this.IAVL.SecurityToken = ((uint)(4294967295u));
			this.IAVL.TagName = "IAVL";
			this.IAVL.Val = false;
			this.IAVL.EndInit();
			// 
			// IALM
			// 
			this.IALM.BeginInit();
			this.IALM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 66D, 130D);
			this.IALM.Name = "IALM";
			this.IALM.SecurityToken = ((uint)(4294967295u));
			this.IALM.TagName = "IALM";
			this.IALM.Val = false;
			this.IALM.EndInit();
			// 
			// AVL
			// 
			this.AVL.BeginInit();
			this.AVL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 119D, 109D);
			this.AVL.Name = "AVL";
			this.AVL.SecurityToken = ((uint)(4294967295u));
			this.AVL.TagName = "AVL";
			this.AVL.Val = 0F;
			this.AVL.ValDecimalPlaces = ((byte)(0));
			this.AVL.ValMaximum = 0F;
			this.AVL.ValMinimum = 0F;
			this.AVL.ValUnits = null;
			this.AVL.EndInit();
			// 
			// ALMW
			// 
			this.ALMW.BeginInit();
			this.ALMW.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 93D, 79D);
			this.ALMW.Name = "ALMW";
			this.ALMW.SecurityToken = ((uint)(4294967295u));
			this.ALMW.TagName = "ALMW";
			this.ALMW.Val = ((short)(0));
			this.ALMW.ValMaximum = ((short)(0));
			this.ALMW.ValMinimum = ((short)(0));
			this.ALMW.ValUnits = null;
			this.ALMW.EndInit();
			// 
			// fMain
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(228D)), ((float)(386D)));
			this.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(3)), ((byte)(22)), ((byte)(20))));
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.freeText1,
			this.line3,
			this.txtEXPLIM,
			this.freeText5,
			this.rectangle4,
			this.txtStatus,
			this.freeText7,
			this.rectangle1,
			this.txtIMPLIM,
			this.freeText2,
			this.rectangle2,
			this.txtRMPUP,
			this.freeText3,
			this.rectangle3,
			this.txtRMPDN,
			this.freeText4,
			this.rectangle5,
			this.txtPNET,
			this.freeText6,
			this.rectangle6,
			this.txtQNET,
			this.freeText8,
			this.rectangle7,
			this.txtCURT,
			this.freeText9,
			this.rectangle8,
			this.txtEGEN,
			this.freeText11,
			this.rectangle10,
			this.txtAVL,
			this.freeText12,
			this.rectangle11,
			this.txtPR,
			this.freeText13,
			this.rectangle12,
			this.sButtonNavDemo1,
			this.EXPLIM,
			this.IMPLIM,
			this.RMPDN,
			this.RMPUP,
			this.CURT,
			this.EGEN,
			this.QNET,
			this.PNET,
			this.PR,
			this.QLT,
			this.ISTA,
			this.IRUN,
			this.IFLT,
			this.IAVL,
			this.IALM,
			this.AVL,
			this.ALMW});
			this.Size = new System.Drawing.Size(228, 386);

		}
		private NxtControl.GuiFramework.FreeText freeText3;
		private NxtControl.GuiFramework.FreeText freeText4;
		private NxtControl.GuiFramework.Rectangle rectangle2;
		private NxtControl.GuiFramework.Rectangle rectangle3;
		private NxtControl.GuiFramework.FreeText freeText1;
		private NxtControl.GuiFramework.FreeText freeText2;
		private NxtControl.GuiFramework.Rectangle rectangle6;
		private NxtControl.GuiFramework.Label txtStatus;
		private NxtControl.GuiFramework.FreeText freeText7;
		private NxtControl.GuiFramework.Rectangle rectangle1;
		private NxtControl.GuiFramework.Label txtEXPLIM;
		private NxtControl.GuiFramework.FreeText freeText5;
		private NxtControl.GuiFramework.Rectangle rectangle4;
		private NxtControl.GuiFramework.Label txtIMPLIM;
		private NxtControl.GuiFramework.Label txtRMPUP;
		private NxtControl.GuiFramework.Label txtRMPDN;
		private NxtControl.GuiFramework.Rectangle rectangle5;
		private NxtControl.GuiFramework.Label txtPNET;
		private NxtControl.GuiFramework.FreeText freeText6;
		private NxtControl.GuiFramework.Label txtQNET;
		private NxtControl.GuiFramework.FreeText freeText8;
		private NxtControl.GuiFramework.Rectangle rectangle7;
		private NxtControl.GuiFramework.Label txtCURT;
		private NxtControl.GuiFramework.FreeText freeText9;
		private NxtControl.GuiFramework.Rectangle rectangle8;
		private NxtControl.GuiFramework.Line line3;
		private NxtControl.GuiFramework.Label txtEGEN;
		private NxtControl.GuiFramework.FreeText freeText11;
		private NxtControl.GuiFramework.Rectangle rectangle10;
		private NxtControl.GuiFramework.Label txtAVL;
		private NxtControl.GuiFramework.FreeText freeText12;
		private NxtControl.GuiFramework.Rectangle rectangle11;
		private NxtControl.GuiFramework.Label txtPR;
		private NxtControl.GuiFramework.FreeText freeText13;
		private NxtControl.GuiFramework.Rectangle rectangle12;
		private SE.Agile.Symbols.Broadcaster_v1_0.sButtonNavDemo sButtonNavDemo1;
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValChanged EXPLIM;
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValChanged IMPLIM;
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValChanged RMPDN;
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValChanged RMPUP;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged CURT;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged EGEN;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged QNET;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged PNET;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged PR;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged QLT;
		private SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged ISTA;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IRUN;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IFLT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IAVL;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IALM;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged AVL;
		private SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged ALMW;
		#endregion
	}
}
