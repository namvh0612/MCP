/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/24/2026
 * Time: 10:59 AM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.acPPC_v1_0
{
	/// <summary>
	/// Summary description for sPR.
	/// </summary>
	partial class sPR
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(sPR));
			this.PR = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.rectBtn = new NxtControl.GuiFramework.RoundedRectangle();
			this.txtData = new NxtControl.GuiFramework.Label();
			this.txtLabel = new NxtControl.GuiFramework.Label();
			this.roundedRectangle1 = new NxtControl.GuiFramework.RoundedRectangle();
			this.rectangle1 = new NxtControl.GuiFramework.Rectangle();
			this.groupData = new NxtControl.GuiFramework.Group();
			// 
			// PR
			// 
			this.PR.BeginInit();
			this.PR.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 267D, 120D);
			this.PR.Name = "PR";
			this.PR.SecurityToken = ((uint)(4294967295u));
			this.PR.TagName = "PR";
			this.PR.Val = 0F;
			this.PR.ValDecimalPlaces = ((byte)(0));
			this.PR.ValMaximum = 0F;
			this.PR.ValMinimum = 0F;
			this.PR.ValUnits = null;
			this.PR.EndInit();
			// 
			// rectBtn
			// 
			this.rectBtn.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(252D)), ((float)(87D)));
			this.rectBtn.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(8)), ((byte)(28)), ((byte)(27))));
			this.rectBtn.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectBtn.Name = "rectBtn";
			this.rectBtn.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(37)), ((byte)(64)), ((byte)(61))), 1F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Flat, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Round, null);
			this.rectBtn.Radius = 10D;
			// 
			// txtData
			// 
			this.txtData.AngleIgnore = true;
			this.txtData.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtData.Bounds = new NxtControl.Drawing.RectF(((float)(12D)), ((float)(44D)), ((float)(200D)), ((float)(26D)));
			this.txtData.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtData.Font = new NxtControl.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Bold);
			this.txtData.FontScale = true;
			this.txtData.Name = "txtData";
			this.txtData.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtData.Text = "99.12 %";
			this.txtData.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.txtData.TextAutoSizeHorizontalOffset = 10;
			this.txtData.TextColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			this.txtData.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// txtLabel
			// 
			this.txtLabel.AngleIgnore = true;
			this.txtLabel.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtLabel.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(12D)), ((float)(200D)), ((float)(26D)));
			this.txtLabel.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtLabel.Font = new NxtControl.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular);
			this.txtLabel.FontScale = true;
			this.txtLabel.Name = "txtLabel";
			this.txtLabel.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtLabel.Text = "Performance";
			this.txtLabel.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.txtLabel.TextAutoSizeHorizontalOffset = 10;
			this.txtLabel.TextColor = new NxtControl.Drawing.Color(((byte)(210)), ((byte)(210)), ((byte)(210)));
			this.txtLabel.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// roundedRectangle1
			// 
			this.roundedRectangle1.Bounds = new NxtControl.Drawing.RectF(((float)(212D)), ((float)(8D)), ((float)(30D)), ((float)(30D)));
			this.roundedRectangle1.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(8)), ((byte)(28)), ((byte)(27))));
			this.roundedRectangle1.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.roundedRectangle1.Name = "roundedRectangle1";
			this.roundedRectangle1.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(37)), ((byte)(64)), ((byte)(61))), 1F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Flat, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Round, null);
			this.roundedRectangle1.Radius = 10D;
			// 
			// rectangle1
			// 
			this.rectangle1.Bounds = new NxtControl.Drawing.RectF(((float)(215D)), ((float)(11D)), ((float)(24D)), ((float)(24D)));
			this.rectangle1.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle1.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle1.ImageBytes = resources.GetString("rectangle1.ImageBytes");
			this.rectangle1.Name = "rectangle1";
			this.rectangle1.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// groupData
			// 
			this.groupData.BeginInit();
			this.groupData.Name = "groupData";
			this.groupData.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.rectBtn,
			this.txtData,
			this.txtLabel,
			this.roundedRectangle1,
			this.rectangle1});
			this.groupData.MouseEnter += new System.EventHandler(this.GroupDataMouseEnter);
			this.groupData.MouseLeave += new System.EventHandler(this.GroupDataMouseLeave);
			this.groupData.EndInit();
			// 
			// sPR
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.PR,
			this.groupData});
			this.SymbolSize = new System.Drawing.Size(520, 232);

		}
		private NxtControl.GuiFramework.RoundedRectangle rectBtn;
		private NxtControl.GuiFramework.Rectangle rectangle1;
		private NxtControl.GuiFramework.Label txtData;
		private NxtControl.GuiFramework.Group groupData;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged PR;
		private NxtControl.GuiFramework.Label txtLabel;
		private NxtControl.GuiFramework.RoundedRectangle roundedRectangle1;
		#endregion
	}
}
