/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/16/2026
 * Time: 10:55 AM
 */

using System;
using NxtControl.GuiFramework;
using NxtControl.Drawing;
using HMI.Main.SupportClasses;

namespace HMI.Main.Symbols.acPPC_v1_0
{
	public partial class sDefault :
		NxtControl.GuiFramework.HMISymbol
	{
		private const double POWER_DEADBAND = 0.001;

		private bool _isRectBtnHovered;

		private PpcVisualStatus _currentStatus =
			PpcVisualStatus.Offline;

		private enum PpcVisualStatus
		{
			Offline,
			Fault,
			Alarm,
			Running,
			Exporting,
			Importing,
			Curtailing,
			Standby,
			Unknown
		}

		public sDefault()
		{
			InitializeComponent();
			AttachEvents();
			UpdateDisplay();
		}

		private void AttachEvents()
		{
			REQ_Fired += REQ_Fired_EventHandler;

			IAVL.OnValChanged += OnValueChanged;
			IRUN.OnValChanged += OnValueChanged;
			IALM.OnValChanged += OnValueChanged;
			IFLT.OnValChanged += OnValueChanged;
			QLT.OnValChanged += OnValueChanged;
			ISTA.OnValChanged += OnValueChanged;

			ASPCMD.OnValChanged += OnValueChanged;
			PBATCMD.OnValChanged += OnValueChanged;
		}

		private void OnValueChanged(
			object sender,
			EventArgs e)
		{
			UpdateDisplay();
		}

		private void UpdateDisplay()
		{
			_currentStatus = ResolveStatus();

			SolarTheme.EquipmentState equipmentState =
				GetEquipmentState(_currentStatus);

			Color statusColor =
				GetStatusColor(_currentStatus);

			HmiDisplayHelper.DisplayData displayData =
				new HmiDisplayHelper.DisplayData();

			displayData.Status = equipmentState;
			displayData.StatusIndicator = indStatus;
			displayData.CardBorder = rectBtn;
			displayData.CardBackground = rectBase;
			displayData.IsHovered = _isRectBtnHovered;

			displayData.Items =
				new HmiDisplayHelper.DisplayItem[]
				{
					HmiDisplayHelper.CreateText(
						txtStatus,
						GetStatusText(_currentStatus),
						statusColor),

					HmiDisplayHelper.CreateValue(
						txtASPCMD,
						ASPCMD.Val,
						"0.00",
						" MW",
						GetInverterCommandColor()),

					HmiDisplayHelper.CreateText(
						txtPBATCMD,
						GetBessCommandText(
							PBATCMD.Val),
						GetBessCommandColor(
							PBATCMD.Val))
				};

			HmiDisplayHelper.Apply(displayData);

			indStatus.BrushColor = statusColor;
			UpdateCardVisual();
		}

		private PpcVisualStatus ResolveStatus()
		{
			if (!HmiValueHelper.ToBool(QLT.Val))
			{
				return PpcVisualStatus.Offline;
			}

			if (HmiValueHelper.ToBool(IFLT.Val))
			{
				return PpcVisualStatus.Fault;
			}

			if (HmiValueHelper.ToBool(IALM.Val))
			{
				return PpcVisualStatus.Alarm;
			}

			switch (HmiValueHelper.ToInt(ISTA.Val))
			{
				case 5:
					return PpcVisualStatus.Exporting;

				case 6:
					return PpcVisualStatus.Importing;

				case 7:
					return PpcVisualStatus.Curtailing;

				case 4:
					return PpcVisualStatus.Running;

				case 3:
					return PpcVisualStatus.Standby;
			}

			if (HmiValueHelper.ToBool(IRUN.Val))
			{
				return PpcVisualStatus.Running;
			}

			return PpcVisualStatus.Standby;
		}

		private SolarTheme.EquipmentState GetEquipmentState(
			PpcVisualStatus status)
		{
			switch (status)
			{
				case PpcVisualStatus.Fault:
					return SolarTheme.EquipmentState.Fault;

				case PpcVisualStatus.Alarm:
					return SolarTheme.EquipmentState.Warning;

				case PpcVisualStatus.Running:
				case PpcVisualStatus.Exporting:
				case PpcVisualStatus.Importing:
				case PpcVisualStatus.Curtailing:
					return SolarTheme.EquipmentState.Running;

				case PpcVisualStatus.Standby:
					return SolarTheme.EquipmentState.Standby;
				
				case PpcVisualStatus.Unknown:
					return SolarTheme.EquipmentState.Unknown;
				
				case PpcVisualStatus.Offline:
					return SolarTheme.EquipmentState.Offline;
				
				default:
					return SolarTheme.EquipmentState.Unknown;
			}
		}

		private string GetStatusText(
			PpcVisualStatus status)
		{
			switch (status)
			{
				case PpcVisualStatus.Fault:
					return "Fault";

				case PpcVisualStatus.Alarm:
					return "Alarm";

				case PpcVisualStatus.Running:
					return "Normal";

				case PpcVisualStatus.Exporting:
					return "Export";

				case PpcVisualStatus.Importing:
					return "Import";

				case PpcVisualStatus.Curtailing:
					return "Curtail";

				case PpcVisualStatus.Standby:
					return "Standby";

				case PpcVisualStatus.Unknown:
					return "Unknown";
				
				case PpcVisualStatus.Offline:
					return "Offline";
				
				default:
					return "Unknown";
			}
		}

		private Color GetStatusColor(
			PpcVisualStatus status)
		{
			switch (status)
			{
				case PpcVisualStatus.Fault:
					return SolarTheme.Status.Fault;

				case PpcVisualStatus.Alarm:
					return SolarTheme.Status.Warning;

				case PpcVisualStatus.Importing:
				case PpcVisualStatus.Curtailing:
					return SolarTheme.Flow.AcPower;

				case PpcVisualStatus.Running:
				case PpcVisualStatus.Exporting:
					return SolarTheme.Status.Healthy;

				case PpcVisualStatus.Standby:
					return SolarTheme.Status.Standby;
				
				case PpcVisualStatus.Unknown:
					return SolarTheme.Status.Unknown;
				
				case PpcVisualStatus.Offline:
					return SolarTheme.Status.Offline;
				
				default:
					return SolarTheme.Status.Unknown;
			}
		}

		private string GetBessCommandText(object value)
		{
			double power =
				HmiValueHelper.ToDouble(value);

			if (power > POWER_DEADBAND)
			{
				return power.ToString("0.00")
					+ " MW Discharge";
			}

			if (power < -POWER_DEADBAND)
			{
				return Math.Abs(power).ToString("0.00")
					+ " MW Charge";
			}

			return "0.00 MW Standby";
		}

		private Color GetInverterCommandColor()
		{
			if (!HmiValueHelper.ToBool(QLT.Val))
			{
				return SolarTheme.Status.Offline;
			}

			if (HmiValueHelper.ToBool(IFLT.Val))
			{
				return SolarTheme.Status.Fault;
			}

			if (HmiValueHelper.ToBool(IALM.Val))
			{
				return SolarTheme.Status.Warning;
			}

			double command =
				HmiValueHelper.ToDouble(ASPCMD.Val);

			if (command < -POWER_DEADBAND)
			{
				return SolarTheme.Status.Fault;
			}

			if (command <= POWER_DEADBAND)
			{
				return SolarTheme.Text.Muted;
			}

			return SolarTheme.Text.Primary;
		}

		private Color GetBessCommandColor(object value)
		{
			if (!HmiValueHelper.ToBool(QLT.Val))
			{
				return SolarTheme.Status.Offline;
			}

			if (HmiValueHelper.ToBool(IFLT.Val))
			{
				return SolarTheme.Status.Fault;
			}

			if (HmiValueHelper.ToBool(IALM.Val))
			{
				return SolarTheme.Status.Warning;
			}

			double power =
				HmiValueHelper.ToDouble(value);

			if (power > POWER_DEADBAND)
			{
				return SolarTheme.Flow.AcPower;
			}

			if (power < -POWER_DEADBAND)
			{
				return SolarTheme.Status.Healthy;
			}

			return SolarTheme.Text.Muted;
		}

		private void UpdateCardVisual()
		{
			HmiDisplayHelper.ApplyStatusCard(
				rectBtn,
				rectBase,
				GetEquipmentState(_currentStatus),
				_isRectBtnHovered);

			if (_currentStatus ==
					PpcVisualStatus.Importing ||
				_currentStatus ==
					PpcVisualStatus.Curtailing)
			{
				rectBtn.PenColor =
					SolarTheme.Flow.AcPower;;
			}
		}

		private void RectBtnMouseEnter(
			object sender,
			EventArgs e)
		{
			_isRectBtnHovered = true;
			UpdateCardVisual();
		}

		private void RectBtnMouseLeave(
			object sender,
			EventArgs e)
		{
			_isRectBtnHovered = false;
			UpdateCardVisual();
		}

		private void REQ_Fired_EventHandler(
			object sender,
			REQEventArgs e)
		{
			lblSymbol.Text =
				HmiValueHelper.SafeText(
					e.AssetName,
					"PPC");
		}
	}
}