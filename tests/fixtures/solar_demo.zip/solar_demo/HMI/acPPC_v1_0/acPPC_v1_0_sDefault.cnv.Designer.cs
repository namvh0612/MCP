/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/16/2026
 * Time: 10:55 AM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.acPPC_v1_0
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sDefault
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(sDefault));
			this.rectangle1 = new NxtControl.GuiFramework.Rectangle();
			this.lblSymbol = new NxtControl.GuiFramework.Label();
			this.txtStatus = new NxtControl.GuiFramework.Label();
			this.indStatus = new NxtControl.GuiFramework.Ellipse();
			this.txtASPCMD = new NxtControl.GuiFramework.Label();
			this.freeText4 = new NxtControl.GuiFramework.FreeText();
			this.txtPBATCMD = new NxtControl.GuiFramework.Label();
			this.freeText5 = new NxtControl.GuiFramework.FreeText();
			this.line1 = new NxtControl.GuiFramework.Line();
			this.line2 = new NxtControl.GuiFramework.Line();
			this.rectBtn = new NxtControl.GuiFramework.RoundedRectangle();
			this.rectBase = new NxtControl.GuiFramework.RoundedRectangle();
			this.IALM = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IAVL = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IFLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.QLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.ISTA = new SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged();
			this.IRUN = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.ASPCMD = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.PBATCMD = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			// 
			// rectangle1
			// 
			this.rectangle1.Bounds = new NxtControl.Drawing.RectF(((float)(50D)), ((float)(37D)), ((float)(140D)), ((float)(140D)));
			this.rectangle1.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle1.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle1.ImageBytes = resources.GetString("rectangle1.ImageBytes");
			this.rectangle1.Name = "rectangle1";
			this.rectangle1.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// lblSymbol
			// 
			this.lblSymbol.AngleIgnore = true;
			this.lblSymbol.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.lblSymbol.Bounds = new NxtControl.Drawing.RectF(((float)(11D)), ((float)(12D)), ((float)(141D)), ((float)(24D)));
			this.lblSymbol.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.lblSymbol.Font = new NxtControl.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
			this.lblSymbol.FontScale = true;
			this.lblSymbol.Name = "lblSymbol";
			this.lblSymbol.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.lblSymbol.Text = "PPC";
			this.lblSymbol.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.lblSymbol.TextAutoSizeHorizontalOffset = 10;
			this.lblSymbol.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.lblSymbol.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// txtStatus
			// 
			this.txtStatus.AngleIgnore = true;
			this.txtStatus.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtStatus.Bounds = new NxtControl.Drawing.RectF(((float)(176D)), ((float)(16D)), ((float)(64D)), ((float)(16D)));
			this.txtStatus.Brush = new NxtControl.Drawing.Brush(true);
			this.txtStatus.Font = new NxtControl.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular);
			this.txtStatus.FontScale = true;
			this.txtStatus.Name = "txtStatus";
			this.txtStatus.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtStatus.Text = "Running";
			this.txtStatus.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.txtStatus.TextAutoSizeHorizontalOffset = 10;
			this.txtStatus.TextColor = new NxtControl.Drawing.Color(((byte)(120)), ((byte)(249)), ((byte)(141)));
			this.txtStatus.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// indStatus
			// 
			this.indStatus.Bounds = new NxtControl.Drawing.RectF(((float)(164D)), ((float)(19D)), ((float)(10D)), ((float)(10D)));
			this.indStatus.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(120)), ((byte)(249)), ((byte)(141))));
			this.indStatus.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.indStatus.Name = "indStatus";
			this.indStatus.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// txtASPCMD
			// 
			this.txtASPCMD.AngleIgnore = true;
			this.txtASPCMD.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtASPCMD.Bounds = new NxtControl.Drawing.RectF(((float)(131D)), ((float)(185D)), ((float)(96D)), ((float)(20D)));
			this.txtASPCMD.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtASPCMD.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtASPCMD.FontScale = true;
			this.txtASPCMD.Name = "txtASPCMD";
			this.txtASPCMD.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtASPCMD.Text = "4.60 MW";
			this.txtASPCMD.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtASPCMD.TextAutoSizeHorizontalOffset = 10;
			this.txtASPCMD.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtASPCMD.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText4
			// 
			this.freeText4.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText4.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText4.Location = new NxtControl.Drawing.PointF(11D, 186D);
			this.freeText4.Name = "freeText4";
			this.freeText4.Text = "Inverter CMD";
			// 
			// txtPBATCMD
			// 
			this.txtPBATCMD.AngleIgnore = true;
			this.txtPBATCMD.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtPBATCMD.Bounds = new NxtControl.Drawing.RectF(((float)(86D)), ((float)(217D)), ((float)(141D)), ((float)(20D)));
			this.txtPBATCMD.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtPBATCMD.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtPBATCMD.FontScale = true;
			this.txtPBATCMD.Name = "txtPBATCMD";
			this.txtPBATCMD.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtPBATCMD.Text = "0.25 MW Charge";
			this.txtPBATCMD.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtPBATCMD.TextAutoSizeHorizontalOffset = 10;
			this.txtPBATCMD.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtPBATCMD.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText5
			// 
			this.freeText5.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText5.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText5.Location = new NxtControl.Drawing.PointF(11D, 218D);
			this.freeText5.Name = "freeText5";
			this.freeText5.Text = "BESS CMD";
			// 
			// line1
			// 
			this.line1.EndPoint = new NxtControl.Drawing.PointF(239D, 177D);
			this.line1.Name = "line1";
			this.line1.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(20)), ((byte)(54)), ((byte)(45))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line1.StartPoint = new NxtControl.Drawing.PointF(2D, 177D);
			// 
			// line2
			// 
			this.line2.EndPoint = new NxtControl.Drawing.PointF(239D, 209D);
			this.line2.Name = "line2";
			this.line2.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(20)), ((byte)(54)), ((byte)(45))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line2.StartPoint = new NxtControl.Drawing.PointF(2D, 209D);
			// 
			// rectBtn
			// 
			this.rectBtn.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(240D)), ((float)(250D)));
			this.rectBtn.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("Transparent"));
			this.rectBtn.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectBtn.Name = "rectBtn";
			this.rectBtn.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fMain", NxtControl.GuiFramework.MouseButtonType.Click));
			this.rectBtn.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(28)), ((byte)(78)), ((byte)(71))), 1F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Flat, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Round, null);
			this.rectBtn.Radius = 10D;
			this.rectBtn.MouseEnter += new System.EventHandler(this.RectBtnMouseEnter);
			this.rectBtn.MouseLeave += new System.EventHandler(this.RectBtnMouseLeave);
			// 
			// rectBase
			// 
			this.rectBase.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(240D)), ((float)(250D)));
			this.rectBase.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(3)), ((byte)(22)), ((byte)(20))));
			this.rectBase.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectBase.Name = "rectBase";
			this.rectBase.Pen = new NxtControl.Drawing.Pen("Transparent");
			this.rectBase.Radius = 10D;
			// 
			// IALM
			// 
			this.IALM.BeginInit();
			this.IALM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 128D, 138D);
			this.IALM.Name = "IALM";
			this.IALM.SecurityToken = ((uint)(4294967295u));
			this.IALM.TagName = "IALM";
			this.IALM.Val = false;
			this.IALM.EndInit();
			// 
			// IAVL
			// 
			this.IAVL.BeginInit();
			this.IAVL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 89D, 121D);
			this.IAVL.Name = "IAVL";
			this.IAVL.SecurityToken = ((uint)(4294967295u));
			this.IAVL.TagName = "IAVL";
			this.IAVL.Val = false;
			this.IAVL.EndInit();
			// 
			// IFLT
			// 
			this.IFLT.BeginInit();
			this.IFLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 109D, 151D);
			this.IFLT.Name = "IFLT";
			this.IFLT.SecurityToken = ((uint)(4294967295u));
			this.IFLT.TagName = "IFLT";
			this.IFLT.Val = false;
			this.IFLT.EndInit();
			// 
			// QLT
			// 
			this.QLT.BeginInit();
			this.QLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 105D, 62D);
			this.QLT.Name = "QLT";
			this.QLT.SecurityToken = ((uint)(4294967295u));
			this.QLT.TagName = "QLT";
			this.QLT.Val = false;
			this.QLT.EndInit();
			// 
			// ISTA
			// 
			this.ISTA.BeginInit();
			this.ISTA.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 91D, 98D);
			this.ISTA.Name = "ISTA";
			this.ISTA.SecurityToken = ((uint)(4294967295u));
			this.ISTA.TagName = "ISTA";
			this.ISTA.Val = ((short)(0));
			this.ISTA.ValMaximum = ((short)(0));
			this.ISTA.ValMinimum = ((short)(0));
			this.ISTA.ValUnits = null;
			this.ISTA.EndInit();
			// 
			// IRUN
			// 
			this.IRUN.BeginInit();
			this.IRUN.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 85D, 74D);
			this.IRUN.Name = "IRUN";
			this.IRUN.SecurityToken = ((uint)(4294967295u));
			this.IRUN.TagName = "IRUN";
			this.IRUN.Val = false;
			this.IRUN.EndInit();
			// 
			// ASPCMD
			// 
			this.ASPCMD.BeginInit();
			this.ASPCMD.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 106D, 164D);
			this.ASPCMD.Name = "ASPCMD";
			this.ASPCMD.SecurityToken = ((uint)(4294967295u));
			this.ASPCMD.TagName = "ASPCMD";
			this.ASPCMD.Val = 0F;
			this.ASPCMD.ValDecimalPlaces = ((byte)(0));
			this.ASPCMD.ValMaximum = 0F;
			this.ASPCMD.ValMinimum = 0F;
			this.ASPCMD.ValUnits = null;
			this.ASPCMD.EndInit();
			// 
			// PBATCMD
			// 
			this.PBATCMD.BeginInit();
			this.PBATCMD.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 166D, 190D);
			this.PBATCMD.Name = "PBATCMD";
			this.PBATCMD.SecurityToken = ((uint)(4294967295u));
			this.PBATCMD.TagName = "PBATCMD";
			this.PBATCMD.Val = 0F;
			this.PBATCMD.ValDecimalPlaces = ((byte)(0));
			this.PBATCMD.ValMaximum = 0F;
			this.PBATCMD.ValMinimum = 0F;
			this.PBATCMD.ValUnits = null;
			this.PBATCMD.EndInit();
			// 
			// sDefault
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.rectBase,
			this.rectangle1,
			this.lblSymbol,
			this.txtStatus,
			this.indStatus,
			this.txtASPCMD,
			this.freeText4,
			this.txtPBATCMD,
			this.freeText5,
			this.line1,
			this.line2,
			this.rectBtn,
			this.IALM,
			this.IAVL,
			this.IFLT,
			this.QLT,
			this.ISTA,
			this.IRUN,
			this.ASPCMD,
			this.PBATCMD});
			this.SymbolSize = new System.Drawing.Size(680, 616);

		}
		private NxtControl.GuiFramework.Rectangle rectangle1;
		private NxtControl.GuiFramework.Label lblSymbol;
		private NxtControl.GuiFramework.Label txtStatus;
		private NxtControl.GuiFramework.Ellipse indStatus;
		private NxtControl.GuiFramework.Label txtASPCMD;
		private NxtControl.GuiFramework.FreeText freeText4;
		private NxtControl.GuiFramework.Label txtPBATCMD;
		private NxtControl.GuiFramework.FreeText freeText5;
		private NxtControl.GuiFramework.Line line1;
		private NxtControl.GuiFramework.Line line2;
		private NxtControl.GuiFramework.RoundedRectangle rectBtn;
		private NxtControl.GuiFramework.RoundedRectangle rectBase;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IALM;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IAVL;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IFLT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged QLT;
		private SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged ISTA;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IRUN;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged ASPCMD;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged PBATCMD;
		#endregion
	}
}