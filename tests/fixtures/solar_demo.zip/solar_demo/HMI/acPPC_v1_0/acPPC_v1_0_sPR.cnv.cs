/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/24/2026
 * Time: 10:59 AM
 */

using System;
using NxtControl.GuiFramework;
using NxtControl.Drawing;
using HMI.Main.SupportClasses;

namespace HMI.Main.Symbols.acPPC_v1_0
{
	public partial class sPR :
		NxtControl.GuiFramework.HMISymbol
	{
		private const double MIN_VALID_PR = 0.0;
		private const double MAX_VALID_PR = 120.0;
		private const double WARNING_LIMIT = 70.0;

		private bool _isRectBtnHovered;

		private SolarTheme.EquipmentState _currentStatus =
			SolarTheme.EquipmentState.Unknown;

		public sPR()
		{
			InitializeComponent();

			PR.OnValChanged += OnValueChanged;

			UpdateDisplay();
		}

		private void OnValueChanged(
			object sender,
			EventArgs e)
		{
			UpdateDisplay();
		}

		private void UpdateDisplay()
		{
			double performanceRatio =
				HmiValueHelper.ToDouble(PR.Val);

			_currentStatus =
				ResolveStatus(performanceRatio);

			HmiDisplayHelper.DisplayData displayData =
				new HmiDisplayHelper.DisplayData();

			displayData.Status = _currentStatus;
			displayData.CardBorder = rectBtn;
			displayData.CardBackground = rectBtn;
			displayData.IsHovered = _isRectBtnHovered;

			displayData.Items =
				new HmiDisplayHelper.DisplayItem[]
				{
					HmiDisplayHelper.CreateValue(
						txtData,
						PR.Val,
						"0.00",
						" %",
						GetValueColor(_currentStatus))
				};

			HmiDisplayHelper.Apply(displayData);
		}

		private SolarTheme.EquipmentState ResolveStatus(
			double performanceRatio)
		{
			if (performanceRatio <= MIN_VALID_PR ||
				performanceRatio > MAX_VALID_PR)
			{
				return SolarTheme.EquipmentState.Fault;
			}

			if (performanceRatio < WARNING_LIMIT)
			{
				return SolarTheme.EquipmentState.Warning;
			}

			return SolarTheme.EquipmentState.Healthy;
		}

		private Color GetValueColor(
			SolarTheme.EquipmentState status)
		{
			switch (status)
			{
				case SolarTheme.EquipmentState.Fault:
					return SolarTheme.Status.Fault;

				case SolarTheme.EquipmentState.Warning:
					return SolarTheme.Status.Warning;

				default:
					return SolarTheme.Text.Primary;
			}
		}

		private void UpdateCardVisual()
		{
			HmiDisplayHelper.ApplyStatusCard(
				rectBtn,
				rectBtn,
				_currentStatus,
				_isRectBtnHovered);
			
			roundedRectangle1.BrushColor =
				_isRectBtnHovered
					? SolarTheme.Surface.RaisedPanel
					: SolarTheme.Surface.Panel;
		
			roundedRectangle1.PenColor =
				_isRectBtnHovered
					? SolarTheme.Border.Hover
					: SolarTheme.Border.Normal;
		
			roundedRectangle1.PenWidth =
				_isRectBtnHovered
					? SolarTheme.Pen.Panel
					: SolarTheme.Pen.Normal;
		}

		private void GroupDataMouseEnter(
			object sender,
			EventArgs e)
		{
			_isRectBtnHovered = true;
			UpdateCardVisual();
		}

		private void GroupDataMouseLeave(
			object sender,
			EventArgs e)
		{
			_isRectBtnHovered = false;
			UpdateCardVisual();
		}
	}
}