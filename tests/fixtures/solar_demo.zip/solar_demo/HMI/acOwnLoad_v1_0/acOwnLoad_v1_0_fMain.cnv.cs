/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/14/2026
 * Time: 11:06 AM
 */

using System;
using NxtControl.GuiFramework;
using NxtControl.Drawing;
using HMI.Main.SupportClasses;

namespace HMI.Main.Faceplates.acOwnLoad_v1_0
{
	public partial class fMain :
		NxtControl.GuiFramework.HMIFaceplate
	{
		public fMain()
		{
			InitializeComponent();
			AttachEvents();
			UpdateDisplay();
		}

		private void AttachEvents()
		{
			REQ_Fired += REQ_Fired_EventHandler;

			IACT.OnValChanged += OnOwnLoadValueChanged;
			IAVL.OnValChanged += OnOwnLoadValueChanged;
			IALM.OnValChanged += OnOwnLoadValueChanged;
			IFLT.OnValChanged += OnOwnLoadValueChanged;
			QLT.OnValChanged += OnOwnLoadValueChanged;

			QLOAD.OnValChanged += OnOwnLoadValueChanged;
			ELOAD.OnValChanged += OnOwnLoadValueChanged;
			LOADLIM.OnValChanged += OnOwnLoadValueChanged;
		}

		private void OnOwnLoadValueChanged(
			object sender,
			EventArgs e)
		{
			UpdateDisplay();
		}

		private void UpdateDisplay()
		{
			SolarTheme.EquipmentState status =
				ResolveStatus();

			Color valueColor =
				GetValueColor(status);

			HmiDisplayHelper.DisplayData displayData =
				new HmiDisplayHelper.DisplayData();

			displayData.Status = status;
			displayData.StatusText =
				GetDisplayStatusText(status);

			displayData.StatusLabel = txtStatus;

			displayData.Items =
				new HmiDisplayHelper.DisplayItem[]
				{
					HmiDisplayHelper.CreateValue(
						txtQLOAD,
						QLOAD.Val,
						"0.00",
						" MVAr",
						valueColor),

					HmiDisplayHelper.CreateValue(
						txtELOAD,
						ELOAD.Val,
						"0.00",
						" MWh",
						valueColor),

					HmiDisplayHelper.CreateValue(
						txtLOADLIM,
						LOADLIM.Val,
						"0.00",
						" MW",
						valueColor)
				};

			HmiDisplayHelper.Apply(displayData);
		}

		private SolarTheme.EquipmentState ResolveStatus()
		{
			return SolarStatusHelper.ResolveRunningAvailable(
				QLT.Val,
				IFLT.Val,
				IALM.Val,
				IACT.Val,
				IAVL.Val);
		}

		private string GetDisplayStatusText(
			SolarTheme.EquipmentState status)
		{
			if (status ==
				SolarTheme.EquipmentState.Running)
			{
				return "Normal";
			}

			return SolarStatusHelper.GetStatusText(status);
		}

		private Color GetValueColor(
			SolarTheme.EquipmentState status)
		{
			switch (status)
			{
				case SolarTheme.EquipmentState.Offline:
					return SolarTheme.Status.Offline;
				
				case SolarTheme.EquipmentState.Unknown:
					return SolarTheme.Status.Unknown;

				case SolarTheme.EquipmentState.Fault:
					return SolarTheme.Status.Fault;

				default:
					return SolarTheme.Text.Primary;
			}
		}

		private void REQ_Fired_EventHandler(
			object sender,
			HMI.Main.Symbols.acOwnLoad_v1_0.REQEventArgs e)
		{
			Title =
				HmiValueHelper.SafeText(
					e.AssetName,
					"Own Load");

			UpdateDisplay();
		}
	}
}