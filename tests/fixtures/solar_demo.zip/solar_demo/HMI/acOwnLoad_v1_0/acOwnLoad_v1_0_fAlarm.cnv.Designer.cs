/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/14/2026
 * Time: 11:53 AM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using NxtControl.GuiFramework;

namespace HMI.Main.Faceplates.acOwnLoad_v1_0
{
	/// <summary>
	/// Summary description for fAlarm.
	/// </summary>
	partial class fAlarm
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new NxtControl.GuiFramework.Label();
			this.label2 = new NxtControl.GuiFramework.Label();
			this.label3 = new NxtControl.GuiFramework.Label();
			this.label4 = new NxtControl.GuiFramework.Label();
			this.label5 = new NxtControl.GuiFramework.Label();
			this.ALMW = new SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged();
			// 
			// label1
			// 
			this.label1.AngleIgnore = true;
			this.label1.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label1.Bounds = new NxtControl.Drawing.RectF(((float)(23D)), ((float)(19D)), ((float)(265D)), ((float)(26D)));
			this.label1.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.label1.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.label1.FontScale = true;
			this.label1.Name = "label1";
			this.label1.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label1.Text = "Label";
			this.label1.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.label1.TextAutoSizeHorizontalOffset = 10;
			this.label1.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.label1.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// label2
			// 
			this.label2.AngleIgnore = true;
			this.label2.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label2.Bounds = new NxtControl.Drawing.RectF(((float)(23D)), ((float)(56D)), ((float)(265D)), ((float)(26D)));
			this.label2.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.label2.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.label2.FontScale = true;
			this.label2.Name = "label2";
			this.label2.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label2.Text = "Label";
			this.label2.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.label2.TextAutoSizeHorizontalOffset = 10;
			this.label2.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.label2.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// label3
			// 
			this.label3.AngleIgnore = true;
			this.label3.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label3.Bounds = new NxtControl.Drawing.RectF(((float)(23D)), ((float)(93D)), ((float)(265D)), ((float)(26D)));
			this.label3.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.label3.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.label3.FontScale = true;
			this.label3.Name = "label3";
			this.label3.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label3.Text = "Label";
			this.label3.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.label3.TextAutoSizeHorizontalOffset = 10;
			this.label3.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.label3.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// label4
			// 
			this.label4.AngleIgnore = true;
			this.label4.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label4.Bounds = new NxtControl.Drawing.RectF(((float)(23D)), ((float)(130D)), ((float)(265D)), ((float)(26D)));
			this.label4.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.label4.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.label4.FontScale = true;
			this.label4.Name = "label4";
			this.label4.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label4.Text = "Label";
			this.label4.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.label4.TextAutoSizeHorizontalOffset = 10;
			this.label4.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.label4.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// label5
			// 
			this.label5.AngleIgnore = true;
			this.label5.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.label5.Bounds = new NxtControl.Drawing.RectF(((float)(23D)), ((float)(167D)), ((float)(265D)), ((float)(26D)));
			this.label5.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.label5.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.label5.FontScale = true;
			this.label5.Name = "label5";
			this.label5.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.label5.Text = "Label";
			this.label5.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.label5.TextAutoSizeHorizontalOffset = 10;
			this.label5.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.label5.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// ALMW
			// 
			this.ALMW.BeginInit();
			this.ALMW.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 100D, 99D);
			this.ALMW.Name = "ALMW";
			this.ALMW.SecurityToken = ((uint)(4294967295u));
			this.ALMW.TagName = "ALMW";
			this.ALMW.Val = ((short)(0));
			this.ALMW.ValMaximum = ((short)(0));
			this.ALMW.ValMinimum = ((short)(0));
			this.ALMW.ValUnits = null;
			this.ALMW.EndInit();
			// 
			// fAlarm
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(306D)), ((float)(219D)));
			this.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(3)), ((byte)(22)), ((byte)(20))));
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.label1,
			this.label2,
			this.label3,
			this.label4,
			this.label5,
			this.ALMW});
			this.Size = new System.Drawing.Size(306, 219);

		}
		private NxtControl.GuiFramework.Label label1;
		private NxtControl.GuiFramework.Label label2;
		private NxtControl.GuiFramework.Label label3;
		private NxtControl.GuiFramework.Label label4;
		private NxtControl.GuiFramework.Label label5;
		private SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged ALMW;
		#endregion
	}
}
