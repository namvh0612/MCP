/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/14/2026
 * Time: 10:45 AM
 */

using System;
using NxtControl.GuiFramework;
using NxtControl.Drawing;
using HMI.Main.SupportClasses;

namespace HMI.Main.Symbols.acOwnLoad_v1_0
{
	public partial class sDefault :
		NxtControl.GuiFramework.HMISymbol
	{
		private bool _isRectBtnHovered;

		private SolarTheme.EquipmentState _currentStatus =
			SolarTheme.EquipmentState.Offline;

		private enum LoadLevel
		{
			Offline,
			Fault,
			High,
			Normal,
			Idle
		}

		public sDefault()
		{
			InitializeComponent();
			AttachEvents();
			UpdateDisplay();
		}

		private void AttachEvents()
		{
			REQ_Fired += REQ_Fired_EventHandler;

			IACT.OnValChanged += OnValueChanged;
			IAVL.OnValChanged += OnValueChanged;
			IALM.OnValChanged += OnValueChanged;
			IFLT.OnValChanged += OnValueChanged;
			QLT.OnValChanged += OnValueChanged;

			PLOAD.OnValChanged += OnValueChanged;
			LOADLIM.OnValChanged += OnValueChanged;
		}

		private void OnValueChanged(
			object sender,
			EventArgs e)
		{
			UpdateDisplay();
		}

		private void UpdateDisplay()
		{
			bool hasValidQuality =
				HmiValueHelper.ToBool(QLT.Val);

			_currentStatus =
				SolarStatusHelper.ResolveRunningAvailable(
					QLT.Val,
					IFLT.Val,
					IALM.Val,
					IACT.Val,
					IAVL.Val);

			LoadLevel loadLevel =
				ResolveLoadLevel();

			HmiDisplayHelper.DisplayData displayData =
				new HmiDisplayHelper.DisplayData();

			displayData.Status = _currentStatus;
			displayData.StatusText =
				SolarStatusHelper.GetStatusText(
					_currentStatus);

			displayData.StatusLabel = txtStatus;
			displayData.StatusIndicator = indStatus;
			displayData.CardBorder = rectBtn;
			displayData.CardBackground = rectBase;
			displayData.IsHovered = _isRectBtnHovered;

			displayData.Items =
				CreateDisplayItems(
					loadLevel,
					hasValidQuality);

			HmiDisplayHelper.Apply(displayData);
		}

		private HmiDisplayHelper.DisplayItem[]
			CreateDisplayItems(
				LoadLevel loadLevel,
				bool hasValidQuality)
		{
			HmiDisplayHelper.DisplayItem powerItem;

			if (hasValidQuality)
			{
				powerItem =
					HmiDisplayHelper.CreateValue(
						txtPLOAD,
						PLOAD.Val,
						"0.00",
						" MW",
						SolarTheme.Text.Primary);
			}
			else
			{
				powerItem =
					HmiDisplayHelper.CreateText(
						txtPLOAD,
						"-- MW",
						SolarTheme.Status.Offline);
			}

			return new HmiDisplayHelper.DisplayItem[]
			{
				powerItem,

				HmiDisplayHelper.CreateText(
					txtLoadLvl,
					GetLoadLevelText(loadLevel),
					GetLoadLevelColor(loadLevel))
			};
		}

		private LoadLevel ResolveLoadLevel()
		{
			if (!HmiValueHelper.ToBool(QLT.Val))
			{
				return LoadLevel.Offline;
			}

			if (HmiValueHelper.ToBool(IFLT.Val))
			{
				return LoadLevel.Fault;
			}

			double activePower =
				HmiValueHelper.ToDouble(PLOAD.Val);

			double warningLimit =
				HmiValueHelper.ToDouble(LOADLIM.Val);

			if (warningLimit > 0.0 &&
				activePower > warningLimit)
			{
				return LoadLevel.High;
			}

			if (!HmiValueHelper.ToBool(IACT.Val) ||
				activePower <= 0.01)
			{
				return LoadLevel.Idle;
			}

			return LoadLevel.Normal;
		}

		private string GetLoadLevelText(
			LoadLevel loadLevel)
		{
			switch (loadLevel)
			{
				case LoadLevel.Offline:
					return "Offline";

				case LoadLevel.Fault:
					return "Fault";

				case LoadLevel.High:
					return "High";

				case LoadLevel.Normal:
					return "Normal";

				case LoadLevel.Idle:
					return "Idle";

				default:
					return "Unknown";
			}
		}

		private Color GetLoadLevelColor(
			LoadLevel loadLevel)
		{
			switch (loadLevel)
			{
				case LoadLevel.Fault:
					return SolarTheme.Status.Fault;

				case LoadLevel.High:
					return SolarTheme.Status.Warning;

				case LoadLevel.Normal:
					return SolarTheme.Text.Primary;

				case LoadLevel.Idle:
					return SolarTheme.Text.Muted;

				case LoadLevel.Offline:
				default:
					return SolarTheme.Status.Offline;
			}
		}

		private void UpdateCardVisual()
		{
			HmiDisplayHelper.ApplyStatusCard(
				rectBtn,
				rectBase,
				_currentStatus,
				_isRectBtnHovered);
		}

		private void RectBtnMouseEnter(
			object sender,
			EventArgs e)
		{
			_isRectBtnHovered = true;
			UpdateCardVisual();
		}

		private void RectBtnMouseLeave(
			object sender,
			EventArgs e)
		{
			_isRectBtnHovered = false;
			UpdateCardVisual();
		}

		private void REQ_Fired_EventHandler(
			object sender,
			REQEventArgs e)
		{
			lblSymbol.Text =
				HmiValueHelper.SafeText(
					e.AssetName,
					"Own Load");
		}
	}
}