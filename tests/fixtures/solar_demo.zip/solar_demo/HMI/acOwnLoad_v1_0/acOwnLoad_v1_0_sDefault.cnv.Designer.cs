/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/14/2026
 * Time: 10:45 AM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.acOwnLoad_v1_0
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sDefault
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(sDefault));
			this.line2 = new NxtControl.GuiFramework.Line();
			this.line1 = new NxtControl.GuiFramework.Line();
			this.freeText5 = new NxtControl.GuiFramework.FreeText();
			this.txtLoadLvl = new NxtControl.GuiFramework.Label();
			this.freeText4 = new NxtControl.GuiFramework.FreeText();
			this.txtPLOAD = new NxtControl.GuiFramework.Label();
			this.indStatus = new NxtControl.GuiFramework.Ellipse();
			this.txtStatus = new NxtControl.GuiFramework.Label();
			this.lblSymbol = new NxtControl.GuiFramework.Label();
			this.rectangle1 = new NxtControl.GuiFramework.Rectangle();
			this.rectBtn = new NxtControl.GuiFramework.RoundedRectangle();
			this.rectBase = new NxtControl.GuiFramework.RoundedRectangle();
			this.IAVL = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IFLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IALM = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IACT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.QLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.PLOAD = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.LOADLIM = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValChanged();
			// 
			// line2
			// 
			this.line2.EndPoint = new NxtControl.Drawing.PointF(239D, 209D);
			this.line2.Name = "line2";
			this.line2.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(20)), ((byte)(54)), ((byte)(45))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line2.StartPoint = new NxtControl.Drawing.PointF(2D, 209D);
			// 
			// line1
			// 
			this.line1.EndPoint = new NxtControl.Drawing.PointF(239D, 177D);
			this.line1.Name = "line1";
			this.line1.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(20)), ((byte)(54)), ((byte)(45))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line1.StartPoint = new NxtControl.Drawing.PointF(2D, 177D);
			// 
			// freeText5
			// 
			this.freeText5.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText5.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText5.Location = new NxtControl.Drawing.PointF(11D, 218D);
			this.freeText5.Name = "freeText5";
			this.freeText5.Text = "Load Level";
			// 
			// txtLoadLvl
			// 
			this.txtLoadLvl.AngleIgnore = true;
			this.txtLoadLvl.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtLoadLvl.Bounds = new NxtControl.Drawing.RectF(((float)(131D)), ((float)(217D)), ((float)(96D)), ((float)(20D)));
			this.txtLoadLvl.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtLoadLvl.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtLoadLvl.FontScale = true;
			this.txtLoadLvl.Name = "txtLoadLvl";
			this.txtLoadLvl.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtLoadLvl.Text = "Normal";
			this.txtLoadLvl.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtLoadLvl.TextAutoSizeHorizontalOffset = 10;
			this.txtLoadLvl.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtLoadLvl.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText4
			// 
			this.freeText4.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText4.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText4.Location = new NxtControl.Drawing.PointF(11D, 186D);
			this.freeText4.Name = "freeText4";
			this.freeText4.Text = "Power";
			// 
			// txtPLOAD
			// 
			this.txtPLOAD.AngleIgnore = true;
			this.txtPLOAD.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtPLOAD.Bounds = new NxtControl.Drawing.RectF(((float)(131D)), ((float)(185D)), ((float)(96D)), ((float)(20D)));
			this.txtPLOAD.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtPLOAD.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtPLOAD.FontScale = true;
			this.txtPLOAD.Name = "txtPLOAD";
			this.txtPLOAD.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtPLOAD.Text = "0.52 MW";
			this.txtPLOAD.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtPLOAD.TextAutoSizeHorizontalOffset = 10;
			this.txtPLOAD.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtPLOAD.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// indStatus
			// 
			this.indStatus.Bounds = new NxtControl.Drawing.RectF(((float)(163D)), ((float)(19D)), ((float)(10D)), ((float)(10D)));
			this.indStatus.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(120)), ((byte)(249)), ((byte)(141))));
			this.indStatus.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.indStatus.Name = "indStatus";
			this.indStatus.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// txtStatus
			// 
			this.txtStatus.AngleIgnore = true;
			this.txtStatus.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtStatus.Bounds = new NxtControl.Drawing.RectF(((float)(175D)), ((float)(16D)), ((float)(53D)), ((float)(16D)));
			this.txtStatus.Brush = new NxtControl.Drawing.Brush(true);
			this.txtStatus.Font = new NxtControl.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular);
			this.txtStatus.FontScale = true;
			this.txtStatus.Name = "txtStatus";
			this.txtStatus.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtStatus.Text = "Running";
			this.txtStatus.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.txtStatus.TextAutoSizeHorizontalOffset = 10;
			this.txtStatus.TextColor = new NxtControl.Drawing.Color(((byte)(120)), ((byte)(249)), ((byte)(141)));
			this.txtStatus.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// lblSymbol
			// 
			this.lblSymbol.AngleIgnore = true;
			this.lblSymbol.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.lblSymbol.Bounds = new NxtControl.Drawing.RectF(((float)(11D)), ((float)(12D)), ((float)(141D)), ((float)(24D)));
			this.lblSymbol.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.lblSymbol.Font = new NxtControl.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
			this.lblSymbol.FontScale = true;
			this.lblSymbol.Name = "lblSymbol";
			this.lblSymbol.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.lblSymbol.Text = "Own Load";
			this.lblSymbol.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.lblSymbol.TextAutoSizeHorizontalOffset = 10;
			this.lblSymbol.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.lblSymbol.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// rectangle1
			// 
			this.rectangle1.Bounds = new NxtControl.Drawing.RectF(((float)(10D)), ((float)(20D)), ((float)(220D)), ((float)(171D)));
			this.rectangle1.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle1.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle1.ImageBytes = resources.GetString("rectangle1.ImageBytes");
			this.rectangle1.Name = "rectangle1";
			this.rectangle1.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectBtn
			// 
			this.rectBtn.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(240D)), ((float)(250D)));
			this.rectBtn.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("Transparent"));
			this.rectBtn.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectBtn.Name = "rectBtn";
			this.rectBtn.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fMain", NxtControl.GuiFramework.MouseButtonType.Click));
			this.rectBtn.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(28)), ((byte)(78)), ((byte)(71))), 1F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Flat, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Round, null);
			this.rectBtn.Radius = 10D;
			this.rectBtn.MouseEnter += new System.EventHandler(this.RectBtnMouseEnter);
			this.rectBtn.MouseLeave += new System.EventHandler(this.RectBtnMouseLeave);
			// 
			// rectBase
			// 
			this.rectBase.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(240D)), ((float)(250D)));
			this.rectBase.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(3)), ((byte)(22)), ((byte)(20))));
			this.rectBase.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectBase.Name = "rectBase";
			this.rectBase.Pen = new NxtControl.Drawing.Pen("Transparent");
			this.rectBase.Radius = 10D;
			// 
			// IAVL
			// 
			this.IAVL.BeginInit();
			this.IAVL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 187D, 158D);
			this.IAVL.Name = "IAVL";
			this.IAVL.SecurityToken = ((uint)(4294967295u));
			this.IAVL.TagName = "IAVL";
			this.IAVL.Val = false;
			this.IAVL.EndInit();
			// 
			// IFLT
			// 
			this.IFLT.BeginInit();
			this.IFLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 106D, 151D);
			this.IFLT.Name = "IFLT";
			this.IFLT.SecurityToken = ((uint)(4294967295u));
			this.IFLT.TagName = "IFLT";
			this.IFLT.Val = false;
			this.IFLT.EndInit();
			// 
			// IALM
			// 
			this.IALM.BeginInit();
			this.IALM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 92D, 166D);
			this.IALM.Name = "IALM";
			this.IALM.SecurityToken = ((uint)(4294967295u));
			this.IALM.TagName = "IALM";
			this.IALM.Val = false;
			this.IALM.EndInit();
			// 
			// IACT
			// 
			this.IACT.BeginInit();
			this.IACT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 142D, 156D);
			this.IACT.Name = "IACT";
			this.IACT.SecurityToken = ((uint)(4294967295u));
			this.IACT.TagName = "IACT";
			this.IACT.Val = false;
			this.IACT.EndInit();
			// 
			// QLT
			// 
			this.QLT.BeginInit();
			this.QLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 170D, 132D);
			this.QLT.Name = "QLT";
			this.QLT.SecurityToken = ((uint)(4294967295u));
			this.QLT.TagName = "QLT";
			this.QLT.Val = false;
			this.QLT.EndInit();
			// 
			// PLOAD
			// 
			this.PLOAD.BeginInit();
			this.PLOAD.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 108D, 176D);
			this.PLOAD.Name = "PLOAD";
			this.PLOAD.SecurityToken = ((uint)(4294967295u));
			this.PLOAD.TagName = "LOADP";
			this.PLOAD.Val = 0F;
			this.PLOAD.ValDecimalPlaces = ((byte)(0));
			this.PLOAD.ValMaximum = 0F;
			this.PLOAD.ValMinimum = 0F;
			this.PLOAD.ValUnits = null;
			this.PLOAD.EndInit();
			// 
			// LOADLIM
			// 
			this.LOADLIM.BeginInit();
			this.LOADLIM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 113D, 148D);
			this.LOADLIM.Name = "LOADLIM";
			this.LOADLIM.SecurityToken = ((uint)(4294967295u));
			this.LOADLIM.TagName = "LOADLIM";
			this.LOADLIM.Val = 0F;
			this.LOADLIM.ValDecimalPlaces = ((byte)(0));
			this.LOADLIM.ValMaximum = 0F;
			this.LOADLIM.ValMinimum = 0F;
			this.LOADLIM.ValUnits = null;
			this.LOADLIM.EndInit();
			// 
			// sDefault
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.rectBase,
			this.rectangle1,
			this.lblSymbol,
			this.txtStatus,
			this.indStatus,
			this.txtPLOAD,
			this.freeText4,
			this.txtLoadLvl,
			this.freeText5,
			this.line1,
			this.line2,
			this.IAVL,
			this.IFLT,
			this.IALM,
			this.IACT,
			this.QLT,
			this.PLOAD,
			this.LOADLIM,
			this.rectBtn});
			this.SymbolSize = new System.Drawing.Size(528, 488);

		}
		private NxtControl.GuiFramework.Rectangle rectangle1;
		private NxtControl.GuiFramework.Label lblSymbol;
		private NxtControl.GuiFramework.Label txtStatus;
		private NxtControl.GuiFramework.Ellipse indStatus;
		private NxtControl.GuiFramework.RoundedRectangle rectBtn;
		private NxtControl.GuiFramework.Label txtPLOAD;
		private NxtControl.GuiFramework.FreeText freeText4;
		private NxtControl.GuiFramework.Label txtLoadLvl;
		private NxtControl.GuiFramework.FreeText freeText5;
		private NxtControl.GuiFramework.Line line1;
		private NxtControl.GuiFramework.Line line2;
		private NxtControl.GuiFramework.RoundedRectangle rectBase;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IAVL;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IFLT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IALM;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IACT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged QLT;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged PLOAD;
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValChanged LOADLIM;
		#endregion
	}
}