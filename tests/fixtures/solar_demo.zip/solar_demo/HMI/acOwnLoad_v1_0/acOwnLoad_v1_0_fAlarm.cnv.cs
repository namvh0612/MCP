/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/14/2026
 * Time: 11:53 AM
 */

using System;
using NxtControl.GuiFramework;
using HMI.Main.SupportClasses;

using GuiLabel =
	NxtControl.GuiFramework.Label;

namespace HMI.Main.Faceplates.acOwnLoad_v1_0
{
	public partial class fAlarm :
		NxtControl.GuiFramework.HMIFaceplate
	{
		public fAlarm()
		{
			InitializeComponent();
			AttachEvents();
			UpdateAlarmDisplay();
		}

		private void AttachEvents()
		{
			ALMW.OnValChanged += OnAlarmWordChanged;
			REQ_Fired += REQ_Fired_EventHandler;
		}

		private void OnAlarmWordChanged(
			object sender,
			EventArgs e)
		{
			UpdateAlarmDisplay();
		}

		private void UpdateAlarmDisplay()
		{
			int alarmWord =
				HmiValueHelper.ToInt(ALMW.Val);

			bool activeLoadInvalid =
				IsBitSet(alarmWord, 1);

			bool reactiveLoadInvalid =
				IsBitSet(alarmWord, 2);

			HmiDisplayHelper.DisplayData displayData =
				new HmiDisplayHelper.DisplayData();

			displayData.Items =
				new HmiDisplayHelper.DisplayItem[]
				{
					CreateAlarmItem(
						label1,
						"Data quality lost",
						IsBitSet(alarmWord, 0),
						SolarTheme.EquipmentState.Fault),

					CreateAlarmItem(
						label2,
						GetLoadDataAlarmText(
							activeLoadInvalid,
							reactiveLoadInvalid),
						activeLoadInvalid ||
							reactiveLoadInvalid,
						SolarTheme.EquipmentState.Fault),

					CreateAlarmItem(
						label3,
						"High-load warning",
						IsBitSet(alarmWord, 3),
						SolarTheme.EquipmentState.Warning),

					CreateAlarmItem(
						label4,
						"Load supply lost",
						IsBitSet(alarmWord, 4),
						SolarTheme.EquipmentState.Fault),

					CreateAlarmItem(
						label5,
						"Energy data invalid",
						IsBitSet(alarmWord, 5),
						SolarTheme.EquipmentState.Warning)
				};

			HmiDisplayHelper.Apply(displayData);
		}

		private HmiDisplayHelper.DisplayItem CreateAlarmItem(
			GuiLabel label,
			string text,
			bool isActive,
			SolarTheme.EquipmentState severity)
		{
			return HmiDisplayHelper.CreateText(
				label,
				text,
				isActive
					? SolarTheme.GetStatusColor(severity)
					: SolarTheme.Status.Offline);
		}

		private string GetLoadDataAlarmText(
			bool activeLoadInvalid,
			bool reactiveLoadInvalid)
		{
			if (activeLoadInvalid &&
				reactiveLoadInvalid)
			{
				return "Active / reactive load data invalid";
			}

			if (activeLoadInvalid)
			{
				return "Active-load invalid";
			}

			if (reactiveLoadInvalid)
			{
				return "Reactive-load invalid";
			}

			return "Active / reactive load data invalid";
		}

		private bool IsBitSet(
			int value,
			int bit)
		{
			if (bit < 0 || bit > 31)
				return false;

			return (value & (1 << bit)) != 0;
		}

		private void REQ_Fired_EventHandler(
			object sender,
			HMI.Main.Symbols.acOwnLoad_v1_0.REQEventArgs e)
		{
			Title =
				HmiValueHelper.SafeText(
					e.AssetName,
					"Own Load Alarms");
		}
	}
}