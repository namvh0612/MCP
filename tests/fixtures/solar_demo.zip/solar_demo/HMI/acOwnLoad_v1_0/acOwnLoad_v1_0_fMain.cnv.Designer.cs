/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/14/2026
 * Time: 11:06 AM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using NxtControl.GuiFramework;

namespace HMI.Main.Faceplates.acOwnLoad_v1_0
{
	/// <summary>
	/// Summary description for fMain.
	/// </summary>
	partial class fMain
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fMain));
			this.rectangle1 = new NxtControl.GuiFramework.Rectangle();
			this.freeText7 = new NxtControl.GuiFramework.FreeText();
			this.txtStatus = new NxtControl.GuiFramework.Label();
			this.txtELOAD = new NxtControl.GuiFramework.Label();
			this.txtLOADLIM = new NxtControl.GuiFramework.Label();
			this.freeText3 = new NxtControl.GuiFramework.FreeText();
			this.freeText4 = new NxtControl.GuiFramework.FreeText();
			this.rectangle2 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle3 = new NxtControl.GuiFramework.Rectangle();
			this.freeText1 = new NxtControl.GuiFramework.FreeText();
			this.line3 = new NxtControl.GuiFramework.Line();
			this.txtQLOAD = new NxtControl.GuiFramework.Label();
			this.freeText2 = new NxtControl.GuiFramework.FreeText();
			this.rectangle6 = new NxtControl.GuiFramework.Rectangle();
			this.sButtonNavDemo1 = new SE.Agile.Symbols.Broadcaster_v1_0.sButtonNavDemo();
			this.ELOAD = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.IACT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IALM = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IAVL = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IFLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.LOADLIM = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValChanged();
			this.QLOAD = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.QLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			// 
			// rectangle1
			// 
			this.rectangle1.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(16D)), ((float)(16D)), ((float)(16D)));
			this.rectangle1.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle1.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle1.ImageBytes = resources.GetString("rectangle1.ImageBytes");
			this.rectangle1.Name = "rectangle1";
			this.rectangle1.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// freeText7
			// 
			this.freeText7.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText7.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText7.Location = new NxtControl.Drawing.PointF(40D, 15D);
			this.freeText7.Name = "freeText7";
			this.freeText7.Text = "Status";
			// 
			// txtStatus
			// 
			this.txtStatus.AngleIgnore = true;
			this.txtStatus.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtStatus.Bounds = new NxtControl.Drawing.RectF(((float)(130D)), ((float)(11D)), ((float)(82D)), ((float)(26D)));
			this.txtStatus.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtStatus.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtStatus.FontScale = true;
			this.txtStatus.Name = "txtStatus";
			this.txtStatus.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fAlarm", NxtControl.GuiFramework.MouseButtonType.Click));
			this.txtStatus.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtStatus.Text = "Normal";
			this.txtStatus.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtStatus.TextAutoSizeHorizontalOffset = 10;
			this.txtStatus.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtStatus.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// txtELOAD
			// 
			this.txtELOAD.AngleIgnore = true;
			this.txtELOAD.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtELOAD.Bounds = new NxtControl.Drawing.RectF(((float)(130D)), ((float)(71D)), ((float)(82D)), ((float)(26D)));
			this.txtELOAD.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtELOAD.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtELOAD.FontScale = true;
			this.txtELOAD.Name = "txtELOAD";
			this.txtELOAD.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtELOAD.Text = "0.54 MWh";
			this.txtELOAD.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtELOAD.TextAutoSizeHorizontalOffset = 10;
			this.txtELOAD.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtELOAD.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// txtLOADLIM
			// 
			this.txtLOADLIM.AngleIgnore = true;
			this.txtLOADLIM.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtLOADLIM.Bounds = new NxtControl.Drawing.RectF(((float)(130D)), ((float)(101D)), ((float)(82D)), ((float)(26D)));
			this.txtLOADLIM.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtLOADLIM.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtLOADLIM.FontScale = true;
			this.txtLOADLIM.Name = "txtLOADLIM";
			this.txtLOADLIM.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtLOADLIM.Text = "1.15 MW";
			this.txtLOADLIM.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtLOADLIM.TextAutoSizeHorizontalOffset = 10;
			this.txtLOADLIM.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtLOADLIM.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText3
			// 
			this.freeText3.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText3.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText3.Location = new NxtControl.Drawing.PointF(40D, 75D);
			this.freeText3.Name = "freeText3";
			this.freeText3.Text = "Energy today";
			// 
			// freeText4
			// 
			this.freeText4.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText4.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText4.Location = new NxtControl.Drawing.PointF(40D, 105D);
			this.freeText4.Name = "freeText4";
			this.freeText4.Text = "Load Limit";
			// 
			// rectangle2
			// 
			this.rectangle2.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(76D)), ((float)(16D)), ((float)(16D)));
			this.rectangle2.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle2.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle2.ImageBytes = resources.GetString("rectangle2.ImageBytes");
			this.rectangle2.Name = "rectangle2";
			this.rectangle2.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle3
			// 
			this.rectangle3.Bounds = new NxtControl.Drawing.RectF(((float)(12D)), ((float)(108D)), ((float)(16D)), ((float)(16D)));
			this.rectangle3.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle3.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle3.ImageBytes = resources.GetString("rectangle3.ImageBytes");
			this.rectangle3.Name = "rectangle3";
			this.rectangle3.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// freeText1
			// 
			this.freeText1.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText1.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Italic);
			this.freeText1.Location = new NxtControl.Drawing.PointF(14D, 144D);
			this.freeText1.Name = "freeText1";
			this.freeText1.Text = "Connector Info.";
			// 
			// line3
			// 
			this.line3.EndPoint = new NxtControl.Drawing.PointF(228D, 134D);
			this.line3.Name = "line3";
			this.line3.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(19)), ((byte)(76)), ((byte)(30))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line3.StartPoint = new NxtControl.Drawing.PointF(2D, 134D);
			// 
			// txtQLOAD
			// 
			this.txtQLOAD.AngleIgnore = true;
			this.txtQLOAD.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtQLOAD.Bounds = new NxtControl.Drawing.RectF(((float)(130D)), ((float)(41D)), ((float)(82D)), ((float)(26D)));
			this.txtQLOAD.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtQLOAD.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtQLOAD.FontScale = true;
			this.txtQLOAD.Name = "txtQLOAD";
			this.txtQLOAD.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtQLOAD.Text = "0.5 MVAr";
			this.txtQLOAD.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtQLOAD.TextAutoSizeHorizontalOffset = 10;
			this.txtQLOAD.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtQLOAD.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText2
			// 
			this.freeText2.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText2.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText2.Location = new NxtControl.Drawing.PointF(40D, 45D);
			this.freeText2.Name = "freeText2";
			this.freeText2.Text = "Q Load";
			// 
			// rectangle6
			// 
			this.rectangle6.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(46D)), ((float)(16D)), ((float)(16D)));
			this.rectangle6.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle6.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle6.ImageBytes = resources.GetString("rectangle6.ImageBytes");
			this.rectangle6.Name = "rectangle6";
			this.rectangle6.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// sButtonNavDemo1
			// 
			this.sButtonNavDemo1.BeginInit();
			this.sButtonNavDemo1.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 198D, 144D);
			this.sButtonNavDemo1.Name = "sButtonNavDemo1";
			this.sButtonNavDemo1.SecurityToken = ((uint)(4294967295u));
			this.sButtonNavDemo1.TagName = "OwnLoad.Broadcaster_v1_0";
			this.sButtonNavDemo1.EndInit();
			// 
			// ELOAD
			// 
			this.ELOAD.BeginInit();
			this.ELOAD.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 92D, 68D);
			this.ELOAD.Name = "ELOAD";
			this.ELOAD.SecurityToken = ((uint)(4294967295u));
			this.ELOAD.TagName = "ELOAD";
			this.ELOAD.Val = 0F;
			this.ELOAD.ValDecimalPlaces = ((byte)(0));
			this.ELOAD.ValMaximum = 0F;
			this.ELOAD.ValMinimum = 0F;
			this.ELOAD.ValUnits = null;
			this.ELOAD.EndInit();
			// 
			// IACT
			// 
			this.IACT.BeginInit();
			this.IACT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 116D, 60D);
			this.IACT.Name = "IACT";
			this.IACT.SecurityToken = ((uint)(4294967295u));
			this.IACT.TagName = "IACT";
			this.IACT.Val = false;
			this.IACT.EndInit();
			// 
			// IALM
			// 
			this.IALM.BeginInit();
			this.IALM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 62D, 72D);
			this.IALM.Name = "IALM";
			this.IALM.SecurityToken = ((uint)(4294967295u));
			this.IALM.TagName = "IALM";
			this.IALM.Val = false;
			this.IALM.EndInit();
			// 
			// IAVL
			// 
			this.IAVL.BeginInit();
			this.IAVL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 99D, 72D);
			this.IAVL.Name = "IAVL";
			this.IAVL.SecurityToken = ((uint)(4294967295u));
			this.IAVL.TagName = "IAVL";
			this.IAVL.Val = false;
			this.IAVL.EndInit();
			// 
			// IFLT
			// 
			this.IFLT.BeginInit();
			this.IFLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 122D, 69D);
			this.IFLT.Name = "IFLT";
			this.IFLT.SecurityToken = ((uint)(4294967295u));
			this.IFLT.TagName = "IFLT";
			this.IFLT.Val = false;
			this.IFLT.EndInit();
			// 
			// LOADLIM
			// 
			this.LOADLIM.BeginInit();
			this.LOADLIM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 70D, 68D);
			this.LOADLIM.Name = "LOADLIM";
			this.LOADLIM.SecurityToken = ((uint)(4294967295u));
			this.LOADLIM.TagName = "LOADLIM";
			this.LOADLIM.Val = 0F;
			this.LOADLIM.ValDecimalPlaces = ((byte)(0));
			this.LOADLIM.ValMaximum = 0F;
			this.LOADLIM.ValMinimum = 0F;
			this.LOADLIM.ValUnits = null;
			this.LOADLIM.EndInit();
			// 
			// QLOAD
			// 
			this.QLOAD.BeginInit();
			this.QLOAD.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 71D, 62D);
			this.QLOAD.Name = "QLOAD";
			this.QLOAD.SecurityToken = ((uint)(4294967295u));
			this.QLOAD.TagName = "LOADQ";
			this.QLOAD.Val = 0F;
			this.QLOAD.ValDecimalPlaces = ((byte)(0));
			this.QLOAD.ValMaximum = 0F;
			this.QLOAD.ValMinimum = 0F;
			this.QLOAD.ValUnits = null;
			this.QLOAD.EndInit();
			// 
			// QLT
			// 
			this.QLT.BeginInit();
			this.QLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 50D, 75D);
			this.QLT.Name = "QLT";
			this.QLT.SecurityToken = ((uint)(4294967295u));
			this.QLT.TagName = "QLT";
			this.QLT.Val = false;
			this.QLT.EndInit();
			// 
			// fMain
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(228D)), ((float)(170D)));
			this.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(3)), ((byte)(22)), ((byte)(20))));
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.txtELOAD,
			this.txtLOADLIM,
			this.freeText3,
			this.freeText4,
			this.rectangle2,
			this.rectangle3,
			this.freeText1,
			this.line3,
			this.txtQLOAD,
			this.freeText2,
			this.rectangle6,
			this.sButtonNavDemo1,
			this.ELOAD,
			this.IACT,
			this.IALM,
			this.IAVL,
			this.IFLT,
			this.LOADLIM,
			this.QLOAD,
			this.QLT,
			this.txtStatus,
			this.freeText7,
			this.rectangle1});
			this.Size = new System.Drawing.Size(228, 170);

		}
		private NxtControl.GuiFramework.Rectangle rectangle1;
		private NxtControl.GuiFramework.FreeText freeText7;
		private NxtControl.GuiFramework.Label txtStatus;
		private NxtControl.GuiFramework.Label txtELOAD;
		private NxtControl.GuiFramework.Label txtLOADLIM;
		private NxtControl.GuiFramework.FreeText freeText3;
		private NxtControl.GuiFramework.FreeText freeText4;
		private NxtControl.GuiFramework.Rectangle rectangle2;
		private NxtControl.GuiFramework.Rectangle rectangle3;
		private NxtControl.GuiFramework.FreeText freeText1;
		private NxtControl.GuiFramework.Line line3;
		private NxtControl.GuiFramework.Label txtQLOAD;
		private NxtControl.GuiFramework.FreeText freeText2;
		private NxtControl.GuiFramework.Rectangle rectangle6;
		private SE.Agile.Symbols.Broadcaster_v1_0.sButtonNavDemo sButtonNavDemo1;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged ELOAD;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IACT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IALM;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IAVL;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IFLT;
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValChanged LOADLIM;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged QLOAD;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged QLT;
		#endregion
	}
}
