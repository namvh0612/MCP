/*
 * Created by EcoStruxure Automation Expert.
 * Date: 7/21/2026
 */

using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.acSimLogic_v1_0
{
	partial class sControl
	{
		#region Component Designer generated code

		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(sControl));
			this.btnMode0 = new NxtControl.GuiFramework.RoundedRectangle();
			this.iconMode0 = new NxtControl.GuiFramework.RoundedRectangle();
			this.lblMode0 = new NxtControl.GuiFramework.Label();
			this.groupMode0 = new NxtControl.GuiFramework.Group();
			this.btnMode1 = new NxtControl.GuiFramework.RoundedRectangle();
			this.iconMode1 = new NxtControl.GuiFramework.RoundedRectangle();
			this.lblMode1 = new NxtControl.GuiFramework.Label();
			this.groupMode1 = new NxtControl.GuiFramework.Group();
			this.btnMode2 = new NxtControl.GuiFramework.RoundedRectangle();
			this.iconMode2 = new NxtControl.GuiFramework.RoundedRectangle();
			this.lblMode2 = new NxtControl.GuiFramework.Label();
			this.groupMode2 = new NxtControl.GuiFramework.Group();
			this.btnMode3 = new NxtControl.GuiFramework.RoundedRectangle();
			this.iconMode3 = new NxtControl.GuiFramework.RoundedRectangle();
			this.lblMode3 = new NxtControl.GuiFramework.Label();
			this.groupMode3 = new NxtControl.GuiFramework.Group();
			this.btnMode4 = new NxtControl.GuiFramework.RoundedRectangle();
			this.iconMode4 = new NxtControl.GuiFramework.RoundedRectangle();
			this.lblMode4 = new NxtControl.GuiFramework.Label();
			this.groupMode4 = new NxtControl.GuiFramework.Group();
			this.btnMode5 = new NxtControl.GuiFramework.RoundedRectangle();
			this.iconMode5 = new NxtControl.GuiFramework.RoundedRectangle();
			this.lblMode5 = new NxtControl.GuiFramework.Label();
			this.groupMode5 = new NxtControl.GuiFramework.Group();
			this.btnMode6 = new NxtControl.GuiFramework.RoundedRectangle();
			this.iconMode6 = new NxtControl.GuiFramework.RoundedRectangle();
			this.lblMode6 = new NxtControl.GuiFramework.Label();
			this.groupMode6 = new NxtControl.GuiFramework.Group();
			this.btnMode7 = new NxtControl.GuiFramework.RoundedRectangle();
			this.iconMode7 = new NxtControl.GuiFramework.RoundedRectangle();
			this.lblMode7 = new NxtControl.GuiFramework.Label();
			this.groupMode7 = new NxtControl.GuiFramework.Group();
			this.SIM_CASE = new SE.Agile.Symbols.HMI_Control_Integer_v1_0.sValChanged();
			this.SIM_EN = new SE.Agile.Symbols.HMI_Control_Bool_v1_0.sValChanged();
			// 
			// btnMode0
			// 
			this.btnMode0.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(112D)), ((float)(92D)));
			this.btnMode0.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(12)), ((byte)(35)), ((byte)(33))));
			this.btnMode0.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.btnMode0.Name = "btnMode0";
			this.btnMode0.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(37)), ((byte)(64)), ((byte)(61))), 1F, NxtControl.Drawing.DashStyle.Solid);
			// 
			// iconMode0
			// 
			this.iconMode0.Bounds = new NxtControl.Drawing.RectF(((float)(78D)), ((float)(6D)), ((float)(28D)), ((float)(28D)));
			this.iconMode0.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(12)), ((byte)(35)), ((byte)(33))));
			this.iconMode0.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.iconMode0.ImageBytes = resources.GetString("iconMode0.ImageBytes");
			this.iconMode0.Name = "iconMode0";
			this.iconMode0.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(37)), ((byte)(64)), ((byte)(61))), 1F, NxtControl.Drawing.DashStyle.Solid);
			// 
			// lblMode0
			// 
			this.lblMode0.AngleIgnore = true;
			this.lblMode0.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.lblMode0.Bounds = new NxtControl.Drawing.RectF(((float)(10D)), ((float)(10D)), ((float)(92D)), ((float)(72D)));
			this.lblMode0.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.lblMode0.Font = new NxtControl.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular);
			this.lblMode0.FontScale = true;
			this.lblMode0.Name = "lblMode0";
			this.lblMode0.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.lblMode0.Text = "Normal Operation";
			this.lblMode0.TextAlignment = NxtControl.Drawing.ContentAlignment.BottomLeft;
			this.lblMode0.TextAutoSizeHorizontalOffset = 10;
			this.lblMode0.TextColor = new NxtControl.Drawing.Color(((byte)(238)), ((byte)(243)), ((byte)(241)));
			this.lblMode0.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// groupMode0
			// 
			this.groupMode0.BeginInit();
			this.groupMode0.Name = "groupMode0";
			this.groupMode0.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.btnMode0,
			this.lblMode0,
			this.iconMode0});
			this.groupMode0.EndInit();
			// 
			// btnMode1
			// 
			this.btnMode1.Bounds = new NxtControl.Drawing.RectF(((float)(126D)), ((float)(0D)), ((float)(112D)), ((float)(92D)));
			this.btnMode1.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(12)), ((byte)(35)), ((byte)(33))));
			this.btnMode1.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.btnMode1.Name = "btnMode1";
			this.btnMode1.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(37)), ((byte)(64)), ((byte)(61))), 1F, NxtControl.Drawing.DashStyle.Solid);
			// 
			// iconMode1
			// 
			this.iconMode1.Bounds = new NxtControl.Drawing.RectF(((float)(204D)), ((float)(6D)), ((float)(28D)), ((float)(28D)));
			this.iconMode1.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(12)), ((byte)(35)), ((byte)(33))));
			this.iconMode1.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.iconMode1.ImageBytes = resources.GetString("iconMode1.ImageBytes");
			this.iconMode1.Name = "iconMode1";
			this.iconMode1.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(37)), ((byte)(64)), ((byte)(61))), 1F, NxtControl.Drawing.DashStyle.Solid);
			// 
			// lblMode1
			// 
			this.lblMode1.AngleIgnore = true;
			this.lblMode1.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.lblMode1.Bounds = new NxtControl.Drawing.RectF(((float)(136D)), ((float)(10D)), ((float)(92D)), ((float)(72D)));
			this.lblMode1.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.lblMode1.Font = new NxtControl.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular);
			this.lblMode1.FontScale = true;
			this.lblMode1.Name = "lblMode1";
			this.lblMode1.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.lblMode1.Text = "Mode Cloudy";
			this.lblMode1.TextAlignment = NxtControl.Drawing.ContentAlignment.BottomLeft;
			this.lblMode1.TextAutoSizeHorizontalOffset = 10;
			this.lblMode1.TextColor = new NxtControl.Drawing.Color(((byte)(238)), ((byte)(243)), ((byte)(241)));
			this.lblMode1.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// groupMode1
			// 
			this.groupMode1.BeginInit();
			this.groupMode1.Name = "groupMode1";
			this.groupMode1.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.btnMode1,
			this.lblMode1,
			this.iconMode1});
			this.groupMode1.EndInit();
			// 
			// btnMode2
			// 
			this.btnMode2.Bounds = new NxtControl.Drawing.RectF(((float)(252D)), ((float)(0D)), ((float)(112D)), ((float)(92D)));
			this.btnMode2.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(12)), ((byte)(35)), ((byte)(33))));
			this.btnMode2.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.btnMode2.Name = "btnMode2";
			this.btnMode2.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(37)), ((byte)(64)), ((byte)(61))), 1F, NxtControl.Drawing.DashStyle.Solid);
			// 
			// iconMode2
			// 
			this.iconMode2.Bounds = new NxtControl.Drawing.RectF(((float)(330D)), ((float)(6D)), ((float)(28D)), ((float)(28D)));
			this.iconMode2.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(12)), ((byte)(35)), ((byte)(33))));
			this.iconMode2.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.iconMode2.ImageBytes = resources.GetString("iconMode2.ImageBytes");
			this.iconMode2.Name = "iconMode2";
			this.iconMode2.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(37)), ((byte)(64)), ((byte)(61))), 1F, NxtControl.Drawing.DashStyle.Solid);
			// 
			// lblMode2
			// 
			this.lblMode2.AngleIgnore = true;
			this.lblMode2.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.lblMode2.Bounds = new NxtControl.Drawing.RectF(((float)(262D)), ((float)(10D)), ((float)(92D)), ((float)(72D)));
			this.lblMode2.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.lblMode2.Font = new NxtControl.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular);
			this.lblMode2.FontScale = true;
			this.lblMode2.Name = "lblMode2";
			this.lblMode2.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.lblMode2.Text = "BESS Charge";
			this.lblMode2.TextAlignment = NxtControl.Drawing.ContentAlignment.BottomLeft;
			this.lblMode2.TextAutoSizeHorizontalOffset = 10;
			this.lblMode2.TextColor = new NxtControl.Drawing.Color(((byte)(238)), ((byte)(243)), ((byte)(241)));
			this.lblMode2.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// groupMode2
			// 
			this.groupMode2.BeginInit();
			this.groupMode2.Name = "groupMode2";
			this.groupMode2.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.btnMode2,
			this.lblMode2,
			this.iconMode2});
			this.groupMode2.EndInit();
			// 
			// btnMode3
			// 
			this.btnMode3.Bounds = new NxtControl.Drawing.RectF(((float)(378D)), ((float)(0D)), ((float)(112D)), ((float)(92D)));
			this.btnMode3.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(12)), ((byte)(35)), ((byte)(33))));
			this.btnMode3.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.btnMode3.Name = "btnMode3";
			this.btnMode3.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(37)), ((byte)(64)), ((byte)(61))), 1F, NxtControl.Drawing.DashStyle.Solid);
			// 
			// iconMode3
			// 
			this.iconMode3.Bounds = new NxtControl.Drawing.RectF(((float)(454D)), ((float)(4D)), ((float)(28D)), ((float)(28D)));
			this.iconMode3.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(12)), ((byte)(35)), ((byte)(33))));
			this.iconMode3.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.iconMode3.ImageBytes = resources.GetString("iconMode3.ImageBytes");
			this.iconMode3.Name = "iconMode3";
			this.iconMode3.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(37)), ((byte)(64)), ((byte)(61))), 1F, NxtControl.Drawing.DashStyle.Solid);
			// 
			// lblMode3
			// 
			this.lblMode3.AngleIgnore = true;
			this.lblMode3.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.lblMode3.Bounds = new NxtControl.Drawing.RectF(((float)(386D)), ((float)(8D)), ((float)(92D)), ((float)(72D)));
			this.lblMode3.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.lblMode3.Font = new NxtControl.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular);
			this.lblMode3.FontScale = true;
			this.lblMode3.Name = "lblMode3";
			this.lblMode3.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.lblMode3.Text = "BESS Discharge";
			this.lblMode3.TextAlignment = NxtControl.Drawing.ContentAlignment.BottomLeft;
			this.lblMode3.TextAutoSizeHorizontalOffset = 10;
			this.lblMode3.TextColor = new NxtControl.Drawing.Color(((byte)(238)), ((byte)(243)), ((byte)(241)));
			this.lblMode3.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// groupMode3
			// 
			this.groupMode3.BeginInit();
			this.groupMode3.Name = "groupMode3";
			this.groupMode3.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.btnMode3,
			this.lblMode3,
			this.iconMode3});
			this.groupMode3.EndInit();
			// 
			// btnMode4
			// 
			this.btnMode4.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(108D)), ((float)(112D)), ((float)(92D)));
			this.btnMode4.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(12)), ((byte)(35)), ((byte)(33))));
			this.btnMode4.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.btnMode4.Name = "btnMode4";
			this.btnMode4.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(37)), ((byte)(64)), ((byte)(61))), 1F, NxtControl.Drawing.DashStyle.Solid);
			// 
			// iconMode4
			// 
			this.iconMode4.Bounds = new NxtControl.Drawing.RectF(((float)(78D)), ((float)(114D)), ((float)(28D)), ((float)(28D)));
			this.iconMode4.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(12)), ((byte)(35)), ((byte)(33))));
			this.iconMode4.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.iconMode4.ImageBytes = resources.GetString("iconMode4.ImageBytes");
			this.iconMode4.Name = "iconMode4";
			this.iconMode4.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(37)), ((byte)(64)), ((byte)(61))), 1F, NxtControl.Drawing.DashStyle.Solid);
			// 
			// lblMode4
			// 
			this.lblMode4.AngleIgnore = true;
			this.lblMode4.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.lblMode4.Bounds = new NxtControl.Drawing.RectF(((float)(10D)), ((float)(118D)), ((float)(92D)), ((float)(72D)));
			this.lblMode4.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.lblMode4.Font = new NxtControl.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular);
			this.lblMode4.FontScale = true;
			this.lblMode4.Name = "lblMode4";
			this.lblMode4.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.lblMode4.Text = "Mode Curtailment";
			this.lblMode4.TextAlignment = NxtControl.Drawing.ContentAlignment.BottomLeft;
			this.lblMode4.TextAutoSizeHorizontalOffset = 10;
			this.lblMode4.TextColor = new NxtControl.Drawing.Color(((byte)(238)), ((byte)(243)), ((byte)(241)));
			this.lblMode4.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// groupMode4
			// 
			this.groupMode4.BeginInit();
			this.groupMode4.Name = "groupMode4";
			this.groupMode4.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.btnMode4,
			this.lblMode4,
			this.iconMode4});
			this.groupMode4.EndInit();
			// 
			// btnMode5
			// 
			this.btnMode5.Bounds = new NxtControl.Drawing.RectF(((float)(126D)), ((float)(108D)), ((float)(112D)), ((float)(92D)));
			this.btnMode5.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(12)), ((byte)(35)), ((byte)(33))));
			this.btnMode5.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.btnMode5.Name = "btnMode5";
			this.btnMode5.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(37)), ((byte)(64)), ((byte)(61))), 1F, NxtControl.Drawing.DashStyle.Solid);
			// 
			// iconMode5
			// 
			this.iconMode5.Bounds = new NxtControl.Drawing.RectF(((float)(204D)), ((float)(114D)), ((float)(28D)), ((float)(28D)));
			this.iconMode5.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(12)), ((byte)(35)), ((byte)(33))));
			this.iconMode5.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.iconMode5.ImageBytes = resources.GetString("iconMode5.ImageBytes");
			this.iconMode5.Name = "iconMode5";
			this.iconMode5.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(37)), ((byte)(64)), ((byte)(61))), 1F, NxtControl.Drawing.DashStyle.Solid);
			// 
			// lblMode5
			// 
			this.lblMode5.AngleIgnore = true;
			this.lblMode5.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.lblMode5.Bounds = new NxtControl.Drawing.RectF(((float)(136D)), ((float)(118D)), ((float)(92D)), ((float)(72D)));
			this.lblMode5.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.lblMode5.Font = new NxtControl.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular);
			this.lblMode5.FontScale = true;
			this.lblMode5.Name = "lblMode5";
			this.lblMode5.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.lblMode5.Text = "Grid Disconnect";
			this.lblMode5.TextAlignment = NxtControl.Drawing.ContentAlignment.BottomLeft;
			this.lblMode5.TextAutoSizeHorizontalOffset = 10;
			this.lblMode5.TextColor = new NxtControl.Drawing.Color(((byte)(238)), ((byte)(243)), ((byte)(241)));
			this.lblMode5.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// groupMode5
			// 
			this.groupMode5.BeginInit();
			this.groupMode5.Name = "groupMode5";
			this.groupMode5.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.btnMode5,
			this.lblMode5,
			this.iconMode5});
			this.groupMode5.EndInit();
			// 
			// btnMode6
			// 
			this.btnMode6.Bounds = new NxtControl.Drawing.RectF(((float)(252D)), ((float)(108D)), ((float)(112D)), ((float)(92D)));
			this.btnMode6.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(12)), ((byte)(35)), ((byte)(33))));
			this.btnMode6.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.btnMode6.Name = "btnMode6";
			this.btnMode6.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(37)), ((byte)(64)), ((byte)(61))), 1F, NxtControl.Drawing.DashStyle.Solid);
			// 
			// iconMode6
			// 
			this.iconMode6.Bounds = new NxtControl.Drawing.RectF(((float)(330D)), ((float)(114D)), ((float)(28D)), ((float)(28D)));
			this.iconMode6.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(12)), ((byte)(35)), ((byte)(33))));
			this.iconMode6.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.iconMode6.ImageBytes = resources.GetString("iconMode6.ImageBytes");
			this.iconMode6.Name = "iconMode6";
			this.iconMode6.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(37)), ((byte)(64)), ((byte)(61))), 1F, NxtControl.Drawing.DashStyle.Solid);
			// 
			// lblMode6
			// 
			this.lblMode6.AngleIgnore = true;
			this.lblMode6.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.lblMode6.Bounds = new NxtControl.Drawing.RectF(((float)(262D)), ((float)(118D)), ((float)(92D)), ((float)(72D)));
			this.lblMode6.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.lblMode6.Font = new NxtControl.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular);
			this.lblMode6.FontScale = true;
			this.lblMode6.Name = "lblMode6";
			this.lblMode6.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.lblMode6.Text = "Inverter Trip";
			this.lblMode6.TextAlignment = NxtControl.Drawing.ContentAlignment.BottomLeft;
			this.lblMode6.TextAutoSizeHorizontalOffset = 10;
			this.lblMode6.TextColor = new NxtControl.Drawing.Color(((byte)(238)), ((byte)(243)), ((byte)(241)));
			this.lblMode6.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// groupMode6
			// 
			this.groupMode6.BeginInit();
			this.groupMode6.Name = "groupMode6";
			this.groupMode6.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.btnMode6,
			this.lblMode6,
			this.iconMode6});
			this.groupMode6.EndInit();
			// 
			// btnMode7
			// 
			this.btnMode7.Bounds = new NxtControl.Drawing.RectF(((float)(378D)), ((float)(108D)), ((float)(112D)), ((float)(92D)));
			this.btnMode7.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(12)), ((byte)(35)), ((byte)(33))));
			this.btnMode7.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.btnMode7.Name = "btnMode7";
			this.btnMode7.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(37)), ((byte)(64)), ((byte)(61))), 1F, NxtControl.Drawing.DashStyle.Solid);
			// 
			// iconMode7
			// 
			this.iconMode7.Bounds = new NxtControl.Drawing.RectF(((float)(454D)), ((float)(112D)), ((float)(28D)), ((float)(28D)));
			this.iconMode7.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(12)), ((byte)(35)), ((byte)(33))));
			this.iconMode7.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.iconMode7.ImageBytes = resources.GetString("iconMode7.ImageBytes");
			this.iconMode7.Name = "iconMode7";
			this.iconMode7.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(37)), ((byte)(64)), ((byte)(61))), 1F, NxtControl.Drawing.DashStyle.Solid);
			// 
			// lblMode7
			// 
			this.lblMode7.AngleIgnore = true;
			this.lblMode7.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.lblMode7.Bounds = new NxtControl.Drawing.RectF(((float)(386D)), ((float)(116D)), ((float)(92D)), ((float)(72D)));
			this.lblMode7.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.lblMode7.Font = new NxtControl.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular);
			this.lblMode7.FontScale = true;
			this.lblMode7.Name = "lblMode7";
			this.lblMode7.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.lblMode7.Text = "Comm. Loss";
			this.lblMode7.TextAlignment = NxtControl.Drawing.ContentAlignment.BottomLeft;
			this.lblMode7.TextAutoSizeHorizontalOffset = 10;
			this.lblMode7.TextColor = new NxtControl.Drawing.Color(((byte)(238)), ((byte)(243)), ((byte)(241)));
			this.lblMode7.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// groupMode7
			// 
			this.groupMode7.BeginInit();
			this.groupMode7.Name = "groupMode7";
			this.groupMode7.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.btnMode7,
			this.lblMode7,
			this.iconMode7});
			this.groupMode7.EndInit();
			// 
			// SIM_CASE
			// 
			this.SIM_CASE.BeginInit();
			this.SIM_CASE.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 237D, 220D);
			this.SIM_CASE.Name = "SIM_CASE";
			this.SIM_CASE.SecurityToken = ((uint)(4294967295u));
			this.SIM_CASE.TagName = "SIM_CASE";
			this.SIM_CASE.Val = ((short)(0));
			this.SIM_CASE.ValMaximum = ((short)(0));
			this.SIM_CASE.ValMinimum = ((short)(0));
			this.SIM_CASE.ValUnits = null;
			this.SIM_CASE.EndInit();
			// 
			// SIM_EN
			// 
			this.SIM_EN.BeginInit();
			this.SIM_EN.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 208D, 289D);
			this.SIM_EN.Name = "SIM_EN";
			this.SIM_EN.SecurityToken = ((uint)(4294967295u));
			this.SIM_EN.TagName = "SIM_EN";
			this.SIM_EN.Val = false;
			this.SIM_EN.EndInit();
			// 
			// sControl
			// 
			this.AnchorPoint = new NxtControl.Drawing.PointF(0D, 1D);
			this.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 0D, 1D);
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.groupMode0,
			this.groupMode1,
			this.groupMode2,
			this.groupMode3,
			this.groupMode4,
			this.groupMode5,
			this.groupMode6,
			this.groupMode7,
			this.SIM_CASE,
			this.SIM_EN});
			this.SymbolSize = new System.Drawing.Size(607, 613);

		}

		private NxtControl.GuiFramework.RoundedRectangle btnMode0;
		private NxtControl.GuiFramework.RoundedRectangle iconMode0;
		private NxtControl.GuiFramework.Label lblMode0;
		private NxtControl.GuiFramework.Group groupMode0;

		private NxtControl.GuiFramework.RoundedRectangle btnMode1;
		private NxtControl.GuiFramework.RoundedRectangle iconMode1;
		private NxtControl.GuiFramework.Label lblMode1;
		private NxtControl.GuiFramework.Group groupMode1;

		private NxtControl.GuiFramework.RoundedRectangle btnMode2;
		private NxtControl.GuiFramework.RoundedRectangle iconMode2;
		private NxtControl.GuiFramework.Label lblMode2;
		private NxtControl.GuiFramework.Group groupMode2;

		private NxtControl.GuiFramework.RoundedRectangle btnMode3;
		private NxtControl.GuiFramework.RoundedRectangle iconMode3;
		private NxtControl.GuiFramework.Label lblMode3;
		private NxtControl.GuiFramework.Group groupMode3;

		private NxtControl.GuiFramework.RoundedRectangle btnMode4;
		private NxtControl.GuiFramework.RoundedRectangle iconMode4;
		private NxtControl.GuiFramework.Label lblMode4;
		private NxtControl.GuiFramework.Group groupMode4;

		private NxtControl.GuiFramework.RoundedRectangle btnMode5;
		private NxtControl.GuiFramework.RoundedRectangle iconMode5;
		private NxtControl.GuiFramework.Label lblMode5;
		private NxtControl.GuiFramework.Group groupMode5;

		private NxtControl.GuiFramework.RoundedRectangle btnMode6;
		private NxtControl.GuiFramework.RoundedRectangle iconMode6;
		private NxtControl.GuiFramework.Label lblMode6;
		private NxtControl.GuiFramework.Group groupMode6;

		private NxtControl.GuiFramework.RoundedRectangle btnMode7;
		private NxtControl.GuiFramework.RoundedRectangle iconMode7;
		private NxtControl.GuiFramework.Label lblMode7;
		private NxtControl.GuiFramework.Group groupMode7;
		private SE.Agile.Symbols.HMI_Control_Integer_v1_0.sValChanged SIM_CASE;
		private SE.Agile.Symbols.HMI_Control_Bool_v1_0.sValChanged SIM_EN;

		#endregion
	}
}