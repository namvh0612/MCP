/*
 * Created by EcoStruxure Automation Expert.
 * Date: 7/26/2026
 */

using System;
using NxtControl.GuiFramework;
using HMI.Main.SupportClasses;

namespace HMI.Main.Symbols.acSimLogic_v1_0
{
	public partial class sSimulation : HMISymbol
	{
		private bool _isReady;
		private bool _simEnabled;
		private bool _isHovered;

		public sSimulation()
		{
			try
			{
				InitializeComponent();
				InitializeControl();
			}
			catch (Exception exception)
			{
				LogError(
					"Initialize sSimulation",
					exception);
			}
		}

		private void InitializeControl()
		{
			if (SIM_EN == null ||
				btnSim == null)
			{
				LogError(
					"Initialize controls",
					new InvalidOperationException(
						"SIM_EN or btnSim is missing."));

				return;
			}

			SIM_EN.OnValChanged -=
				OnSimulationValueChanged;

			SIM_EN.OnValChanged +=
				OnSimulationValueChanged;

			_isReady = true;
			_simEnabled = SIM_EN.Val;

			UpdateVisual();
		}

		private void OnSimulationValueChanged(
			object sender,
			EventArgs e)
		{
			if (!_isReady)
				return;

			_simEnabled = SIM_EN.Val;
			UpdateVisual();
		}

		private void UpdateVisual()
		{
			if (!_isReady ||
				btnSim == null)
			{
				return;
			}

			btnSim.Text = "SIMULATION";

			if (_simEnabled)
			{
				btnSim.BrushColor =
					SolarTheme.Surface.Selected;

				btnSim.PenColor =
					SolarTheme.Border.Selected;

				btnSim.PenWidth =
					_isHovered
						? SolarTheme.Pen.Selected
						: SolarTheme.Pen.Status;

				btnSim.TextColor =
					SolarTheme.Text.Primary;

				return;
			}

			if (_isHovered)
			{
				btnSim.BrushColor =
					SolarTheme.Surface.Hover;

				btnSim.PenColor =
					SolarTheme.Border.Hover;

				btnSim.PenWidth =
					SolarTheme.Pen.Panel;

				btnSim.TextColor =
					SolarTheme.Text.Primary;

				return;
			}

			btnSim.BrushColor =
				SolarTheme.Surface.Panel;

			btnSim.PenColor =
				SolarTheme.Border.Normal;

			btnSim.PenWidth =
				SolarTheme.Pen.Normal;

			btnSim.TextColor =
				SolarTheme.Text.Secondary;
		}

		void BtnSimMouseEnter(
			object sender,
			EventArgs e)
		{
			if (!_isReady)
				return;

			_isHovered = true;
			UpdateVisual();
		}

		void BtnSimMouseLeave(
			object sender,
			EventArgs e)
		{
			if (!_isReady)
				return;

			_isHovered = false;
			UpdateVisual();
		}

		void SSimulationMouseLeave(
			object sender,
			EventArgs e)
		{
			if (!_isReady)
				return;

			_isHovered = false;
			UpdateVisual();
		}

		void BtnSimClick(
			object sender,
			EventArgs e)
		{
			if (!_isReady)
				return;

			bool requestedState =
				!_simEnabled;

			_simEnabled =
				requestedState;

			UpdateVisual();

			try
			{
				SIM_EN.FireEvent_CNF(
					requestedState);
			}
			catch (Exception exception)
			{
				_simEnabled = SIM_EN.Val;
				UpdateVisual();

				LogError(
					"Change simulation state",
					exception);
			}
		}

		private void LogError(
			string operation,
			Exception exception)
		{
			try
			{
				NxtControl.Services.LoggingService
					.ErrorFormatted(
						"acSimLogic sSimulation: {0}. "
						+ "Error: {1}. Stack: {2}",
						operation,
						exception != null
							? exception.Message
							: "Unknown error",
						exception != null
							? exception.StackTrace
							: string.Empty);
			}
			catch
			{
				// Prevent logging failure from crashing HMI.
			}
		}
	}
}