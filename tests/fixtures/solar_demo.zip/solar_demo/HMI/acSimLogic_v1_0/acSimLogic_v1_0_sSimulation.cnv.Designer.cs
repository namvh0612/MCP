/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/26/2026
 * Time: 2:51 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.acSimLogic_v1_0
{
	/// <summary>
	/// Summary description for sSimulation.
	/// </summary>
	partial class sSimulation
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnSim = new NxtControl.GuiFramework.RoundedRectangle();
			this.SIM_EN = new SE.Agile.Symbols.HMI_Control_Bool_v1_0.sValChanged();
			// 
			// btnSim
			// 
			this.btnSim.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(108D)), ((float)(25D)));
			this.btnSim.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(5)), ((byte)(22)), ((byte)(21))));
			this.btnSim.Font = new NxtControl.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular);
			this.btnSim.Name = "btnSim";
			this.btnSim.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(37)), ((byte)(64)), ((byte)(61))), 1F, NxtControl.Drawing.DashStyle.Solid);
			this.btnSim.Text = "SIMULATION";
			this.btnSim.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleCenter;
			this.btnSim.TextColor = new NxtControl.Drawing.Color(((byte)(130)), ((byte)(130)), ((byte)(130)));
			this.btnSim.MouseEnter += new System.EventHandler(this.BtnSimMouseEnter);
			this.btnSim.MouseLeave += new System.EventHandler(this.BtnSimMouseLeave);
			this.btnSim.Click += new System.EventHandler(this.BtnSimClick);
			// 
			// SIM_EN
			// 
			this.SIM_EN.BeginInit();
			this.SIM_EN.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 35D, 60D);
			this.SIM_EN.Name = "SIM_EN";
			this.SIM_EN.SecurityToken = ((uint)(4294967295u));
			this.SIM_EN.TagName = "SIM_EN";
			this.SIM_EN.Val = false;
			this.SIM_EN.EndInit();
			// 
			// sSimulation
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.btnSim,
			this.SIM_EN});
			this.SymbolSize = new System.Drawing.Size(168, 88);

		}
		private NxtControl.GuiFramework.RoundedRectangle btnSim;
		private SE.Agile.Symbols.HMI_Control_Bool_v1_0.sValChanged SIM_EN;
		#endregion
	}
}
