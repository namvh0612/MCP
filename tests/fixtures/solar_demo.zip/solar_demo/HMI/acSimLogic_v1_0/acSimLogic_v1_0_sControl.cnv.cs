/*
 * Created by EcoStruxure Automation Expert.
 * Date: 7/24/2026
 */

using System;
using NxtControl.GuiFramework;
using HMI.Main.SupportClasses;

using GuiGroup =
	NxtControl.GuiFramework.Group;

using GuiRectangle =
	NxtControl.GuiFramework.RoundedRectangle;

using GuiLabel =
	NxtControl.GuiFramework.Label;

using GuiColor =
	NxtControl.Drawing.Color;

namespace HMI.Main.Symbols.acSimLogic_v1_0
{
	public partial class sControl : HMISymbol
	{
		
		private const double ICON_BRUSH_MIX = 0.08;
		private const double ICON_PEN_MIX = 0.18;
		private const double ICON_SELECTED_BRUSH_MIX = 0.10;
		private const double ICON_SELECTED_PEN_MIX = 0.22;
		private const double ICON_HOVER_BRUSH_MIX = 0.12;
		private const double ICON_HOVER_PEN_MIX = 0.26;
		
		private bool _isReady;
		private bool _simEnabled;
		private short _simMode;

		private GuiGroup _hoveredModeGroup;

		private GuiGroup[] _modeGroups;
		private GuiRectangle[] _modeButtons;
		private GuiRectangle[] _modeIcons;
		private GuiLabel[] _modeLabels;

		/*
		 * Button mapping:
		 *
		 * Mode 0 = Normal
		 * Mode 1 = Cloudy
		 * Mode 2 = BESS Charge
		 * Mode 3 = BESS Discharge
		 * Mode 4 = Curtailment
		 * Mode 5 = Grid Disconnect
		 * Mode 6 = Inverter Trip
		 * Mode 7 = Communication Loss
		 */
		private readonly short[] _modeValues =
		{
			0,
			1,
			4,
			5,
			2,
			7,
			9,
			14
		};

		public sControl()
		{
			try
			{
				InitializeComponent();
				InitializeControls();
			}
			catch (Exception exception)
			{
				LogError(
					"Initialize sControl",
					exception);
			}
		}

		private void InitializeControls()
		{
			_modeGroups = new GuiGroup[]
			{
				groupMode0,
				groupMode1,
				groupMode2,
				groupMode3,
				groupMode4,
				groupMode5,
				groupMode6,
				groupMode7
			};

			_modeButtons = new GuiRectangle[]
			{
				btnMode0,
				btnMode1,
				btnMode2,
				btnMode3,
				btnMode4,
				btnMode5,
				btnMode6,
				btnMode7
			};

			_modeIcons = new GuiRectangle[]
			{
				iconMode0,
				iconMode1,
				iconMode2,
				iconMode3,
				iconMode4,
				iconMode5,
				iconMode6,
				iconMode7
			};

			_modeLabels = new GuiLabel[]
			{
				lblMode0,
				lblMode1,
				lblMode2,
				lblMode3,
				lblMode4,
				lblMode5,
				lblMode6,
				lblMode7
			};

			if (!ValidateControls())
			{
				LogError(
					"Initialize controls",
					new InvalidOperationException(
						"One or more HMI controls are missing."));

				return;
			}

			AttachEvents();

			_isReady = true;

			ReadCurrentValues();
			UpdateDisplay();
		}

		private bool ValidateControls()
		{
			if (SIM_EN == null ||
				SIM_CASE == null)
			{
				return false;
			}

			if (_modeGroups == null ||
				_modeButtons == null ||
				_modeIcons == null ||
				_modeLabels == null)
			{
				return false;
			}

			if (_modeGroups.Length !=
					_modeValues.Length ||
				_modeButtons.Length !=
					_modeValues.Length ||
				_modeIcons.Length !=
					_modeValues.Length ||
				_modeLabels.Length !=
					_modeValues.Length)
			{
				return false;
			}

			for (int i = 0;
				i < _modeValues.Length;
				i++)
			{
				if (_modeGroups[i] == null ||
					_modeButtons[i] == null ||
					_modeIcons[i] == null ||
					_modeLabels[i] == null)
				{
					return false;
				}
			}

			return true;
		}

		private void AttachEvents()
		{
			SIM_EN.OnValChanged -=
				OnValueChanged;

			SIM_CASE.OnValChanged -=
				OnValueChanged;

			SIM_EN.OnValChanged +=
				OnValueChanged;

			SIM_CASE.OnValChanged +=
				OnValueChanged;

			for (int i = 0;
				i < _modeGroups.Length;
				i++)
			{
				GuiGroup group =
					_modeGroups[i];

				group.Click -=
					ModeGroupClick;

				group.MouseEnter -=
					ModeGroupMouseEnter;

				group.MouseLeave -=
					ModeGroupMouseLeave;

				group.Click +=
					ModeGroupClick;

				group.MouseEnter +=
					ModeGroupMouseEnter;

				group.MouseLeave +=
					ModeGroupMouseLeave;
			}
		}

		private void OnValueChanged(
			object sender,
			EventArgs e)
		{
			ExecuteSafe(
				"Read HMI values",
				delegate
				{
					ReadCurrentValues();
					UpdateDisplay();
				});
		}

		private void ReadCurrentValues()
		{
			if (!_isReady)
				return;

			_simEnabled =
				SIM_EN.Val;

			short receivedMode =
				SIM_CASE.Val;

			if (IsValidMode(receivedMode))
			{
				_simMode =
					receivedMode;
			}
			else
			{
				_simMode = 0;
			}
		}

		private bool IsValidMode(
			short mode)
		{
			return Array.IndexOf(
				_modeValues,
				mode) >= 0;
		}

		private void UpdateDisplay()
		{
			if (!_isReady)
				return;

			UpdateModeVisuals();
		}

		private void UpdateRadioMode(
			short mode)
		{
			if (!_isReady ||
				!_simEnabled ||
				!IsValidMode(mode))
			{
				return;
			}

			_simMode = mode;

			UpdateModeVisuals();

			SIM_CASE.FireEvent_CNF(
				mode);
		}

		private void UpdateModeVisuals()
		{
			if (!_isReady)
				return;

			for (int i = 0;
				i < _modeValues.Length;
				i++)
			{
				bool isSelected =
					_modeValues[i] ==
					_simMode;

				bool isHovered =
					object.ReferenceEquals(
						_modeGroups[i],
						_hoveredModeGroup);

				SetModeVisual(
					_modeButtons[i],
					_modeIcons[i],
					_modeLabels[i],
					_modeValues[i],
					_simEnabled,
					isSelected,
					isHovered);
			}
		}

		private void SetModeVisual(
			GuiRectangle button,
			GuiRectangle icon,
			GuiLabel label,
			short mode,
			bool isEnabled,
			bool isSelected,
			bool isHovered)
		{
			if (button == null ||
				icon == null ||
				label == null)
			{
				return;
			}

			/*
			 * Disabled has highest priority.
			 */
			if (!isEnabled)
			{
				ApplyVisual(
					button,
					SolarTheme.Surface.Disabled,
					SolarTheme.Border.Disabled,
					SolarTheme.Pen.Normal);

				SetIconVisual(
					icon,
					SolarTheme.Surface.Disabled,
					isEnabled,
					isSelected,
					isHovered);

				label.TextColor =
					SolarTheme.Text.Muted;

				return;
			}

			label.TextColor =
				SolarTheme.Text.Primary;

			/*
			 * Selected scenario.
			 */
			if (isSelected)
			{
				GuiColor selectedBrush =
					GetSelectedBrush(mode);

				GuiColor selectedPen =
					GetSelectedPen(mode);

				ApplyVisual(
					button,
					selectedBrush,
					selectedPen,
					SolarTheme.Pen.Selected);

				SetIconVisual(
					icon,
					selectedBrush,
					isEnabled,
					isSelected,
					isHovered);

				return;
			}

			/*
			 * Hovered scenario.
			 */
			if (isHovered)
			{
				ApplyVisual(
					button,
					SolarTheme.Surface.Hover,
					SolarTheme.Border.Hover,
					SolarTheme.Pen.Panel);

				SetIconVisual(
					icon,
					SolarTheme.Surface.Hover,
					isEnabled,
					isSelected,
					isHovered);

				return;
			}

			/*
			 * Default scenario.
			 */
			ApplyVisual(
				button,
				SolarTheme.Surface.RaisedPanel,
				SolarTheme.Border.Normal,
				SolarTheme.Pen.Normal);

			SetIconVisual(
				icon,
				SolarTheme.Surface.RaisedPanel,
				isEnabled,
				isSelected,
				isHovered);
		}

		private GuiColor GetSelectedBrush(
			short mode)
		{
			switch (mode)
			{
				/*
				 * Cloudy.
				 */
				case 1:
					return SolarTheme.Surface.Warning;

				/*
				 * BESS Discharge.
				 */
				case 5:
					return SolarTheme.Surface.Warning;

				/*
				 * Curtailment.
				 */
				case 2:
					return SolarTheme.Surface.Warning;

				/*
				 * Grid Disconnect,
				 * Inverter Trip,
				 * Communication Loss.
				 */
				case 7:
				case 9:
				case 14:
					return SolarTheme.Surface.Fault;

				/*
				 * Normal and BESS Charge.
				 */
				default:
					return SolarTheme.Surface.Selected;
			}
		}

		private GuiColor GetSelectedPen(
			short mode)
		{
			switch (mode)
			{
				/*
				 * Cloudy: yellow.
				 */
				case 1:
					return SolarTheme.Status.Warning;

				/*
				 * BESS Discharge: orange.
				 */
				case 5:
					return SolarTheme.Flow.AcPower;

				/*
				 * Curtailment: orange.
				 */
				case 2:
					return SolarTheme.Flow.AcPower;

				/*
				 * Fault scenarios: red.
				 */
				case 7:
				case 9:
				case 14:
					return SolarTheme.Status.Fault;

				/*
				 * Normal and BESS Charge: green.
				 */
				default:
					return SolarTheme.Border.Selected;
			}
		}

		private void ApplyVisual(
			GuiRectangle shape,
			GuiColor brushColor,
			GuiColor penColor,
			float penWidth)
		{
			if (shape == null)
				return;

			shape.BrushColor =
				brushColor;

			shape.PenColor =
				penColor;

			shape.PenWidth =
				penWidth;
		}
		
		private void SetIconVisual(
			GuiRectangle icon,
			GuiColor buttonBrush,
			bool isEnabled,
			bool isSelected,
			bool isHovered)
		{
			if (icon == null)
				return;
		
			if (!isEnabled)
			{
				icon.BrushColor =
					SolarTheme.Surface.Disabled;
		
				icon.PenColor =
					SolarTheme.Border.Disabled;
		
				icon.PenWidth =
					SolarTheme.Pen.Normal;
		
				return;
			}
		
			double brushMix =
				isHovered
					? ICON_HOVER_BRUSH_MIX
					: isSelected
						? ICON_SELECTED_BRUSH_MIX
						: ICON_BRUSH_MIX;
		
			double penMix =
				isHovered
					? ICON_HOVER_PEN_MIX
					: isSelected
						? ICON_SELECTED_PEN_MIX
						: ICON_PEN_MIX;
		
			icon.BrushColor =
				MixColor(
					buttonBrush,
					SolarTheme.Text.Primary,
					brushMix);
		
			icon.PenColor =
				MixColor(
					buttonBrush,
					SolarTheme.Text.Primary,
					penMix);
		
			icon.PenWidth =
				SolarTheme.Pen.Normal;
		}
		
		private GuiColor MixColor(
			GuiColor source,
			GuiColor target,
			double ratio)
		{
			if (ratio < 0.0)
				ratio = 0.0;
		
			if (ratio > 1.0)
				ratio = 1.0;
		
			return new GuiColor(
				MixChannel(source.R, target.R, ratio),
				MixChannel(source.G, target.G, ratio),
				MixChannel(source.B, target.B, ratio));
		}
		
		private byte MixChannel(
			byte source,
			byte target,
			double ratio)
		{
			double value =
				source +
				((target - source) * ratio);
		
			if (value < 0.0)
				value = 0.0;
		
			if (value > 255.0)
				value = 255.0;
		
			return Convert.ToByte(value);
		}

		private short GetGroupMode(
			GuiGroup selectedGroup)
		{
			if (selectedGroup == null)
				return -1;

			for (int i = 0;
				i < _modeGroups.Length;
				i++)
			{
				if (object.ReferenceEquals(
					_modeGroups[i],
					selectedGroup))
				{
					return _modeValues[i];
				}
			}

			return -1;
		}

		private void ModeGroupClick(
			object sender,
			EventArgs e)
		{
			ExecuteSafe(
				"Mode group click",
				delegate
				{
					if (!_simEnabled)
						return;

					GuiGroup selectedGroup =
						sender as GuiGroup;

					short selectedMode =
						GetGroupMode(
							selectedGroup);

					if (selectedMode < 0)
						return;

					/*
					 * Clicking the active scenario
					 * returns the system to Mode 0.
					 *
					 * Clicking Mode 0 keeps Mode 0.
					 */
					short targetMode =
						selectedMode != 0 &&
						_simMode == selectedMode
							? (short)0
							: selectedMode;

					UpdateRadioMode(
						targetMode);
				});
		}

		private void ModeGroupMouseEnter(
			object sender,
			EventArgs e)
		{
			ExecuteSafe(
				"Mode group mouse enter",
				delegate
				{
					_hoveredModeGroup =
						sender as GuiGroup;

					UpdateModeVisuals();
				});
		}

		private void ModeGroupMouseLeave(
			object sender,
			EventArgs e)
		{
			ExecuteSafe(
				"Mode group mouse leave",
				delegate
				{
					GuiGroup selectedGroup =
						sender as GuiGroup;

					if (object.ReferenceEquals(
						_hoveredModeGroup,
						selectedGroup))
					{
						_hoveredModeGroup = null;
					}

					UpdateModeVisuals();
				});
		}

		private void ExecuteSafe(
			string operation,
			Action action)
		{
			if (!_isReady ||
				action == null)
			{
				return;
			}

			try
			{
				action();
			}
			catch (Exception exception)
			{
				LogError(
					operation,
					exception);
			}
		}

		private void LogError(
			string operation,
			Exception exception)
		{
			try
			{
				NxtControl.Services.LoggingService
					.ErrorFormatted(
						"acSimLogic sControl: {0}. "
						+ "Error: {1}. Stack: {2}",
						operation,
						exception != null
							? exception.Message
							: "Unknown error",
						exception != null
							? exception.StackTrace
							: string.Empty);
			}
			catch
			{
				// Prevent logging failure from crashing HMI.
			}
		}
	}
}