/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/13/2026
 * Time: 4:18 PM
 */

using System;
using NxtControl.GuiFramework;
using HMI.Main.SupportClasses;

namespace HMI.Main.Symbols.acTransformer_v1_0
{
	public partial class sDefault :
		NxtControl.GuiFramework.HMISymbol
	{
		private bool _isRectBtnHovered;

		private SolarTheme.EquipmentState _currentStatus =
			SolarTheme.EquipmentState.Offline;

		public sDefault()
		{
			InitializeComponent();
			AttachEvents();
			UpdateDisplay();
		}

		private void AttachEvents()
		{
			REQ_Fired += REQ_Fired_EventHandler;

			IAVL.OnValChanged += OnTransformerValueChanged;
			IALM.OnValChanged += OnTransformerValueChanged;
			IFLT.OnValChanged += OnTransformerValueChanged;
			QLT.OnValChanged += OnTransformerValueChanged;

			VLV.OnValChanged += OnTransformerValueChanged;
			VMV.OnValChanged += OnTransformerValueChanged;
			LOAD.OnValChanged += OnTransformerValueChanged;

			TOIL.OnValChanged += OnTransformerValueChanged;
			TWND.OnValChanged += OnTransformerValueChanged;
		}

		private void OnTransformerValueChanged(
			object sender,
			EventArgs e)
		{
			UpdateDisplay();
		}

		private void UpdateDisplay()
		{
			bool hasValidQuality =
				HmiValueHelper.ToBool(QLT.Val);

			_currentStatus =
				SolarStatusHelper.ResolveStandard(
					QLT.Val,
					IFLT.Val,
					IALM.Val,
					IAVL.Val,
					SolarTheme.EquipmentState.Running,
					SolarTheme.EquipmentState.Standby);

			HmiDisplayHelper.DisplayData displayData =
				new HmiDisplayHelper.DisplayData();

			displayData.Status = _currentStatus;
			displayData.StatusText =
				SolarStatusHelper.GetStatusText(
					_currentStatus);

			displayData.StatusLabel = txtStatus;
			displayData.StatusIndicator = indStatus;
			displayData.CardBorder = rectBtn;
			displayData.CardBackground = rectBase;
			displayData.IsHovered = _isRectBtnHovered;

			displayData.Items =
				hasValidQuality
					? CreateValidMeasurementItems()
					: CreateInvalidMeasurementItems();

			HmiDisplayHelper.Apply(displayData);
		}

		private HmiDisplayHelper.DisplayItem[]
			CreateValidMeasurementItems()
		{
			return new HmiDisplayHelper.DisplayItem[]
			{
				HmiDisplayHelper.CreateText(
					txtVR,
					FormatVoltageRatio(
						VLV.Val,
						VMV.Val),
					SolarTheme.Text.Primary),

				HmiDisplayHelper.CreateValue(
					txtLOAD,
					LOAD.Val,
					"0.0",
					" %",
					SolarTheme.Text.Primary),

				HmiDisplayHelper.CreateValue(
					txtTOIL,
					TOIL.Val,
					"0.0",
					" °C",
					SolarTheme.Text.Primary),

				HmiDisplayHelper.CreateValue(
					txtTWND,
					TWND.Val,
					"0.0",
					" °C",
					SolarTheme.Text.Primary)
			};
		}

		private HmiDisplayHelper.DisplayItem[]
			CreateInvalidMeasurementItems()
		{
			return new HmiDisplayHelper.DisplayItem[]
			{
				HmiDisplayHelper.CreateText(
					txtVR,
					"-- / --",
					SolarTheme.Status.Offline),

				HmiDisplayHelper.CreateText(
					txtLOAD,
					"-- %",
					SolarTheme.Status.Offline),

				HmiDisplayHelper.CreateText(
					txtTOIL,
					"-- °C",
					SolarTheme.Status.Offline),

				HmiDisplayHelper.CreateText(
					txtTWND,
					"-- °C",
					SolarTheme.Status.Offline)
			};
		}

		private string FormatVoltageRatio(
			object lowVoltageValue,
			object mediumVoltageValue)
		{
			double lowVoltage =
				HmiValueHelper.ToDouble(
					lowVoltageValue);

			double mediumVoltage =
				HmiValueHelper.ToDouble(
					mediumVoltageValue);

			if (lowVoltage <= 0.0 ||
				mediumVoltage <= 0.0)
			{
				return "-- / --";
			}

			double lowVoltageKv =
				lowVoltage / 1000.0;

			double mediumVoltageKv =
				mediumVoltage / 1000.0;

			return lowVoltageKv.ToString("0.0")
				+ " / "
				+ mediumVoltageKv.ToString("0.#")
				+ " kV";
		}

		private void UpdateCardVisual()
		{
			HmiDisplayHelper.ApplyStatusCard(
				rectBtn,
				rectBase,
				_currentStatus,
				_isRectBtnHovered);
		}

		private void RectBtnMouseEnter(
			object sender,
			EventArgs e)
		{
			_isRectBtnHovered = true;
			UpdateCardVisual();
		}

		private void RectBtnMouseLeave(
			object sender,
			EventArgs e)
		{
			_isRectBtnHovered = false;
			UpdateCardVisual();
		}

		private void REQ_Fired_EventHandler(
			object sender,
			REQEventArgs e)
		{
			lblSymbol.Text =
				HmiValueHelper.SafeText(
					e.AssetName,
					"Transformer");
		}
	}
}