/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/13/2026
 * Time: 4:18 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.acTransformer_v1_0
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sDefault
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(sDefault));
			this.rectangle1 = new NxtControl.GuiFramework.Rectangle();
			this.lblSymbol = new NxtControl.GuiFramework.Label();
			this.txtStatus = new NxtControl.GuiFramework.Label();
			this.indStatus = new NxtControl.GuiFramework.Ellipse();
			this.rectBtn = new NxtControl.GuiFramework.RoundedRectangle();
			this.txtVR = new NxtControl.GuiFramework.Label();
			this.freeText4 = new NxtControl.GuiFramework.FreeText();
			this.txtLOAD = new NxtControl.GuiFramework.Label();
			this.freeText5 = new NxtControl.GuiFramework.FreeText();
			this.txtTOIL = new NxtControl.GuiFramework.Label();
			this.freeText6 = new NxtControl.GuiFramework.FreeText();
			this.txtTWND = new NxtControl.GuiFramework.Label();
			this.freeText12 = new NxtControl.GuiFramework.FreeText();
			this.rectBase = new NxtControl.GuiFramework.RoundedRectangle();
			this.IALM = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IAVL = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IFLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.QLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.LOAD = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.VMV = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.TOIL = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.TWND = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.VLV = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.line1 = new NxtControl.GuiFramework.Line();
			this.line2 = new NxtControl.GuiFramework.Line();
			this.line3 = new NxtControl.GuiFramework.Line();
			this.line4 = new NxtControl.GuiFramework.Line();
			// 
			// rectangle1
			// 
			this.rectangle1.Bounds = new NxtControl.Drawing.RectF(((float)(10D)), ((float)(45D)), ((float)(220D)), ((float)(220D)));
			this.rectangle1.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle1.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle1.ImageBytes = resources.GetString("rectangle1.ImageBytes");
			this.rectangle1.Name = "rectangle1";
			this.rectangle1.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// lblSymbol
			// 
			this.lblSymbol.AngleIgnore = true;
			this.lblSymbol.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.lblSymbol.Bounds = new NxtControl.Drawing.RectF(((float)(11D)), ((float)(12D)), ((float)(141D)), ((float)(24D)));
			this.lblSymbol.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.lblSymbol.Font = new NxtControl.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
			this.lblSymbol.FontScale = true;
			this.lblSymbol.Name = "lblSymbol";
			this.lblSymbol.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.lblSymbol.Text = "Transformer";
			this.lblSymbol.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.lblSymbol.TextAutoSizeHorizontalOffset = 10;
			this.lblSymbol.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.lblSymbol.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// txtStatus
			// 
			this.txtStatus.AngleIgnore = true;
			this.txtStatus.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtStatus.Bounds = new NxtControl.Drawing.RectF(((float)(167D)), ((float)(16D)), ((float)(65D)), ((float)(16D)));
			this.txtStatus.Brush = new NxtControl.Drawing.Brush(true);
			this.txtStatus.Font = new NxtControl.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular);
			this.txtStatus.FontScale = true;
			this.txtStatus.Name = "txtStatus";
			this.txtStatus.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtStatus.Text = "Running";
			this.txtStatus.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.txtStatus.TextAutoSizeHorizontalOffset = 10;
			this.txtStatus.TextColor = new NxtControl.Drawing.Color(((byte)(120)), ((byte)(249)), ((byte)(141)));
			this.txtStatus.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// indStatus
			// 
			this.indStatus.Bounds = new NxtControl.Drawing.RectF(((float)(155D)), ((float)(19D)), ((float)(10D)), ((float)(10D)));
			this.indStatus.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(120)), ((byte)(249)), ((byte)(141))));
			this.indStatus.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.indStatus.Name = "indStatus";
			this.indStatus.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectBtn
			// 
			this.rectBtn.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(240D)), ((float)(412D)));
			this.rectBtn.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("Transparent"));
			this.rectBtn.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectBtn.Name = "rectBtn";
			this.rectBtn.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fMain", NxtControl.GuiFramework.MouseButtonType.Click));
			this.rectBtn.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(28)), ((byte)(78)), ((byte)(71))), 1F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Flat, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Round, null);
			this.rectBtn.Radius = 10D;
			this.rectBtn.MouseEnter += new System.EventHandler(this.RectBtnMouseEnter);
			this.rectBtn.MouseLeave += new System.EventHandler(this.RectBtnMouseLeave);
			// 
			// txtVR
			// 
			this.txtVR.AngleIgnore = true;
			this.txtVR.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtVR.Bounds = new NxtControl.Drawing.RectF(((float)(131D)), ((float)(287D)), ((float)(96D)), ((float)(20D)));
			this.txtVR.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtVR.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtVR.FontScale = true;
			this.txtVR.Name = "txtVR";
			this.txtVR.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtVR.Text = "0.4/11 kV";
			this.txtVR.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtVR.TextAutoSizeHorizontalOffset = 10;
			this.txtVR.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtVR.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText4
			// 
			this.freeText4.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText4.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText4.Location = new NxtControl.Drawing.PointF(11D, 288D);
			this.freeText4.Name = "freeText4";
			this.freeText4.Text = "Voltage Ratio";
			// 
			// txtLOAD
			// 
			this.txtLOAD.AngleIgnore = true;
			this.txtLOAD.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtLOAD.Bounds = new NxtControl.Drawing.RectF(((float)(131D)), ((float)(319D)), ((float)(96D)), ((float)(20D)));
			this.txtLOAD.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtLOAD.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtLOAD.FontScale = true;
			this.txtLOAD.Name = "txtLOAD";
			this.txtLOAD.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtLOAD.Text = "72.4 %";
			this.txtLOAD.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtLOAD.TextAutoSizeHorizontalOffset = 10;
			this.txtLOAD.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtLOAD.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText5
			// 
			this.freeText5.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText5.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText5.Location = new NxtControl.Drawing.PointF(11D, 320D);
			this.freeText5.Name = "freeText5";
			this.freeText5.Text = "Load Level";
			// 
			// txtTOIL
			// 
			this.txtTOIL.AngleIgnore = true;
			this.txtTOIL.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtTOIL.Bounds = new NxtControl.Drawing.RectF(((float)(131D)), ((float)(351D)), ((float)(96D)), ((float)(20D)));
			this.txtTOIL.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtTOIL.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtTOIL.FontScale = true;
			this.txtTOIL.Name = "txtTOIL";
			this.txtTOIL.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtTOIL.Text = "62.3 °C";
			this.txtTOIL.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtTOIL.TextAutoSizeHorizontalOffset = 10;
			this.txtTOIL.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtTOIL.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText6
			// 
			this.freeText6.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText6.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText6.Location = new NxtControl.Drawing.PointF(11D, 352D);
			this.freeText6.Name = "freeText6";
			this.freeText6.Text = "Oil Temp.";
			// 
			// txtTWND
			// 
			this.txtTWND.AngleIgnore = true;
			this.txtTWND.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtTWND.Bounds = new NxtControl.Drawing.RectF(((float)(131D)), ((float)(382D)), ((float)(96D)), ((float)(20D)));
			this.txtTWND.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtTWND.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtTWND.FontScale = true;
			this.txtTWND.Name = "txtTWND";
			this.txtTWND.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtTWND.Text = "68.1 °C";
			this.txtTWND.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtTWND.TextAutoSizeHorizontalOffset = 10;
			this.txtTWND.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtTWND.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText12
			// 
			this.freeText12.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText12.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText12.Location = new NxtControl.Drawing.PointF(11D, 383D);
			this.freeText12.Name = "freeText12";
			this.freeText12.Text = "Winding Temp.";
			// 
			// rectBase
			// 
			this.rectBase.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(240D)), ((float)(412D)));
			this.rectBase.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(3)), ((byte)(22)), ((byte)(20))));
			this.rectBase.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectBase.Name = "rectBase";
			this.rectBase.Pen = new NxtControl.Drawing.Pen("Transparent");
			this.rectBase.Radius = 10D;
			// 
			// IALM
			// 
			this.IALM.BeginInit();
			this.IALM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 390D, 242D);
			this.IALM.Name = "IALM";
			this.IALM.SecurityToken = ((uint)(4294967295u));
			this.IALM.TagName = "IALM";
			this.IALM.Val = false;
			this.IALM.EndInit();
			// 
			// IAVL
			// 
			this.IAVL.BeginInit();
			this.IAVL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 336D, 264D);
			this.IAVL.Name = "IAVL";
			this.IAVL.SecurityToken = ((uint)(4294967295u));
			this.IAVL.TagName = "IAVL";
			this.IAVL.Val = false;
			this.IAVL.EndInit();
			// 
			// IFLT
			// 
			this.IFLT.BeginInit();
			this.IFLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 292D, 278D);
			this.IFLT.Name = "IFLT";
			this.IFLT.SecurityToken = ((uint)(4294967295u));
			this.IFLT.TagName = "IFLT";
			this.IFLT.Val = false;
			this.IFLT.EndInit();
			// 
			// QLT
			// 
			this.QLT.BeginInit();
			this.QLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 293D, 304D);
			this.QLT.Name = "QLT";
			this.QLT.SecurityToken = ((uint)(4294967295u));
			this.QLT.TagName = "QLT";
			this.QLT.Val = false;
			this.QLT.EndInit();
			// 
			// LOAD
			// 
			this.LOAD.BeginInit();
			this.LOAD.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 315D, 211D);
			this.LOAD.Name = "LOAD";
			this.LOAD.SecurityToken = ((uint)(4294967295u));
			this.LOAD.TagName = "LOAD";
			this.LOAD.Val = 0F;
			this.LOAD.ValDecimalPlaces = ((byte)(0));
			this.LOAD.ValMaximum = 0F;
			this.LOAD.ValMinimum = 0F;
			this.LOAD.ValUnits = null;
			this.LOAD.EndInit();
			// 
			// VMV
			// 
			this.VMV.BeginInit();
			this.VMV.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 116D, 276D);
			this.VMV.Name = "VMV";
			this.VMV.SecurityToken = ((uint)(4294967295u));
			this.VMV.TagName = "VMV";
			this.VMV.Val = 0F;
			this.VMV.ValDecimalPlaces = ((byte)(0));
			this.VMV.ValMaximum = 0F;
			this.VMV.ValMinimum = 0F;
			this.VMV.ValUnits = null;
			this.VMV.EndInit();
			// 
			// TOIL
			// 
			this.TOIL.BeginInit();
			this.TOIL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 106D, 255D);
			this.TOIL.Name = "TOIL";
			this.TOIL.SecurityToken = ((uint)(4294967295u));
			this.TOIL.TagName = "TOIL";
			this.TOIL.Val = 0F;
			this.TOIL.ValDecimalPlaces = ((byte)(0));
			this.TOIL.ValMaximum = 0F;
			this.TOIL.ValMinimum = 0F;
			this.TOIL.ValUnits = null;
			this.TOIL.EndInit();
			// 
			// TWND
			// 
			this.TWND.BeginInit();
			this.TWND.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 79D, 293D);
			this.TWND.Name = "TWND";
			this.TWND.SecurityToken = ((uint)(4294967295u));
			this.TWND.TagName = "TWND";
			this.TWND.Val = 0F;
			this.TWND.ValDecimalPlaces = ((byte)(0));
			this.TWND.ValMaximum = 0F;
			this.TWND.ValMinimum = 0F;
			this.TWND.ValUnits = null;
			this.TWND.EndInit();
			// 
			// VLV
			// 
			this.VLV.BeginInit();
			this.VLV.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 26D, 333D);
			this.VLV.Name = "VLV";
			this.VLV.SecurityToken = ((uint)(4294967295u));
			this.VLV.TagName = "VLV";
			this.VLV.Val = 0F;
			this.VLV.ValDecimalPlaces = ((byte)(0));
			this.VLV.ValMaximum = 0F;
			this.VLV.ValMinimum = 0F;
			this.VLV.ValUnits = null;
			this.VLV.EndInit();
			// 
			// line1
			// 
			this.line1.EndPoint = new NxtControl.Drawing.PointF(239D, 281D);
			this.line1.Name = "line1";
			this.line1.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(20)), ((byte)(54)), ((byte)(45))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line1.StartPoint = new NxtControl.Drawing.PointF(2D, 281D);
			// 
			// line2
			// 
			this.line2.EndPoint = new NxtControl.Drawing.PointF(239D, 313D);
			this.line2.Name = "line2";
			this.line2.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(20)), ((byte)(54)), ((byte)(45))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line2.StartPoint = new NxtControl.Drawing.PointF(2D, 313D);
			// 
			// line3
			// 
			this.line3.EndPoint = new NxtControl.Drawing.PointF(239D, 345D);
			this.line3.Name = "line3";
			this.line3.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(20)), ((byte)(54)), ((byte)(45))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line3.StartPoint = new NxtControl.Drawing.PointF(2D, 345D);
			// 
			// line4
			// 
			this.line4.EndPoint = new NxtControl.Drawing.PointF(239D, 376D);
			this.line4.Name = "line4";
			this.line4.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(20)), ((byte)(54)), ((byte)(45))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line4.StartPoint = new NxtControl.Drawing.PointF(2D, 376D);
			// 
			// sDefault
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.rectBase,
			this.rectangle1,
			this.lblSymbol,
			this.txtStatus,
			this.indStatus,
			this.txtVR,
			this.freeText4,
			this.txtLOAD,
			this.freeText5,
			this.txtTOIL,
			this.freeText6,
			this.txtTWND,
			this.freeText12,
			this.IALM,
			this.IAVL,
			this.IFLT,
			this.QLT,
			this.LOAD,
			this.VMV,
			this.TOIL,
			this.TWND,
			this.VLV,
			this.line1,
			this.line2,
			this.line3,
			this.line4,
			this.rectBtn});
			this.SymbolSize = new System.Drawing.Size(496, 456);

		}
		private NxtControl.GuiFramework.Rectangle rectangle1;
		private NxtControl.GuiFramework.Label lblSymbol;
		private NxtControl.GuiFramework.Label txtStatus;
		private NxtControl.GuiFramework.Ellipse indStatus;
		private NxtControl.GuiFramework.RoundedRectangle rectBtn;
		private NxtControl.GuiFramework.Label txtVR;
		private NxtControl.GuiFramework.FreeText freeText4;
		private NxtControl.GuiFramework.Label txtLOAD;
		private NxtControl.GuiFramework.FreeText freeText5;
		private NxtControl.GuiFramework.Label txtTOIL;
		private NxtControl.GuiFramework.FreeText freeText6;
		private NxtControl.GuiFramework.Label txtTWND;
		private NxtControl.GuiFramework.FreeText freeText12;
		private NxtControl.GuiFramework.RoundedRectangle rectBase;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IALM;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IAVL;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IFLT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged QLT;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged LOAD;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged VMV;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged TOIL;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged TWND;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged VLV;
		private NxtControl.GuiFramework.Line line1;
		private NxtControl.GuiFramework.Line line2;
		private NxtControl.GuiFramework.Line line3;
		private NxtControl.GuiFramework.Line line4;
		#endregion
	}
}