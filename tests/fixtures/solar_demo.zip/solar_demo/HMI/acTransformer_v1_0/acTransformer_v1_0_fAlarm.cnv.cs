/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/13/2026
 * Time: 8:42 PM
 */

using System;
using NxtControl.GuiFramework;
using HMI.Main.SupportClasses;

using GuiLabel =
	NxtControl.GuiFramework.Label;

namespace HMI.Main.Faceplates.acTransformer_v1_0
{
	public partial class fAlarm :
		NxtControl.GuiFramework.HMIFaceplate
	{
		private sealed class AlarmDefinition
		{
			public readonly int Bit;
			public readonly string Text;
			public readonly SolarTheme.EquipmentState Severity;
			public readonly GuiLabel Label;

			public AlarmDefinition(
				int bit,
				string text,
				SolarTheme.EquipmentState severity,
				GuiLabel label)
			{
				Bit = bit;
				Text = text;
				Severity = severity;
				Label = label;
			}
		}

		private AlarmDefinition[] _alarms;

		public fAlarm()
		{
			InitializeComponent();
			InitializeAlarms();
			AttachEvents();
			UpdateAlarmDisplay();
		}

		private void InitializeAlarms()
		{
			_alarms = new AlarmDefinition[]
			{
				new AlarmDefinition(
					0,
					"Communication / data quality lost",
					SolarTheme.EquipmentState.Fault,
					label1),

				new AlarmDefinition(
					1,
					"Transformer breaker open / trip",
					SolarTheme.EquipmentState.Fault,
					label2),

				new AlarmDefinition(
					2,
					"Transformer load above warning limit",
					SolarTheme.EquipmentState.Warning,
					label3),

				new AlarmDefinition(
					3,
					"Transformer severe overload",
					SolarTheme.EquipmentState.Fault,
					label4),

				new AlarmDefinition(
					4,
					"Oil temperature high",
					SolarTheme.EquipmentState.Warning,
					label5),

				new AlarmDefinition(
					5,
					"Winding overtemperature",
					SolarTheme.EquipmentState.Fault,
					label6),

				new AlarmDefinition(
					6,
					"LV voltage out of range",
					SolarTheme.EquipmentState.Fault,
					label7),

				new AlarmDefinition(
					7,
					"Transformer power loss high",
					SolarTheme.EquipmentState.Warning,
					label8)
			};
		}

		private void AttachEvents()
		{
			ALMW.OnValChanged += OnAlarmWordChanged;
			REQ_Fired += REQ_Fired_EventHandler;
		}

		private void OnAlarmWordChanged(
			object sender,
			EventArgs e)
		{
			UpdateAlarmDisplay();
		}

		private void UpdateAlarmDisplay()
		{
			int alarmWord =
				HmiValueHelper.ToInt(ALMW.Val);

			HmiDisplayHelper.DisplayItem[] displayItems =
				new HmiDisplayHelper.DisplayItem[
					_alarms.Length + 1];

			for (int i = 0; i < _alarms.Length; i++)
			{
				AlarmDefinition alarm =
					_alarms[i];

				bool isActive =
					IsBitSet(
						alarmWord,
						alarm.Bit);

				displayItems[i] =
					HmiDisplayHelper.CreateText(
						alarm.Label,
						alarm.Text,
						isActive
							? SolarTheme.GetStatusColor(
								alarm.Severity)
							: SolarTheme.Status.Offline);
			}

			HmiDisplayHelper.DisplayData displayData =
				new HmiDisplayHelper.DisplayData();

			displayData.Items = displayItems;

			HmiDisplayHelper.Apply(displayData);
		}

		private bool IsBitSet(
			int value,
			int bit)
		{
			if (bit < 0 || bit > 31)
				return false;

			return (value & (1 << bit)) != 0;
		}

		private void REQ_Fired_EventHandler(
			object sender,
			HMI.Main.Symbols.acTransformer_v1_0.REQEventArgs e)
		{
			Title =
				HmiValueHelper.SafeText(
					e.AssetName,
					"Transformer Alarms");
		}
	}
}