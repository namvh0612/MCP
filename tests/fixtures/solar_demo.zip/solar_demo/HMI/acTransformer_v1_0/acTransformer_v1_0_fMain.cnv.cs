/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/13/2026
 * Time: 7:44 PM
 */

using System;
using NxtControl.GuiFramework;
using HMI.Main.SupportClasses;

namespace HMI.Main.Faceplates.acTransformer_v1_0
{
	public partial class fMain :
		NxtControl.GuiFramework.HMIFaceplate
	{
		/*
		 * PFMV > 0: Lead
		 * PFMV < 0: Lag
		 */
		private const bool POSITIVE_PF_IS_LEADING = true;

		public fMain()
		{
			InitializeComponent();
			AttachEvents();
			UpdateDisplay();
		}

		private void AttachEvents()
		{
			REQ_Fired += REQ_Fired_EventHandler;

			IAVL.OnValChanged += OnTransformerValueChanged;
			IALM.OnValChanged += OnTransformerValueChanged;
			IFLT.OnValChanged += OnTransformerValueChanged;
			QLT.OnValChanged += OnTransformerValueChanged;

			OLALM.OnValChanged += OnTransformerValueChanged;
			TMPALM.OnValChanged += OnTransformerValueChanged;

			ILV.OnValChanged += OnTransformerValueChanged;
			IMV.OnValChanged += OnTransformerValueChanged;
			PFMV.OnValChanged += OnTransformerValueChanged;
		}

		private void OnTransformerValueChanged(
			object sender,
			EventArgs e)
		{
			UpdateDisplay();
		}

		private void UpdateDisplay()
		{
			bool hasValidQuality =
				HmiValueHelper.ToBool(QLT.Val);

			SolarTheme.EquipmentState status =
				ResolveStatus();

			HmiDisplayHelper.DisplayData displayData =
				new HmiDisplayHelper.DisplayData();

			displayData.Status = status;
			displayData.StatusText =
				SolarStatusHelper.GetStatusText(status);

			displayData.StatusLabel = txtStatus;

			displayData.Items =
				hasValidQuality
					? CreateValidMeasurementItems()
					: CreateInvalidMeasurementItems();

			HmiDisplayHelper.Apply(displayData);
		}

		private SolarTheme.EquipmentState ResolveStatus()
		{
			bool alarmActive =
				HmiValueHelper.ToBool(IALM.Val)
				|| HmiValueHelper.ToBool(OLALM.Val)
				|| HmiValueHelper.ToBool(TMPALM.Val);

			return SolarStatusHelper.ResolveStandard(
				QLT.Val,
				IFLT.Val,
				alarmActive,
				IAVL.Val,
				SolarTheme.EquipmentState.Healthy,
				SolarTheme.EquipmentState.Standby);
		}

		private HmiDisplayHelper.DisplayItem[]
			CreateValidMeasurementItems()
		{
			return new HmiDisplayHelper.DisplayItem[]
			{
				HmiDisplayHelper.CreateValue(
					txtILV,
					ILV.Val,
					"N0",
					" A",
					SolarTheme.Text.Primary),

				HmiDisplayHelper.CreateValue(
					txtIMV,
					IMV.Val,
					"N0",
					" A",
					SolarTheme.Text.Primary),

				HmiDisplayHelper.CreateText(
					txtPFMV,
					GetPowerFactorText(PFMV.Val),
					SolarTheme.Text.Primary)
			};
		}

		private HmiDisplayHelper.DisplayItem[]
			CreateInvalidMeasurementItems()
		{
			return new HmiDisplayHelper.DisplayItem[]
			{
				HmiDisplayHelper.CreateText(
					txtILV,
					"--",
					SolarTheme.Status.Offline),

				HmiDisplayHelper.CreateText(
					txtIMV,
					"--",
					SolarTheme.Status.Offline),

				HmiDisplayHelper.CreateText(
					txtPFMV,
					"--",
					SolarTheme.Status.Offline)
			};
		}

		private string GetPowerFactorText(object value)
		{
			double powerFactor =
				HmiValueHelper.ToDouble(value);

			double absolutePowerFactor =
				Math.Abs(powerFactor);

			if (absolutePowerFactor < 0.001)
			{
				return "0.00";
			}

			absolutePowerFactor =
				HmiValueHelper.Clamp(
					absolutePowerFactor,
					0.0,
					1.0);

			string direction;

			if (POSITIVE_PF_IS_LEADING)
			{
				direction =
					powerFactor >= 0.0
						? " Lead"
						: " Lag";
			}
			else
			{
				direction =
					powerFactor >= 0.0
						? " Lag"
						: " Lead";
			}

			return absolutePowerFactor.ToString("0.00")
				+ direction;
		}

		private void REQ_Fired_EventHandler(
			object sender,
			HMI.Main.Symbols.acTransformer_v1_0.REQEventArgs e)
		{
			Title =
				HmiValueHelper.SafeText(
					e.AssetName,
					"Transformer");

			UpdateDisplay();
		}
	}
}