/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/13/2026
 * Time: 7:44 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using NxtControl.GuiFramework;

namespace HMI.Main.Faceplates.acTransformer_v1_0
{
	/// <summary>
	/// Summary description for fMain.
	/// </summary>
	partial class fMain
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fMain));
			this.txtILV = new NxtControl.GuiFramework.Label();
			this.txtIMV = new NxtControl.GuiFramework.Label();
			this.txtPFMV = new NxtControl.GuiFramework.Label();
			this.freeText1 = new NxtControl.GuiFramework.FreeText();
			this.freeText2 = new NxtControl.GuiFramework.FreeText();
			this.freeText3 = new NxtControl.GuiFramework.FreeText();
			this.txtStatus = new NxtControl.GuiFramework.Label();
			this.freeText7 = new NxtControl.GuiFramework.FreeText();
			this.rectangle1 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle2 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle3 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle4 = new NxtControl.GuiFramework.Rectangle();
			this.freeText4 = new NxtControl.GuiFramework.FreeText();
			this.line3 = new NxtControl.GuiFramework.Line();
			this.IMV = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.IALM = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IAVL = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IFLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.ILV = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.OLALM = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.QLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.TMPALM = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.PFMV = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.sButtonNavDemo2 = new SE.Agile.Symbols.Broadcaster_v1_0.sButtonNavDemo();
			// 
			// txtILV
			// 
			this.txtILV.AngleIgnore = true;
			this.txtILV.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtILV.Bounds = new NxtControl.Drawing.RectF(((float)(120D)), ((float)(47D)), ((float)(92D)), ((float)(14D)));
			this.txtILV.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtILV.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtILV.FontScale = true;
			this.txtILV.Name = "txtILV";
			this.txtILV.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtILV.Text = "6.945 A";
			this.txtILV.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtILV.TextAutoSizeHorizontalOffset = 10;
			this.txtILV.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtILV.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// txtIMV
			// 
			this.txtIMV.AngleIgnore = true;
			this.txtIMV.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtIMV.Bounds = new NxtControl.Drawing.RectF(((float)(120D)), ((float)(77D)), ((float)(92D)), ((float)(14D)));
			this.txtIMV.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtIMV.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtIMV.FontScale = true;
			this.txtIMV.Name = "txtIMV";
			this.txtIMV.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtIMV.Text = "262 A";
			this.txtIMV.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtIMV.TextAutoSizeHorizontalOffset = 10;
			this.txtIMV.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtIMV.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// txtPFMV
			// 
			this.txtPFMV.AngleIgnore = true;
			this.txtPFMV.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtPFMV.Bounds = new NxtControl.Drawing.RectF(((float)(120D)), ((float)(107D)), ((float)(92D)), ((float)(14D)));
			this.txtPFMV.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtPFMV.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtPFMV.FontScale = true;
			this.txtPFMV.Name = "txtPFMV";
			this.txtPFMV.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtPFMV.Text = "0.99 Lead";
			this.txtPFMV.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtPFMV.TextAutoSizeHorizontalOffset = 10;
			this.txtPFMV.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtPFMV.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText1
			// 
			this.freeText1.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText1.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText1.Location = new NxtControl.Drawing.PointF(40D, 45D);
			this.freeText1.Name = "freeText1";
			this.freeText1.Text = "LV Current";
			// 
			// freeText2
			// 
			this.freeText2.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText2.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText2.Location = new NxtControl.Drawing.PointF(40D, 75D);
			this.freeText2.Name = "freeText2";
			this.freeText2.Text = "MV Current";
			// 
			// freeText3
			// 
			this.freeText3.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText3.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText3.Location = new NxtControl.Drawing.PointF(40D, 105D);
			this.freeText3.Name = "freeText3";
			this.freeText3.Text = "Power Factor";
			// 
			// txtStatus
			// 
			this.txtStatus.AngleIgnore = true;
			this.txtStatus.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtStatus.Bounds = new NxtControl.Drawing.RectF(((float)(120D)), ((float)(17D)), ((float)(92D)), ((float)(14D)));
			this.txtStatus.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtStatus.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtStatus.FontScale = true;
			this.txtStatus.Name = "txtStatus";
			this.txtStatus.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fAlarm", NxtControl.GuiFramework.MouseButtonType.Click));
			this.txtStatus.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtStatus.Text = "Healthy";
			this.txtStatus.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtStatus.TextAutoSizeHorizontalOffset = 10;
			this.txtStatus.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtStatus.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText7
			// 
			this.freeText7.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText7.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText7.Location = new NxtControl.Drawing.PointF(40D, 15D);
			this.freeText7.Name = "freeText7";
			this.freeText7.Text = "Status";
			// 
			// rectangle1
			// 
			this.rectangle1.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(16D)), ((float)(16D)), ((float)(16D)));
			this.rectangle1.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle1.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle1.ImageBytes = resources.GetString("rectangle1.ImageBytes");
			this.rectangle1.Name = "rectangle1";
			this.rectangle1.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle2
			// 
			this.rectangle2.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(46D)), ((float)(16D)), ((float)(16D)));
			this.rectangle2.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle2.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle2.ImageBytes = resources.GetString("rectangle2.ImageBytes");
			this.rectangle2.Name = "rectangle2";
			this.rectangle2.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle3
			// 
			this.rectangle3.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(76D)), ((float)(16D)), ((float)(16D)));
			this.rectangle3.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle3.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle3.ImageBytes = resources.GetString("rectangle3.ImageBytes");
			this.rectangle3.Name = "rectangle3";
			this.rectangle3.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle4
			// 
			this.rectangle4.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(106D)), ((float)(16D)), ((float)(16D)));
			this.rectangle4.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle4.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle4.ImageBytes = resources.GetString("rectangle4.ImageBytes");
			this.rectangle4.Name = "rectangle4";
			this.rectangle4.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// freeText4
			// 
			this.freeText4.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText4.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Italic);
			this.freeText4.Location = new NxtControl.Drawing.PointF(14D, 143D);
			this.freeText4.Name = "freeText4";
			this.freeText4.Text = "Connector Info.";
			// 
			// line3
			// 
			this.line3.EndPoint = new NxtControl.Drawing.PointF(227D, 134D);
			this.line3.Name = "line3";
			this.line3.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(20)), ((byte)(54)), ((byte)(45))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line3.StartPoint = new NxtControl.Drawing.PointF(1D, 134D);
			// 
			// IMV
			// 
			this.IMV.BeginInit();
			this.IMV.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 120D, 82D);
			this.IMV.Name = "IMV";
			this.IMV.SecurityToken = ((uint)(4294967295u));
			this.IMV.TagName = "IMV";
			this.IMV.Val = 0F;
			this.IMV.ValDecimalPlaces = ((byte)(0));
			this.IMV.ValMaximum = 0F;
			this.IMV.ValMinimum = 0F;
			this.IMV.ValUnits = null;
			this.IMV.EndInit();
			// 
			// IALM
			// 
			this.IALM.BeginInit();
			this.IALM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 112D, 86D);
			this.IALM.Name = "IALM";
			this.IALM.SecurityToken = ((uint)(4294967295u));
			this.IALM.TagName = "IALM";
			this.IALM.Val = false;
			this.IALM.EndInit();
			// 
			// IAVL
			// 
			this.IAVL.BeginInit();
			this.IAVL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 90D, 85D);
			this.IAVL.Name = "IAVL";
			this.IAVL.SecurityToken = ((uint)(4294967295u));
			this.IAVL.TagName = "IAVL";
			this.IAVL.Val = false;
			this.IAVL.EndInit();
			// 
			// IFLT
			// 
			this.IFLT.BeginInit();
			this.IFLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 112D, 91D);
			this.IFLT.Name = "IFLT";
			this.IFLT.SecurityToken = ((uint)(4294967295u));
			this.IFLT.TagName = "IFLT";
			this.IFLT.Val = false;
			this.IFLT.EndInit();
			// 
			// ILV
			// 
			this.ILV.BeginInit();
			this.ILV.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 118D, 108D);
			this.ILV.Name = "ILV";
			this.ILV.SecurityToken = ((uint)(4294967295u));
			this.ILV.TagName = "ILV";
			this.ILV.Val = 0F;
			this.ILV.ValDecimalPlaces = ((byte)(0));
			this.ILV.ValMaximum = 0F;
			this.ILV.ValMinimum = 0F;
			this.ILV.ValUnits = null;
			this.ILV.EndInit();
			// 
			// OLALM
			// 
			this.OLALM.BeginInit();
			this.OLALM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 127D, 108D);
			this.OLALM.Name = "OLALM";
			this.OLALM.SecurityToken = ((uint)(4294967295u));
			this.OLALM.TagName = "OLALM";
			this.OLALM.Val = false;
			this.OLALM.EndInit();
			// 
			// QLT
			// 
			this.QLT.BeginInit();
			this.QLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 115D, 74D);
			this.QLT.Name = "QLT";
			this.QLT.SecurityToken = ((uint)(4294967295u));
			this.QLT.TagName = "QLT";
			this.QLT.Val = false;
			this.QLT.EndInit();
			// 
			// TMPALM
			// 
			this.TMPALM.BeginInit();
			this.TMPALM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 97D, 101D);
			this.TMPALM.Name = "TMPALM";
			this.TMPALM.SecurityToken = ((uint)(4294967295u));
			this.TMPALM.TagName = "TMPALM";
			this.TMPALM.Val = false;
			this.TMPALM.EndInit();
			// 
			// PFMV
			// 
			this.PFMV.BeginInit();
			this.PFMV.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 63D, 74D);
			this.PFMV.Name = "PFMV";
			this.PFMV.SecurityToken = ((uint)(4294967295u));
			this.PFMV.TagName = "PFMV";
			this.PFMV.Val = 0F;
			this.PFMV.ValDecimalPlaces = ((byte)(0));
			this.PFMV.ValMaximum = 0F;
			this.PFMV.ValMinimum = 0F;
			this.PFMV.ValUnits = null;
			this.PFMV.EndInit();
			// 
			// sButtonNavDemo2
			// 
			this.sButtonNavDemo2.BeginInit();
			this.sButtonNavDemo2.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 198D, 144D);
			this.sButtonNavDemo2.Name = "sButtonNavDemo2";
			this.sButtonNavDemo2.SecurityToken = ((uint)(4294967295u));
			this.sButtonNavDemo2.TagName = "Transformer.Broadcaster_v1_0";
			this.sButtonNavDemo2.EndInit();
			// 
			// fMain
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(228D)), ((float)(173D)));
			this.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(3)), ((byte)(22)), ((byte)(20))));
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.txtILV,
			this.txtIMV,
			this.txtPFMV,
			this.freeText1,
			this.freeText2,
			this.freeText3,
			this.txtStatus,
			this.freeText7,
			this.rectangle1,
			this.rectangle2,
			this.rectangle3,
			this.rectangle4,
			this.freeText4,
			this.line3,
			this.IMV,
			this.IALM,
			this.IAVL,
			this.IFLT,
			this.ILV,
			this.OLALM,
			this.QLT,
			this.TMPALM,
			this.PFMV,
			this.sButtonNavDemo2});
			this.Size = new System.Drawing.Size(228, 173);

		}
		private NxtControl.GuiFramework.Label txtStatus;
		private NxtControl.GuiFramework.FreeText freeText7;
		private NxtControl.GuiFramework.Rectangle rectangle1;
		private NxtControl.GuiFramework.FreeText freeText4;
		private NxtControl.GuiFramework.FreeText freeText1;
		private NxtControl.GuiFramework.FreeText freeText2;
		private NxtControl.GuiFramework.FreeText freeText3;
		private NxtControl.GuiFramework.Rectangle rectangle2;
		private NxtControl.GuiFramework.Rectangle rectangle3;
		private NxtControl.GuiFramework.Rectangle rectangle4;
		private NxtControl.GuiFramework.Label txtILV;
		private NxtControl.GuiFramework.Label txtIMV;
		private NxtControl.GuiFramework.Label txtPFMV;
		private NxtControl.GuiFramework.Line line3;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged IMV;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IALM;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IAVL;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IFLT;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged ILV;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged OLALM;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged QLT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged TMPALM;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged PFMV;
		private SE.Agile.Symbols.Broadcaster_v1_0.sButtonNavDemo sButtonNavDemo2;
		#endregion
	}
}
