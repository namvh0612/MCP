/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/8/2026
 * Time: 4:47 PM
 */

using System;
using NxtControl.GuiFramework;
using NxtControl.Drawing;
using HMI.Main.SupportClasses;

namespace HMI.Main.Faceplates.acInverter_v1_0
{
	public partial class fMain :
		NxtControl.GuiFramework.HMIFaceplate
	{
		private const double CURTAILMENT_THRESHOLD = 0.1;

		public fMain()
		{
			InitializeComponent();
			AttachEvents();
			UpdateDisplay();
		}

		private void AttachEvents()
		{
			REQ_Fired += REQ_Fired_EventHandler;

			IAVL.OnValChanged += OnInverterValueChanged;
			IALM.OnValChanged += OnInverterValueChanged;
			IFLT.OnValChanged += OnInverterValueChanged;
			IRUN.OnValChanged += OnInverterValueChanged;
			QLT.OnValChanged += OnInverterValueChanged;
			CURT.OnValChanged += OnInverterValueChanged;

			VDC.OnValChanged += OnInverterValueChanged;
			IDC.OnValChanged += OnInverterValueChanged;
			PDC.OnValChanged += OnInverterValueChanged;

			VAC.OnValChanged += OnInverterValueChanged;
			IAC.OnValChanged += OnInverterValueChanged;
			PAC.OnValChanged += OnInverterValueChanged;
			QAC.OnValChanged += OnInverterValueChanged;
		}

		private void OnInverterValueChanged(
			object sender,
			EventArgs e)
		{
			UpdateDisplay();
		}

		private void UpdateDisplay()
		{
			SolarTheme.EquipmentState status =
				ResolveStatus();

			bool isCurtailing =
				status ==
					SolarTheme.EquipmentState.Running
				&& HmiValueHelper.ToDouble(CURT.Val)
					> CURTAILMENT_THRESHOLD;

			Color statusColor =
				isCurtailing
					? SolarTheme.Flow.AcPower
					: SolarTheme.GetStatusColor(status);

			string statusText =
				isCurtailing
					? "Curt."
					: SolarStatusHelper.GetStatusText(status);

			HmiDisplayHelper.DisplayData displayData =
				new HmiDisplayHelper.DisplayData();

			displayData.Status = status;

			displayData.Items =
				new HmiDisplayHelper.DisplayItem[]
				{
					HmiDisplayHelper.CreateText(
						txtStatus,
						statusText,
						statusColor),

					HmiDisplayHelper.CreateValue(
						txtVDC,
						VDC.Val,
						"0",
						" V",
						GetMeasurementColor(
							VDC.Val,
							false)),

					HmiDisplayHelper.CreateValue(
						txtIDC,
						IDC.Val,
						"0",
						" A",
						GetMeasurementColor(
							IDC.Val,
							false)),

					HmiDisplayHelper.CreateValue(
						txtPDC,
						PDC.Val,
						"0.00",
						" MW",
						GetMeasurementColor(
							PDC.Val,
							false)),

					HmiDisplayHelper.CreateValue(
						txtVAC,
						VAC.Val,
						"0",
						" V",
						GetMeasurementColor(
							VAC.Val,
							false)),

					HmiDisplayHelper.CreateValue(
						txtIAC,
						IAC.Val,
						"0",
						" A",
						GetMeasurementColor(
							IAC.Val,
							false)),

					HmiDisplayHelper.CreateValue(
						txtPAC,
						PAC.Val,
						"0.00",
						" MW",
						GetMeasurementColor(
							PAC.Val,
							false)),

					HmiDisplayHelper.CreateValue(
						txtQAC,
						QAC.Val,
						"0.00",
						" MVAr",
						GetMeasurementColor(
							QAC.Val,
							true))
				};

			HmiDisplayHelper.Apply(displayData);
		}

		private SolarTheme.EquipmentState ResolveStatus()
		{
			return SolarStatusHelper.ResolveRunningAvailable(
				QLT.Val,
				IFLT.Val,
				IALM.Val,
				IRUN.Val,
				IAVL.Val);
		}

		private Color GetMeasurementColor(
			object value,
			bool allowNegative)
		{
			if (!HmiValueHelper.ToBool(QLT.Val))
			{
				return SolarTheme.Status.Offline;
			}

			if (!allowNegative &&
				HmiValueHelper.ToDouble(value) < 0.0)
			{
				return SolarTheme.Status.Fault;
			}

			return SolarTheme.Text.Primary;
		}

		private void REQ_Fired_EventHandler(
			object sender,
			HMI.Main.Symbols.acInverter_v1_0.REQEventArgs e)
		{
			Title =
				HmiValueHelper.SafeText(
					e.AssetName,
					"Inverter");

			UpdateDisplay();
		}

		private void RectBtnDCMouseEnter(
			object sender,
			EventArgs e)
		{
			rectBtnDC.PenColor =
				SolarTheme.Flow.DcPower;
		}

		private void RectBtnDCMouseLeave(
			object sender,
			EventArgs e)
		{
			rectBtnDC.PenColor =
				SolarTheme.Border.Normal;
		}

		private void RectBtnACMouseEnter(
			object sender,
			EventArgs e)
		{
			rectBtnAC.PenColor =
				SolarTheme.Flow.AcPower;
		}

		private void RectBtnACMouseLeave(
			object sender,
			EventArgs e)
		{
			rectBtnAC.PenColor =
				SolarTheme.Border.Normal;
		}
	}
}