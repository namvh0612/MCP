/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/8/2026
 * Time: 2:32 PM
 */

using System;
using NxtControl.GuiFramework;
using NxtControl.Drawing;
using HMI.Main.SupportClasses;

namespace HMI.Main.Symbols.acInverter_v1_0
{
	public partial class sDefault :
		NxtControl.GuiFramework.HMISymbol
	{
		private const double CURTAILMENT_THRESHOLD = 0.1;
		private const double REACTIVE_POWER_DEADBAND = 0.001;

		private bool _isRectBtnHovered;
		private bool _isCurtailing;

		private SolarTheme.EquipmentState _currentStatus =
			SolarTheme.EquipmentState.Offline;

		public sDefault()
		{
			InitializeComponent();
			AttachEvents();
			UpdateDisplay();
		}

		private void AttachEvents()
		{
			REQ_Fired += REQ_Fired_EventHandler;

			IRUN.OnValChanged += OnValueChanged;
			IAVL.OnValChanged += OnValueChanged;
			IALM.OnValChanged += OnValueChanged;
			IFLT.OnValChanged += OnValueChanged;
			QLT.OnValChanged += OnValueChanged;
			CURT.OnValChanged += OnValueChanged;

			PAC.OnValChanged += OnValueChanged;
			QAC.OnValChanged += OnValueChanged;
			PF.OnValChanged += OnValueChanged;
			EFF.OnValChanged += OnValueChanged;
			ASPFB.OnValChanged += OnValueChanged;
		}

		private void OnValueChanged(
			object sender,
			EventArgs e)
		{
			UpdateDisplay();
		}

		private void UpdateDisplay()
		{
			_currentStatus = ResolveStatus();

			_isCurtailing =
				_currentStatus ==
					SolarTheme.EquipmentState.Running
				&& HmiValueHelper.ToDouble(CURT.Val)
					> CURTAILMENT_THRESHOLD;

			Color statusColor =
				_isCurtailing
					? SolarTheme.Flow.AcPower
					: SolarTheme.GetStatusColor(
						_currentStatus);

			Color valueColor =
				_currentStatus ==
					SolarTheme.EquipmentState.Offline
					? SolarTheme.Status.Offline
					: SolarTheme.Text.Primary;

			HmiDisplayHelper.DisplayData displayData =
				new HmiDisplayHelper.DisplayData();

			displayData.Status = _currentStatus;
			displayData.StatusIndicator = indStatus;
			displayData.CardBorder = rectBtn;
			displayData.CardBackground = rectBase;
			displayData.IsHovered = _isRectBtnHovered;

			displayData.Items =
				new HmiDisplayHelper.DisplayItem[]
				{
					HmiDisplayHelper.CreateText(
						txtStatus,
						_isCurtailing
							? "Curtail"
							: SolarStatusHelper.GetStatusText(
								_currentStatus),
						statusColor),

					HmiDisplayHelper.CreateValue(
						txtPAC,
						PAC.Val,
						"0.00",
						" MW",
						valueColor),

					HmiDisplayHelper.CreateText(
						txtPF,
						GetPowerFactorText(
							PF.Val,
							QAC.Val),
						valueColor),

					HmiDisplayHelper.CreateValue(
						txtEFF,
						EFF.Val,
						"0.0",
						" %",
						valueColor),

					HmiDisplayHelper.CreateValue(
						txtASPFB,
						ASPFB.Val,
						"0.00",
						" MW",
						valueColor)
				};

			HmiDisplayHelper.Apply(displayData);

			// Curtailment uses AC-flow orange instead
			// of the normal Running indicator.
			if (_isCurtailing)
			{
				indStatus.BrushColor =
					SolarTheme.Flow.AcPower;
			}

			UpdateCardVisual();
		}

		private SolarTheme.EquipmentState ResolveStatus()
		{
			return SolarStatusHelper.ResolveRunningAvailable(
				QLT.Val,
				IFLT.Val,
				IALM.Val,
				IRUN.Val,
				IAVL.Val);
		}

		private string GetPowerFactorText(
			object powerFactorValue,
			object reactivePowerValue)
		{
			double powerFactor =
				Math.Abs(
					HmiValueHelper.ToDouble(
						powerFactorValue));

			powerFactor =
				HmiValueHelper.Clamp(
					powerFactor,
					0.0,
					1.0);

			return powerFactor.ToString("0.00")
				+ GetLeadLag(reactivePowerValue);
		}

		private string GetLeadLag(
			object reactivePowerValue)
		{
			double reactivePower =
				HmiValueHelper.ToDouble(
					reactivePowerValue);

			if (reactivePower >
				REACTIVE_POWER_DEADBAND)
			{
				return " Lag";
			}

			if (reactivePower <
				-REACTIVE_POWER_DEADBAND)
			{
				return " Lead";
			}

			return " Unity";
		}

		private void UpdateCardVisual()
		{
			HmiDisplayHelper.ApplyStatusCard(
				rectBtn,
				rectBase,
				_currentStatus,
				_isRectBtnHovered);

			if (_isCurtailing)
			{
				rectBtn.PenColor =
					SolarTheme.Flow.AcPower;;
			}
		}

		private void RectBtnMouseEnter(
			object sender,
			EventArgs e)
		{
			_isRectBtnHovered = true;
			UpdateCardVisual();
		}

		private void RectBtnMouseLeave(
			object sender,
			EventArgs e)
		{
			_isRectBtnHovered = false;
			UpdateCardVisual();
		}

		private void REQ_Fired_EventHandler(
			object sender,
			REQEventArgs e)
		{
			lblSymbol.Text =
				HmiValueHelper.SafeText(
					e.AssetName,
					"Inverter");
		}
	}
}