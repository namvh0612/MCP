/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/24/2026
 * Time: 10:03 AM
 */

using System;
using NxtControl.GuiFramework;
using NxtControl.Drawing;
using HMI.Main.SupportClasses;

namespace HMI.Main.Symbols.acInverter_v1_0
{
	public partial class sAcPwr :
		NxtControl.GuiFramework.HMISymbol
	{
		private const double POWER_DEADBAND = 0.001;

		private bool _isRectBtnHovered;

		private SolarTheme.EquipmentState _currentStatus =
			SolarTheme.EquipmentState.Offline;

		public sAcPwr()
		{
			InitializeComponent();
			AttachEvents();
			UpdateDisplay();
		}

		private void AttachEvents()
		{
			PAC.OnValChanged += OnInverterValueChanged;
			IAVL.OnValChanged += OnInverterValueChanged;
			IALM.OnValChanged += OnInverterValueChanged;
			IFLT.OnValChanged += OnInverterValueChanged;
			QLT.OnValChanged += OnInverterValueChanged;
		}

		private void OnInverterValueChanged(
			object sender,
			EventArgs e)
		{
			UpdateDisplay();
		}

		private void UpdateDisplay()
		{
			double acPower =
				HmiValueHelper.ToDouble(PAC.Val);

			_currentStatus =
				ResolveStatus(acPower);

			HmiDisplayHelper.DisplayData displayData =
				new HmiDisplayHelper.DisplayData();

			displayData.Status = _currentStatus;
			displayData.CardBorder = rectBtn;
			displayData.CardBackground = rectBtn;
			displayData.IsHovered = _isRectBtnHovered;

			displayData.Items =
				new HmiDisplayHelper.DisplayItem[]
				{
					HmiDisplayHelper.CreateValue(
						txtData,
						PAC.Val,
						"0.00",
						" MWac",
						GetValueColor(_currentStatus))
				};

			HmiDisplayHelper.Apply(displayData);
		}

		private SolarTheme.EquipmentState ResolveStatus(
			double acPower)
		{
			SolarTheme.EquipmentState priorityStatus;
		
			if (SolarStatusHelper.TryResolvePriorityStatus(
				QLT.Val,
				IFLT.Val,
				IALM.Val,
				out priorityStatus))
			{
				return priorityStatus;
			}
		
			if (acPower < -POWER_DEADBAND)
			{
				return SolarTheme.EquipmentState.Fault;
			}
		
			if (!HmiValueHelper.ToBool(IAVL.Val))
			{
				return SolarTheme.EquipmentState.Unknown;
			}
		
			if (acPower <= POWER_DEADBAND)
			{
				return SolarTheme.EquipmentState.Standby;
			}
		
			return SolarTheme.EquipmentState.Running;
		}

		private Color GetValueColor(
			SolarTheme.EquipmentState status)
		{
			switch (status)
			{
				case SolarTheme.EquipmentState.Fault:
					return SolarTheme.Status.Fault;

				case SolarTheme.EquipmentState.Alarm:
					return SolarTheme.Status.Alarm;
				
				case SolarTheme.EquipmentState.Warning:
					return SolarTheme.Status.Warning;
				
				case SolarTheme.EquipmentState.Unknown:
					return SolarTheme.Status.Unknown;

				case SolarTheme.EquipmentState.Offline:
					return SolarTheme.Status.Offline;

				case SolarTheme.EquipmentState.Standby:
					return SolarTheme.Text.Muted;

				default:
					return SolarTheme.Text.Primary;
			}
		}

		private void UpdateCardVisual()
		{
			HmiDisplayHelper.ApplyStatusCard(
				rectBtn,
				rectBtn,
				_currentStatus,
				_isRectBtnHovered);
			
			roundedRectangle1.BrushColor =
				_isRectBtnHovered
					? SolarTheme.Surface.RaisedPanel
					: SolarTheme.Surface.Panel;
		
			roundedRectangle1.PenColor =
				_isRectBtnHovered
					? SolarTheme.Border.Hover
					: SolarTheme.Border.Normal;
		
			roundedRectangle1.PenWidth =
				_isRectBtnHovered
					? SolarTheme.Pen.Panel
					: SolarTheme.Pen.Normal;
		}

		private void GroupDataMouseEnter(
			object sender,
			EventArgs e)
		{
			_isRectBtnHovered = true;
			UpdateCardVisual();
		}

		private void GroupDataMouseLeave(
			object sender,
			EventArgs e)
		{
			_isRectBtnHovered = false;
			UpdateCardVisual();
		}
	}
}