/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/13/2026
 * Time: 11:50 AM
 */

using System;
using NxtControl.GuiFramework;
using HMI.Main.SupportClasses;

using GuiLabel =
	NxtControl.GuiFramework.Label;

namespace HMI.Main.Faceplates.acInverter_v1_0
{
	public partial class fAlarm :
		NxtControl.GuiFramework.HMIFaceplate
	{
		private sealed class AlarmDefinition
		{
			public readonly int Bit;
			public readonly string Text;
			public readonly SolarTheme.EquipmentState Severity;
			public readonly GuiLabel Label;

			public AlarmDefinition(
				int bit,
				string text,
				SolarTheme.EquipmentState severity,
				GuiLabel label)
			{
				Bit = bit;
				Text = text;
				Severity = severity;
				Label = label;
			}
		}

		private AlarmDefinition[] _alarms;

		public fAlarm()
		{
			InitializeComponent();
			InitializeAlarms();
			AttachEvents();
			UpdateAlarmDisplay();
		}

		private void InitializeAlarms()
		{
			_alarms = new AlarmDefinition[]
			{
				new AlarmDefinition(
					0,
					"Data quality lost",
					SolarTheme.EquipmentState.Fault,
					label1),

				new AlarmDefinition(
					1,
					"Communication lost",
					SolarTheme.EquipmentState.Fault,
					label2),

				new AlarmDefinition(
					2,
					"Upstream DC source fault",
					SolarTheme.EquipmentState.Fault,
					label3),

				new AlarmDefinition(
					3,
					"DC input undervoltage",
					SolarTheme.EquipmentState.Warning,
					label4),

				new AlarmDefinition(
					4,
					"DC input overvoltage",
					SolarTheme.EquipmentState.Fault,
					label5),

				new AlarmDefinition(
					5,
					"Inverter trip",
					SolarTheme.EquipmentState.Fault,
					label6),

				new AlarmDefinition(
					6,
					"Active power tracking error",
					SolarTheme.EquipmentState.Warning,
					label7),

				new AlarmDefinition(
					7,
					"AC output voltage out of range",
					SolarTheme.EquipmentState.Fault,
					label8),

				new AlarmDefinition(
					8,
					"AC output frequency out of range",
					SolarTheme.EquipmentState.Fault,
					label9),

				new AlarmDefinition(
					9,
					"Power factor tracking error",
					SolarTheme.EquipmentState.Warning,
					label10)
			};
		}

		private void AttachEvents()
		{
			ALMW.OnValChanged += OnAlarmWordChanged;
			REQ_Fired += REQ_Fired_EventHandler;
		}

		private void OnAlarmWordChanged(
			object sender,
			EventArgs e)
		{
			UpdateAlarmDisplay();
		}

		private void UpdateAlarmDisplay()
		{
			int alarmWord =
				HmiValueHelper.ToInt(ALMW.Val);

			HmiDisplayHelper.DisplayItem[] displayItems =
				new HmiDisplayHelper.DisplayItem[
					_alarms.Length];

			for (int i = 0; i < _alarms.Length; i++)
			{
				AlarmDefinition alarm =
					_alarms[i];

				bool isActive =
					IsBitSet(
						alarmWord,
						alarm.Bit);

				displayItems[i] =
					HmiDisplayHelper.CreateText(
						alarm.Label,
						alarm.Text,
						isActive
							? SolarTheme.GetStatusColor(
								alarm.Severity)
							: SolarTheme.Status.Offline);
			}

			HmiDisplayHelper.DisplayData displayData =
				new HmiDisplayHelper.DisplayData();

			displayData.Items = displayItems;

			HmiDisplayHelper.Apply(displayData);
		}

		private bool IsBitSet(
			int value,
			int bit)
		{
			if (bit < 0 || bit > 31)
				return false;

			return (value & (1 << bit)) != 0;
		}

		private void REQ_Fired_EventHandler(
			object sender,
			HMI.Main.Symbols.acInverter_v1_0.REQEventArgs e)
		{
			Title =
				HmiValueHelper.SafeText(
					e.AssetName,
					"Inverter Alarms");
		}
	}
}