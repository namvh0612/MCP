/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/8/2026
 * Time: 2:32 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.acInverter_v1_0
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sDefault
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(sDefault));
			this.rectangle1 = new NxtControl.GuiFramework.Rectangle();
			this.lblSymbol = new NxtControl.GuiFramework.Label();
			this.txtStatus = new NxtControl.GuiFramework.Label();
			this.indStatus = new NxtControl.GuiFramework.Ellipse();
			this.rectBtn = new NxtControl.GuiFramework.RoundedRectangle();
			this.txtPAC = new NxtControl.GuiFramework.Label();
			this.freeText4 = new NxtControl.GuiFramework.FreeText();
			this.txtPF = new NxtControl.GuiFramework.Label();
			this.freeText5 = new NxtControl.GuiFramework.FreeText();
			this.txtEFF = new NxtControl.GuiFramework.Label();
			this.freeText6 = new NxtControl.GuiFramework.FreeText();
			this.line1 = new NxtControl.GuiFramework.Line();
			this.line2 = new NxtControl.GuiFramework.Line();
			this.line3 = new NxtControl.GuiFramework.Line();
			this.txtASPFB = new NxtControl.GuiFramework.Label();
			this.freeText12 = new NxtControl.GuiFramework.FreeText();
			this.line4 = new NxtControl.GuiFramework.Line();
			this.rectBase = new NxtControl.GuiFramework.RoundedRectangle();
			this.PAC = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.PF = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.EFF = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.ASPFB = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.IRUN = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IFLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IALM = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IAVL = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.QLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.CURT = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.QAC = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.CURT_1 = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			// 
			// rectangle1
			// 
			this.rectangle1.Bounds = new NxtControl.Drawing.RectF(((float)(10D)), ((float)(45D)), ((float)(220D)), ((float)(220D)));
			this.rectangle1.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle1.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle1.ImageBytes = resources.GetString("rectangle1.ImageBytes");
			this.rectangle1.Name = "rectangle1";
			this.rectangle1.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// lblSymbol
			// 
			this.lblSymbol.AngleIgnore = true;
			this.lblSymbol.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.lblSymbol.Bounds = new NxtControl.Drawing.RectF(((float)(11D)), ((float)(12D)), ((float)(141D)), ((float)(24D)));
			this.lblSymbol.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.lblSymbol.Font = new NxtControl.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
			this.lblSymbol.FontScale = true;
			this.lblSymbol.Name = "lblSymbol";
			this.lblSymbol.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.lblSymbol.Text = "Inverter";
			this.lblSymbol.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.lblSymbol.TextAutoSizeHorizontalOffset = 10;
			this.lblSymbol.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.lblSymbol.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// txtStatus
			// 
			this.txtStatus.AngleIgnore = true;
			this.txtStatus.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtStatus.Bounds = new NxtControl.Drawing.RectF(((float)(167D)), ((float)(16D)), ((float)(65D)), ((float)(16D)));
			this.txtStatus.Brush = new NxtControl.Drawing.Brush(true);
			this.txtStatus.Font = new NxtControl.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular);
			this.txtStatus.FontScale = true;
			this.txtStatus.Name = "txtStatus";
			this.txtStatus.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtStatus.Text = "Running";
			this.txtStatus.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.txtStatus.TextAutoSizeHorizontalOffset = 10;
			this.txtStatus.TextColor = new NxtControl.Drawing.Color(((byte)(120)), ((byte)(249)), ((byte)(141)));
			this.txtStatus.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// indStatus
			// 
			this.indStatus.Bounds = new NxtControl.Drawing.RectF(((float)(155D)), ((float)(19D)), ((float)(10D)), ((float)(10D)));
			this.indStatus.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(120)), ((byte)(249)), ((byte)(141))));
			this.indStatus.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.indStatus.Name = "indStatus";
			this.indStatus.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectBtn
			// 
			this.rectBtn.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(240D)), ((float)(412D)));
			this.rectBtn.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("Transparent"));
			this.rectBtn.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectBtn.Name = "rectBtn";
			this.rectBtn.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fMain", NxtControl.GuiFramework.MouseButtonType.Click));
			this.rectBtn.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(28)), ((byte)(78)), ((byte)(71))), 1F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Flat, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Round, null);
			this.rectBtn.Radius = 10D;
			this.rectBtn.MouseEnter += new System.EventHandler(this.RectBtnMouseEnter);
			this.rectBtn.MouseLeave += new System.EventHandler(this.RectBtnMouseLeave);
			// 
			// txtPAC
			// 
			this.txtPAC.AngleIgnore = true;
			this.txtPAC.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtPAC.Bounds = new NxtControl.Drawing.RectF(((float)(131D)), ((float)(287D)), ((float)(96D)), ((float)(20D)));
			this.txtPAC.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtPAC.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtPAC.FontScale = true;
			this.txtPAC.Name = "txtPAC";
			this.txtPAC.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtPAC.Text = "4.52 MW";
			this.txtPAC.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtPAC.TextAutoSizeHorizontalOffset = 10;
			this.txtPAC.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtPAC.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText4
			// 
			this.freeText4.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText4.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText4.Location = new NxtControl.Drawing.PointF(11D, 288D);
			this.freeText4.Name = "freeText4";
			this.freeText4.Text = "AC Power";
			// 
			// txtPF
			// 
			this.txtPF.AngleIgnore = true;
			this.txtPF.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtPF.Bounds = new NxtControl.Drawing.RectF(((float)(131D)), ((float)(319D)), ((float)(96D)), ((float)(20D)));
			this.txtPF.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtPF.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtPF.FontScale = true;
			this.txtPF.Name = "txtPF";
			this.txtPF.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtPF.Text = "0.99 Lag";
			this.txtPF.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtPF.TextAutoSizeHorizontalOffset = 10;
			this.txtPF.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtPF.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText5
			// 
			this.freeText5.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText5.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText5.Location = new NxtControl.Drawing.PointF(11D, 320D);
			this.freeText5.Name = "freeText5";
			this.freeText5.Text = "Power Factor";
			// 
			// txtEFF
			// 
			this.txtEFF.AngleIgnore = true;
			this.txtEFF.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtEFF.Bounds = new NxtControl.Drawing.RectF(((float)(131D)), ((float)(351D)), ((float)(96D)), ((float)(20D)));
			this.txtEFF.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtEFF.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtEFF.FontScale = true;
			this.txtEFF.Name = "txtEFF";
			this.txtEFF.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtEFF.Text = "97.8%";
			this.txtEFF.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtEFF.TextAutoSizeHorizontalOffset = 10;
			this.txtEFF.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtEFF.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText6
			// 
			this.freeText6.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText6.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText6.Location = new NxtControl.Drawing.PointF(11D, 352D);
			this.freeText6.Name = "freeText6";
			this.freeText6.Text = "Efficiency";
			// 
			// line1
			// 
			this.line1.EndPoint = new NxtControl.Drawing.PointF(239D, 281D);
			this.line1.Name = "line1";
			this.line1.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(20)), ((byte)(54)), ((byte)(45))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line1.StartPoint = new NxtControl.Drawing.PointF(2D, 281D);
			// 
			// line2
			// 
			this.line2.EndPoint = new NxtControl.Drawing.PointF(239D, 313D);
			this.line2.Name = "line2";
			this.line2.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(20)), ((byte)(54)), ((byte)(45))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line2.StartPoint = new NxtControl.Drawing.PointF(2D, 313D);
			// 
			// line3
			// 
			this.line3.EndPoint = new NxtControl.Drawing.PointF(239D, 345D);
			this.line3.Name = "line3";
			this.line3.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(20)), ((byte)(54)), ((byte)(45))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line3.StartPoint = new NxtControl.Drawing.PointF(2D, 345D);
			// 
			// txtASPFB
			// 
			this.txtASPFB.AngleIgnore = true;
			this.txtASPFB.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtASPFB.Bounds = new NxtControl.Drawing.RectF(((float)(131D)), ((float)(382D)), ((float)(96D)), ((float)(20D)));
			this.txtASPFB.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtASPFB.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtASPFB.FontScale = true;
			this.txtASPFB.Name = "txtASPFB";
			this.txtASPFB.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtASPFB.Text = "4.60 MW";
			this.txtASPFB.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtASPFB.TextAutoSizeHorizontalOffset = 10;
			this.txtASPFB.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtASPFB.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText12
			// 
			this.freeText12.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText12.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText12.Location = new NxtControl.Drawing.PointF(11D, 383D);
			this.freeText12.Name = "freeText12";
			this.freeText12.Text = "Setpoint";
			// 
			// line4
			// 
			this.line4.EndPoint = new NxtControl.Drawing.PointF(239D, 376D);
			this.line4.Name = "line4";
			this.line4.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(20)), ((byte)(54)), ((byte)(45))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line4.StartPoint = new NxtControl.Drawing.PointF(2D, 376D);
			// 
			// rectBase
			// 
			this.rectBase.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(240D)), ((float)(412D)));
			this.rectBase.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(3)), ((byte)(22)), ((byte)(20))));
			this.rectBase.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectBase.Name = "rectBase";
			this.rectBase.Pen = new NxtControl.Drawing.Pen("Transparent");
			this.rectBase.Radius = 10D;
			// 
			// PAC
			// 
			this.PAC.BeginInit();
			this.PAC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 422D, 298D);
			this.PAC.Name = "PAC";
			this.PAC.SecurityToken = ((uint)(4294967295u));
			this.PAC.TagName = "PAC";
			this.PAC.Val = 0F;
			this.PAC.ValDecimalPlaces = ((byte)(0));
			this.PAC.ValMaximum = 0F;
			this.PAC.ValMinimum = 0F;
			this.PAC.ValUnits = null;
			this.PAC.EndInit();
			// 
			// PF
			// 
			this.PF.BeginInit();
			this.PF.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 286D, 304D);
			this.PF.Name = "PF";
			this.PF.SecurityToken = ((uint)(4294967295u));
			this.PF.TagName = "PF";
			this.PF.Val = 0F;
			this.PF.ValDecimalPlaces = ((byte)(0));
			this.PF.ValMaximum = 0F;
			this.PF.ValMinimum = 0F;
			this.PF.ValUnits = null;
			this.PF.EndInit();
			// 
			// EFF
			// 
			this.EFF.BeginInit();
			this.EFF.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 305D, 196D);
			this.EFF.Name = "EFF";
			this.EFF.SecurityToken = ((uint)(4294967295u));
			this.EFF.TagName = "EFF";
			this.EFF.Val = 0F;
			this.EFF.ValDecimalPlaces = ((byte)(0));
			this.EFF.ValMaximum = 0F;
			this.EFF.ValMinimum = 0F;
			this.EFF.ValUnits = null;
			this.EFF.EndInit();
			// 
			// ASPFB
			// 
			this.ASPFB.BeginInit();
			this.ASPFB.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 291D, 125D);
			this.ASPFB.Name = "ASPFB";
			this.ASPFB.SecurityToken = ((uint)(4294967295u));
			this.ASPFB.TagName = "ASPFB";
			this.ASPFB.Val = 0F;
			this.ASPFB.ValDecimalPlaces = ((byte)(0));
			this.ASPFB.ValMaximum = 0F;
			this.ASPFB.ValMinimum = 0F;
			this.ASPFB.ValUnits = null;
			this.ASPFB.EndInit();
			// 
			// IRUN
			// 
			this.IRUN.BeginInit();
			this.IRUN.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 376D, 223D);
			this.IRUN.Name = "IRUN";
			this.IRUN.SecurityToken = ((uint)(4294967295u));
			this.IRUN.TagName = "IRUN";
			this.IRUN.Val = false;
			this.IRUN.EndInit();
			// 
			// IFLT
			// 
			this.IFLT.BeginInit();
			this.IFLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 254D, 247D);
			this.IFLT.Name = "IFLT";
			this.IFLT.SecurityToken = ((uint)(4294967295u));
			this.IFLT.TagName = "IFLT";
			this.IFLT.Val = false;
			this.IFLT.EndInit();
			// 
			// IALM
			// 
			this.IALM.BeginInit();
			this.IALM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 288D, 177D);
			this.IALM.Name = "IALM";
			this.IALM.SecurityToken = ((uint)(4294967295u));
			this.IALM.TagName = "IALM";
			this.IALM.Val = false;
			this.IALM.EndInit();
			// 
			// IAVL
			// 
			this.IAVL.BeginInit();
			this.IAVL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 293D, 177D);
			this.IAVL.Name = "IAVL";
			this.IAVL.SecurityToken = ((uint)(4294967295u));
			this.IAVL.TagName = "IAVL";
			this.IAVL.Val = false;
			this.IAVL.EndInit();
			// 
			// QLT
			// 
			this.QLT.BeginInit();
			this.QLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 281D, 232D);
			this.QLT.Name = "QLT";
			this.QLT.SecurityToken = ((uint)(4294967295u));
			this.QLT.TagName = "QLT";
			this.QLT.Val = false;
			this.QLT.EndInit();
			// 
			// CURT
			// 
			this.CURT.BeginInit();
			this.CURT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 288D, 138D);
			this.CURT.Name = "CURT";
			this.CURT.SecurityToken = ((uint)(4294967295u));
			this.CURT.TagName = "CURT";
			this.CURT.Val = 0F;
			this.CURT.ValDecimalPlaces = ((byte)(0));
			this.CURT.ValMaximum = 0F;
			this.CURT.ValMinimum = 0F;
			this.CURT.ValUnits = null;
			this.CURT.EndInit();
			// 
			// QAC
			// 
			this.QAC.BeginInit();
			this.QAC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 393D, 273D);
			this.QAC.Name = "QAC";
			this.QAC.SecurityToken = ((uint)(4294967295u));
			this.QAC.TagName = "QAC";
			this.QAC.Val = 0F;
			this.QAC.ValDecimalPlaces = ((byte)(0));
			this.QAC.ValMaximum = 0F;
			this.QAC.ValMinimum = 0F;
			this.QAC.ValUnits = null;
			this.QAC.EndInit();
			// 
			// CURT_1
			// 
			this.CURT_1.BeginInit();
			this.CURT_1.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 381D, 340D);
			this.CURT_1.Name = "CURT_1";
			this.CURT_1.SecurityToken = ((uint)(4294967295u));
			this.CURT_1.TagName = "CURT";
			this.CURT_1.Val = 0F;
			this.CURT_1.ValDecimalPlaces = ((byte)(0));
			this.CURT_1.ValMaximum = 0F;
			this.CURT_1.ValMinimum = 0F;
			this.CURT_1.ValUnits = null;
			this.CURT_1.EndInit();
			// 
			// sDefault
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.rectBase,
			this.rectangle1,
			this.lblSymbol,
			this.txtStatus,
			this.indStatus,
			this.txtPAC,
			this.freeText4,
			this.txtPF,
			this.freeText5,
			this.txtEFF,
			this.freeText6,
			this.line1,
			this.line2,
			this.line3,
			this.txtASPFB,
			this.freeText12,
			this.line4,
			this.PAC,
			this.PF,
			this.EFF,
			this.ASPFB,
			this.IRUN,
			this.IFLT,
			this.IALM,
			this.IAVL,
			this.QLT,
			this.CURT,
			this.QAC,
			this.CURT_1,
			this.rectBtn});
			this.SymbolSize = new System.Drawing.Size(648, 496);

		}
		private NxtControl.GuiFramework.Rectangle rectangle1;
		private NxtControl.GuiFramework.Label lblSymbol;
		private NxtControl.GuiFramework.Label txtStatus;
		private NxtControl.GuiFramework.Ellipse indStatus;
		private NxtControl.GuiFramework.RoundedRectangle rectBtn;
		private NxtControl.GuiFramework.Label txtPAC;
		private NxtControl.GuiFramework.FreeText freeText4;
		private NxtControl.GuiFramework.Label txtPF;
		private NxtControl.GuiFramework.FreeText freeText5;
		private NxtControl.GuiFramework.Label txtEFF;
		private NxtControl.GuiFramework.FreeText freeText6;
		private NxtControl.GuiFramework.Line line1;
		private NxtControl.GuiFramework.Line line2;
		private NxtControl.GuiFramework.Line line3;
		private NxtControl.GuiFramework.Label txtASPFB;
		private NxtControl.GuiFramework.FreeText freeText12;
		private NxtControl.GuiFramework.Line line4;
		private NxtControl.GuiFramework.RoundedRectangle rectBase;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged PAC;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged PF;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged EFF;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged ASPFB;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IRUN;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IFLT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IALM;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IAVL;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged QLT;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged CURT;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged QAC;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged CURT_1;
		#endregion
	}
}