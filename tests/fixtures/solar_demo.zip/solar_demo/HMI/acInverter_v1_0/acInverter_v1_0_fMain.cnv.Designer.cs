/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/8/2026
 * Time: 4:47 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using NxtControl.GuiFramework;

namespace HMI.Main.Faceplates.acInverter_v1_0
{
	/// <summary>
	/// Summary description for fMain.
	/// </summary>
	partial class fMain
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fMain));
			this.txtVDC = new NxtControl.GuiFramework.Label();
			this.txtIDC = new NxtControl.GuiFramework.Label();
			this.txtPDC = new NxtControl.GuiFramework.Label();
			this.freeText1 = new NxtControl.GuiFramework.FreeText();
			this.freeText2 = new NxtControl.GuiFramework.FreeText();
			this.freeText3 = new NxtControl.GuiFramework.FreeText();
			this.txtStatus = new NxtControl.GuiFramework.Label();
			this.freeText7 = new NxtControl.GuiFramework.FreeText();
			this.txtVAC = new NxtControl.GuiFramework.Label();
			this.freeText8 = new NxtControl.GuiFramework.FreeText();
			this.rectangle1 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle2 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle3 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle4 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle5 = new NxtControl.GuiFramework.Rectangle();
			this.txtIAC = new NxtControl.GuiFramework.Label();
			this.freeText5 = new NxtControl.GuiFramework.FreeText();
			this.rectangle6 = new NxtControl.GuiFramework.Rectangle();
			this.txtPAC = new NxtControl.GuiFramework.Label();
			this.freeText6 = new NxtControl.GuiFramework.FreeText();
			this.rectangle7 = new NxtControl.GuiFramework.Rectangle();
			this.txtQAC = new NxtControl.GuiFramework.Label();
			this.freeText9 = new NxtControl.GuiFramework.FreeText();
			this.rectangle8 = new NxtControl.GuiFramework.Rectangle();
			this.freeText4 = new NxtControl.GuiFramework.FreeText();
			this.rectBtnDC = new NxtControl.GuiFramework.RoundedRectangle();
			this.rectBtnAC = new NxtControl.GuiFramework.RoundedRectangle();
			this.IALM = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IAVL = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.QLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IFLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IRUN = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.PAC = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.PDC = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.VAC = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.VDC = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.IAC = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.IDC = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.QAC = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.sButtonNavDemo2 = new SE.Agile.Symbols.Broadcaster_v1_0.sButtonNavDemo();
			this.CURT = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			// 
			// txtVDC
			// 
			this.txtVDC.AngleIgnore = true;
			this.txtVDC.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtVDC.Bounds = new NxtControl.Drawing.RectF(((float)(120D)), ((float)(49D)), ((float)(92D)), ((float)(14D)));
			this.txtVDC.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtVDC.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtVDC.FontScale = true;
			this.txtVDC.Name = "txtVDC";
			this.txtVDC.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtVDC.Text = "805 V";
			this.txtVDC.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtVDC.TextAutoSizeHorizontalOffset = 10;
			this.txtVDC.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtVDC.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// txtIDC
			// 
			this.txtIDC.AngleIgnore = true;
			this.txtIDC.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtIDC.Bounds = new NxtControl.Drawing.RectF(((float)(120D)), ((float)(79D)), ((float)(92D)), ((float)(14D)));
			this.txtIDC.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtIDC.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtIDC.FontScale = true;
			this.txtIDC.Name = "txtIDC";
			this.txtIDC.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtIDC.Text = "6773 A";
			this.txtIDC.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtIDC.TextAutoSizeHorizontalOffset = 10;
			this.txtIDC.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtIDC.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// txtPDC
			// 
			this.txtPDC.AngleIgnore = true;
			this.txtPDC.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtPDC.Bounds = new NxtControl.Drawing.RectF(((float)(120D)), ((float)(109D)), ((float)(92D)), ((float)(14D)));
			this.txtPDC.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtPDC.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtPDC.FontScale = true;
			this.txtPDC.Name = "txtPDC";
			this.txtPDC.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtPDC.Text = "5.45 MW";
			this.txtPDC.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtPDC.TextAutoSizeHorizontalOffset = 10;
			this.txtPDC.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtPDC.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText1
			// 
			this.freeText1.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText1.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText1.Location = new NxtControl.Drawing.PointF(40D, 47D);
			this.freeText1.Name = "freeText1";
			this.freeText1.Text = "DC Voltage";
			// 
			// freeText2
			// 
			this.freeText2.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText2.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText2.Location = new NxtControl.Drawing.PointF(40D, 77D);
			this.freeText2.Name = "freeText2";
			this.freeText2.Text = "DC Current";
			// 
			// freeText3
			// 
			this.freeText3.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText3.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText3.Location = new NxtControl.Drawing.PointF(40D, 107D);
			this.freeText3.Name = "freeText3";
			this.freeText3.Text = "DC Power";
			// 
			// txtStatus
			// 
			this.txtStatus.AngleIgnore = true;
			this.txtStatus.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtStatus.Bounds = new NxtControl.Drawing.RectF(((float)(120D)), ((float)(17D)), ((float)(92D)), ((float)(14D)));
			this.txtStatus.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtStatus.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtStatus.FontScale = true;
			this.txtStatus.Name = "txtStatus";
			this.txtStatus.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fAlarm", NxtControl.GuiFramework.MouseButtonType.Click));
			this.txtStatus.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtStatus.Text = "Healthy";
			this.txtStatus.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtStatus.TextAutoSizeHorizontalOffset = 10;
			this.txtStatus.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtStatus.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText7
			// 
			this.freeText7.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText7.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText7.Location = new NxtControl.Drawing.PointF(40D, 15D);
			this.freeText7.Name = "freeText7";
			this.freeText7.Text = "Status";
			// 
			// txtVAC
			// 
			this.txtVAC.AngleIgnore = true;
			this.txtVAC.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtVAC.Bounds = new NxtControl.Drawing.RectF(((float)(120D)), ((float)(149D)), ((float)(92D)), ((float)(14D)));
			this.txtVAC.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtVAC.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtVAC.FontScale = true;
			this.txtVAC.Name = "txtVAC";
			this.txtVAC.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtVAC.Text = "400 V";
			this.txtVAC.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtVAC.TextAutoSizeHorizontalOffset = 10;
			this.txtVAC.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtVAC.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText8
			// 
			this.freeText8.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText8.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText8.Location = new NxtControl.Drawing.PointF(40D, 147D);
			this.freeText8.Name = "freeText8";
			this.freeText8.Text = "AC Voltage";
			// 
			// rectangle1
			// 
			this.rectangle1.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(16D)), ((float)(16D)), ((float)(16D)));
			this.rectangle1.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle1.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle1.ImageBytes = resources.GetString("rectangle1.ImageBytes");
			this.rectangle1.Name = "rectangle1";
			this.rectangle1.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle2
			// 
			this.rectangle2.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(48D)), ((float)(16D)), ((float)(16D)));
			this.rectangle2.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle2.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle2.ImageBytes = resources.GetString("rectangle2.ImageBytes");
			this.rectangle2.Name = "rectangle2";
			this.rectangle2.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle3
			// 
			this.rectangle3.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(78D)), ((float)(16D)), ((float)(16D)));
			this.rectangle3.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle3.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle3.ImageBytes = resources.GetString("rectangle3.ImageBytes");
			this.rectangle3.Name = "rectangle3";
			this.rectangle3.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle4
			// 
			this.rectangle4.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(108D)), ((float)(16D)), ((float)(16D)));
			this.rectangle4.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle4.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle4.ImageBytes = resources.GetString("rectangle4.ImageBytes");
			this.rectangle4.Name = "rectangle4";
			this.rectangle4.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle5
			// 
			this.rectangle5.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(148D)), ((float)(16D)), ((float)(16D)));
			this.rectangle5.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle5.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle5.ImageBytes = resources.GetString("rectangle5.ImageBytes");
			this.rectangle5.Name = "rectangle5";
			this.rectangle5.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// txtIAC
			// 
			this.txtIAC.AngleIgnore = true;
			this.txtIAC.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtIAC.Bounds = new NxtControl.Drawing.RectF(((float)(120D)), ((float)(179D)), ((float)(92D)), ((float)(14D)));
			this.txtIAC.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtIAC.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtIAC.FontScale = true;
			this.txtIAC.Name = "txtIAC";
			this.txtIAC.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtIAC.Text = "6524 A";
			this.txtIAC.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtIAC.TextAutoSizeHorizontalOffset = 10;
			this.txtIAC.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtIAC.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText5
			// 
			this.freeText5.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText5.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText5.Location = new NxtControl.Drawing.PointF(40D, 177D);
			this.freeText5.Name = "freeText5";
			this.freeText5.Text = "AC Current";
			// 
			// rectangle6
			// 
			this.rectangle6.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(178D)), ((float)(16D)), ((float)(16D)));
			this.rectangle6.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle6.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle6.ImageBytes = resources.GetString("rectangle6.ImageBytes");
			this.rectangle6.Name = "rectangle6";
			this.rectangle6.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// txtPAC
			// 
			this.txtPAC.AngleIgnore = true;
			this.txtPAC.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtPAC.Bounds = new NxtControl.Drawing.RectF(((float)(120D)), ((float)(209D)), ((float)(92D)), ((float)(14D)));
			this.txtPAC.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtPAC.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtPAC.FontScale = true;
			this.txtPAC.Name = "txtPAC";
			this.txtPAC.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtPAC.Text = "4.52 MW";
			this.txtPAC.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtPAC.TextAutoSizeHorizontalOffset = 10;
			this.txtPAC.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtPAC.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText6
			// 
			this.freeText6.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText6.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText6.Location = new NxtControl.Drawing.PointF(40D, 207D);
			this.freeText6.Name = "freeText6";
			this.freeText6.Text = "AC Power";
			// 
			// rectangle7
			// 
			this.rectangle7.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(208D)), ((float)(16D)), ((float)(16D)));
			this.rectangle7.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle7.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle7.ImageBytes = resources.GetString("rectangle7.ImageBytes");
			this.rectangle7.Name = "rectangle7";
			this.rectangle7.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// txtQAC
			// 
			this.txtQAC.AngleIgnore = true;
			this.txtQAC.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtQAC.Bounds = new NxtControl.Drawing.RectF(((float)(120D)), ((float)(239D)), ((float)(92D)), ((float)(14D)));
			this.txtQAC.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtQAC.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtQAC.FontScale = true;
			this.txtQAC.Name = "txtQAC";
			this.txtQAC.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtQAC.Text = "0.00 MVAr";
			this.txtQAC.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtQAC.TextAutoSizeHorizontalOffset = 10;
			this.txtQAC.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtQAC.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText9
			// 
			this.freeText9.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText9.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText9.Location = new NxtControl.Drawing.PointF(40D, 237D);
			this.freeText9.Name = "freeText9";
			this.freeText9.Text = "Reative Pwr";
			// 
			// rectangle8
			// 
			this.rectangle8.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(238D)), ((float)(16D)), ((float)(16D)));
			this.rectangle8.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle8.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle8.ImageBytes = resources.GetString("rectangle8.ImageBytes");
			this.rectangle8.Name = "rectangle8";
			this.rectangle8.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// freeText4
			// 
			this.freeText4.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText4.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Italic);
			this.freeText4.Location = new NxtControl.Drawing.PointF(13D, 271D);
			this.freeText4.Name = "freeText4";
			this.freeText4.Text = "Connector Info.";
			// 
			// rectBtnDC
			// 
			this.rectBtnDC.Bounds = new NxtControl.Drawing.RectF(((float)(8D)), ((float)(42D)), ((float)(211D)), ((float)(89D)));
			this.rectBtnDC.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("Transparent"));
			this.rectBtnDC.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectBtnDC.Name = "rectBtnDC";
			this.rectBtnDC.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(114)), ((byte)(110)), ((byte)(106))), 1F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Flat, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Round, null);
			this.rectBtnDC.Radius = 10D;
			this.rectBtnDC.MouseEnter += new System.EventHandler(this.RectBtnDCMouseEnter);
			this.rectBtnDC.MouseLeave += new System.EventHandler(this.RectBtnDCMouseLeave);
			// 
			// rectBtnAC
			// 
			this.rectBtnAC.Bounds = new NxtControl.Drawing.RectF(((float)(8D)), ((float)(139D)), ((float)(211D)), ((float)(123D)));
			this.rectBtnAC.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("Transparent"));
			this.rectBtnAC.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectBtnAC.Name = "rectBtnAC";
			this.rectBtnAC.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(114)), ((byte)(110)), ((byte)(106))), 1F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Flat, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Round, null);
			this.rectBtnAC.Radius = 10D;
			this.rectBtnAC.MouseEnter += new System.EventHandler(this.RectBtnACMouseEnter);
			this.rectBtnAC.MouseLeave += new System.EventHandler(this.RectBtnACMouseLeave);
			// 
			// IALM
			// 
			this.IALM.BeginInit();
			this.IALM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 148D, 174D);
			this.IALM.Name = "IALM";
			this.IALM.SecurityToken = ((uint)(4294967295u));
			this.IALM.TagName = "IALM";
			this.IALM.Val = false;
			this.IALM.EndInit();
			// 
			// IAVL
			// 
			this.IAVL.BeginInit();
			this.IAVL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 82D, 180D);
			this.IAVL.Name = "IAVL";
			this.IAVL.SecurityToken = ((uint)(4294967295u));
			this.IAVL.TagName = "IAVL";
			this.IAVL.Val = false;
			this.IAVL.EndInit();
			// 
			// QLT
			// 
			this.QLT.BeginInit();
			this.QLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 167D, 200D);
			this.QLT.Name = "QLT";
			this.QLT.SecurityToken = ((uint)(4294967295u));
			this.QLT.TagName = "QLT";
			this.QLT.Val = false;
			this.QLT.EndInit();
			// 
			// IFLT
			// 
			this.IFLT.BeginInit();
			this.IFLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 106D, 191D);
			this.IFLT.Name = "IFLT";
			this.IFLT.SecurityToken = ((uint)(4294967295u));
			this.IFLT.TagName = "IFLT";
			this.IFLT.Val = false;
			this.IFLT.EndInit();
			// 
			// IRUN
			// 
			this.IRUN.BeginInit();
			this.IRUN.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 130D, 180D);
			this.IRUN.Name = "IRUN";
			this.IRUN.SecurityToken = ((uint)(4294967295u));
			this.IRUN.TagName = "IRUN";
			this.IRUN.Val = false;
			this.IRUN.EndInit();
			// 
			// PAC
			// 
			this.PAC.BeginInit();
			this.PAC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 109D, 185D);
			this.PAC.Name = "PAC";
			this.PAC.SecurityToken = ((uint)(4294967295u));
			this.PAC.TagName = "PAC";
			this.PAC.Val = 0F;
			this.PAC.ValDecimalPlaces = ((byte)(0));
			this.PAC.ValMaximum = 0F;
			this.PAC.ValMinimum = 0F;
			this.PAC.ValUnits = null;
			this.PAC.EndInit();
			// 
			// PDC
			// 
			this.PDC.BeginInit();
			this.PDC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 70D, 226D);
			this.PDC.Name = "PDC";
			this.PDC.SecurityToken = ((uint)(4294967295u));
			this.PDC.TagName = "PDC";
			this.PDC.Val = 0F;
			this.PDC.ValDecimalPlaces = ((byte)(0));
			this.PDC.ValMaximum = 0F;
			this.PDC.ValMinimum = 0F;
			this.PDC.ValUnits = null;
			this.PDC.EndInit();
			// 
			// VAC
			// 
			this.VAC.BeginInit();
			this.VAC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 114D, 212D);
			this.VAC.Name = "VAC";
			this.VAC.SecurityToken = ((uint)(4294967295u));
			this.VAC.TagName = "VAC";
			this.VAC.Val = 0F;
			this.VAC.ValDecimalPlaces = ((byte)(0));
			this.VAC.ValMaximum = 0F;
			this.VAC.ValMinimum = 0F;
			this.VAC.ValUnits = null;
			this.VAC.EndInit();
			// 
			// VDC
			// 
			this.VDC.BeginInit();
			this.VDC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 68D, 193D);
			this.VDC.Name = "VDC";
			this.VDC.SecurityToken = ((uint)(4294967295u));
			this.VDC.TagName = "VDC";
			this.VDC.Val = 0F;
			this.VDC.ValDecimalPlaces = ((byte)(0));
			this.VDC.ValMaximum = 0F;
			this.VDC.ValMinimum = 0F;
			this.VDC.ValUnits = null;
			this.VDC.EndInit();
			// 
			// IAC
			// 
			this.IAC.BeginInit();
			this.IAC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 40D, 179D);
			this.IAC.Name = "IAC";
			this.IAC.SecurityToken = ((uint)(4294967295u));
			this.IAC.TagName = "IAC";
			this.IAC.Val = 0F;
			this.IAC.ValDecimalPlaces = ((byte)(0));
			this.IAC.ValMaximum = 0F;
			this.IAC.ValMinimum = 0F;
			this.IAC.ValUnits = null;
			this.IAC.EndInit();
			// 
			// IDC
			// 
			this.IDC.BeginInit();
			this.IDC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 59D, 187D);
			this.IDC.Name = "IDC";
			this.IDC.SecurityToken = ((uint)(4294967295u));
			this.IDC.TagName = "IDC";
			this.IDC.Val = 0F;
			this.IDC.ValDecimalPlaces = ((byte)(0));
			this.IDC.ValMaximum = 0F;
			this.IDC.ValMinimum = 0F;
			this.IDC.ValUnits = null;
			this.IDC.EndInit();
			// 
			// QAC
			// 
			this.QAC.BeginInit();
			this.QAC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 174D, 212D);
			this.QAC.Name = "QAC";
			this.QAC.SecurityToken = ((uint)(4294967295u));
			this.QAC.TagName = "QAC";
			this.QAC.Val = 0F;
			this.QAC.ValDecimalPlaces = ((byte)(0));
			this.QAC.ValMaximum = 0F;
			this.QAC.ValMinimum = 0F;
			this.QAC.ValUnits = null;
			this.QAC.EndInit();
			// 
			// sButtonNavDemo2
			// 
			this.sButtonNavDemo2.BeginInit();
			this.sButtonNavDemo2.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 201D, 273D);
			this.sButtonNavDemo2.Name = "sButtonNavDemo2";
			this.sButtonNavDemo2.SecurityToken = ((uint)(4294967295u));
			this.sButtonNavDemo2.TagName = "Inverter.Broadcaster_v1_0";
			this.sButtonNavDemo2.EndInit();
			// 
			// CURT
			// 
			this.CURT.BeginInit();
			this.CURT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 159D, 138D);
			this.CURT.Name = "CURT";
			this.CURT.SecurityToken = ((uint)(4294967295u));
			this.CURT.TagName = "CURT";
			this.CURT.Val = 0F;
			this.CURT.ValDecimalPlaces = ((byte)(0));
			this.CURT.ValMaximum = 0F;
			this.CURT.ValMinimum = 0F;
			this.CURT.ValUnits = null;
			this.CURT.EndInit();
			// 
			// fMain
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(228D)), ((float)(300D)));
			this.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(3)), ((byte)(22)), ((byte)(20))));
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.txtStatus,
			this.freeText7,
			this.rectangle1,
			this.freeText4,
			this.txtVDC,
			this.txtIDC,
			this.txtPDC,
			this.freeText1,
			this.freeText2,
			this.freeText3,
			this.rectangle2,
			this.rectangle3,
			this.rectangle4,
			this.txtVAC,
			this.freeText8,
			this.rectangle5,
			this.txtIAC,
			this.freeText5,
			this.rectangle6,
			this.txtPAC,
			this.freeText6,
			this.rectangle7,
			this.txtQAC,
			this.freeText9,
			this.rectangle8,
			this.IALM,
			this.IAVL,
			this.QLT,
			this.IFLT,
			this.IRUN,
			this.PAC,
			this.PDC,
			this.VAC,
			this.VDC,
			this.IAC,
			this.IDC,
			this.QAC,
			this.rectBtnAC,
			this.rectBtnDC,
			this.sButtonNavDemo2,
			this.CURT});
			this.Size = new System.Drawing.Size(228, 300);

		}
		private NxtControl.GuiFramework.Label txtVDC;
		private NxtControl.GuiFramework.Label txtIDC;
		private NxtControl.GuiFramework.Label txtPDC;
		private NxtControl.GuiFramework.FreeText freeText1;
		private NxtControl.GuiFramework.FreeText freeText2;
		private NxtControl.GuiFramework.FreeText freeText3;
		private NxtControl.GuiFramework.Label txtStatus;
		private NxtControl.GuiFramework.FreeText freeText7;
		private NxtControl.GuiFramework.Label txtVAC;
		private NxtControl.GuiFramework.FreeText freeText8;
		private NxtControl.GuiFramework.Rectangle rectangle1;
		private NxtControl.GuiFramework.Rectangle rectangle2;
		private NxtControl.GuiFramework.Rectangle rectangle3;
		private NxtControl.GuiFramework.Rectangle rectangle4;
		private NxtControl.GuiFramework.Rectangle rectangle5;
		private NxtControl.GuiFramework.Label txtIAC;
		private NxtControl.GuiFramework.FreeText freeText5;
		private NxtControl.GuiFramework.Rectangle rectangle6;
		private NxtControl.GuiFramework.Label txtPAC;
		private NxtControl.GuiFramework.FreeText freeText6;
		private NxtControl.GuiFramework.Rectangle rectangle7;
		private NxtControl.GuiFramework.Label txtQAC;
		private NxtControl.GuiFramework.FreeText freeText9;
		private NxtControl.GuiFramework.Rectangle rectangle8;
		private NxtControl.GuiFramework.FreeText freeText4;
		private NxtControl.GuiFramework.RoundedRectangle rectBtnDC;
		private NxtControl.GuiFramework.RoundedRectangle rectBtnAC;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IALM;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IAVL;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged QLT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IFLT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IRUN;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged PAC;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged PDC;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged VAC;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged VDC;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged IAC;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged IDC;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged QAC;
		private SE.Agile.Symbols.Broadcaster_v1_0.sButtonNavDemo sButtonNavDemo2;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged CURT;
		#endregion
	}
}
