﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/27/2026
 * Time: 10:26 PM
 * 
 */

using System;
using NxtControl.GuiFramework;
using System.ComponentModel;
using NxtControl.Drawing;
using HMI.Main.SupportClasses;

namespace HMI.Main.Graphics
{
	/// <summary>
	/// Description of sNavigation.
	/// </summary>
	public partial class sNavigation : NxtControl.GuiFramework.GraphicSymbol
	{
		public delegate void BoolValueChangedEventHandler(object sender, bool value);
		public event BoolValueChangedEventHandler StateChange;

		private string _buttonText = "PageName";
		private bool _value = false;
		private bool _isHover = false;

		private Color _offBackgroundColor = SolarTheme.Surface.RaisedPanel;
		private Color _offBorderColor = SolarTheme.Border.Normal;

		private Color _hoverBackgroundColor = SolarTheme.Surface.Hover;
		private Color _hoverBorderColor = SolarTheme.Border.Hover;

		private Color _onBackgroundColor = SolarTheme.Surface.Selected;
		private Color _onBorderColor = SolarTheme.Border.Selected;
		
		public sNavigation()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			UpdateUi();
		}
		
		// -----------------------------
		// Public Properties
		// -----------------------------
		

		[DefaultValue("Manual Mode")]
		[RefreshProperties(RefreshProperties.All)]
		[Category("Button")]
		[DisplayName("Text")]
		[Description("Text displayed on the button.")]
		public string ButtonText
		{
			get { return _buttonText; }
			set
			{
				_buttonText = value;
				UpdateUi();
			}
		}

		[DefaultValue(false)]
		[RefreshProperties(RefreshProperties.All)]
		[Category("Button")]
		[DisplayName("Value")]
		[Description("Boolean state of the button. False = OFF, True = ON.")]
		public bool Value
		{
			get { return _value; }
			set
			{
				SetValue(value, false);
			}
		}

		[RefreshProperties(RefreshProperties.All)]
		[Category("Button Colors - OFF")]
		[DisplayName("OFF Background")]
		[Description("Background color when the button is OFF.")]
		public Color OffBackgroundColor
		{
			get { return _offBackgroundColor; }
			set
			{
				_offBackgroundColor = value;
				UpdateUi();
			}
		}

		[RefreshProperties(RefreshProperties.All)]
		[Category("Button Colors - OFF")]
		[DisplayName("OFF Border")]
		[Description("Border color when the button is OFF.")]
		public Color OffBorderColor
		{
			get { return _offBorderColor; }
			set
			{
				_offBorderColor = value;
				UpdateUi();
			}
		}

		[RefreshProperties(RefreshProperties.All)]
		[Category("Button Colors - Hover")]
		[DisplayName("Hover Background")]
		[Description("Background color when mouse is hovering over the button.")]
		public Color HoverBackgroundColor
		{
			get { return _hoverBackgroundColor; }
			set
			{
				_hoverBackgroundColor = value;
				UpdateUi();
			}
		}

		[RefreshProperties(RefreshProperties.All)]
		[Category("Button Colors - Hover")]
		[DisplayName("Hover Border")]
		[Description("Border color when mouse is hovering over the button.")]
		public Color HoverBorderColor
		{
			get { return _hoverBorderColor; }
			set
			{
				_hoverBorderColor = value;
				UpdateUi();
			}
		}

		[RefreshProperties(RefreshProperties.All)]
		[Category("Button Colors - ON")]
		[DisplayName("ON Background")]
		[Description("Background color when the button is ON.")]
		public Color OnBackgroundColor
		{
			get { return _onBackgroundColor; }
			set
			{
				_onBackgroundColor = value;
				UpdateUi();
			}
		}

		[RefreshProperties(RefreshProperties.All)]
		[Category("Button Colors - ON")]
		[DisplayName("ON Border")]
		[Description("Border color when the button is ON.")]
		public Color OnBorderColor
		{
			get { return _onBorderColor; }
			set
			{
				_onBorderColor = value;
				UpdateUi();
			}
		}

		// -----------------------------
		// Designer Events
		// -----------------------------

		void ButtonDefaultMouseEnter(object sender, EventArgs e)
		{
			_isHover = true;
			UpdateUi();
		}

		void ButtonDefaultMouseLeave(object sender, EventArgs e)
		{
			_isHover = false;
			UpdateUi();
		}

		void ButtonDefaultClick(object sender, EventArgs e)
		{
			SetValue(!_value, true);
		}

		// -----------------------------
		// Internal Logic
		// -----------------------------

		private void SetValue(bool value, bool notify)
		{
			_value = value;
			UpdateUi();

			if (notify && StateChange != null)
			{
				StateChange(this, _value);
			}
		}

		private void UpdateUi()
		{
			// Text
			buttonDefault.Text = _buttonText;

			// Visual state
			if (_isHover)
			{
				buttonDefault.BrushColor = _hoverBackgroundColor;
				SetBorderColor(_hoverBorderColor);
				return;
			}

			if (_value)
			{
				buttonDefault.BrushColor = _onBackgroundColor;
				SetBorderColor(_onBorderColor);
			}
			else
			{
				buttonDefault.BrushColor = _offBackgroundColor;
				SetBorderColor(_offBorderColor);
			}
		}

		private void SetBorderColor(Color color)
		{
			buttonDefault.PenColor = color;
		}
	}
}
