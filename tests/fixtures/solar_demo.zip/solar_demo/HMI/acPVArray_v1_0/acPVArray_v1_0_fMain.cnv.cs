/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/1/2026
 * Time: 12:57 PM
 */

using System;
using NxtControl.GuiFramework;
using NxtControl.Drawing;
using HMI.Main.SupportClasses;

namespace HMI.Main.Faceplates.acPVArray_v1_0
{
	public partial class fMain :
		NxtControl.GuiFramework.HMIFaceplate
	{
		private const double IRR_WARNING_LIMIT = 400.0;

		public fMain()
		{
			InitializeComponent();
			AttachEvents();
			UpdateDisplay();
		}

		private void AttachEvents()
		{
			IAVL.OnValChanged += OnPVArrayValueChanged;
			IALM.OnValChanged += OnPVArrayValueChanged;
			IFLT.OnValChanged += OnPVArrayValueChanged;
			QLT.OnValChanged += OnPVArrayValueChanged;

			TAMB.OnValChanged += OnPVArrayValueChanged;
			VDC.OnValChanged += OnPVArrayValueChanged;
			IDC.OnValChanged += OnPVArrayValueChanged;
			EGEN.OnValChanged += OnPVArrayValueChanged;
			IRR.OnValChanged += OnPVArrayValueChanged;

			REQ_Fired += REQ_Fired_EventHandler;
		}

		private void OnPVArrayValueChanged(
			object sender,
			EventArgs e)
		{
			UpdateDisplay();
		}

		private void UpdateDisplay()
		{
			SolarTheme.EquipmentState status =
				SolarStatusHelper.ResolveStandard(
					QLT.Val,
					IFLT.Val,
					IALM.Val,
					IAVL.Val,
					SolarTheme.EquipmentState.Healthy,
					SolarTheme.EquipmentState.Standby);

			double irradiance =
				HmiValueHelper.ToDouble(IRR.Val);

			Color irradianceColor =
				irradiance < IRR_WARNING_LIMIT
					? SolarTheme.Status.Warning
					: SolarTheme.Text.Primary;

			HmiDisplayHelper.DisplayData displayData =
				new HmiDisplayHelper.DisplayData();

			displayData.Status = status;
			displayData.StatusText =
				SolarStatusHelper.GetStatusText(status);

			displayData.StatusLabel = txtStatus;

			displayData.Items =
				new HmiDisplayHelper.DisplayItem[]
				{
					HmiDisplayHelper.CreateValue(
						txtIRR,
						IRR.Val,
						"0",
						" W/m²",
						irradianceColor),

					HmiDisplayHelper.CreateValue(
						txtTAMB,
						TAMB.Val,
						"0",
						" °C",
						SolarTheme.Text.Primary),

					HmiDisplayHelper.CreateValue(
						txtVDC,
						VDC.Val,
						"0",
						" V",
						SolarTheme.Text.Primary),

					HmiDisplayHelper.CreateValue(
						txtIDC,
						IDC.Val,
						"0",
						" A",
						SolarTheme.Text.Primary),

					HmiDisplayHelper.CreateValue(
						txtEGEN,
						EGEN.Val,
						"0.00",
						" MWh",
						SolarTheme.Text.Primary)
				};

			HmiDisplayHelper.Apply(displayData);
		}

		private void REQ_Fired_EventHandler(
			object sender,
			HMI.Main.Symbols.acPVArray_v1_0.REQEventArgs e)
		{
			Title = HmiValueHelper.SafeText(
				e.AssetName,
				"PV Array");

			UpdateDisplay();
		}
	}
}