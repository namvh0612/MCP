/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 6/30/2026
 * Time: 4:29 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace HMI.Main.Symbols.acPVArray_v1_0
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sDefault
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(sDefault));
			this.STRON = new SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged();
			this.STRTOT = new SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged();
			this.TMOD = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.rectangle1 = new NxtControl.GuiFramework.Rectangle();
			this.rectBtn = new NxtControl.GuiFramework.RoundedRectangle();
			this.rectBase = new NxtControl.GuiFramework.RoundedRectangle();
			this.lblSymbol = new NxtControl.GuiFramework.Label();
			this.txtStatus = new NxtControl.GuiFramework.Label();
			this.indStatus = new NxtControl.GuiFramework.Ellipse();
			this.line1 = new NxtControl.GuiFramework.Line();
			this.txtStrings = new NxtControl.GuiFramework.Label();
			this.txtModuleTemp = new NxtControl.GuiFramework.Label();
			this.txtPDC = new NxtControl.GuiFramework.Label();
			this.freeText4 = new NxtControl.GuiFramework.FreeText();
			this.freeText5 = new NxtControl.GuiFramework.FreeText();
			this.freeText6 = new NxtControl.GuiFramework.FreeText();
			this.line2 = new NxtControl.GuiFramework.Line();
			this.line3 = new NxtControl.GuiFramework.Line();
			this.PDC = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.IALM = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IAVL = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IFLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.QLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			// 
			// STRON
			// 
			this.STRON.BeginInit();
			this.STRON.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 560D, 215D);
			this.STRON.Name = "STRON";
			this.STRON.SecurityToken = ((uint)(4294967295u));
			this.STRON.TagName = "STRON";
			this.STRON.Val = ((short)(0));
			this.STRON.ValMaximum = ((short)(0));
			this.STRON.ValMinimum = ((short)(0));
			this.STRON.ValUnits = null;
			this.STRON.EndInit();
			// 
			// STRTOT
			// 
			this.STRTOT.BeginInit();
			this.STRTOT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 522D, 250D);
			this.STRTOT.Name = "STRTOT";
			this.STRTOT.SecurityToken = ((uint)(4294967295u));
			this.STRTOT.TagName = "STRTOT";
			this.STRTOT.Val = ((short)(0));
			this.STRTOT.ValMaximum = ((short)(0));
			this.STRTOT.ValMinimum = ((short)(0));
			this.STRTOT.ValUnits = null;
			this.STRTOT.EndInit();
			// 
			// TMOD
			// 
			this.TMOD.BeginInit();
			this.TMOD.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 410D, 280D);
			this.TMOD.Name = "TMOD";
			this.TMOD.SecurityToken = ((uint)(4294967295u));
			this.TMOD.TagName = "TMOD";
			this.TMOD.Val = 0F;
			this.TMOD.ValDecimalPlaces = ((byte)(0));
			this.TMOD.ValMaximum = 0F;
			this.TMOD.ValMinimum = 0F;
			this.TMOD.ValUnits = null;
			this.TMOD.EndInit();
			// 
			// rectangle1
			// 
			this.rectangle1.Bounds = new NxtControl.Drawing.RectF(((float)(9D)), ((float)(56D)), ((float)(223D)), ((float)(74D)));
			this.rectangle1.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.rectangle1.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle1.ImageBytes = resources.GetString("rectangle1.ImageBytes");
			this.rectangle1.Name = "rectangle1";
			this.rectangle1.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectBtn
			// 
			this.rectBtn.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(240D)), ((float)(250D)));
			this.rectBtn.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("Transparent"));
			this.rectBtn.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectBtn.Name = "rectBtn";
			this.rectBtn.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fMain", NxtControl.GuiFramework.MouseButtonType.Click));
			this.rectBtn.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(28)), ((byte)(78)), ((byte)(71))), 1F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Flat, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Round, null);
			this.rectBtn.Radius = 10D;
			this.rectBtn.MouseEnter += new System.EventHandler(this.RectBtnMouseEnter);
			this.rectBtn.MouseLeave += new System.EventHandler(this.RectBtnMouseLeave);
			// 
			// rectBase
			// 
			this.rectBase.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(240D)), ((float)(250D)));
			this.rectBase.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(3)), ((byte)(22)), ((byte)(20))));
			this.rectBase.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectBase.Name = "rectBase";
			this.rectBase.Pen = new NxtControl.Drawing.Pen("Transparent");
			this.rectBase.Radius = 10D;
			// 
			// lblSymbol
			// 
			this.lblSymbol.AngleIgnore = true;
			this.lblSymbol.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.lblSymbol.Bounds = new NxtControl.Drawing.RectF(((float)(11D)), ((float)(12D)), ((float)(113D)), ((float)(24D)));
			this.lblSymbol.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.lblSymbol.Font = new NxtControl.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
			this.lblSymbol.FontScale = true;
			this.lblSymbol.Name = "lblSymbol";
			this.lblSymbol.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.lblSymbol.Text = "PV Array";
			this.lblSymbol.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.lblSymbol.TextAutoSizeHorizontalOffset = 10;
			this.lblSymbol.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.lblSymbol.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// txtStatus
			// 
			this.txtStatus.AngleIgnore = true;
			this.txtStatus.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtStatus.Bounds = new NxtControl.Drawing.RectF(((float)(178D)), ((float)(16D)), ((float)(53D)), ((float)(16D)));
			this.txtStatus.Brush = new NxtControl.Drawing.Brush(true);
			this.txtStatus.Font = new NxtControl.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular);
			this.txtStatus.FontScale = true;
			this.txtStatus.Name = "txtStatus";
			this.txtStatus.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtStatus.Text = "Healthy";
			this.txtStatus.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.txtStatus.TextAutoSizeHorizontalOffset = 10;
			this.txtStatus.TextColor = new NxtControl.Drawing.Color(((byte)(120)), ((byte)(249)), ((byte)(141)));
			this.txtStatus.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// indStatus
			// 
			this.indStatus.Bounds = new NxtControl.Drawing.RectF(((float)(166D)), ((float)(19D)), ((float)(10D)), ((float)(10D)));
			this.indStatus.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(120)), ((byte)(249)), ((byte)(141))));
			this.indStatus.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.indStatus.Name = "indStatus";
			this.indStatus.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// line1
			// 
			this.line1.EndPoint = new NxtControl.Drawing.PointF(239D, 151D);
			this.line1.Name = "line1";
			this.line1.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(20)), ((byte)(54)), ((byte)(45))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line1.StartPoint = new NxtControl.Drawing.PointF(2D, 151D);
			// 
			// txtStrings
			// 
			this.txtStrings.AngleIgnore = true;
			this.txtStrings.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtStrings.Bounds = new NxtControl.Drawing.RectF(((float)(131D)), ((float)(157D)), ((float)(96D)), ((float)(20D)));
			this.txtStrings.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtStrings.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtStrings.FontScale = true;
			this.txtStrings.Name = "txtStrings";
			this.txtStrings.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtStrings.Text = "23/24";
			this.txtStrings.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtStrings.TextAutoSizeHorizontalOffset = 10;
			this.txtStrings.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtStrings.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// txtModuleTemp
			// 
			this.txtModuleTemp.AngleIgnore = true;
			this.txtModuleTemp.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtModuleTemp.Bounds = new NxtControl.Drawing.RectF(((float)(131D)), ((float)(189D)), ((float)(96D)), ((float)(20D)));
			this.txtModuleTemp.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtModuleTemp.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtModuleTemp.FontScale = true;
			this.txtModuleTemp.Name = "txtModuleTemp";
			this.txtModuleTemp.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtModuleTemp.Text = "42 °C";
			this.txtModuleTemp.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtModuleTemp.TextAutoSizeHorizontalOffset = 10;
			this.txtModuleTemp.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtModuleTemp.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// txtPDC
			// 
			this.txtPDC.AngleIgnore = true;
			this.txtPDC.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtPDC.Bounds = new NxtControl.Drawing.RectF(((float)(131D)), ((float)(220D)), ((float)(96D)), ((float)(20D)));
			this.txtPDC.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtPDC.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtPDC.FontScale = true;
			this.txtPDC.Name = "txtPDC";
			this.txtPDC.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtPDC.Text = "5.00 MW";
			this.txtPDC.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtPDC.TextAutoSizeHorizontalOffset = 10;
			this.txtPDC.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtPDC.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText4
			// 
			this.freeText4.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText4.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText4.Location = new NxtControl.Drawing.PointF(11D, 158D);
			this.freeText4.Name = "freeText4";
			this.freeText4.Text = "Strings Online";
			// 
			// freeText5
			// 
			this.freeText5.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText5.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText5.Location = new NxtControl.Drawing.PointF(11D, 190D);
			this.freeText5.Name = "freeText5";
			this.freeText5.Text = "Module Temp.";
			// 
			// freeText6
			// 
			this.freeText6.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText6.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText6.Location = new NxtControl.Drawing.PointF(11D, 221D);
			this.freeText6.Name = "freeText6";
			this.freeText6.Text = "DC Power";
			// 
			// line2
			// 
			this.line2.EndPoint = new NxtControl.Drawing.PointF(239D, 183D);
			this.line2.Name = "line2";
			this.line2.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(20)), ((byte)(54)), ((byte)(45))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line2.StartPoint = new NxtControl.Drawing.PointF(2D, 183D);
			// 
			// line3
			// 
			this.line3.EndPoint = new NxtControl.Drawing.PointF(239D, 214D);
			this.line3.Name = "line3";
			this.line3.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(20)), ((byte)(54)), ((byte)(45))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line3.StartPoint = new NxtControl.Drawing.PointF(2D, 214D);
			// 
			// PDC
			// 
			this.PDC.BeginInit();
			this.PDC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 203D, 227D);
			this.PDC.Name = "PDC";
			this.PDC.SecurityToken = ((uint)(4294967295u));
			this.PDC.TagName = "PDC";
			this.PDC.Val = 0F;
			this.PDC.ValDecimalPlaces = ((byte)(0));
			this.PDC.ValMaximum = 0F;
			this.PDC.ValMinimum = 0F;
			this.PDC.ValUnits = null;
			this.PDC.EndInit();
			// 
			// IALM
			// 
			this.IALM.BeginInit();
			this.IALM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 255D, 194D);
			this.IALM.Name = "IALM";
			this.IALM.SecurityToken = ((uint)(4294967295u));
			this.IALM.TagName = "IALM";
			this.IALM.Val = false;
			this.IALM.EndInit();
			// 
			// IAVL
			// 
			this.IAVL.BeginInit();
			this.IAVL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 239D, 201D);
			this.IAVL.Name = "IAVL";
			this.IAVL.SecurityToken = ((uint)(4294967295u));
			this.IAVL.TagName = "IAVL";
			this.IAVL.Val = false;
			this.IAVL.EndInit();
			// 
			// IFLT
			// 
			this.IFLT.BeginInit();
			this.IFLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 232D, 240D);
			this.IFLT.Name = "IFLT";
			this.IFLT.SecurityToken = ((uint)(4294967295u));
			this.IFLT.TagName = "IFLT";
			this.IFLT.Val = false;
			this.IFLT.EndInit();
			// 
			// QLT
			// 
			this.QLT.BeginInit();
			this.QLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 183D, 265D);
			this.QLT.Name = "QLT";
			this.QLT.SecurityToken = ((uint)(4294967295u));
			this.QLT.TagName = "QLT";
			this.QLT.Val = false;
			this.QLT.EndInit();
			// 
			// sDefault
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.rectBase,
			this.STRON,
			this.STRTOT,
			this.TMOD,
			this.rectangle1,
			this.lblSymbol,
			this.txtStatus,
			this.indStatus,
			this.PDC,
			this.IALM,
			this.IAVL,
			this.IFLT,
			this.QLT,
			this.txtStrings,
			this.freeText4,
			this.txtModuleTemp,
			this.freeText5,
			this.txtPDC,
			this.freeText6,
			this.line1,
			this.line2,
			this.line3,
			this.rectBtn});
			this.SymbolSize = new System.Drawing.Size(600, 400);

		}
		private SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged STRON;
		private SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged STRTOT;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged TMOD;
		private NxtControl.GuiFramework.Label lblSymbol;
		private NxtControl.GuiFramework.Rectangle rectangle1;
		private NxtControl.GuiFramework.RoundedRectangle rectBtn;
		private NxtControl.GuiFramework.RoundedRectangle rectBase;
		private NxtControl.GuiFramework.Label txtStatus;
		private NxtControl.GuiFramework.Ellipse indStatus;
		private NxtControl.GuiFramework.Line line1;
		private NxtControl.GuiFramework.Label txtStrings;
		private NxtControl.GuiFramework.Label txtModuleTemp;
		private NxtControl.GuiFramework.Label txtPDC;
		private NxtControl.GuiFramework.FreeText freeText4;
		private NxtControl.GuiFramework.FreeText freeText5;
		private NxtControl.GuiFramework.FreeText freeText6;
		private NxtControl.GuiFramework.Line line2;
		private NxtControl.GuiFramework.Line line3;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged PDC;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IALM;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IAVL;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IFLT;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged QLT;
		#endregion
	}
}