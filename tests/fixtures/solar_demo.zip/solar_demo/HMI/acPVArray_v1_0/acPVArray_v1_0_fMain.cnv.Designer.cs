/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/1/2026
 * Time: 12:57 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using NxtControl.GuiFramework;

namespace HMI.Main.Faceplates.acPVArray_v1_0
{
	/// <summary>
	/// Summary description for fMain.
	/// </summary>
	partial class fMain
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fMain));
			this.EGEN = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.IDC = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.IRR = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.PDC = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.QLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.TAMB = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.VDC = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.STRTOT = new SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged();
			this.txtTAMB = new NxtControl.GuiFramework.Label();
			this.txtVDC = new NxtControl.GuiFramework.Label();
			this.txtIDC = new NxtControl.GuiFramework.Label();
			this.freeText3 = new NxtControl.GuiFramework.FreeText();
			this.freeText4 = new NxtControl.GuiFramework.FreeText();
			this.freeText5 = new NxtControl.GuiFramework.FreeText();
			this.txtEGEN = new NxtControl.GuiFramework.Label();
			this.freeText8 = new NxtControl.GuiFramework.FreeText();
			this.txtStatus = new NxtControl.GuiFramework.Label();
			this.freeText7 = new NxtControl.GuiFramework.FreeText();
			this.rectangle1 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle2 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle3 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle4 = new NxtControl.GuiFramework.Rectangle();
			this.rectangle5 = new NxtControl.GuiFramework.Rectangle();
			this.freeText1 = new NxtControl.GuiFramework.FreeText();
			this.line3 = new NxtControl.GuiFramework.Line();
			this.sButtonNavDemo1 = new SE.Agile.Symbols.Broadcaster_v1_0.sButtonNavDemo();
			this.IALM = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IAVL = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IFLT = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.txtIRR = new NxtControl.GuiFramework.Label();
			this.freeText2 = new NxtControl.GuiFramework.FreeText();
			this.rectangle6 = new NxtControl.GuiFramework.Rectangle();
			// 
			// EGEN
			// 
			this.EGEN.BeginInit();
			this.EGEN.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 157D, 244D);
			this.EGEN.Name = "EGEN";
			this.EGEN.SecurityToken = ((uint)(4294967295u));
			this.EGEN.TagName = "EGEN";
			this.EGEN.Val = 0F;
			this.EGEN.ValDecimalPlaces = ((byte)(0));
			this.EGEN.ValMaximum = 0F;
			this.EGEN.ValMinimum = 0F;
			this.EGEN.ValUnits = null;
			this.EGEN.EndInit();
			// 
			// IDC
			// 
			this.IDC.BeginInit();
			this.IDC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 100D, 213D);
			this.IDC.Name = "IDC";
			this.IDC.SecurityToken = ((uint)(4294967295u));
			this.IDC.TagName = "IDC";
			this.IDC.Val = 0F;
			this.IDC.ValDecimalPlaces = ((byte)(0));
			this.IDC.ValMaximum = 0F;
			this.IDC.ValMinimum = 0F;
			this.IDC.ValUnits = null;
			this.IDC.EndInit();
			// 
			// IRR
			// 
			this.IRR.BeginInit();
			this.IRR.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 254D, 208D);
			this.IRR.Name = "IRR";
			this.IRR.SecurityToken = ((uint)(4294967295u));
			this.IRR.TagName = "IRR";
			this.IRR.Val = 0F;
			this.IRR.ValDecimalPlaces = ((byte)(0));
			this.IRR.ValMaximum = 0F;
			this.IRR.ValMinimum = 0F;
			this.IRR.ValUnits = null;
			this.IRR.EndInit();
			// 
			// PDC
			// 
			this.PDC.BeginInit();
			this.PDC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 367D, 115D);
			this.PDC.Name = "PDC";
			this.PDC.SecurityToken = ((uint)(4294967295u));
			this.PDC.TagName = "PDC";
			this.PDC.Val = 0F;
			this.PDC.ValDecimalPlaces = ((byte)(0));
			this.PDC.ValMaximum = 0F;
			this.PDC.ValMinimum = 0F;
			this.PDC.ValUnits = null;
			this.PDC.EndInit();
			// 
			// QLT
			// 
			this.QLT.BeginInit();
			this.QLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 240D, 227D);
			this.QLT.Name = "QLT";
			this.QLT.SecurityToken = ((uint)(4294967295u));
			this.QLT.TagName = "QLT";
			this.QLT.Val = false;
			this.QLT.EndInit();
			// 
			// TAMB
			// 
			this.TAMB.BeginInit();
			this.TAMB.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 254D, 265D);
			this.TAMB.Name = "TAMB";
			this.TAMB.SecurityToken = ((uint)(4294967295u));
			this.TAMB.TagName = "TAMB";
			this.TAMB.Val = 0F;
			this.TAMB.ValDecimalPlaces = ((byte)(0));
			this.TAMB.ValMaximum = 0F;
			this.TAMB.ValMinimum = 0F;
			this.TAMB.ValUnits = null;
			this.TAMB.EndInit();
			// 
			// VDC
			// 
			this.VDC.BeginInit();
			this.VDC.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 170D, 239D);
			this.VDC.Name = "VDC";
			this.VDC.SecurityToken = ((uint)(4294967295u));
			this.VDC.TagName = "VDC";
			this.VDC.Val = 0F;
			this.VDC.ValDecimalPlaces = ((byte)(0));
			this.VDC.ValMaximum = 0F;
			this.VDC.ValMinimum = 0F;
			this.VDC.ValUnits = null;
			this.VDC.EndInit();
			// 
			// STRTOT
			// 
			this.STRTOT.BeginInit();
			this.STRTOT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 220D, 286D);
			this.STRTOT.Name = "STRTOT";
			this.STRTOT.SecurityToken = ((uint)(4294967295u));
			this.STRTOT.TagName = "STRTOT";
			this.STRTOT.Val = ((short)(0));
			this.STRTOT.ValMaximum = ((short)(0));
			this.STRTOT.ValMinimum = ((short)(0));
			this.STRTOT.ValUnits = null;
			this.STRTOT.EndInit();
			// 
			// txtTAMB
			// 
			this.txtTAMB.AngleIgnore = true;
			this.txtTAMB.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtTAMB.Bounds = new NxtControl.Drawing.RectF(((float)(130D)), ((float)(71D)), ((float)(82D)), ((float)(26D)));
			this.txtTAMB.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtTAMB.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtTAMB.FontScale = true;
			this.txtTAMB.Name = "txtTAMB";
			this.txtTAMB.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtTAMB.Text = "35 °C";
			this.txtTAMB.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtTAMB.TextAutoSizeHorizontalOffset = 10;
			this.txtTAMB.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtTAMB.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// txtVDC
			// 
			this.txtVDC.AngleIgnore = true;
			this.txtVDC.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtVDC.Bounds = new NxtControl.Drawing.RectF(((float)(130D)), ((float)(101D)), ((float)(82D)), ((float)(26D)));
			this.txtVDC.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtVDC.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtVDC.FontScale = true;
			this.txtVDC.Name = "txtVDC";
			this.txtVDC.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtVDC.Text = "805 V";
			this.txtVDC.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtVDC.TextAutoSizeHorizontalOffset = 10;
			this.txtVDC.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtVDC.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// txtIDC
			// 
			this.txtIDC.AngleIgnore = true;
			this.txtIDC.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtIDC.Bounds = new NxtControl.Drawing.RectF(((float)(130D)), ((float)(131D)), ((float)(82D)), ((float)(26D)));
			this.txtIDC.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtIDC.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtIDC.FontScale = true;
			this.txtIDC.Name = "txtIDC";
			this.txtIDC.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtIDC.Text = "6773 A";
			this.txtIDC.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtIDC.TextAutoSizeHorizontalOffset = 10;
			this.txtIDC.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtIDC.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText3
			// 
			this.freeText3.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText3.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText3.Location = new NxtControl.Drawing.PointF(40D, 75D);
			this.freeText3.Name = "freeText3";
			this.freeText3.Text = "Ambient Temp.";
			// 
			// freeText4
			// 
			this.freeText4.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText4.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText4.Location = new NxtControl.Drawing.PointF(40D, 105D);
			this.freeText4.Name = "freeText4";
			this.freeText4.Text = "DC Bus";
			// 
			// freeText5
			// 
			this.freeText5.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText5.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText5.Location = new NxtControl.Drawing.PointF(40D, 135D);
			this.freeText5.Name = "freeText5";
			this.freeText5.Text = "DC Current";
			// 
			// txtEGEN
			// 
			this.txtEGEN.AngleIgnore = true;
			this.txtEGEN.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtEGEN.Bounds = new NxtControl.Drawing.RectF(((float)(130D)), ((float)(163D)), ((float)(82D)), ((float)(26D)));
			this.txtEGEN.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtEGEN.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtEGEN.FontScale = true;
			this.txtEGEN.Name = "txtEGEN";
			this.txtEGEN.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtEGEN.Text = "1.23 MWh";
			this.txtEGEN.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtEGEN.TextAutoSizeHorizontalOffset = 10;
			this.txtEGEN.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtEGEN.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText8
			// 
			this.freeText8.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText8.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText8.Location = new NxtControl.Drawing.PointF(40D, 167D);
			this.freeText8.Name = "freeText8";
			this.freeText8.Text = "Energy Gen.";
			// 
			// txtStatus
			// 
			this.txtStatus.AngleIgnore = true;
			this.txtStatus.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtStatus.Bounds = new NxtControl.Drawing.RectF(((float)(130D)), ((float)(11D)), ((float)(82D)), ((float)(26D)));
			this.txtStatus.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtStatus.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtStatus.FontScale = true;
			this.txtStatus.Name = "txtStatus";
			this.txtStatus.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtStatus.Text = "Normal";
			this.txtStatus.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtStatus.TextAutoSizeHorizontalOffset = 10;
			this.txtStatus.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtStatus.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText7
			// 
			this.freeText7.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText7.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText7.Location = new NxtControl.Drawing.PointF(40D, 15D);
			this.freeText7.Name = "freeText7";
			this.freeText7.Text = "Status";
			// 
			// rectangle1
			// 
			this.rectangle1.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(16D)), ((float)(16D)), ((float)(16D)));
			this.rectangle1.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle1.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle1.ImageBytes = resources.GetString("rectangle1.ImageBytes");
			this.rectangle1.Name = "rectangle1";
			this.rectangle1.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle2
			// 
			this.rectangle2.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(76D)), ((float)(16D)), ((float)(16D)));
			this.rectangle2.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle2.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle2.ImageBytes = resources.GetString("rectangle2.ImageBytes");
			this.rectangle2.Name = "rectangle2";
			this.rectangle2.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle3
			// 
			this.rectangle3.Bounds = new NxtControl.Drawing.RectF(((float)(12D)), ((float)(108D)), ((float)(16D)), ((float)(16D)));
			this.rectangle3.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle3.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle3.ImageBytes = resources.GetString("rectangle3.ImageBytes");
			this.rectangle3.Name = "rectangle3";
			this.rectangle3.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle4
			// 
			this.rectangle4.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(136D)), ((float)(16D)), ((float)(16D)));
			this.rectangle4.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle4.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle4.ImageBytes = resources.GetString("rectangle4.ImageBytes");
			this.rectangle4.Name = "rectangle4";
			this.rectangle4.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// rectangle5
			// 
			this.rectangle5.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(168D)), ((float)(16D)), ((float)(16D)));
			this.rectangle5.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle5.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle5.ImageBytes = resources.GetString("rectangle5.ImageBytes");
			this.rectangle5.Name = "rectangle5";
			this.rectangle5.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// freeText1
			// 
			this.freeText1.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText1.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Italic);
			this.freeText1.Location = new NxtControl.Drawing.PointF(14D, 205D);
			this.freeText1.Name = "freeText1";
			this.freeText1.Text = "Connector Info.";
			// 
			// line3
			// 
			this.line3.EndPoint = new NxtControl.Drawing.PointF(227D, 195D);
			this.line3.Name = "line3";
			this.line3.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(20)), ((byte)(54)), ((byte)(45))), 0.5F, NxtControl.Drawing.DashStyle.Solid, NxtControl.Drawing.LineCap.Round, NxtControl.Drawing.LineCap.Round, ((uint)(0u)), ((uint)(0u)), System.Drawing.Drawing2D.LineJoin.Miter, null);
			this.line3.StartPoint = new NxtControl.Drawing.PointF(1D, 195D);
			// 
			// sButtonNavDemo1
			// 
			this.sButtonNavDemo1.BeginInit();
			this.sButtonNavDemo1.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 198D, 206D);
			this.sButtonNavDemo1.Name = "sButtonNavDemo1";
			this.sButtonNavDemo1.SecurityToken = ((uint)(4294967295u));
			this.sButtonNavDemo1.TagName = "PVArray.Broadcaster_v1_0";
			this.sButtonNavDemo1.EndInit();
			// 
			// IALM
			// 
			this.IALM.BeginInit();
			this.IALM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 161D, 216D);
			this.IALM.Name = "IALM";
			this.IALM.SecurityToken = ((uint)(4294967295u));
			this.IALM.TagName = "IALM";
			this.IALM.Val = false;
			this.IALM.EndInit();
			// 
			// IAVL
			// 
			this.IAVL.BeginInit();
			this.IAVL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 82D, 90D);
			this.IAVL.Name = "IAVL";
			this.IAVL.SecurityToken = ((uint)(4294967295u));
			this.IAVL.TagName = "IAVL";
			this.IAVL.Val = false;
			this.IAVL.EndInit();
			// 
			// IFLT
			// 
			this.IFLT.BeginInit();
			this.IFLT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 54D, 121D);
			this.IFLT.Name = "IFLT";
			this.IFLT.SecurityToken = ((uint)(4294967295u));
			this.IFLT.TagName = "IFLT";
			this.IFLT.Val = false;
			this.IFLT.EndInit();
			// 
			// txtIRR
			// 
			this.txtIRR.AngleIgnore = true;
			this.txtIRR.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtIRR.Bounds = new NxtControl.Drawing.RectF(((float)(130D)), ((float)(41D)), ((float)(82D)), ((float)(26D)));
			this.txtIRR.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtIRR.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
			this.txtIRR.FontScale = true;
			this.txtIRR.Name = "txtIRR";
			this.txtIRR.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtIRR.Text = "800 W/m²";
			this.txtIRR.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.txtIRR.TextAutoSizeHorizontalOffset = 10;
			this.txtIRR.TextColor = new NxtControl.Drawing.Color(((byte)(240)), ((byte)(244)), ((byte)(243)));
			this.txtIRR.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// freeText2
			// 
			this.freeText2.Color = new NxtControl.Drawing.Color(((byte)(167)), ((byte)(181)), ((byte)(177)));
			this.freeText2.Font = new NxtControl.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular);
			this.freeText2.Location = new NxtControl.Drawing.PointF(40D, 45D);
			this.freeText2.Name = "freeText2";
			this.freeText2.Text = "Irradiance";
			// 
			// rectangle6
			// 
			this.rectangle6.Bounds = new NxtControl.Drawing.RectF(((float)(14D)), ((float)(46D)), ((float)(16D)), ((float)(16D)));
			this.rectangle6.Brush = new NxtControl.Drawing.Brush(true);
			this.rectangle6.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.rectangle6.ImageBytes = resources.GetString("rectangle6.ImageBytes");
			this.rectangle6.Name = "rectangle6";
			this.rectangle6.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// fMain
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(228D)), ((float)(234D)));
			this.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(3)), ((byte)(22)), ((byte)(20))));
			this.FaceplateClose = NxtControl.GuiFramework.CloseFaceplateBehavior.Automatic;
			this.FaceplateFrameType = "(none)";
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.EGEN,
			this.IALM,
			this.IDC,
			this.IRR,
			this.PDC,
			this.QLT,
			this.TAMB,
			this.VDC,
			this.STRTOT,
			this.txtTAMB,
			this.txtVDC,
			this.txtIDC,
			this.freeText3,
			this.freeText4,
			this.freeText5,
			this.txtEGEN,
			this.freeText8,
			this.rectangle2,
			this.rectangle3,
			this.rectangle4,
			this.rectangle5,
			this.freeText1,
			this.line3,
			this.sButtonNavDemo1,
			this.IAVL,
			this.IFLT,
			this.txtIRR,
			this.freeText2,
			this.rectangle6,
			this.txtStatus,
			this.freeText7,
			this.rectangle1});
			this.Size = new System.Drawing.Size(228, 234);

		}
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged EGEN;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IALM;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged IDC;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged IRR;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged PDC;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged QLT;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged TAMB;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged VDC;
		private SE.Agile.Symbols.HMI_Indication_Integer_v1_0.sValChanged STRTOT;
		private NxtControl.GuiFramework.Label txtTAMB;
		private NxtControl.GuiFramework.Label txtVDC;
		private NxtControl.GuiFramework.Label txtIDC;
		private NxtControl.GuiFramework.FreeText freeText3;
		private NxtControl.GuiFramework.FreeText freeText4;
		private NxtControl.GuiFramework.FreeText freeText5;
		private NxtControl.GuiFramework.Label txtEGEN;
		private NxtControl.GuiFramework.FreeText freeText8;
		private NxtControl.GuiFramework.Label txtStatus;
		private NxtControl.GuiFramework.FreeText freeText7;
		private NxtControl.GuiFramework.Line line3;
		private NxtControl.GuiFramework.FreeText freeText1;
		private NxtControl.GuiFramework.Rectangle rectangle1;
		private NxtControl.GuiFramework.Rectangle rectangle2;
		private NxtControl.GuiFramework.Rectangle rectangle3;
		private NxtControl.GuiFramework.Rectangle rectangle4;
		private NxtControl.GuiFramework.Rectangle rectangle5;
		private SE.Agile.Symbols.Broadcaster_v1_0.sButtonNavDemo sButtonNavDemo1;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IAVL;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IFLT;
		private NxtControl.GuiFramework.Label txtIRR;
		private NxtControl.GuiFramework.FreeText freeText2;
		private NxtControl.GuiFramework.Rectangle rectangle6;
		#endregion
	}
}
