/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/23/2026
 * Time: 11:28 PM
 */

using System;
using NxtControl.GuiFramework;
using NxtControl.Drawing;
using HMI.Main.SupportClasses;

namespace HMI.Main.Symbols.acPVArray_v1_0
{
	public partial class sIrradiance :
		NxtControl.GuiFramework.HMISymbol
	{
		private const double IRR_WARNING_LIMIT =
			400.0;

		private bool _isRectBtnHovered;

		private SolarTheme.EquipmentState _currentStatus =
			SolarTheme.EquipmentState.Unknown;

		public sIrradiance()
		{
			InitializeComponent();

			IRR.OnValChanged +=
				OnPVArrayValueChanged;

			UpdateDisplay();
		}

		private void OnPVArrayValueChanged(
			object sender,
			EventArgs e)
		{
			UpdateDisplay();
		}

		private void UpdateDisplay()
		{
			double irradiance =
				HmiValueHelper.ToDouble(IRR.Val);

			_currentStatus =
				irradiance < IRR_WARNING_LIMIT
					? SolarTheme.EquipmentState.Alarm
					: SolarTheme.EquipmentState.Healthy;

			Color valueColor =
				_currentStatus ==
				SolarTheme.EquipmentState.Warning
					? SolarTheme.Status.Warning
					: SolarTheme.Text.Primary;

			HmiDisplayHelper.DisplayData data =
				new HmiDisplayHelper.DisplayData();

			data.Status =
				_currentStatus;

			/*
			 * The same RoundedRectangle is used as
			 * both the card background and border.
			 */
			data.CardBorder =
				rectBtn;

			data.CardBackground =
				rectBtn;

			data.IsHovered =
				_isRectBtnHovered;

			data.Items =
				new HmiDisplayHelper.DisplayItem[]
				{
					HmiDisplayHelper.CreateValue(
						txtData,
						IRR.Val,
						"0",
						" W/m²",
						valueColor)
				};

			HmiDisplayHelper.Apply(data);
		}

		private void UpdateCardVisual()
		{
			HmiDisplayHelper.ApplyStatusCard(
				rectBtn,
				rectBtn,
				_currentStatus,
				_isRectBtnHovered);
			
			roundedRectangle1.BrushColor =
				_isRectBtnHovered
					? SolarTheme.Surface.RaisedPanel
					: SolarTheme.Surface.Panel;
		
			roundedRectangle1.PenColor =
				_isRectBtnHovered
					? SolarTheme.Border.Hover
					: SolarTheme.Border.Normal;
		
			roundedRectangle1.PenWidth =
				_isRectBtnHovered
					? SolarTheme.Pen.Panel
					: SolarTheme.Pen.Normal;
		}

		void GroupDataMouseEnter(
			object sender,
			EventArgs e)
		{
			_isRectBtnHovered = true;
			UpdateCardVisual();
		}

		void GroupDataMouseLeave(
			object sender,
			EventArgs e)
		{
			_isRectBtnHovered = false;
			UpdateCardVisual();
		}
	}
}