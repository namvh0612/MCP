/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 6/30/2026
 * Time: 4:29 PM
 */

using System;
using NxtControl.GuiFramework;
using NxtControl.Drawing;
using HMI.Main.SupportClasses;

namespace HMI.Main.Symbols.acPVArray_v1_0
{
	public partial class sDefault :
		NxtControl.GuiFramework.HMISymbol
	{
		private bool _isRectBtnHovered;

		private SolarTheme.EquipmentState _currentStatus =
			SolarTheme.EquipmentState.Offline;

		public sDefault()
		{
			InitializeComponent();

			TMOD.OnValChanged +=
				OnPVArrayValueChanged;

			STRON.OnValChanged +=
				OnPVArrayValueChanged;

			STRTOT.OnValChanged +=
				OnPVArrayValueChanged;

			PDC.OnValChanged +=
				OnPVArrayValueChanged;

			IAVL.OnValChanged +=
				OnPVArrayValueChanged;

			IALM.OnValChanged +=
				OnPVArrayValueChanged;

			IFLT.OnValChanged +=
				OnPVArrayValueChanged;

			QLT.OnValChanged +=
				OnPVArrayValueChanged;

			this.REQ_Fired +=
				REQ_Fired_EventHandler;

			UpdateDisplay();
		}

		private void OnPVArrayValueChanged(
			object sender,
			EventArgs e)
		{
			UpdateDisplay();
		}

		private void UpdateDisplay()
		{
			_currentStatus =
				SolarStatusHelper.ResolveStandard(
					QLT.Val,
					IFLT.Val,
					IALM.Val,
					IAVL.Val,
					SolarTheme.EquipmentState.Healthy,
					SolarTheme.EquipmentState.Standby);

			Color moduleTemperatureColor =
				HmiValueHelper.ToDouble(TMOD.Val) > 75.0
					? SolarTheme.Status.Warning
					: SolarTheme.Text.Primary;

			string stringsText =
				HmiValueHelper
					.ToInt(STRON.Val)
					.ToString()
				+ "/"
				+ HmiValueHelper
					.ToInt(STRTOT.Val)
					.ToString();

			HmiDisplayHelper.DisplayData data =
				new HmiDisplayHelper.DisplayData();

			data.Status =
				_currentStatus;

			data.StatusLabel =
				txtStatus;

			data.StatusIndicator =
				indStatus;

			data.CardBorder =
				rectBtn;

			data.CardBackground =
				rectBase;

			data.IsHovered =
				_isRectBtnHovered;

			data.Items =
				new HmiDisplayHelper.DisplayItem[]
				{
					HmiDisplayHelper.CreateValue(
						txtModuleTemp,
						TMOD.Val,
						"0",
						" °C",
						moduleTemperatureColor),

					HmiDisplayHelper.CreateText(
						txtStrings,
						stringsText),

					HmiDisplayHelper.CreateValue(
						txtPDC,
						PDC.Val,
						"0.00",
						" MW")
				};

			HmiDisplayHelper.Apply(data);
		}

		private void UpdateCardVisual()
		{
			HmiDisplayHelper.ApplyStatusCard(
				rectBtn,
				rectBase,
				_currentStatus,
				_isRectBtnHovered);
		}

		void RectBtnMouseEnter(
			object sender,
			EventArgs e)
		{
			_isRectBtnHovered = true;
			UpdateCardVisual();
		}

		void RectBtnMouseLeave(
			object sender,
			EventArgs e)
		{
			_isRectBtnHovered = false;
			UpdateCardVisual();
		}

		void REQ_Fired_EventHandler(
			object sender,
			REQEventArgs e)
		{
			if (e == null)
				return;

			lblSymbol.Text =
				HmiValueHelper.SafeText(
					e.AssetName,
					"PV Array");
		}
	}
}