/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 7/24/2026
 * Time: 9:47 AM
 */

using System;
using NxtControl.GuiFramework;
using NxtControl.Drawing;
using HMI.Main.SupportClasses;

namespace HMI.Main.Symbols.acPVArray_v1_0
{
	public partial class sPvDcPwr :
		NxtControl.GuiFramework.HMISymbol
	{
		private bool _isRectBtnHovered;

		private SolarTheme.EquipmentState _currentStatus =
			SolarTheme.EquipmentState.Offline;

		public sPvDcPwr()
		{
			InitializeComponent();

			PDC.OnValChanged +=
				OnPVArrayValueChanged;

			UpdateDisplay();
		}

		private void OnPVArrayValueChanged(
			object sender,
			EventArgs e)
		{
			UpdateDisplay();
		}

		private void UpdateDisplay()
		{
			double dcPower =
				HmiValueHelper.ToDouble(PDC.Val);

			_currentStatus =
				dcPower <= 0.0
					? SolarTheme.EquipmentState.Offline
					: SolarTheme.EquipmentState.Healthy;

			Color valueColor =
				_currentStatus ==
				SolarTheme.EquipmentState.Offline
					? SolarTheme.Status.Offline
					: SolarTheme.Text.Primary;

			HmiDisplayHelper.DisplayData displayData =
				new HmiDisplayHelper.DisplayData();

			displayData.Status = _currentStatus;
			displayData.CardBorder = rectBtn;
			displayData.CardBackground = rectBtn;
			displayData.IsHovered = _isRectBtnHovered;

			displayData.Items =
				new HmiDisplayHelper.DisplayItem[]
				{
					HmiDisplayHelper.CreateValue(
						txtData,
						PDC.Val,
						"0.00",
						" MWdc",
						valueColor)
				};

			HmiDisplayHelper.Apply(displayData);
		}

		private void UpdateCardVisual()
		{
			HmiDisplayHelper.ApplyStatusCard(
				rectBtn,
				rectBtn,
				_currentStatus,
				_isRectBtnHovered);
			
			roundedRectangle1.BrushColor =
				_isRectBtnHovered
					? SolarTheme.Surface.RaisedPanel
					: SolarTheme.Surface.Panel;
		
			roundedRectangle1.PenColor =
				_isRectBtnHovered
					? SolarTheme.Border.Hover
					: SolarTheme.Border.Normal;
		
			roundedRectangle1.PenWidth =
				_isRectBtnHovered
					? SolarTheme.Pen.Panel
					: SolarTheme.Pen.Normal;
		}

		private void GroupDataMouseEnter(
			object sender,
			EventArgs e)
		{
			_isRectBtnHovered = true;
			UpdateCardVisual();
		}

		private void GroupDataMouseLeave(
			object sender,
			EventArgs e)
		{
			_isRectBtnHovered = false;
			UpdateCardVisual();
		}
	}
}