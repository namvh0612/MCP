/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 8/11/2025
 * Time: 2:02 PM
 * 
 */

using System;
using NxtControl.GuiFramework;

namespace SE.Agile.Faceplates.acTransmitter_v1_0
{
	/// <summary>
	/// Description of faceplateMain.
	/// </summary>
	public partial class fMain : NxtControl.GuiFramework.HMIFaceplate
	{
		private bool _IHH;
		private bool _IHI;
		private bool _ILO;
		private bool _ILL;
		
		public fMain()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			txtIHH.Visible = false;
			txtIHI.Visible = false;
			txtILO.Visible = false;
			txtILL.Visible = false;
			
			IHH.OnValChanged += OnSubCatValueChanged;
			IHI.OnValChanged += OnSubCatValueChanged;
			ILO.OnValChanged += OnSubCatValueChanged;
			ILL.OnValChanged += OnSubCatValueChanged;
			IA.OnValChanged += OnSubCatValueChanged;
			IRSTPER.OnValChanged += OnSubCatValueChanged;
		}

		void AssetNameValueChanged(object sender, ValueChangedEventArgs e)
		{
			Title = (string)e.Value;
		}

		// EXECUTE logic triggered by child value change
	    private void OnSubCatValueChanged(object sender, EventArgs e)
	    {
			if (_IHH != IHH.Val)
			{
				txtIHH.Visible = IHH.Val;
			}
			
			if (_IHI != IHI.Val)
			{
				txtIHI.Visible = IHI.Val;
			}
						
			if (_ILO != ILO.Val)
			{
				txtILO.Visible = ILO.Val;
			}
									
			if (_ILL != ILL.Val)
			{
				txtILL.Visible = ILL.Val;
			}
			
			navAlarm.Visible = !IA.Val;
			navAlarmActive.Visible = IA.Val;
			
			symBtnCACAK.Enabled = IRSTPER.Val;
			
			_IHH = IHH.Val;
			_IHI = IHI.Val;
			_ILO = ILO.Val;
			_ILL = ILL.Val;
		}
	}
}
