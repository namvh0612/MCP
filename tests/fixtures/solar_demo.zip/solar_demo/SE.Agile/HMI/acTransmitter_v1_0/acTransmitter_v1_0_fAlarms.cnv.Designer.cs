/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 4/28/2026
 * Time: 6:08 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using NxtControl.GuiFramework;

namespace SE.Agile.Faceplates.acTransmitter_v1_0
{
	/// <summary>
	/// Summary description for sAlarms.
	/// </summary>
	partial class fAlarms
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.AssetName = new System.HMI.Symbols.Base.Execute<string>();
			this.symHH = new SE.Agile.Symbols.DA_v1_0.sDA();
			this.symHI = new SE.Agile.Symbols.DA_v1_0.sDA();
			this.symLL = new SE.Agile.Symbols.DA_v1_0.sDA();
			this.symLO = new SE.Agile.Symbols.DA_v1_0.sDA();
			this.symRH = new SE.Agile.Symbols.DA_v1_0.sDA();
			this.symRL = new SE.Agile.Symbols.DA_v1_0.sDA();
			// 
			// AssetName
			// 
			this.AssetName.BeginInit();
			this.AssetName.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.AssetName.IsOnlyInput = true;
			this.AssetName.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.AssetName.Name = "AssetName";
			this.AssetName.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.AssetName.TagName = "AssetName";
			this.AssetName.Value = null;
			this.AssetName.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.AssetNameValueChanged);
			this.AssetName.EndInit();
			// 
			// symHH
			// 
			this.symHH.BeginInit();
			this.symHH.AlarmOffColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.symHH.AlarmOnColor = new NxtControl.Drawing.Color("Red");
			this.symHH.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 32D, 16D);
			this.symHH.IndicationOffColor = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(114)), ((byte)(110)), ((byte)(106))));
			this.symHH.IndicationOnColor = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(0))));
			this.symHH.LabelText = "High High Alarm";
			this.symHH.Name = "symHH";
			this.symHH.SecurityToken = ((uint)(4294967295u));
			this.symHH.TagName = "Equipment.HH";
			this.symHH.EndInit();
			// 
			// symHI
			// 
			this.symHI.BeginInit();
			this.symHI.AlarmOffColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.symHI.AlarmOnColor = new NxtControl.Drawing.Color("Red");
			this.symHI.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 32D, 40D);
			this.symHI.IndicationOffColor = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(114)), ((byte)(110)), ((byte)(106))));
			this.symHI.IndicationOnColor = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(0))));
			this.symHI.LabelText = "High Alarm";
			this.symHI.Name = "symHI";
			this.symHI.SecurityToken = ((uint)(4294967295u));
			this.symHI.TagName = "Equipment.HI";
			this.symHI.EndInit();
			// 
			// symLL
			// 
			this.symLL.BeginInit();
			this.symLL.AlarmOffColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.symLL.AlarmOnColor = new NxtControl.Drawing.Color("Red");
			this.symLL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 32D, 88D);
			this.symLL.IndicationOffColor = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(114)), ((byte)(110)), ((byte)(106))));
			this.symLL.IndicationOnColor = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(0))));
			this.symLL.LabelText = "Low Low Alarm";
			this.symLL.Name = "symLL";
			this.symLL.SecurityToken = ((uint)(4294967295u));
			this.symLL.TagName = "Equipment.LL";
			this.symLL.EndInit();
			// 
			// symLO
			// 
			this.symLO.BeginInit();
			this.symLO.AlarmOffColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.symLO.AlarmOnColor = new NxtControl.Drawing.Color("Red");
			this.symLO.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 32D, 64D);
			this.symLO.IndicationOffColor = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(114)), ((byte)(110)), ((byte)(106))));
			this.symLO.IndicationOnColor = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(0))));
			this.symLO.LabelText = "Low Alarm";
			this.symLO.Name = "symLO";
			this.symLO.SecurityToken = ((uint)(4294967295u));
			this.symLO.TagName = "Equipment.LO";
			this.symLO.EndInit();
			// 
			// symRH
			// 
			this.symRH.BeginInit();
			this.symRH.AlarmOffColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.symRH.AlarmOnColor = new NxtControl.Drawing.Color("Red");
			this.symRH.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 32D, 112D);
			this.symRH.IndicationOffColor = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(114)), ((byte)(110)), ((byte)(106))));
			this.symRH.IndicationOnColor = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(0))));
			this.symRH.LabelText = "Out of Range High";
			this.symRH.Name = "symRH";
			this.symRH.SecurityToken = ((uint)(4294967295u));
			this.symRH.TagName = "Equipment.RH";
			this.symRH.EndInit();
			// 
			// symRL
			// 
			this.symRL.BeginInit();
			this.symRL.AlarmOffColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.symRL.AlarmOnColor = new NxtControl.Drawing.Color("Red");
			this.symRL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 32D, 136D);
			this.symRL.IndicationOffColor = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(114)), ((byte)(110)), ((byte)(106))));
			this.symRL.IndicationOnColor = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(0))));
			this.symRL.LabelText = "Out of Range Low";
			this.symRL.Name = "symRL";
			this.symRL.SecurityToken = ((uint)(4294967295u));
			this.symRL.TagName = "Equipment.RL";
			this.symRL.EndInit();
			// 
			// fAlarms
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(240D)), ((float)(180D)));
			this.Brush = new NxtControl.Drawing.Brush("FaceplateBrush");
			this.FaceplateClose = NxtControl.GuiFramework.CloseFaceplateBehavior.Automatic;
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.AssetName,
			this.symHH,
			this.symHI,
			this.symLL,
			this.symLO,
			this.symRH,
			this.symRL});
			this.Size = new System.Drawing.Size(240, 180);

		}
		private System.HMI.Symbols.Base.Execute<string> AssetName;
		private SE.Agile.Symbols.DA_v1_0.sDA symHH;
		private SE.Agile.Symbols.DA_v1_0.sDA symHI;
		private SE.Agile.Symbols.DA_v1_0.sDA symLL;
		private SE.Agile.Symbols.DA_v1_0.sDA symLO;
		private SE.Agile.Symbols.DA_v1_0.sDA symRH;
		private SE.Agile.Symbols.DA_v1_0.sDA symRL;
		#endregion
	}
}
