/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 4/28/2026
 * Time: 6:08 PM
 * 
 */

using System;
using NxtControl.GuiFramework;

namespace SE.Agile.Faceplates.acTransmitter_v1_0
{
	/// <summary>
	/// Description of sAlarms.
	/// </summary>
	public partial class fAlarms : NxtControl.GuiFramework.HMIFaceplate
	{
		public fAlarms()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}
		
		void AssetNameValueChanged(object sender, ValueChangedEventArgs e)
		{
			Title = (string)e.Value;
		}
		
	}
}
