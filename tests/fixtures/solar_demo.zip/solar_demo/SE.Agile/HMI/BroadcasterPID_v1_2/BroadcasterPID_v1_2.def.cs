using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region BroadcasterPID_v1_2_HMI;
#endregion BroadcasterPID_v1_2_HMI;

#endregion Definitions;

