/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 9/22/2025
 * Time: 9:35 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using NxtControl.GuiFramework;

namespace SE.Agile.Faceplates.acTwoPositionActuator_v1_0
{
	/// <summary>
	/// Summary description for sParameters.
	/// </summary>
	partial class fParameters
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.symCFOPENPRE = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed();
			this.symCFCLOSPRE = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed();
			this.symBtnCMSKOPEN = new SE.Agile.Symbols.HMI_Control_Bool_v1_0.sButtonTwoStateNamed();
			this.symBtnCMSKCLOS = new SE.Agile.Symbols.HMI_Control_Bool_v1_0.sButtonTwoStateNamed();
			this.AssetName = new System.HMI.Symbols.Base.Execute<string>();
			// 
			// symCFOPENPRE
			// 
			this.symCFOPENPRE.BeginInit();
			this.symCFOPENPRE.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -32D, 16D);
			this.symCFOPENPRE.LabelText = "Fully Open Delay:";
			this.symCFOPENPRE.Name = "symCFOPENPRE";
			this.symCFOPENPRE.SecurityToken = ((uint)(4294967295u));
			this.symCFOPENPRE.TagName = "Equipment.CFOPENPRE";
			this.symCFOPENPRE.EndInit();
			// 
			// symCFCLOSPRE
			// 
			this.symCFCLOSPRE.BeginInit();
			this.symCFCLOSPRE.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -32D, 48D);
			this.symCFCLOSPRE.LabelText = "Fully Closed Delay:";
			this.symCFCLOSPRE.Name = "symCFCLOSPRE";
			this.symCFCLOSPRE.SecurityToken = ((uint)(4294967295u));
			this.symCFCLOSPRE.TagName = "Equipment.CFCLOSPRE";
			this.symCFCLOSPRE.EndInit();
			// 
			// symBtnCMSKOPEN
			// 
			this.symBtnCMSKOPEN.BeginInit();
			this.symBtnCMSKOPEN.ButtonFalseColor = new NxtControl.Drawing.Color(((byte)(110)), ((byte)(110)), ((byte)(110)));
			this.symBtnCMSKOPEN.ButtonTrueColor = new NxtControl.Drawing.Color(((byte)(0)), ((byte)(168)), ((byte)(231)));
			this.symBtnCMSKOPEN.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -32D, 80D);
			this.symBtnCMSKOPEN.LabelText = "Open Simulation:";
			this.symBtnCMSKOPEN.Name = "symBtnCMSKOPEN";
			this.symBtnCMSKOPEN.SecurityToken = ((uint)(4294967295u));
			this.symBtnCMSKOPEN.TagName = "Equipment.CMSKOPEN";
			this.symBtnCMSKOPEN.EndInit();
			// 
			// symBtnCMSKCLOS
			// 
			this.symBtnCMSKCLOS.BeginInit();
			this.symBtnCMSKCLOS.ButtonFalseColor = new NxtControl.Drawing.Color(((byte)(110)), ((byte)(110)), ((byte)(110)));
			this.symBtnCMSKCLOS.ButtonTrueColor = new NxtControl.Drawing.Color(((byte)(0)), ((byte)(168)), ((byte)(231)));
			this.symBtnCMSKCLOS.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -32D, 112D);
			this.symBtnCMSKCLOS.LabelText = "Close Simulation:";
			this.symBtnCMSKCLOS.Name = "symBtnCMSKCLOS";
			this.symBtnCMSKCLOS.SecurityToken = ((uint)(4294967295u));
			this.symBtnCMSKCLOS.TagName = "Equipment.CMSKCLOS";
			this.symBtnCMSKCLOS.EndInit();
			// 
			// AssetName
			// 
			this.AssetName.BeginInit();
			this.AssetName.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 62D, 336D);
			this.AssetName.IsOnlyInput = true;
			this.AssetName.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.AssetName.Name = "AssetName";
			this.AssetName.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.AssetName.TagName = "AssetName";
			this.AssetName.Value = null;
			this.AssetName.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.AssetNameValueChanged);
			this.AssetName.EndInit();
			// 
			// fParameters
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(250D)), ((float)(192D)));
			this.Brush = new NxtControl.Drawing.Brush("FaceplateBrush");
			this.FaceplateClose = NxtControl.GuiFramework.CloseFaceplateBehavior.Automatic;
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.symCFOPENPRE,
			this.symCFCLOSPRE,
			this.symBtnCMSKOPEN,
			this.symBtnCMSKCLOS,
			this.AssetName});
			this.Size = new System.Drawing.Size(250, 192);

		}
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed symCFOPENPRE;
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed symCFCLOSPRE;
		private SE.Agile.Symbols.HMI_Control_Bool_v1_0.sButtonTwoStateNamed symBtnCMSKOPEN;
		private SE.Agile.Symbols.HMI_Control_Bool_v1_0.sButtonTwoStateNamed symBtnCMSKCLOS;
		private System.HMI.Symbols.Base.Execute<string> AssetName;
		#endregion
	}
}
