using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region acTwoPositionActuator_v1_0_HMI;

namespace SE.Agile.Symbols.acTwoPositionActuator_v1_0
{
  partial class sVLVHoriz
  {

    private SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fMain fMain
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fMain faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fMain)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fMain));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fMain();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fParameters fParameters
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fParameters faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fParameters)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fParameters));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fParameters();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fAlarms fAlarms
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fAlarms faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fAlarms)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fAlarms));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fAlarms();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    protected override void DoOpenFaceplate(OpenFaceplate openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fMain;

      if ("fParameters" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fParameters;

      if ("fAlarms" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fAlarms;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

    public override void DoOpenFaceplate(string openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == openFaceplate)
        hmiFaceplate = fMain;

      if ("fParameters" == openFaceplate)
        hmiFaceplate = fParameters;

      if ("fAlarms" == openFaceplate)
        hmiFaceplate = fAlarms;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

  }
}

namespace SE.Agile.Faceplates.acTwoPositionActuator_v1_0
{
  partial class fMain
  {

    private SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fParameters fParameters
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fParameters faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fParameters)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fParameters));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fParameters();

          faceplate.SetConnectionInfo(this.TagName, this.ConnectionSymbolPath, this.ChannelId, this.ParentType);

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fAlarms fAlarms
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fAlarms faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fAlarms)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fAlarms));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fAlarms();

          faceplate.SetConnectionInfo(this.TagName, this.ConnectionSymbolPath, this.ChannelId, this.ParentType);

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    protected override void DoOpenFaceplate(OpenFaceplate openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fParameters" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fParameters;

      if ("fAlarms" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fAlarms;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

    public override void DoOpenFaceplate(string openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fParameters" == openFaceplate)
        hmiFaceplate = fParameters;

      if ("fAlarms" == openFaceplate)
        hmiFaceplate = fAlarms;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

  }
}

namespace SE.Agile.Faceplates.acTwoPositionActuator_v1_0
{
  partial class fParameters
  {

    private SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fMain fMain
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fMain faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fMain)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fMain));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fMain();

          faceplate.SetConnectionInfo(this.TagName, this.ConnectionSymbolPath, this.ChannelId, this.ParentType);

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fAlarms fAlarms
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fAlarms faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fAlarms)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fAlarms));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fAlarms();

          faceplate.SetConnectionInfo(this.TagName, this.ConnectionSymbolPath, this.ChannelId, this.ParentType);

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    protected override void DoOpenFaceplate(OpenFaceplate openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fMain;

      if ("fAlarms" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fAlarms;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

    public override void DoOpenFaceplate(string openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == openFaceplate)
        hmiFaceplate = fMain;

      if ("fAlarms" == openFaceplate)
        hmiFaceplate = fAlarms;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

  }
}

namespace SE.Agile.Faceplates.acTwoPositionActuator_v1_0
{
  partial class fAlarms
  {

    private SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fMain fMain
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fMain faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fMain)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fMain));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fMain();

          faceplate.SetConnectionInfo(this.TagName, this.ConnectionSymbolPath, this.ChannelId, this.ParentType);

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fParameters fParameters
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fParameters faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fParameters)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fParameters));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acTwoPositionActuator_v1_0.fParameters();

          faceplate.SetConnectionInfo(this.TagName, this.ConnectionSymbolPath, this.ChannelId, this.ParentType);

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    protected override void DoOpenFaceplate(OpenFaceplate openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fMain;

      if ("fParameters" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fParameters;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

    public override void DoOpenFaceplate(string openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == openFaceplate)
        hmiFaceplate = fMain;

      if ("fParameters" == openFaceplate)
        hmiFaceplate = fParameters;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

  }
}
#endregion acTwoPositionActuator_v1_0_HMI;

#endregion Definitions;

