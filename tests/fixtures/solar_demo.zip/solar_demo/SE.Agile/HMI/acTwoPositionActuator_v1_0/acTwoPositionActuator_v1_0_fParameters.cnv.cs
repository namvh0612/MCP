/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 9/22/2025
 * Time: 9:35 PM
 * 
 */

using System;
using NxtControl.GuiFramework;

namespace SE.Agile.Faceplates.acTwoPositionActuator_v1_0
{
	/// <summary>
	/// Description of sParameters.
	/// </summary>
	public partial class fParameters : NxtControl.GuiFramework.HMIFaceplate
	{
		public fParameters()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}
		
		void AssetNameValueChanged(object sender, ValueChangedEventArgs e)
		{
			Title = (string)e.Value;
		}
	}
}
