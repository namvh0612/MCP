/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 8/11/2025
 * Time: 2:02 PM
 * 
 */

using System;
using NxtControl.GuiFramework;

namespace SE.Agile.Faceplates.acTwoPositionActuator_v1_0
{
	/// <summary>
	/// Description of faceplateMain.
	/// </summary>
	public partial class fMain : NxtControl.GuiFramework.HMIFaceplate
	{
		private int _CMODE;
		
		public fMain()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			ICOPENR.OnValChanged += OnSubCatValueChanged;
			IOPEN.OnValChanged += OnSubCatValueChanged;
			ICLOS.OnValChanged += OnSubCatValueChanged;
			CMODE.OnValChanged += OnSubCatValueChanged;
			IA.OnValChanged += OnSubCatValueChanged;
			IRSTPERM.OnValChanged += OnSubCatValueChanged;
		}

		void AssetNameValueChanged(object sender, ValueChangedEventArgs e)
		{
			Title = (string)e.Value;
		}
		
		// EXECUTE logic triggered by child value change
	    private void OnSubCatValueChanged(object sender, EventArgs e)
	    {
			txtStatus.Text = "Error";
			
			if (IOPEN.Val && ICLOS.Val)
			{
				txtStatus.Text = "Position Discrepancy";
			}
			else if (IOPEN.Val)
			{
				txtStatus.Text = "Opened";
			}
			else if (ICLOS.Val)
			{
				txtStatus.Text = "Closed";
			}
			else if (ICOPENR.Val && !IOPEN.Val)
			{
				txtStatus.Text = "Opening";
			}
			else if (!ICOPENR.Val && !ICLOS.Val)
			{
				txtStatus.Text = "Closing";
			}
			else
			{
				txtStatus.Text = "No Position Status";
			}
			
			if (_CMODE != CMODE.Val)
			{
				symBtnCME.Enabled = (CMODE.Val == 3);
			}
			
			navAlarm.Visible = !IA.Val;
			navAlarmActive.Visible = IA.Val;
			
			symBtnCFLRST.Enabled = IRSTPERM.Val;
			
			_CMODE = CMODE.Val;
		}

	}
}
