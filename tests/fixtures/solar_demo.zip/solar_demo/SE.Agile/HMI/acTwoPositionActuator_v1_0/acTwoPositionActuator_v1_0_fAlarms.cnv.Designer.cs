/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 4/28/2026
 * Time: 5:59 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using NxtControl.GuiFramework;

namespace SE.Agile.Faceplates.acTwoPositionActuator_v1_0
{
	/// <summary>
	/// Summary description for fAlarms.
	/// </summary>
	partial class fAlarms
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.AssetName = new System.HMI.Symbols.Base.Execute<string>();
			this.symDISCFTOPEN = new SE.Agile.Symbols.DA_v1_0.sDA();
			this.symDISCFTCLOS = new SE.Agile.Symbols.DA_v1_0.sDA();
			// 
			// AssetName
			// 
			this.AssetName.BeginInit();
			this.AssetName.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.AssetName.IsOnlyInput = true;
			this.AssetName.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.AssetName.Name = "AssetName";
			this.AssetName.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.AssetName.TagName = "AssetName";
			this.AssetName.Value = null;
			this.AssetName.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.AssetNameValueChanged);
			this.AssetName.EndInit();
			// 
			// symDISCFTOPEN
			// 
			this.symDISCFTOPEN.BeginInit();
			this.symDISCFTOPEN.AlarmOffColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.symDISCFTOPEN.AlarmOnColor = new NxtControl.Drawing.Color("Red");
			this.symDISCFTOPEN.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 24D, 16D);
			this.symDISCFTOPEN.IndicationOffColor = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(114)), ((byte)(110)), ((byte)(106))));
			this.symDISCFTOPEN.IndicationOnColor = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(0))));
			this.symDISCFTOPEN.LabelText = "Failed to Open";
			this.symDISCFTOPEN.Name = "symDISCFTOPEN";
			this.symDISCFTOPEN.SecurityToken = ((uint)(4294967295u));
			this.symDISCFTOPEN.TagName = "Equipment.DISCFTOPEN";
			this.symDISCFTOPEN.EndInit();
			// 
			// symDISCFTCLOS
			// 
			this.symDISCFTCLOS.BeginInit();
			this.symDISCFTCLOS.AlarmOffColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.symDISCFTCLOS.AlarmOnColor = new NxtControl.Drawing.Color("Red");
			this.symDISCFTCLOS.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 24D, 40D);
			this.symDISCFTCLOS.IndicationOffColor = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(114)), ((byte)(110)), ((byte)(106))));
			this.symDISCFTCLOS.IndicationOnColor = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(0))));
			this.symDISCFTCLOS.LabelText = "Failed to Close";
			this.symDISCFTCLOS.Name = "symDISCFTCLOS";
			this.symDISCFTCLOS.SecurityToken = ((uint)(4294967295u));
			this.symDISCFTCLOS.TagName = "Equipment.DISCFTCLOS";
			this.symDISCFTCLOS.EndInit();
			// 
			// fAlarms
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(240D)), ((float)(152D)));
			this.Brush = new NxtControl.Drawing.Brush("FaceplateBrush");
			this.FaceplateClose = NxtControl.GuiFramework.CloseFaceplateBehavior.Automatic;
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.AssetName,
			this.symDISCFTOPEN,
			this.symDISCFTCLOS});
			this.Size = new System.Drawing.Size(240, 152);

		}
		private System.HMI.Symbols.Base.Execute<string> AssetName;
		private SE.Agile.Symbols.DA_v1_0.sDA symDISCFTOPEN;
		private SE.Agile.Symbols.DA_v1_0.sDA symDISCFTCLOS;
		#endregion
	}
}
