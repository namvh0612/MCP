/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 8/11/2025
 * Time: 2:02 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using NxtControl.GuiFramework;

namespace SE.Agile.Faceplates.acTwoPositionActuator_v1_0
{
	/// <summary>
	/// Summary description for faceplateMain.
	/// </summary>
	partial class fMain
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fMain));
			this.AssetName = new System.HMI.Symbols.Base.Execute<string>();
			this.lblStatus = new NxtControl.GuiFramework.FreeText();
			this.symTxtMode = new SE.Agile.Symbols.ModeSelector_v1_0.sModeNamedMiddle();
			this.txtStatus = new NxtControl.GuiFramework.FreeText();
			this.symIFL = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed();
			this.symIAOK = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed();
			this.symISIM = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed();
			this.symIPI = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed();
			this.symBtnMode = new SE.Agile.Symbols.ModeSelector_v1_0.sButtonQuad();
			this.navParameters = new NxtControl.GuiFramework.Rectangle();
			this.navData = new NxtControl.GuiFramework.Rectangle();
			this.navInterlock = new NxtControl.GuiFramework.Rectangle();
			this.navPermissive = new NxtControl.GuiFramework.Rectangle();
			this.navTrend = new NxtControl.GuiFramework.Rectangle();
			this.symIOPEN = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed();
			this.symICLOS = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed();
			this.symIPIE = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed();
			this.symBtnCME = new SE.Agile.Symbols.HMI_Control_Bool_v1_0.sButtonVert2();
			this.ICOPENR = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.ICLOS = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IOPEN = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.CMODE = new SE.Agile.Symbols.HMI_Control_Integer_v1_0.sValChanged();
			this.navPrograms = new SE.Agile.Symbols.Broadcaster_v1_0.sButtonNavProgram();
			this.navAlarm = new NxtControl.GuiFramework.Rectangle();
			this.navAlarmActive = new NxtControl.GuiFramework.Rectangle();
			this.IA = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IRSTPERM = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.symBtnCFLRST = new SE.Agile.Symbols.HMI_Control_Bool_v1_0.sButtonValSet();
			this.symIIOFL = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed();
			// 
			// AssetName
			// 
			this.AssetName.BeginInit();
			this.AssetName.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.AssetName.IsOnlyInput = true;
			this.AssetName.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.AssetName.Name = "AssetName";
			this.AssetName.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.AssetName.TagName = "AssetName";
			this.AssetName.Value = null;
			this.AssetName.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.AssetNameValueChanged);
			this.AssetName.EndInit();
			// 
			// lblStatus
			// 
			this.lblStatus.Color = new NxtControl.Drawing.Color("LabelTextColor");
			this.lblStatus.Font = new NxtControl.Drawing.Font("LabelFont");
			this.lblStatus.Location = new NxtControl.Drawing.PointF(95D, 32D);
			this.lblStatus.Name = "lblStatus";
			this.lblStatus.Text = "Status:";
			// 
			// symTxtMode
			// 
			this.symTxtMode.BeginInit();
			this.symTxtMode.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -16D, 8D);
			this.symTxtMode.LabelText = "Mode:";
			this.symTxtMode.Name = "symTxtMode";
			this.symTxtMode.SecurityToken = ((uint)(4294967295u));
			this.symTxtMode.TagName = "Equipment.Mode";
			this.symTxtMode.EndInit();
			// 
			// txtStatus
			// 
			this.txtStatus.Color = new NxtControl.Drawing.Color("LabelTextColor");
			this.txtStatus.Font = new NxtControl.Drawing.Font("HMI Sans Serif", 9F, System.Drawing.FontStyle.Regular);
			this.txtStatus.Location = new NxtControl.Drawing.PointF(138D, 32D);
			this.txtStatus.Name = "txtStatus";
			this.txtStatus.Text = "Unknown";
			// 
			// symIFL
			// 
			this.symIFL.BeginInit();
			this.symIFL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -16D, 48D);
			this.symIFL.LabelText = "Fault Status:";
			this.symIFL.Name = "symIFL";
			this.symIFL.OffText = "Ok";
			this.symIFL.OnText = "Failed";
			this.symIFL.SecurityToken = ((uint)(4294967295u));
			this.symIFL.TagName = "Equipment.IFL";
			this.symIFL.EndInit();
			// 
			// symIAOK
			// 
			this.symIAOK.BeginInit();
			this.symIAOK.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -16D, 72D);
			this.symIAOK.LabelText = "Available in Auto:";
			this.symIAOK.Name = "symIAOK";
			this.symIAOK.OffText = "No";
			this.symIAOK.OnText = "Yes";
			this.symIAOK.SecurityToken = ((uint)(4294967295u));
			this.symIAOK.TagName = "Equipment.IAOK";
			this.symIAOK.EndInit();
			// 
			// symISIM
			// 
			this.symISIM.BeginInit();
			this.symISIM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -16D, 120D);
			this.symISIM.LabelText = "Simulation:";
			this.symISIM.Name = "symISIM";
			this.symISIM.SecurityToken = ((uint)(4294967295u));
			this.symISIM.TagName = "Equipment.ISIM";
			this.symISIM.EndInit();
			// 
			// symIPI
			// 
			this.symIPI.BeginInit();
			this.symIPI.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -16D, 192D);
			this.symIPI.LabelText = "Process Interlock:";
			this.symIPI.Name = "symIPI";
			this.symIPI.OffText = "Inactive";
			this.symIPI.OnText = "Active";
			this.symIPI.SecurityToken = ((uint)(4294967295u));
			this.symIPI.TagName = "Equipment.IPI";
			this.symIPI.EndInit();
			// 
			// symBtnMode
			// 
			this.symBtnMode.BeginInit();
			this.symBtnMode.ButtonTextDisabledColor = new NxtControl.Drawing.Color("ButtonTextDisabledColor");
			this.symBtnMode.ButtonToggleOnBrush = new NxtControl.Drawing.Brush("ButtonBrush");
			this.symBtnMode.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 88D, 248D);
			this.symBtnMode.Name = "symBtnMode";
			this.symBtnMode.SecurityToken = ((uint)(4294967295u));
			this.symBtnMode.TagName = "Equipment.Mode";
			this.symBtnMode.EndInit();
			// 
			// navParameters
			// 
			this.navParameters.Bounds = new NxtControl.Drawing.RectF(((float)(232D)), ((float)(24D)), ((float)(24D)), ((float)(24D)));
			this.navParameters.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.navParameters.ImageBytes = resources.GetString("navParameters.ImageBytes");
			this.navParameters.Name = "navParameters";
			this.navParameters.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fParameters", NxtControl.GuiFramework.MouseButtonType.Click));
			// 
			// navData
			// 
			this.navData.Bounds = new NxtControl.Drawing.RectF(((float)(232D)), ((float)(48D)), ((float)(24D)), ((float)(24D)));
			this.navData.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.navData.ImageBytes = resources.GetString("navData.ImageBytes");
			this.navData.Name = "navData";
			// 
			// navInterlock
			// 
			this.navInterlock.Bounds = new NxtControl.Drawing.RectF(((float)(232D)), ((float)(72D)), ((float)(24D)), ((float)(24D)));
			this.navInterlock.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.navInterlock.ImageBytes = resources.GetString("navInterlock.ImageBytes");
			this.navInterlock.Name = "navInterlock";
			// 
			// navPermissive
			// 
			this.navPermissive.Bounds = new NxtControl.Drawing.RectF(((float)(232D)), ((float)(120D)), ((float)(24D)), ((float)(24D)));
			this.navPermissive.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.navPermissive.ImageBytes = resources.GetString("navPermissive.ImageBytes");
			this.navPermissive.Name = "navPermissive";
			// 
			// navTrend
			// 
			this.navTrend.Bounds = new NxtControl.Drawing.RectF(((float)(232D)), ((float)(144D)), ((float)(24D)), ((float)(24D)));
			this.navTrend.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.navTrend.ImageBytes = resources.GetString("navTrend.ImageBytes");
			this.navTrend.Name = "navTrend";
			// 
			// symIOPEN
			// 
			this.symIOPEN.BeginInit();
			this.symIOPEN.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -16D, 144D);
			this.symIOPEN.LabelText = "Fully Opened:";
			this.symIOPEN.Name = "symIOPEN";
			this.symIOPEN.OffText = "No";
			this.symIOPEN.OnText = "Yes";
			this.symIOPEN.SecurityToken = ((uint)(4294967295u));
			this.symIOPEN.TagName = "Equipment.IOPEN";
			this.symIOPEN.EndInit();
			// 
			// symICLOS
			// 
			this.symICLOS.BeginInit();
			this.symICLOS.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -16D, 168D);
			this.symICLOS.LabelText = "Fully Closed:";
			this.symICLOS.Name = "symICLOS";
			this.symICLOS.OffText = "No";
			this.symICLOS.OnText = "Yes";
			this.symICLOS.SecurityToken = ((uint)(4294967295u));
			this.symICLOS.TagName = "Equipment.ICLOS";
			this.symICLOS.EndInit();
			// 
			// symIPIE
			// 
			this.symIPIE.BeginInit();
			this.symIPIE.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -16D, 216D);
			this.symIPIE.LabelText = "Process Interlock Open:";
			this.symIPIE.Name = "symIPIE";
			this.symIPIE.SecurityToken = ((uint)(4294967295u));
			this.symIPIE.TagName = "Equipment.IPIE";
			this.symIPIE.EndInit();
			// 
			// symBtnCME
			// 
			this.symBtnCME.BeginInit();
			this.symBtnCME.ButtonDisableText = "Close";
			this.symBtnCME.ButtonEnableText = "Open";
			this.symBtnCME.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 16D, 248D);
			this.symBtnCME.Enabled = false;
			this.symBtnCME.Name = "symBtnCME";
			this.symBtnCME.SecurityToken = ((uint)(4294967295u));
			this.symBtnCME.TagName = "Equipment.CME";
			this.symBtnCME.EndInit();
			// 
			// ICOPENR
			// 
			this.ICOPENR.BeginInit();
			this.ICOPENR.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 23D, 11D);
			this.ICOPENR.Name = "ICOPENR";
			this.ICOPENR.SecurityToken = ((uint)(4294967295u));
			this.ICOPENR.TagName = "Equipment.ICOPENR";
			this.ICOPENR.Val = false;
			this.ICOPENR.EndInit();
			// 
			// ICLOS
			// 
			this.ICLOS.BeginInit();
			this.ICLOS.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 30D, 18D);
			this.ICLOS.Name = "ICLOS";
			this.ICLOS.SecurityToken = ((uint)(4294967295u));
			this.ICLOS.TagName = "Equipment.ICLOS";
			this.ICLOS.Val = false;
			this.ICLOS.EndInit();
			// 
			// IOPEN
			// 
			this.IOPEN.BeginInit();
			this.IOPEN.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 36D, 33D);
			this.IOPEN.Name = "IOPEN";
			this.IOPEN.SecurityToken = ((uint)(4294967295u));
			this.IOPEN.TagName = "Equipment.IOPEN";
			this.IOPEN.Val = false;
			this.IOPEN.EndInit();
			// 
			// CMODE
			// 
			this.CMODE.BeginInit();
			this.CMODE.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 20D, 21D);
			this.CMODE.Name = "CMODE";
			this.CMODE.SecurityToken = ((uint)(4294967295u));
			this.CMODE.TagName = "Equipment.Mode.CMODE";
			this.CMODE.Val = ((short)(0));
			this.CMODE.ValMaximum = ((short)(0));
			this.CMODE.ValMinimum = ((short)(0));
			this.CMODE.ValUnits = null;
			this.CMODE.EndInit();
			// 
			// navPrograms
			// 
			this.navPrograms.BeginInit();
			this.navPrograms.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 232D, 0D);
			this.navPrograms.Name = "navPrograms";
			this.navPrograms.SecurityToken = ((uint)(4294967295u));
			this.navPrograms.TagName = "Control.Broadcaster_v1_0";
			this.navPrograms.EndInit();
			// 
			// navAlarm
			// 
			this.navAlarm.Bounds = new NxtControl.Drawing.RectF(((float)(232D)), ((float)(96D)), ((float)(24D)), ((float)(24D)));
			this.navAlarm.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.navAlarm.ImageBytes = resources.GetString("navAlarm.ImageBytes");
			this.navAlarm.Name = "navAlarm";
			this.navAlarm.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fAlarms", NxtControl.GuiFramework.MouseButtonType.Click));
			// 
			// navAlarmActive
			// 
			this.navAlarmActive.Bounds = new NxtControl.Drawing.RectF(((float)(232D)), ((float)(96D)), ((float)(24D)), ((float)(24D)));
			this.navAlarmActive.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.navAlarmActive.ImageBytes = resources.GetString("navAlarmActive.ImageBytes");
			this.navAlarmActive.Name = "navAlarmActive";
			this.navAlarmActive.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fAlarms", NxtControl.GuiFramework.MouseButtonType.Click));
			this.navAlarmActive.Visible = false;
			// 
			// IA
			// 
			this.IA.BeginInit();
			this.IA.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 26D, 27D);
			this.IA.Name = "IA";
			this.IA.SecurityToken = ((uint)(4294967295u));
			this.IA.TagName = "Equipment.IA";
			this.IA.Val = false;
			this.IA.EndInit();
			// 
			// IRSTPERM
			// 
			this.IRSTPERM.BeginInit();
			this.IRSTPERM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 18D, 115D);
			this.IRSTPERM.Name = "IRSTPERM";
			this.IRSTPERM.SecurityToken = ((uint)(4294967295u));
			this.IRSTPERM.TagName = "Equipment.IRSTPERM";
			this.IRSTPERM.Val = false;
			this.IRSTPERM.EndInit();
			// 
			// symBtnCFLRST
			// 
			this.symBtnCFLRST.BeginInit();
			this.symBtnCFLRST.ButtonText = "Reset";
			this.symBtnCFLRST.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 157D, 328D);
			this.symBtnCFLRST.Enabled = false;
			this.symBtnCFLRST.Name = "symBtnCFLRST";
			this.symBtnCFLRST.SecurityToken = ((uint)(4294967295u));
			this.symBtnCFLRST.TagName = "Equipment.CFLRST";
			this.symBtnCFLRST.EndInit();
			// 
			// symIIOFL
			// 
			this.symIIOFL.BeginInit();
			this.symIIOFL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -16D, 96D);
			this.symIIOFL.LabelText = "IO Fault:";
			this.symIIOFL.Name = "symIIOFL";
			this.symIIOFL.OffText = "No";
			this.symIIOFL.OnText = "Yes";
			this.symIIOFL.SecurityToken = ((uint)(4294967295u));
			this.symIIOFL.TagName = "Equipment.IIOFL";
			this.symIIOFL.EndInit();
			// 
			// fMain
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(260D)), ((float)(368D)));
			this.Brush = new NxtControl.Drawing.Brush("FaceplateBrush");
			this.FaceplateClose = NxtControl.GuiFramework.CloseFaceplateBehavior.Automatic;
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.AssetName,
			this.lblStatus,
			this.symTxtMode,
			this.txtStatus,
			this.symIFL,
			this.symIAOK,
			this.symISIM,
			this.symIPI,
			this.symBtnMode,
			this.navParameters,
			this.navData,
			this.navInterlock,
			this.navPermissive,
			this.navTrend,
			this.symIOPEN,
			this.symICLOS,
			this.symIPIE,
			this.symBtnCME,
			this.ICOPENR,
			this.ICLOS,
			this.IOPEN,
			this.CMODE,
			this.navPrograms,
			this.navAlarm,
			this.navAlarmActive,
			this.IA,
			this.IRSTPERM,
			this.symBtnCFLRST,
			this.symIIOFL});
			this.Size = new System.Drawing.Size(260, 368);

		}
		private System.HMI.Symbols.Base.Execute<string> AssetName;
		private NxtControl.GuiFramework.FreeText lblStatus;
		private SE.Agile.Symbols.ModeSelector_v1_0.sModeNamedMiddle symTxtMode;
		private NxtControl.GuiFramework.FreeText txtStatus;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed symIFL;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed symIAOK;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed symISIM;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed symIPI;
		private SE.Agile.Symbols.ModeSelector_v1_0.sButtonQuad symBtnMode;
		private NxtControl.GuiFramework.Rectangle navParameters;
		private NxtControl.GuiFramework.Rectangle navData;
		private NxtControl.GuiFramework.Rectangle navInterlock;
		private NxtControl.GuiFramework.Rectangle navAlarm;
		private NxtControl.GuiFramework.Rectangle navPermissive;
		private NxtControl.GuiFramework.Rectangle navTrend;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed symIOPEN;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed symICLOS;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed symIPIE;
		private SE.Agile.Symbols.HMI_Control_Bool_v1_0.sButtonVert2 symBtnCME;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged ICOPENR;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged ICLOS;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IOPEN;
		private SE.Agile.Symbols.HMI_Control_Integer_v1_0.sValChanged CMODE;
		private SE.Agile.Symbols.Broadcaster_v1_0.sButtonNavProgram navPrograms;
		private NxtControl.GuiFramework.Rectangle navAlarmActive;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IA;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IRSTPERM;
		private SE.Agile.Symbols.HMI_Control_Bool_v1_0.sButtonValSet symBtnCFLRST;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed symIIOFL;
		#endregion
	}
}
