﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 9/18/2025
 * Time: 9:28 AM
 * 
 */

using System;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.HMI_Indication_Real_v1_0
{
	/// <summary>
	/// Description of sValChanged.
	/// </summary>
	public partial class sValChanged : NxtControl.GuiFramework.HMISymbol
	{
		private float _val;
		private float _valMinimum;
		private float _valMaximum;
		private string _valUnits;
		private byte _valDecimalPlaces;
		
		public sValChanged()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}
			
	    // Event to notify value change
	    public event EventHandler OnValChanged;
	
	    public float Val
	    {
	    	get { return _val; }
	        set
	        {
	            if (_val != value)
	            {
	                _val = value;
                    OnValueChanged();
                }
	        }
	    }
	    
	    public float ValMinimum
	    {
	    	get { return _valMinimum; }
	        set
	        {
	            if (_valMinimum != value)
	            {
	                _valMinimum = value;
                    OnValueChanged();
                }
	        }
	    }
	    	    
		public float ValMaximum
	    {
	    	get { return _valMaximum; }
	        set
	        {
	            if (_valMaximum != value)
	            {
	                _valMaximum = value;
                    OnValueChanged();
                }
	        }
	    }
	    
	  	public string ValUnits
	    {
	    	get { return _valUnits; }
	        set
	        {
	            if (_valUnits != value)
	            {
	                _valUnits = value;
                    OnValueChanged();
                }
	        }
	    }
	  	
	  	public byte ValDecimalPlaces
	    {
	    	get { return _valDecimalPlaces; }
	        set
	        {
	            if (_valDecimalPlaces != value)
	            {
	                _valDecimalPlaces = value;
                    OnValueChanged();
                }
	        }
	    }
		
	    protected virtual void OnValueChanged()
	    {
	        OnValChanged?.Invoke(this, EventArgs.Empty);
	    }

		void ValueValueChanged(object sender, ValueChangedEventArgs e)
		{
			Val = (float)e.Value;
		}
		
		void MinimumValueChanged(object sender, ValueChangedEventArgs e)
		{
			ValMinimum = (float)e.Value;
		}

		void MaximumValueChanged(object sender, ValueChangedEventArgs e)
		{
			ValMaximum = (float)e.Value;
		}
		
		void UnitsValueChanged(object sender, ValueChangedEventArgs e)
		{
			ValUnits = e.Value.ToString();
		}
		
		void DecimalPlacesValueChanged(object sender, ValueChangedEventArgs e)
		{
			ValDecimalPlaces = (byte)e.Value;
		}
	}
}
