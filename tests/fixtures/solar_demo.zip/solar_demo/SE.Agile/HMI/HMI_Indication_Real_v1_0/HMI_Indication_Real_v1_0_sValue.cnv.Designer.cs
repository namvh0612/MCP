/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 8/20/2025
 * Time: 10:04 AM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.HMI_Indication_Real_v1_0
{
	/// <summary>
	/// Summary description for sNamed.
	/// </summary>
	partial class sValue
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.DecimalPlaces = new System.HMI.Symbols.Base.Execute<byte>();
			this.Value = new System.HMI.Symbols.Base.TextBox<float>();
			// 
			// DecimalPlaces
			// 
			this.DecimalPlaces.BeginInit();
			this.DecimalPlaces.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.DecimalPlaces.IsOnlyInput = true;
			this.DecimalPlaces.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.DecimalPlaces.Name = "DecimalPlaces";
			this.DecimalPlaces.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.DecimalPlaces.TagName = "DecimalPlaces";
			this.DecimalPlaces.Value = ((byte)(0));
			this.DecimalPlaces.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.DecimalPlacesValueChanged);
			this.DecimalPlaces.EndInit();
			// 
			// Value
			// 
			this.Value.BeginInit();
			this.Value.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.Value.DesignMatrix = new NxtControl.Drawing.Matrix2D(0.64D, 0D, 0D, 0.96153846153846156D, 23.999999999999996D, 16D);
			this.Value.IgnoreMouseEvents = true;
			this.Value.IsOnlyInput = true;
			this.Value.IsPrefixSuffixOutside = false;
			this.Value.MaximumTag = new NxtControl.GuiFramework.AuxHMIAccessor("Maximum", this.Value);
			this.Value.MinimumTag = new NxtControl.GuiFramework.AuxHMIAccessor("Minimum", this.Value);
			this.Value.Name = "Value";
			this.Value.NumberBase = NxtControl.GuiFramework.NumberBase.Decimal;
			this.Value.Pen = new NxtControl.Drawing.Pen("Transparent");
			this.Value.SetColor = new NxtControl.Drawing.Color("Yellow");
			this.Value.TagName = "Value";
			this.Value.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.Value.UseRange = true;
			this.Value.Value = 0F;
			this.Value.EndInit();
			// 
			// sValue
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.Value,
			this.DecimalPlaces});
			this.SymbolSize = new System.Drawing.Size(168, 60);

		}
		private System.HMI.Symbols.Base.TextBox<float> Value;
		private System.HMI.Symbols.Base.Execute<byte> DecimalPlaces;
		#endregion
	}
}
