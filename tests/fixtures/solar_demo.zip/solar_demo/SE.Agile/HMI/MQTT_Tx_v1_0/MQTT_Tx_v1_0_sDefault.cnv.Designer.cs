/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 6/5/2025
 * Time: 9:41 AM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.MQTT_Tx_v1_0
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sDefault
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      			this.Name = "sDefault";
		}
		#endregion
	}
}
