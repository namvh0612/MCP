using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region SystemTime_SMSPLCOK_v1_0_HMI;
#endregion SystemTime_SMSPLCOK_v1_0_HMI;

#endregion Definitions;

