﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 9/23/2025
 * Time: 6:23 PM
 * 
 */

using System;
using NxtControl.GuiFramework;

namespace SE.Agile.Faceplates.bcTransmitter_v1_0
{
	/// <summary>
	/// Description of fParameters.
	/// </summary>
	public partial class fParameters : NxtControl.GuiFramework.HMIFaceplate
	{
		private bool _CSIM;
		
		public fParameters()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();

			CSIM.OnValChanged += OnSubCatValueChanged;
		}
		
		void AssetNameValueChanged(object sender, ValueChangedEventArgs e)
		{
			Title = (string)e.Value;
		}
		
		// EXECUTE logic triggered by child value change
	    private void OnSubCatValueChanged(object sender, EventArgs e)
	    {
			if (_CSIM != CSIM.Val)
			{
				symCPSIM.Enabled = CSIM.Val;
			}
			
			_CSIM = CSIM.Val;
		}
	}
}
