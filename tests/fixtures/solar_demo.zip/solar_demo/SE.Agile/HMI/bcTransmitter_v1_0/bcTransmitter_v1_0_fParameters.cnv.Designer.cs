/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 9/23/2025
 * Time: 6:23 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using NxtControl.GuiFramework;

namespace SE.Agile.Faceplates.bcTransmitter_v1_0
{
	/// <summary>
	/// Summary description for fParameters.
	/// </summary>
	partial class fParameters
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.AssetName = new System.HMI.Symbols.Base.Execute<string>();
			this.symCPDDAND = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed();
			this.symCDBON = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed();
			this.symCPHH = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed();
			this.symCPHI = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed();
			this.symCPLL = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed();
			this.symCPLO = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed();
			this.symCPSIM = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed();
			this.symBtnCSIM = new SE.Agile.Symbols.HMI_Control_Bool_v1_0.sButtonTwoStateNamed();
			this.CSIM = new SE.Agile.Symbols.HMI_Control_Bool_v1_0.sValChanged();
			// 
			// AssetName
			// 
			this.AssetName.BeginInit();
			this.AssetName.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.AssetName.IsOnlyInput = true;
			this.AssetName.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.AssetName.Name = "AssetName";
			this.AssetName.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.AssetName.TagName = "AssetName";
			this.AssetName.Value = null;
			this.AssetName.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.AssetNameValueChanged);
			this.AssetName.EndInit();
			// 
			// symCPDDAND
			// 
			this.symCPDDAND.BeginInit();
			this.symCPDDAND.DecimalPlacesCount = ((uint)(2u));
			this.symCPDDAND.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -24D, 16D);
			this.symCPDDAND.Enabled = true;
			this.symCPDDAND.LabelText = "Control Deadband:";
			this.symCPDDAND.Name = "symCPDDAND";
			this.symCPDDAND.SecurityToken = ((uint)(4294967295u));
			this.symCPDDAND.TagName = "CPDDAND";
			this.symCPDDAND.EndInit();
			// 
			// symCDBON
			// 
			this.symCDBON.BeginInit();
			this.symCDBON.DecimalPlacesCount = ((uint)(2u));
			this.symCDBON.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -24D, 48D);
			this.symCDBON.Enabled = true;
			this.symCDBON.LabelText = "De-Bounce On Time";
			this.symCDBON.Name = "symCDBON";
			this.symCDBON.SecurityToken = ((uint)(4294967295u));
			this.symCDBON.TagName = "CDBON";
			this.symCDBON.EndInit();
			// 
			// symCPHH
			// 
			this.symCPHH.BeginInit();
			this.symCPHH.DecimalPlacesCount = ((uint)(2u));
			this.symCPHH.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -24D, 80D);
			this.symCPHH.Enabled = true;
			this.symCPHH.LabelText = "HH Setpoint:";
			this.symCPHH.Name = "symCPHH";
			this.symCPHH.SecurityToken = ((uint)(4294967295u));
			this.symCPHH.TagName = "CPHH";
			this.symCPHH.EndInit();
			// 
			// symCPHI
			// 
			this.symCPHI.BeginInit();
			this.symCPHI.DecimalPlacesCount = ((uint)(2u));
			this.symCPHI.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -24D, 112D);
			this.symCPHI.Enabled = true;
			this.symCPHI.LabelText = "HI Setpoint:";
			this.symCPHI.Name = "symCPHI";
			this.symCPHI.SecurityToken = ((uint)(4294967295u));
			this.symCPHI.TagName = "CPHI";
			this.symCPHI.EndInit();
			// 
			// symCPLL
			// 
			this.symCPLL.BeginInit();
			this.symCPLL.DecimalPlacesCount = ((uint)(2u));
			this.symCPLL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -24D, 176D);
			this.symCPLL.Enabled = true;
			this.symCPLL.LabelText = "LL Setpoint:";
			this.symCPLL.Name = "symCPLL";
			this.symCPLL.SecurityToken = ((uint)(4294967295u));
			this.symCPLL.TagName = "CPLL";
			this.symCPLL.EndInit();
			// 
			// symCPLO
			// 
			this.symCPLO.BeginInit();
			this.symCPLO.DecimalPlacesCount = ((uint)(2u));
			this.symCPLO.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -24D, 144D);
			this.symCPLO.Enabled = true;
			this.symCPLO.LabelText = "LO Setpoint:";
			this.symCPLO.Name = "symCPLO";
			this.symCPLO.SecurityToken = ((uint)(4294967295u));
			this.symCPLO.TagName = "CPLO";
			this.symCPLO.EndInit();
			// 
			// symCPSIM
			// 
			this.symCPSIM.BeginInit();
			this.symCPSIM.DecimalPlacesCount = ((uint)(2u));
			this.symCPSIM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -24D, 240D);
			this.symCPSIM.Enabled = true;
			this.symCPSIM.LabelText = "Simulation Value:";
			this.symCPSIM.Name = "symCPSIM";
			this.symCPSIM.SecurityToken = ((uint)(4294967295u));
			this.symCPSIM.TagName = "CPSIM";
			this.symCPSIM.EndInit();
			// 
			// symBtnCSIM
			// 
			this.symBtnCSIM.BeginInit();
			this.symBtnCSIM.ButtonFalseColor = new NxtControl.Drawing.Color(((byte)(110)), ((byte)(110)), ((byte)(110)));
			this.symBtnCSIM.ButtonTrueColor = new NxtControl.Drawing.Color(((byte)(0)), ((byte)(168)), ((byte)(231)));
			this.symBtnCSIM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -24D, 208D);
			this.symBtnCSIM.Enabled = true;
			this.symBtnCSIM.LabelText = "Simulation:";
			this.symBtnCSIM.Name = "symBtnCSIM";
			this.symBtnCSIM.SecurityToken = ((uint)(4294967295u));
			this.symBtnCSIM.TagName = "CSIM";
			this.symBtnCSIM.EndInit();
			// 
			// CSIM
			// 
			this.CSIM.BeginInit();
			this.CSIM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 26D, 101D);
			this.CSIM.Name = "CSIM";
			this.CSIM.SecurityToken = ((uint)(4294967295u));
			this.CSIM.TagName = "CSIM";
			this.CSIM.Val = false;
			this.CSIM.EndInit();
			// 
			// fParameters
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(260D)), ((float)(312D)));
			this.Brush = new NxtControl.Drawing.Brush("FaceplateBrush");
			this.FaceplateClose = NxtControl.GuiFramework.CloseFaceplateBehavior.Automatic;
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.AssetName,
			this.symCPDDAND,
			this.symCDBON,
			this.symCPHH,
			this.symCPHI,
			this.symCPLL,
			this.symCPLO,
			this.symCPSIM,
			this.symBtnCSIM,
			this.CSIM});
			this.Size = new System.Drawing.Size(260, 312);

		}
		private System.HMI.Symbols.Base.Execute<string> AssetName;
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed symCPDDAND;
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed symCDBON;
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed symCPHH;
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed symCPHI;
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed symCPLL;
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed symCPLO;
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed symCPSIM;
		private SE.Agile.Symbols.HMI_Control_Bool_v1_0.sButtonTwoStateNamed symBtnCSIM;
		private SE.Agile.Symbols.HMI_Control_Bool_v1_0.sValChanged CSIM;
		#endregion
	}
}
