/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 9/23/2025
 * Time: 9:37 AM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using NxtControl.GuiFramework;

namespace SE.Agile.Faceplates.bcTransmitter_v1_0
{
	/// <summary>
	/// Summary description for fMain.
	/// </summary>
	partial class fMain
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fMain));
			this.symBtnMode = new SE.Agile.Symbols.ModeSelector_v1_0.sButtonQuad();
			this.AssetName = new System.HMI.Symbols.Base.Execute<string>();
			this.symTxtMode = new SE.Agile.Symbols.ModeSelector_v1_0.sModeNamedMiddle();
			this.symIAOK = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed();
			this.symISIM = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed();
			this.navParameters = new NxtControl.GuiFramework.Rectangle();
			this.navData = new NxtControl.GuiFramework.Rectangle();
			this.navInterlock = new NxtControl.GuiFramework.Rectangle();
			this.navPermissive = new NxtControl.GuiFramework.Rectangle();
			this.navTrend = new NxtControl.GuiFramework.Rectangle();
			this.symI = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValueMiddleNamed();
			this.sBarI = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValueBarVert();
			this.IHH = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IHI = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.ILL = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.ILO = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.txtIHH = new NxtControl.GuiFramework.FreeText();
			this.txtIHI = new NxtControl.GuiFramework.FreeText();
			this.txtILO = new NxtControl.GuiFramework.FreeText();
			this.txtILL = new NxtControl.GuiFramework.FreeText();
			this.navAlarm = new NxtControl.GuiFramework.Rectangle();
			this.navAlarmActive = new NxtControl.GuiFramework.Rectangle();
			this.IA = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.symBtnCACAK = new SE.Agile.Symbols.HMI_Control_Bool_v1_0.sButtonValSet();
			this.IRSTPER = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.symIOMODE = new SE.Agile.Symbols.HMI_Control_Integer_v1_0.sButtonToggle();
			this.symIIOFL = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed();
			// 
			// symBtnMode
			// 
			this.symBtnMode.BeginInit();
			this.symBtnMode.ButtonTextDisabledColor = new NxtControl.Drawing.Color("ButtonTextDisabledColor");
			this.symBtnMode.ButtonToggleOnBrush = new NxtControl.Drawing.Brush("ButtonPushedBrush");
			this.symBtnMode.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 80D, 320D);
			this.symBtnMode.Name = "symBtnMode";
			this.symBtnMode.SecurityToken = ((uint)(4294967295u));
			this.symBtnMode.ShowDisabled = false;
			this.symBtnMode.TagName = "Mode";
			this.symBtnMode.EndInit();
			// 
			// AssetName
			// 
			this.AssetName.BeginInit();
			this.AssetName.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.AssetName.IsOnlyInput = true;
			this.AssetName.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.AssetName.Name = "AssetName";
			this.AssetName.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.AssetName.TagName = "AssetName";
			this.AssetName.Value = null;
			this.AssetName.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.AssetNameValueChanged);
			this.AssetName.EndInit();
			// 
			// symTxtMode
			// 
			this.symTxtMode.BeginInit();
			this.symTxtMode.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -32D, 8D);
			this.symTxtMode.LabelText = "Mode:";
			this.symTxtMode.Name = "symTxtMode";
			this.symTxtMode.SecurityToken = ((uint)(4294967295u));
			this.symTxtMode.TagName = "Mode";
			this.symTxtMode.EndInit();
			// 
			// symIAOK
			// 
			this.symIAOK.BeginInit();
			this.symIAOK.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -32D, 32D);
			this.symIAOK.LabelText = "Available in Auto:";
			this.symIAOK.Name = "symIAOK";
			this.symIAOK.OffText = "No";
			this.symIAOK.OnText = "Yes";
			this.symIAOK.SecurityToken = ((uint)(4294967295u));
			this.symIAOK.TagName = "IAOK";
			this.symIAOK.EndInit();
			// 
			// symISIM
			// 
			this.symISIM.BeginInit();
			this.symISIM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -32D, 320D);
			this.symISIM.LabelText = "Simulation:";
			this.symISIM.Name = "symISIM";
			this.symISIM.SecurityToken = ((uint)(4294967295u));
			this.symISIM.TagName = "ISIM";
			this.symISIM.EndInit();
			// 
			// navParameters
			// 
			this.navParameters.Bounds = new NxtControl.Drawing.RectF(((float)(224D)), ((float)(0D)), ((float)(24D)), ((float)(24D)));
			this.navParameters.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.navParameters.ImageBytes = resources.GetString("navParameters.ImageBytes");
			this.navParameters.Name = "navParameters";
			this.navParameters.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fParameters", NxtControl.GuiFramework.MouseButtonType.Click));
			// 
			// navData
			// 
			this.navData.Bounds = new NxtControl.Drawing.RectF(((float)(224D)), ((float)(24D)), ((float)(24D)), ((float)(24D)));
			this.navData.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.navData.ImageBytes = resources.GetString("navData.ImageBytes");
			this.navData.Name = "navData";
			// 
			// navInterlock
			// 
			this.navInterlock.Bounds = new NxtControl.Drawing.RectF(((float)(224D)), ((float)(48D)), ((float)(24D)), ((float)(24D)));
			this.navInterlock.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.navInterlock.ImageBytes = resources.GetString("navInterlock.ImageBytes");
			this.navInterlock.Name = "navInterlock";
			// 
			// navPermissive
			// 
			this.navPermissive.Bounds = new NxtControl.Drawing.RectF(((float)(224D)), ((float)(96D)), ((float)(24D)), ((float)(24D)));
			this.navPermissive.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.navPermissive.ImageBytes = resources.GetString("navPermissive.ImageBytes");
			this.navPermissive.Name = "navPermissive";
			// 
			// navTrend
			// 
			this.navTrend.Bounds = new NxtControl.Drawing.RectF(((float)(224D)), ((float)(120D)), ((float)(24D)), ((float)(24D)));
			this.navTrend.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.navTrend.ImageBytes = resources.GetString("navTrend.ImageBytes");
			this.navTrend.Name = "navTrend";
			// 
			// symI
			// 
			this.symI.BeginInit();
			this.symI.DecimalPlacesCount = ((uint)(2u));
			this.symI.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -32D, 296D);
			this.symI.LabelText = "Process variable:";
			this.symI.Name = "symI";
			this.symI.SecurityToken = ((uint)(4294967295u));
			this.symI.TagName = "I";
			this.symI.EndInit();
			// 
			// sBarI
			// 
			this.sBarI.BeginInit();
			this.sBarI.BarRangeTextStyle = System.Windows.Forms.TickStyle.TopLeft;
			this.sBarI.BarTickStyle = System.Windows.Forms.TickStyle.Both;
			this.sBarI.BarValueBrush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("Yellow"));
			this.sBarI.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 40D, 80D);
			this.sBarI.LabelText = "PV";
			this.sBarI.LabelTextLocation = new NxtControl.Drawing.PointF(86D, 223D);
			this.sBarI.Name = "sBarI";
			this.sBarI.SecurityToken = ((uint)(4294967295u));
			this.sBarI.ShowUnits = true;
			this.sBarI.TagName = "I";
			this.sBarI.UnitsTextLocation = new NxtControl.Drawing.PointF(86D, 34D);
			this.sBarI.EndInit();
			// 
			// IHH
			// 
			this.IHH.BeginInit();
			this.IHH.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 20D, 157D);
			this.IHH.Name = "IHH";
			this.IHH.SecurityToken = ((uint)(4294967295u));
			this.IHH.TagName = "HH.I";
			this.IHH.Val = false;
			this.IHH.EndInit();
			// 
			// IHI
			// 
			this.IHI.BeginInit();
			this.IHI.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 31D, 146D);
			this.IHI.Name = "IHI";
			this.IHI.SecurityToken = ((uint)(4294967295u));
			this.IHI.TagName = "HI.I";
			this.IHI.Val = false;
			this.IHI.EndInit();
			// 
			// ILL
			// 
			this.ILL.BeginInit();
			this.ILL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 28D, 144D);
			this.ILL.Name = "ILL";
			this.ILL.SecurityToken = ((uint)(4294967295u));
			this.ILL.TagName = "LL.I";
			this.ILL.Val = false;
			this.ILL.EndInit();
			// 
			// ILO
			// 
			this.ILO.BeginInit();
			this.ILO.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 32D, 179D);
			this.ILO.Name = "ILO";
			this.ILO.SecurityToken = ((uint)(4294967295u));
			this.ILO.TagName = "LO.I";
			this.ILO.Val = false;
			this.ILO.EndInit();
			// 
			// txtIHH
			// 
			this.txtIHH.Color = new NxtControl.Drawing.Color("LabelTextColor");
			this.txtIHH.Font = new NxtControl.Drawing.Font("LabelFont");
			this.txtIHH.Location = new NxtControl.Drawing.PointF(160D, 128D);
			this.txtIHH.Name = "txtIHH";
			this.txtIHH.Text = "HH";
			// 
			// txtIHI
			// 
			this.txtIHI.Color = new NxtControl.Drawing.Color("LabelTextColor");
			this.txtIHI.Font = new NxtControl.Drawing.Font("LabelFont");
			this.txtIHI.Location = new NxtControl.Drawing.PointF(160D, 144D);
			this.txtIHI.Name = "txtIHI";
			this.txtIHI.Text = "HI";
			// 
			// txtILO
			// 
			this.txtILO.Color = new NxtControl.Drawing.Color("LabelTextColor");
			this.txtILO.Font = new NxtControl.Drawing.Font("LabelFont");
			this.txtILO.Location = new NxtControl.Drawing.PointF(160D, 208D);
			this.txtILO.Name = "txtILO";
			this.txtILO.Text = "LO";
			// 
			// txtILL
			// 
			this.txtILL.Color = new NxtControl.Drawing.Color("LabelTextColor");
			this.txtILL.Font = new NxtControl.Drawing.Font("LabelFont");
			this.txtILL.Location = new NxtControl.Drawing.PointF(160D, 224D);
			this.txtILL.Name = "txtILL";
			this.txtILL.Text = "LL";
			// 
			// navAlarm
			// 
			this.navAlarm.Bounds = new NxtControl.Drawing.RectF(((float)(224D)), ((float)(72D)), ((float)(24D)), ((float)(24D)));
			this.navAlarm.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.navAlarm.ImageBytes = resources.GetString("navAlarm.ImageBytes");
			this.navAlarm.Name = "navAlarm";
			this.navAlarm.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fAlarms", NxtControl.GuiFramework.MouseButtonType.Click));
			// 
			// navAlarmActive
			// 
			this.navAlarmActive.Bounds = new NxtControl.Drawing.RectF(((float)(224D)), ((float)(72D)), ((float)(24D)), ((float)(24D)));
			this.navAlarmActive.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.navAlarmActive.ImageBytes = resources.GetString("navAlarmActive.ImageBytes");
			this.navAlarmActive.Name = "navAlarmActive";
			this.navAlarmActive.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fAlarms", NxtControl.GuiFramework.MouseButtonType.Click));
			this.navAlarmActive.Visible = false;
			// 
			// IA
			// 
			this.IA.BeginInit();
			this.IA.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 6D, 71D);
			this.IA.Name = "IA";
			this.IA.SecurityToken = ((uint)(4294967295u));
			this.IA.TagName = "IA";
			this.IA.Val = false;
			this.IA.EndInit();
			// 
			// symBtnCACAK
			// 
			this.symBtnCACAK.BeginInit();
			this.symBtnCACAK.ButtonText = "Reset";
			this.symBtnCACAK.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 149D, 392D);
			this.symBtnCACAK.Enabled = false;
			this.symBtnCACAK.Name = "symBtnCACAK";
			this.symBtnCACAK.SecurityToken = ((uint)(4294967295u));
			this.symBtnCACAK.TagName = "CACAK";
			this.symBtnCACAK.EndInit();
			// 
			// IRSTPER
			// 
			this.IRSTPER.BeginInit();
			this.IRSTPER.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 54D, 167D);
			this.IRSTPER.Name = "IRSTPER";
			this.IRSTPER.SecurityToken = ((uint)(4294967295u));
			this.IRSTPER.TagName = "IRSTPER";
			this.IRSTPER.Val = false;
			this.IRSTPER.EndInit();
			// 
			// symIOMODE
			// 
			this.symIOMODE.BeginInit();
			this.symIOMODE.ButtonToggleNotSetText = "No Source";
			this.symIOMODE.ButtonToggleOffText = "I/O";
			this.symIOMODE.ButtonToggleOffValue = ((short)(1));
			this.symIOMODE.ButtonToggleOnBrush = new NxtControl.Drawing.Brush("ButtonPushedBrush");
			this.symIOMODE.ButtonToggleOnText = "Derived";
			this.symIOMODE.ButtonToggleOnValue = ((short)(2));
			this.symIOMODE.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 8D, 348D);
			this.symIOMODE.Name = "symIOMODE";
			this.symIOMODE.SecurityToken = ((uint)(4294967295u));
			this.symIOMODE.TagName = "IOMODE";
			this.symIOMODE.EndInit();
			// 
			// symIIOFL
			// 
			this.symIIOFL.BeginInit();
			this.symIIOFL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -32D, 56D);
			this.symIIOFL.LabelText = "IO Fault:";
			this.symIIOFL.Name = "symIIOFL";
			this.symIIOFL.OffText = "No";
			this.symIIOFL.OnText = "Yes";
			this.symIIOFL.SecurityToken = ((uint)(4294967295u));
			this.symIIOFL.TagName = "IIOFL";
			this.symIIOFL.EndInit();
			// 
			// fMain
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(250D)), ((float)(432D)));
			this.Brush = new NxtControl.Drawing.Brush("FaceplateBrush");
			this.FaceplateClose = NxtControl.GuiFramework.CloseFaceplateBehavior.Automatic;
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.symBtnMode,
			this.AssetName,
			this.symTxtMode,
			this.symIAOK,
			this.symISIM,
			this.navParameters,
			this.navData,
			this.navInterlock,
			this.navPermissive,
			this.navTrend,
			this.symI,
			this.sBarI,
			this.IHH,
			this.IHI,
			this.ILL,
			this.ILO,
			this.txtIHH,
			this.txtIHI,
			this.txtILO,
			this.txtILL,
			this.navAlarm,
			this.navAlarmActive,
			this.IA,
			this.symBtnCACAK,
			this.IRSTPER,
			this.symIOMODE,
			this.symIIOFL});
			this.Size = new System.Drawing.Size(250, 432);

		}
		private SE.Agile.Symbols.ModeSelector_v1_0.sButtonQuad symBtnMode;
		private System.HMI.Symbols.Base.Execute<string> AssetName;
		private SE.Agile.Symbols.ModeSelector_v1_0.sModeNamedMiddle symTxtMode;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed symIAOK;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed symISIM;
		private NxtControl.GuiFramework.Rectangle navParameters;
		private NxtControl.GuiFramework.Rectangle navData;
		private NxtControl.GuiFramework.Rectangle navInterlock;
		private NxtControl.GuiFramework.Rectangle navAlarm;
		private NxtControl.GuiFramework.Rectangle navPermissive;
		private NxtControl.GuiFramework.Rectangle navTrend;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValueMiddleNamed symI;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValueBarVert sBarI;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IHH;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IHI;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged ILL;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged ILO;
		private NxtControl.GuiFramework.FreeText txtIHH;
		private NxtControl.GuiFramework.FreeText txtIHI;
		private NxtControl.GuiFramework.FreeText txtILO;
		private NxtControl.GuiFramework.FreeText txtILL;
		private NxtControl.GuiFramework.Rectangle navAlarmActive;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IA;
		private SE.Agile.Symbols.HMI_Control_Bool_v1_0.sButtonValSet symBtnCACAK;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IRSTPER;
		private SE.Agile.Symbols.HMI_Control_Integer_v1_0.sButtonToggle symIOMODE;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed symIIOFL;
		#endregion
	}
}
