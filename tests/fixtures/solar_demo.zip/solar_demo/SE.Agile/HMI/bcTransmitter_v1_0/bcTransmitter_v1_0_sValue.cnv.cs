﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 5/5/2026
 * Time: 11:17 PM
 * 
 */

using System;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.bcTransmitter_v1_0
{
	/// <summary>
	/// Description of sValue.
	/// </summary>
	public partial class sValue : NxtControl.GuiFramework.HMISymbol
	{
		private bool _IFL;
		private bool _ISIM;
		private bool _IA;
		
		private NxtControl.Drawing.Brush _brushFault = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(234)), ((byte)(22)), ((byte)(30))));
		private NxtControl.Drawing.Brush _brushSimulation = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(254)), ((byte)(186)), ((byte)(10))));
		
		public sValue()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			IFL.OnValChanged += OnSubCatValueChanged;
			ISIM.OnValChanged += OnSubCatValueChanged;
			IA.OnValChanged += OnSubCatValueChanged;
		}
	
		void AssetNameValueChanged(object sender, ValueChangedEventArgs e)
		{
			txtAssetName.Text = e.Value.ToString();
			
			GroupStatus.Visible = _ISIM || _IFL;
    		alarmBell.Visible = _IA;
		}
		
		// EXECUTE logic triggered by child value change
	    private void OnSubCatValueChanged(object sender, EventArgs e)
	    {
			if (IFL.Val != _IFL || ISIM.Val != _ISIM)
	    	{	
	    		if (IFL.Val)
	    		{
	    			StatusBody.Brush = _brushFault;
	    		}
	    		else if (ISIM.Val)
	    		{
	    			StatusBody.Brush = _brushSimulation;
	    		}
	    		
	    		GroupStatus.Visible = ISIM.Val || IFL.Val;
	    	}

	    	if (IA.Val != _IA)
	    	{
	    		alarmBell.Visible = IA.Val;
	    	}
	    	
			_IFL = IFL.Val;
			_ISIM = ISIM.Val;
			_IA = IA.Val;
		}
	}
}
