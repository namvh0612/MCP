/*
 * Created by EcoStruxure Automation Expert.
 * User: sclark
 * Date: 12/9/2024
 * Time: 9:22 AM
 * 
 */

using System;
using NxtControl.GuiFramework;
using System.ComponentModel;

namespace SE.Agile.Symbols.bcTransmitter_v1_0
{
	/// <summary>
	/// Description of sDefault.
	/// </summary>
	public partial class sBarVertical : NxtControl.GuiFramework.HMISymbol
	{
		private float _I;
		private byte _IDecimalPlaces;
		private string _IUnits;
		private bool _IFL;
		private bool _ISIM;
		private bool _IA;
		
		private NxtControl.Drawing.Brush _brushFault = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(234)), ((byte)(22)), ((byte)(30))));
		private NxtControl.Drawing.Brush _brushSimulation = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(254)), ((byte)(186)), ((byte)(10))));
		
		public sBarVertical()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			I.OnValChanged += OnSubCatValueChanged;
			IFL.OnValChanged += OnSubCatValueChanged;
			ISIM.OnValChanged += OnSubCatValueChanged;
			IA.OnValChanged += OnSubCatValueChanged;
		}

		[RefreshProperties(RefreshProperties.All), Category("Symbol")]
		public NxtControl.Drawing.Brush BarValueBrush
		{
			get { return symBarI.BarValueBrush; }
			set
			{
				symBarI.BarValueBrush = value;
			}
		}
		
		void AssetNameValueChanged(object sender, ValueChangedEventArgs e)
		{
			txtAssetName.Text = e.Value.ToString();
			
			GroupStatus.Visible = _ISIM || _IFL;
    		alarmBell.Visible = _IA;
		}
		
		// EXECUTE logic triggered by child value change
	    private void OnSubCatValueChanged(object sender, EventArgs e)
	    {
	    	if ((I.Val != _I) || (I.ValDecimalPlaces != _IDecimalPlaces))
	    	{
	    		txtI.Text = I.Val.ToString($"F{I.ValDecimalPlaces}");
	    	}
	    	
	    	if (I.ValUnits != _IUnits)
	    	{
	    		lblI.Text = $"PV {I.ValUnits}";
	    	}
	    	
			if (IFL.Val != _IFL || ISIM.Val != _ISIM)
	    	{	
	    		if (IFL.Val)
	    		{
	    			StatusBody.Brush = _brushFault;
	    		}
	    		else if (ISIM.Val)
	    		{
	    			StatusBody.Brush = _brushSimulation;
	    		}
	    		
	    		GroupStatus.Visible = ISIM.Val || IFL.Val;
	    	}

	    	if (IA.Val != _IA)
	    	{
	    		alarmBell.Visible = IA.Val;
	    	}
	    	
			_I = I.Val;
			_IDecimalPlaces = I.ValDecimalPlaces;
			_IUnits = I.ValUnits;
			_IFL = IFL.Val;
			_ISIM = ISIM.Val;
			_IA = IA.Val;
		}
	}
}
