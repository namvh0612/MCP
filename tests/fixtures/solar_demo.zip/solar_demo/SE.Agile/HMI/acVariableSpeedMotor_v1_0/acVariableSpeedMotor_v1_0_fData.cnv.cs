/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 4/20/2026
 * Time: 12:25 PM
 * 
 */

using System;
using NxtControl.GuiFramework;

namespace SE.Agile.Faceplates.acVariableSpeedMotor_v1_0
{
	/// <summary>
	/// Description of sMetering.
	/// </summary>
	public partial class fData : NxtControl.GuiFramework.HMIFaceplate
	{
		public fData()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}
		
		void AssetNameValueChanged(object sender, ValueChangedEventArgs e)
		{
			Title = (string)e.Value;
		}
	}
}
