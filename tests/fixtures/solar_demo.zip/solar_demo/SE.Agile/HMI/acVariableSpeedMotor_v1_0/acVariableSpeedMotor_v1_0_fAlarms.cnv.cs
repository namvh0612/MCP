﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 2/27/2026
 * Time: 12:42 AM
 * 
 */

using System;
using NxtControl.GuiFramework;

namespace SE.Agile.Faceplates.acVariableSpeedMotor_v1_0
{
	/// <summary>
	/// Description of fAlarms.
	/// </summary>
	public partial class fAlarms : NxtControl.GuiFramework.HMIFaceplate
	{
		public fAlarms()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}
		
		void AssetNameValueChanged(object sender, ValueChangedEventArgs e)
		{
			Title = (string)e.Value;
		}
	}
}
