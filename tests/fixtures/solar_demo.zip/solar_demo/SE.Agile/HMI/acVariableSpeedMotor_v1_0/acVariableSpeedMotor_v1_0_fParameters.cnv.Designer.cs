/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 9/22/2025
 * Time: 5:30 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using NxtControl.GuiFramework;

namespace SE.Agile.Faceplates.acVariableSpeedMotor_v1_0
{
	/// <summary>
	/// Summary description for fParameters.
	/// </summary>
	partial class fParameters
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.symCSTTFL = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed();
			this.symCSTPL = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed();
			this.symCHICLAMP = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed();
			this.symCLOCLAMP = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed();
			this.symCSPDDBSP = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed();
			this.symBtnCMSK = new SE.Agile.Symbols.HMI_Control_Bool_v1_0.sButtonTwoStateNamed();
			this.AssetName = new System.HMI.Symbols.Base.Execute<string>();
			// 
			// symCSTTFL
			// 
			this.symCSTTFL.BeginInit();
			this.symCSTTFL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -8D, 8D);
			this.symCSTTFL.Enabled = true;
			this.symCSTTFL.LabelText = "Time to Start:";
			this.symCSTTFL.Name = "symCSTTFL";
			this.symCSTTFL.SecurityToken = ((uint)(4294967295u));
			this.symCSTTFL.TagName = "Equipment.CSTTFL";
			this.symCSTTFL.EndInit();
			// 
			// symCSTPL
			// 
			this.symCSTPL.BeginInit();
			this.symCSTPL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -8D, 40D);
			this.symCSTPL.Enabled = true;
			this.symCSTPL.LabelText = "Time to Stop:";
			this.symCSTPL.Name = "symCSTPL";
			this.symCSTPL.SecurityToken = ((uint)(4294967295u));
			this.symCSTPL.TagName = "Equipment.CSTPFL";
			this.symCSTPL.EndInit();
			// 
			// symCHICLAMP
			// 
			this.symCHICLAMP.BeginInit();
			this.symCHICLAMP.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -8D, 72D);
			this.symCHICLAMP.Enabled = true;
			this.symCHICLAMP.LabelText = "Output HI Clamp SP:";
			this.symCHICLAMP.Name = "symCHICLAMP";
			this.symCHICLAMP.SecurityToken = ((uint)(4294967295u));
			this.symCHICLAMP.TagName = "Equipment.CHICLAMP";
			this.symCHICLAMP.EndInit();
			// 
			// symCLOCLAMP
			// 
			this.symCLOCLAMP.BeginInit();
			this.symCLOCLAMP.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -8D, 104D);
			this.symCLOCLAMP.Enabled = true;
			this.symCLOCLAMP.LabelText = "Output LO Clamp SP:";
			this.symCLOCLAMP.Name = "symCLOCLAMP";
			this.symCLOCLAMP.SecurityToken = ((uint)(4294967295u));
			this.symCLOCLAMP.TagName = "Equipment.CLOCLAMP";
			this.symCLOCLAMP.EndInit();
			// 
			// symCSPDDBSP
			// 
			this.symCSPDDBSP.BeginInit();
			this.symCSPDDBSP.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -8D, 136D);
			this.symCSPDDBSP.Enabled = true;
			this.symCSPDDBSP.LabelText = "Input Deadband:";
			this.symCSPDDBSP.Name = "symCSPDDBSP";
			this.symCSPDDBSP.SecurityToken = ((uint)(4294967295u));
			this.symCSPDDBSP.TagName = "Equipment.CSPDDBSP";
			this.symCSPDDBSP.EndInit();
			// 
			// symBtnCMSK
			// 
			this.symBtnCMSK.BeginInit();
			this.symBtnCMSK.ButtonFalseColor = new NxtControl.Drawing.Color(((byte)(110)), ((byte)(110)), ((byte)(110)));
			this.symBtnCMSK.ButtonTrueColor = new NxtControl.Drawing.Color(((byte)(0)), ((byte)(168)), ((byte)(231)));
			this.symBtnCMSK.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -8D, 168D);
			this.symBtnCMSK.Enabled = true;
			this.symBtnCMSK.LabelText = "Simulation";
			this.symBtnCMSK.Name = "symBtnCMSK";
			this.symBtnCMSK.SecurityToken = ((uint)(4294967295u));
			this.symBtnCMSK.TagName = "Equipment.CMSK";
			this.symBtnCMSK.EndInit();
			// 
			// AssetName
			// 
			this.AssetName.BeginInit();
			this.AssetName.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.AssetName.IsOnlyInput = true;
			this.AssetName.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.AssetName.Name = "AssetName";
			this.AssetName.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.AssetName.TagName = "AssetName";
			this.AssetName.Value = null;
			this.AssetName.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.AssetNameValueChanged);
			this.AssetName.EndInit();
			// 
			// fParameters
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(280D)), ((float)(272D)));
			this.Brush = new NxtControl.Drawing.Brush("FaceplateBrush");
			this.FaceplateClose = NxtControl.GuiFramework.CloseFaceplateBehavior.Automatic;
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.symCSTTFL,
			this.symCSTPL,
			this.symCHICLAMP,
			this.symCLOCLAMP,
			this.symCSPDDBSP,
			this.symBtnCMSK,
			this.AssetName});
			this.Size = new System.Drawing.Size(280, 272);

		}
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed symCSTTFL;
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed symCSTPL;
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed symCHICLAMP;
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed symCLOCLAMP;
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed symCSPDDBSP;
		private SE.Agile.Symbols.HMI_Control_Bool_v1_0.sButtonTwoStateNamed symBtnCMSK;
		private System.HMI.Symbols.Base.Execute<string> AssetName;
		#endregion
	}
}
