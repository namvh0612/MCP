/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 2/27/2026
 * Time: 12:42 AM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using NxtControl.GuiFramework;

namespace SE.Agile.Faceplates.acVariableSpeedMotor_v1_0
{
	/// <summary>
	/// Summary description for fAlarms.
	/// </summary>
	partial class fAlarms
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.AssetName = new System.HMI.Symbols.Base.Execute<string>();
			this.symSTRTFL = new SE.Agile.Symbols.DA_v1_0.sDA();
			this.symSTOPFL = new SE.Agile.Symbols.DA_v1_0.sDA();
			this.symDF = new SE.Agile.Symbols.DIA_v1_0.sDIA();
			this.symHRSTOTMNT = new SE.Agile.Symbols.DA_v1_0.sDA();
			// 
			// AssetName
			// 
			this.AssetName.BeginInit();
			this.AssetName.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.AssetName.IsOnlyInput = true;
			this.AssetName.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.AssetName.Name = "AssetName";
			this.AssetName.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.AssetName.TagName = "AssetName";
			this.AssetName.Value = null;
			this.AssetName.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.AssetNameValueChanged);
			this.AssetName.EndInit();
			// 
			// symSTRTFL
			// 
			this.symSTRTFL.BeginInit();
			this.symSTRTFL.AlarmOffColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.symSTRTFL.AlarmOnColor = new NxtControl.Drawing.Color("Red");
			this.symSTRTFL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 24D, 16D);
			this.symSTRTFL.IndicationOffColor = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(114)), ((byte)(110)), ((byte)(106))));
			this.symSTRTFL.IndicationOnColor = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(0))));
			this.symSTRTFL.LabelText = "Failed to Start";
			this.symSTRTFL.Name = "symSTRTFL";
			this.symSTRTFL.SecurityToken = ((uint)(4294967295u));
			this.symSTRTFL.TagName = "Equipment.STRTFL";
			this.symSTRTFL.EndInit();
			// 
			// symSTOPFL
			// 
			this.symSTOPFL.BeginInit();
			this.symSTOPFL.AlarmOffColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.symSTOPFL.AlarmOnColor = new NxtControl.Drawing.Color("Red");
			this.symSTOPFL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 24D, 40D);
			this.symSTOPFL.IndicationOffColor = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(114)), ((byte)(110)), ((byte)(106))));
			this.symSTOPFL.IndicationOnColor = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(0))));
			this.symSTOPFL.LabelText = "Failed to Stop";
			this.symSTOPFL.Name = "symSTOPFL";
			this.symSTOPFL.SecurityToken = ((uint)(4294967295u));
			this.symSTOPFL.TagName = "Equipment.STOPFL";
			this.symSTOPFL.EndInit();
			// 
			// symDF
			// 
			this.symDF.BeginInit();
			this.symDF.AlarmOffColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.symDF.AlarmOnColor = new NxtControl.Drawing.Color("Red");
			this.symDF.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 24D, 64D);
			this.symDF.IndicationOffColor = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(114)), ((byte)(110)), ((byte)(106))));
			this.symDF.IndicationOnColor = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(0))));
			this.symDF.LabelText = "Drive Fault";
			this.symDF.Name = "symDF";
			this.symDF.SecurityToken = ((uint)(4294967295u));
			this.symDF.TagName = "Equipment.DF";
			this.symDF.EndInit();
			// 
			// symHRSTOTMNT
			// 
			this.symHRSTOTMNT.BeginInit();
			this.symHRSTOTMNT.AlarmOffColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.symHRSTOTMNT.AlarmOnColor = new NxtControl.Drawing.Color("Red");
			this.symHRSTOTMNT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 24D, 88D);
			this.symHRSTOTMNT.IndicationOffColor = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(114)), ((byte)(110)), ((byte)(106))));
			this.symHRSTOTMNT.IndicationOnColor = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(0))));
			this.symHRSTOTMNT.LabelText = "Maintenance Required";
			this.symHRSTOTMNT.Name = "symHRSTOTMNT";
			this.symHRSTOTMNT.SecurityToken = ((uint)(4294967295u));
			this.symHRSTOTMNT.TagName = "Equipment.HRSTOT.MNT";
			this.symHRSTOTMNT.EndInit();
			// 
			// fAlarms
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(240D)), ((float)(152D)));
			this.Brush = new NxtControl.Drawing.Brush("FaceplateBrush");
			this.FaceplateClose = NxtControl.GuiFramework.CloseFaceplateBehavior.Automatic;
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.AssetName,
			this.symSTRTFL,
			this.symSTOPFL,
			this.symDF,
			this.symHRSTOTMNT});
			this.Size = new System.Drawing.Size(240, 152);

		}
		private System.HMI.Symbols.Base.Execute<string> AssetName;
		private SE.Agile.Symbols.DA_v1_0.sDA symSTRTFL;
		private SE.Agile.Symbols.DA_v1_0.sDA symSTOPFL;
		private SE.Agile.Symbols.DIA_v1_0.sDIA symDF;
		private SE.Agile.Symbols.DA_v1_0.sDA symHRSTOTMNT;
		#endregion
	}
}
