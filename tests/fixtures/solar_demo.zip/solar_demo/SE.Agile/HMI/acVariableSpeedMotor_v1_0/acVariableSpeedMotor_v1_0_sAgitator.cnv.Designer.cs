/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 8/11/2025
 * Time: 1:58 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.acVariableSpeedMotor_v1_0
{
	/// <summary>
	/// Summary description for overviewSymbol.
	/// </summary>
	partial class sAgitator
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.alarmFrame = new NxtControl.GuiFramework.AlarmFrame();
			this.AssetName = new System.HMI.Symbols.Base.Execute<string>();
			this.lblISPD = new NxtControl.GuiFramework.FreeText();
			this.txtAssetName = new NxtControl.GuiFramework.Label();
			this.txtMode = new SE.Agile.Symbols.ModeSelector_v1_0.sModeIcon();
			this.IRUN = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.ISPD = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.txtISPD = new NxtControl.GuiFramework.DrawnTextBox();
			this.AgitatorMixL = new NxtControl.GuiFramework.Polygon();
			this.AgitatorMixR = new NxtControl.GuiFramework.Polygon();
			this.line2 = new NxtControl.GuiFramework.Line();
			this.AgitatorPie = new NxtControl.GuiFramework.Pie();
			this.AgitatorRectangle = new NxtControl.GuiFramework.Rectangle();
			this.line24 = new NxtControl.GuiFramework.Line();
			this.line25 = new NxtControl.GuiFramework.Line();
			this.line26 = new NxtControl.GuiFramework.Line();
			this.line27 = new NxtControl.GuiFramework.Line();
			this.line28 = new NxtControl.GuiFramework.Line();
			this.GroupAgitator = new NxtControl.GuiFramework.Group();
			this.ISIM = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IA = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IFL = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IPRUN = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.StatusBody = new NxtControl.GuiFramework.Ellipse();
			this.StatusPolygon = new NxtControl.GuiFramework.Polygon();
			this.StatusEllipse = new NxtControl.GuiFramework.Ellipse();
			this.GroupStatus = new NxtControl.GuiFramework.Group();
			this.alarmBell = new NxtControl.GuiFramework.Rectangle();
			this.interlocked = new NxtControl.GuiFramework.Rectangle();
			this.IPI = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			((System.ComponentModel.ISupportInitialize)(this.alarmFrame)).BeginInit();
			// 
			// alarmFrame
			// 
			this.alarmFrame.Bounds = new NxtControl.Drawing.RectF(((float)(56D)), ((float)(56D)), ((float)(40D)), ((float)(104D)));
			this.alarmFrame.FrameWidth = ((uint)(2u));
			this.alarmFrame.Name = "alarmFrame";
			this.alarmFrame.Radius = 5D;
			// 
			// AssetName
			// 
			this.AssetName.BeginInit();
			this.AssetName.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.AssetName.IsOnlyInput = true;
			this.AssetName.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.AssetName.Name = "AssetName";
			this.AssetName.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.AssetName.TagName = "AssetName";
			this.AssetName.Value = null;
			this.AssetName.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.AssetNameValueChanged);
			this.AssetName.EndInit();
			// 
			// lblISPD
			// 
			this.lblISPD.Color = new NxtControl.Drawing.Color("LabelTextColor");
			this.lblISPD.Font = new NxtControl.Drawing.Font("LabelFont");
			this.lblISPD.Location = new NxtControl.Drawing.PointF(99D, 66D);
			this.lblISPD.Name = "lblISPD";
			this.lblISPD.Text = "Speed %";
			// 
			// txtAssetName
			// 
			this.txtAssetName.AngleIgnore = true;
			this.txtAssetName.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtAssetName.Bounds = new NxtControl.Drawing.RectF(((float)(45D)), ((float)(22D)), ((float)(62D)), ((float)(20D)));
			this.txtAssetName.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtAssetName.Font = new NxtControl.Drawing.Font("LabelFont");
			this.txtAssetName.FontScale = true;
			this.txtAssetName.Name = "txtAssetName";
			this.txtAssetName.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtAssetName.Text = "Name";
			this.txtAssetName.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleCenter;
			this.txtAssetName.TextAutoSize = true;
			this.txtAssetName.TextAutoSizeHorizontalOffset = 10;
			this.txtAssetName.TextColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.txtAssetName.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// txtMode
			// 
			this.txtMode.BeginInit();
			this.txtMode.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 42D, 34D);
			this.txtMode.Name = "txtMode";
			this.txtMode.SecurityToken = ((uint)(4294967295u));
			this.txtMode.TagName = "Equipment.Mode";
			this.txtMode.EndInit();
			// 
			// IRUN
			// 
			this.IRUN.BeginInit();
			this.IRUN.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 14D, 35D);
			this.IRUN.Name = "IRUN";
			this.IRUN.SecurityToken = ((uint)(4294967295u));
			this.IRUN.TagName = "Equipment.IRUN";
			this.IRUN.Val = false;
			this.IRUN.EndInit();
			// 
			// ISPD
			// 
			this.ISPD.BeginInit();
			this.ISPD.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 19D, 73D);
			this.ISPD.Name = "ISPD";
			this.ISPD.SecurityToken = ((uint)(4294967295u));
			this.ISPD.TagName = "Equipment.ISPD";
			this.ISPD.Val = 0F;
			this.ISPD.ValDecimalPlaces = ((byte)(0));
			this.ISPD.ValMaximum = 0F;
			this.ISPD.ValMinimum = 0F;
			this.ISPD.ValUnits = null;
			this.ISPD.EndInit();
			// 
			// txtISPD
			// 
			this.txtISPD.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtISPD.Bounds = new NxtControl.Drawing.RectF(((float)(96D)), ((float)(80D)), ((float)(48D)), ((float)(25D)));
			this.txtISPD.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.txtISPD.Font = new NxtControl.Drawing.Font("TextBoxFont");
			this.txtISPD.FontScale = true;
			this.txtISPD.Maximum = 100D;
			this.txtISPD.Minimum = 0D;
			this.txtISPD.Name = "txtISPD";
			this.txtISPD.Pen = new NxtControl.Drawing.Pen("TextBoxPen");
			this.txtISPD.Text = "0.00";
			this.txtISPD.TextAutoSizeHorizontalOffset = 10;
			this.txtISPD.TextAutoSizeVerticalOffset = 2;
			this.txtISPD.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// AgitatorMixL
			// 
			this.AgitatorMixL.Bounds = new NxtControl.Drawing.RectF(((float)(65D)), ((float)(138D)), ((float)(11D)), ((float)(10D)));
			this.AgitatorMixL.Closed = true;
			this.AgitatorMixL.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.AgitatorMixL.Name = "AgitatorMixL";
			this.AgitatorMixL.Points.AddRange(new NxtControl.Drawing.PointF[] {
			new NxtControl.Drawing.PointF(65D, 138D),
			new NxtControl.Drawing.PointF(65D, 148D),
			new NxtControl.Drawing.PointF(76D, 143D)});
			// 
			// AgitatorMixR
			// 
			this.AgitatorMixR.Bounds = new NxtControl.Drawing.RectF(((float)(76D)), ((float)(138D)), ((float)(11D)), ((float)(10D)));
			this.AgitatorMixR.Closed = true;
			this.AgitatorMixR.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.AgitatorMixR.Name = "AgitatorMixR";
			this.AgitatorMixR.Points.AddRange(new NxtControl.Drawing.PointF[] {
			new NxtControl.Drawing.PointF(87D, 148D),
			new NxtControl.Drawing.PointF(87D, 138D),
			new NxtControl.Drawing.PointF(76D, 143D)});
			// 
			// line2
			// 
			this.line2.EndPoint = new NxtControl.Drawing.PointF(76D, 103D);
			this.line2.Name = "line2";
			this.line2.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("SymStaticIconColor"), 1F, NxtControl.Drawing.DashStyle.Solid);
			this.line2.StartPoint = new NxtControl.Drawing.PointF(76D, 143D);
			// 
			// AgitatorPie
			// 
			this.AgitatorPie.Bounds = new NxtControl.Drawing.RectF(((float)(68D)), ((float)(87D)), ((float)(16D)), ((float)(16D)));
			this.AgitatorPie.Center = new NxtControl.Drawing.PointF(76D, 95D);
			this.AgitatorPie.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.AgitatorPie.Name = "AgitatorPie";
			this.AgitatorPie.RadiusX = 8D;
			this.AgitatorPie.RadiusY = 8D;
			this.AgitatorPie.StartAngle = 180D;
			this.AgitatorPie.SweepAngle = -180D;
			// 
			// AgitatorRectangle
			// 
			this.AgitatorRectangle.Bounds = new NxtControl.Drawing.RectF(((float)(67.5D)), ((float)(64D)), ((float)(17D)), ((float)(31D)));
			this.AgitatorRectangle.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.AgitatorRectangle.Name = "AgitatorRectangle";
			// 
			// line24
			// 
			this.line24.EndPoint = new NxtControl.Drawing.PointF(68D, 67D);
			this.line24.Name = "line24";
			this.line24.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("SymStaticIconColor"), 1F, NxtControl.Drawing.DashStyle.Solid);
			this.line24.StartPoint = new NxtControl.Drawing.PointF(85D, 67D);
			// 
			// line25
			// 
			this.line25.EndPoint = new NxtControl.Drawing.PointF(70D, 95D);
			this.line25.Name = "line25";
			this.line25.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("SymStaticIconColor"), 1F, NxtControl.Drawing.DashStyle.Solid);
			this.line25.StartPoint = new NxtControl.Drawing.PointF(70D, 67D);
			// 
			// line26
			// 
			this.line26.EndPoint = new NxtControl.Drawing.PointF(74D, 94D);
			this.line26.Name = "line26";
			this.line26.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("SymStaticIconColor"), 1F, NxtControl.Drawing.DashStyle.Solid);
			this.line26.StartPoint = new NxtControl.Drawing.PointF(74D, 67D);
			// 
			// line27
			// 
			this.line27.EndPoint = new NxtControl.Drawing.PointF(78D, 95D);
			this.line27.Name = "line27";
			this.line27.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("SymStaticIconColor"), 1F, NxtControl.Drawing.DashStyle.Solid);
			this.line27.StartPoint = new NxtControl.Drawing.PointF(78D, 67D);
			// 
			// line28
			// 
			this.line28.EndPoint = new NxtControl.Drawing.PointF(82D, 95D);
			this.line28.Name = "line28";
			this.line28.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("SymStaticIconColor"), 1F, NxtControl.Drawing.DashStyle.Solid);
			this.line28.StartPoint = new NxtControl.Drawing.PointF(82D, 67D);
			// 
			// GroupAgitator
			// 
			this.GroupAgitator.BeginInit();
			this.GroupAgitator.Name = "GroupAgitator";
			this.GroupAgitator.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fMain", NxtControl.GuiFramework.MouseButtonType.Click));
			this.GroupAgitator.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.AgitatorMixL,
			this.AgitatorMixR,
			this.line2,
			this.AgitatorPie,
			this.AgitatorRectangle,
			this.line24,
			this.line25,
			this.line26,
			this.line27,
			this.line28});
			this.GroupAgitator.EndInit();
			// 
			// ISIM
			// 
			this.ISIM.BeginInit();
			this.ISIM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 26D, 77D);
			this.ISIM.Name = "ISIM";
			this.ISIM.SecurityToken = ((uint)(4294967295u));
			this.ISIM.TagName = "Equipment.ISIM";
			this.ISIM.Val = false;
			this.ISIM.EndInit();
			// 
			// IA
			// 
			this.IA.BeginInit();
			this.IA.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 20D, 129D);
			this.IA.Name = "IA";
			this.IA.SecurityToken = ((uint)(4294967295u));
			this.IA.TagName = "Equipment.IA";
			this.IA.Val = false;
			this.IA.EndInit();
			// 
			// IFL
			// 
			this.IFL.BeginInit();
			this.IFL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 43D, 202D);
			this.IFL.Name = "IFL";
			this.IFL.SecurityToken = ((uint)(4294967295u));
			this.IFL.TagName = "Equipment.IFL";
			this.IFL.Val = false;
			this.IFL.EndInit();
			// 
			// IPRUN
			// 
			this.IPRUN.BeginInit();
			this.IPRUN.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 52D, 202D);
			this.IPRUN.Name = "IPRUN";
			this.IPRUN.SecurityToken = ((uint)(4294967295u));
			this.IPRUN.TagName = "Equipment.IPRUN";
			this.IPRUN.Val = false;
			this.IPRUN.EndInit();
			// 
			// StatusBody
			// 
			this.StatusBody.Bounds = new NxtControl.Drawing.RectF(((float)(80D)), ((float)(88D)), ((float)(11D)), ((float)(11D)));
			this.StatusBody.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(254)), ((byte)(186)), ((byte)(10))));
			this.StatusBody.Font = new NxtControl.Drawing.Font("HMI Sans Serif", 7F, System.Drawing.FontStyle.Bold);
			this.StatusBody.Name = "StatusBody";
			this.StatusBody.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("Transparent"), 0F, NxtControl.Drawing.DashStyle.Solid);
			this.StatusBody.TextAlignment = NxtControl.Drawing.ContentAlignment.TopCenter;
			this.StatusBody.TextAutoSizeHorizontalOffset = 0;
			this.StatusBody.TextAutoSizeVerticalOffset = 0;
			this.StatusBody.TextColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			// 
			// StatusPolygon
			// 
			this.StatusPolygon.Bounds = new NxtControl.Drawing.RectF(((float)(85D)), ((float)(91D)), ((float)(1D)), ((float)(5D)));
			this.StatusPolygon.Closed = true;
			this.StatusPolygon.Font = new NxtControl.Drawing.Font("HMI Sans Serif", 9F, System.Drawing.FontStyle.Regular);
			this.StatusPolygon.Name = "StatusPolygon";
			this.StatusPolygon.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("Transparent"), 0F, NxtControl.Drawing.DashStyle.Solid);
			this.StatusPolygon.Points.AddRange(new NxtControl.Drawing.PointF[] {
			new NxtControl.Drawing.PointF(86D, 96D),
			new NxtControl.Drawing.PointF(86D, 91D),
			new NxtControl.Drawing.PointF(85D, 91D),
			new NxtControl.Drawing.PointF(85D, 96D)});
			// 
			// StatusEllipse
			// 
			this.StatusEllipse.Bounds = new NxtControl.Drawing.RectF(((float)(85D)), ((float)(96D)), ((float)(1D)), ((float)(1D)));
			this.StatusEllipse.Font = new NxtControl.Drawing.Font("HMI Sans Serif", 2F, System.Drawing.FontStyle.Regular);
			this.StatusEllipse.Name = "StatusEllipse";
			this.StatusEllipse.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("Transparent"), 0F, NxtControl.Drawing.DashStyle.Solid);
			this.StatusEllipse.TextAutoSizeHorizontalOffset = 0;
			this.StatusEllipse.TextAutoSizeVerticalOffset = 0;
			// 
			// GroupStatus
			// 
			this.GroupStatus.BeginInit();
			this.GroupStatus.Name = "GroupStatus";
			this.GroupStatus.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.StatusBody,
			this.StatusPolygon,
			this.StatusEllipse});
			this.GroupStatus.EndInit();
			// 
			// alarmBell
			// 
			this.alarmBell.Bounds = new NxtControl.Drawing.RectF(((float)(51D)), ((float)(59D)), ((float)(14D)), ((float)(14D)));
			this.alarmBell.Brush = new NxtControl.Drawing.Brush(true);
			this.alarmBell.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.alarmBell.ImageName = "SE.Agile.HMI:Icons.Alarm_14x14";
			this.alarmBell.Name = "alarmBell";
			this.alarmBell.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// interlocked
			// 
			this.interlocked.Bounds = new NxtControl.Drawing.RectF(((float)(52D)), ((float)(83D)), ((float)(14D)), ((float)(14D)));
			this.interlocked.Brush = new NxtControl.Drawing.Brush(true);
			this.interlocked.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.interlocked.ImageName = "SE.Agile.HMI:Icons.Interlocked_14x14";
			this.interlocked.Name = "interlocked";
			this.interlocked.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// IPI
			// 
			this.IPI.BeginInit();
			this.IPI.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 11D, 116D);
			this.IPI.Name = "IPI";
			this.IPI.SecurityToken = ((uint)(4294967295u));
			this.IPI.TagName = "Equipment.IPI";
			this.IPI.Val = false;
			this.IPI.EndInit();
			// 
			// sAgitator
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.alarmFrame,
			this.AssetName,
			this.lblISPD,
			this.txtAssetName,
			this.txtMode,
			this.IRUN,
			this.ISPD,
			this.txtISPD,
			this.GroupAgitator,
			this.ISIM,
			this.IA,
			this.IFL,
			this.IPRUN,
			this.GroupStatus,
			this.alarmBell,
			this.interlocked,
			this.IPI});
			this.SymbolSize = new System.Drawing.Size(256, 272);
			((System.ComponentModel.ISupportInitialize)(this.alarmFrame)).EndInit();

		}
		private NxtControl.GuiFramework.AlarmFrame alarmFrame;
		private System.HMI.Symbols.Base.Execute<string> AssetName;
		private NxtControl.GuiFramework.DrawnTextBox txtISPD;
		private NxtControl.GuiFramework.FreeText lblISPD;
		private NxtControl.GuiFramework.Label txtAssetName;
		private SE.Agile.Symbols.ModeSelector_v1_0.sModeIcon txtMode;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IRUN;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged ISPD;
		private NxtControl.GuiFramework.Polygon AgitatorMixL;
		private NxtControl.GuiFramework.Polygon AgitatorMixR;
		private NxtControl.GuiFramework.Line line2;
		private NxtControl.GuiFramework.Pie AgitatorPie;
		private NxtControl.GuiFramework.Rectangle AgitatorRectangle;
		private NxtControl.GuiFramework.Line line24;
		private NxtControl.GuiFramework.Line line25;
		private NxtControl.GuiFramework.Line line26;
		private NxtControl.GuiFramework.Line line27;
		private NxtControl.GuiFramework.Line line28;
		private NxtControl.GuiFramework.Group GroupAgitator;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged ISIM;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IA;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IFL;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IPRUN;
		private NxtControl.GuiFramework.Ellipse StatusBody;
		private NxtControl.GuiFramework.Polygon StatusPolygon;
		private NxtControl.GuiFramework.Ellipse StatusEllipse;
		private NxtControl.GuiFramework.Group GroupStatus;
		private NxtControl.GuiFramework.Rectangle alarmBell;
		private NxtControl.GuiFramework.Rectangle interlocked;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IPI;
		#endregion
	}
}
