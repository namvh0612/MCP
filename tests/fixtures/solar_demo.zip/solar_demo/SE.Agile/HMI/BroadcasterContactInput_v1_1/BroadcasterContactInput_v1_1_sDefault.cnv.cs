/*
 * Created by EcoStruxure Automation Expert.
 * User: mdcAdmin
 * Date: 12/9/2024
 * Time: 1:10 PM
 * 
 */

using System;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.BroadcasterContactInput_v1_1
{
	/// <summary>
	/// Description of sDefault.
	/// </summary>
	public partial class sDefault : NxtControl.GuiFramework.HMISymbol
	{
		public sDefault()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}
	}
}
