using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region BroadcasterContactInput_v1_1_HMI;
#endregion BroadcasterContactInput_v1_1_HMI;

#endregion Definitions;

