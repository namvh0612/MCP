/*
 * Created by EcoStruxure Automation Expert.
 * User: sclark
 * Date: 12/9/2024
 * Time: 9:22 AM
 * 
 */

using System;
using NxtControl.GuiFramework;
using System.ComponentModel;

namespace SE.Agile.Symbols.FIP_DIA_v1_0
{
	/// <summary>
	/// Description of sDefault.
	/// </summary>
	public partial class sDIA : NxtControl.GuiFramework.HMISymbol
	{
		private bool _I;
		private bool _A;
		private string _labelText = "LabelText";
		private NxtControl.Drawing.Brush _inidcationOffColor = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(114)), ((byte)(110)), ((byte)(106))));
		private NxtControl.Drawing.Brush _inidcationOnColor = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(0))));
		private NxtControl.Drawing.Color _alarmOffColor = new NxtControl.Drawing.Color("LabelTextColor");
		private NxtControl.Drawing.Color _alarmOnColor = new NxtControl.Drawing.Color("Red");
		
		public sDIA()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			UpdateUI();
			
			I.OnValChanged += OnSubCatValueChanged;
			A.OnValChanged += OnSubCatValueChanged;
			ACK.OnValChanged += OnSubCatValueChanged;
			DIS.OnValChanged += OnSubCatValueChanged;
		}
		
		[DefaultValue("LabelText"), RefreshProperties(RefreshProperties.All), Category("Symbol")]
		public string LabelText
		{
			get { return _labelText; }
			
			set
			{ 
				_labelText = value;
				lblText.Text = _labelText;
			}
		}
			
		[RefreshProperties(RefreshProperties.All), Category("Symbol")]
		public NxtControl.Drawing.Brush IndicationOnColor
		{
			get { return _inidcationOnColor; }
			set
			{
				_inidcationOnColor = value;
			}
		}
		
		[RefreshProperties(RefreshProperties.All), Category("Symbol")]
		public NxtControl.Drawing.Brush IndicationOffColor
		{
			get { return _inidcationOffColor; }
			set
			{
				_inidcationOffColor = value;
			}
		}
		
		[RefreshProperties(RefreshProperties.All), Category("Symbol")]
		public NxtControl.Drawing.Color AlarmOnColor
		{
			get { return _alarmOnColor; }
			set
			{
				_alarmOnColor = value;
			}
		}
		
		[RefreshProperties(RefreshProperties.All), Category("Symbol")]
		public NxtControl.Drawing.Color AlarmOffColor
		{
			get { return _alarmOffColor; }
			set
			{
				_alarmOffColor = value;
			}
		}
		
		// EXECUTE logic triggered by child value change
	    private void OnSubCatValueChanged(object sender, EventArgs e)
	    {
	    	if (I.Val != _I)
	    	{
				if (I.Val)
				{
					IndicationLight.Brush = _inidcationOnColor;
				}
				else
				{
					IndicationLight.Brush = _inidcationOffColor;
				}
	    	}
	    	
	    	if (A.Val != _A)
	    	{
				if (A.Val)
				{
					lblText.TextColor = _alarmOnColor;
				}
				else
				{
					lblText.TextColor = _alarmOffColor;
				}
	    	}
	    	
	    	btnACK.Visible = A.Val && !ACK.Val && !DIS.Val;
	    	
	    	IndicationDisabled.Visible = DIS.Val;
	    	
			_I = I.Val;
			_A = A.Val;
		}

		void BtnACKClick(object sender, EventArgs e)
		{
			if (!ACK.Val)
			{
				ACK.FireEvent_CNF(true);
			}
		}
		
		private void UpdateUI()
		{
			if (I.Val)
			{
				IndicationLight.Brush = _inidcationOnColor;
			}
			else
			{
				IndicationLight.Brush = _inidcationOffColor;
			}
		}
	}
}
