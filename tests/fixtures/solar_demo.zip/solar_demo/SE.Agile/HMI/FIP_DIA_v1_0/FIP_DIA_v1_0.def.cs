using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region FIP_DIA_v1_0_HMI;
#endregion FIP_DIA_v1_0_HMI;

#endregion Definitions;

