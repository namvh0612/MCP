/*
 * Created by EcoStruxure Automation Expert.
 * User: sclark
 * Date: 12/9/2024
 * Time: 9:22 AM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.FIP_DIA_v1_0
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sDIA
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(sDIA));
			this.lblText = new NxtControl.GuiFramework.Label();
			this.IndicationLight = new NxtControl.GuiFramework.Ellipse();
			this.I = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.A = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.btnACK = new NxtControl.GuiFramework.Rectangle();
			this.ACK = new SE.Agile.Symbols.HMI_Control_Bool_v1_0.sValChanged();
			this.DIS = new SE.Agile.Symbols.HMI_Control_Bool_v1_0.sValChanged();
			this.IndicationDisabled = new NxtControl.GuiFramework.Rectangle();
			// 
			// lblText
			// 
			this.lblText.AngleIgnore = true;
			this.lblText.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.lblText.Bounds = new NxtControl.Drawing.RectF(((float)(88D)), ((float)(12D)), ((float)(150D)), ((float)(26D)));
			this.lblText.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.lblText.Font = new NxtControl.Drawing.Font("LabelFont");
			this.lblText.FontScale = true;
			this.lblText.Name = "lblText";
			this.lblText.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.lblText.Text = "LabelText";
			this.lblText.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.lblText.TextAutoSizeHorizontalOffset = 10;
			this.lblText.TextColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.lblText.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// IndicationLight
			// 
			this.IndicationLight.Bounds = new NxtControl.Drawing.RectF(((float)(56D)), ((float)(16D)), ((float)(14D)), ((float)(14D)));
			this.IndicationLight.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.IndicationLight.Name = "IndicationLight";
			// 
			// I
			// 
			this.I.BeginInit();
			this.I.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 86D, 145D);
			this.I.Name = "I";
			this.I.SecurityToken = ((uint)(4294967295u));
			this.I.TagName = "I";
			this.I.Val = false;
			this.I.EndInit();
			// 
			// A
			// 
			this.A.BeginInit();
			this.A.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 53D, 149D);
			this.A.Name = "A";
			this.A.SecurityToken = ((uint)(4294967295u));
			this.A.TagName = "A";
			this.A.Val = false;
			this.A.EndInit();
			// 
			// btnACK
			// 
			this.btnACK.Bounds = new NxtControl.Drawing.RectF(((float)(74D)), ((float)(16D)), ((float)(14D)), ((float)(14D)));
			this.btnACK.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("Transparent"));
			this.btnACK.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.btnACK.ImageBytes = resources.GetString("btnACK.ImageBytes");
			this.btnACK.Name = "btnACK";
			this.btnACK.Pen = new NxtControl.Drawing.Pen("Transparent");
			this.btnACK.Visible = false;
			this.btnACK.Click += new System.EventHandler(this.BtnACKClick);
			// 
			// ACK
			// 
			this.ACK.BeginInit();
			this.ACK.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 28D, 21D);
			this.ACK.Name = "ACK";
			this.ACK.SecurityToken = ((uint)(4294967295u));
			this.ACK.TagName = "ACK";
			this.ACK.Val = false;
			this.ACK.EndInit();
			// 
			// DIS
			// 
			this.DIS.BeginInit();
			this.DIS.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 24D, 12D);
			this.DIS.Name = "DIS";
			this.DIS.SecurityToken = ((uint)(4294967295u));
			this.DIS.TagName = "DIS";
			this.DIS.Val = false;
			this.DIS.EndInit();
			// 
			// IndicationDisabled
			// 
			this.IndicationDisabled.Bounds = new NxtControl.Drawing.RectF(((float)(74D)), ((float)(16D)), ((float)(14D)), ((float)(14D)));
			this.IndicationDisabled.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("Transparent"));
			this.IndicationDisabled.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.IndicationDisabled.ImageBytes = resources.GetString("IndicationDisabled.ImageBytes");
			this.IndicationDisabled.Name = "IndicationDisabled";
			this.IndicationDisabled.Pen = new NxtControl.Drawing.Pen("Transparent");
			this.IndicationDisabled.Visible = false;
			// 
			// sDIA
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.lblText,
			this.IndicationLight,
			this.I,
			this.A,
			this.btnACK,
			this.ACK,
			this.DIS,
			this.IndicationDisabled});
			this.SymbolSize = new System.Drawing.Size(248, 48);

		}
		private NxtControl.GuiFramework.Label lblText;
		private NxtControl.GuiFramework.Ellipse IndicationLight;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged I;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged A;
		private NxtControl.GuiFramework.Rectangle btnACK;
		private SE.Agile.Symbols.HMI_Control_Bool_v1_0.sValChanged ACK;
		private SE.Agile.Symbols.HMI_Control_Bool_v1_0.sValChanged DIS;
		private NxtControl.GuiFramework.Rectangle IndicationDisabled;
		#endregion
	}
}
