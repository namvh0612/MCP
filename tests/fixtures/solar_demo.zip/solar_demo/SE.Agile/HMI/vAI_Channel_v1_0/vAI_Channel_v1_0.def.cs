using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region vAI_Channel_v1_0_HMI;
#endregion vAI_Channel_v1_0_HMI;

#endregion Definitions;

