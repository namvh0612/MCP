﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/25/2026
 * Time: 11:59 PM
 * 
 */

using System;
using NxtControl.GuiFramework;

namespace SE.Agile.SupportClasses
{
	public partial class SolarStatusHelper
	{
		public SolarStatusHelper()
		{
		}

		public static bool TryResolvePriorityStatus(
			object quality,
			object fault,
			object alarm,
			out SolarTheme.EquipmentState status)
		{
			if (!HmiValueHelper.ToBool(quality))
			{
				status =
					SolarTheme.EquipmentState.Offline;

				return true;
			}

			if (HmiValueHelper.ToBool(fault))
			{
				status =
					SolarTheme.EquipmentState.Fault;

				return true;
			}

			if (HmiValueHelper.ToBool(alarm))
			{
				status =
					SolarTheme.EquipmentState.Warning;

				return true;
			}

			status =
				SolarTheme.EquipmentState.Unknown;

			return false;
		}

		public static SolarTheme.EquipmentState ResolveStandard(
			object quality,
			object fault,
			object alarm,
			object active,
			SolarTheme.EquipmentState activeState,
			SolarTheme.EquipmentState fallbackState)
		{
			SolarTheme.EquipmentState priorityStatus;

			if (TryResolvePriorityStatus(
				quality,
				fault,
				alarm,
				out priorityStatus))
			{
				return priorityStatus;
			}

			if (HmiValueHelper.ToBool(active))
			{
				return activeState;
			}

			return fallbackState;
		}

		public static SolarTheme.EquipmentState ResolveRunningAvailable(
			object quality,
			object fault,
			object alarm,
			object running,
			object available)
		{
			SolarTheme.EquipmentState priorityStatus;

			if (TryResolvePriorityStatus(
				quality,
				fault,
				alarm,
				out priorityStatus))
			{
				return priorityStatus;
			}

			if (HmiValueHelper.ToBool(running))
			{
				return SolarTheme.EquipmentState.Running;
			}

			if (HmiValueHelper.ToBool(available))
			{
				return SolarTheme.EquipmentState.Healthy;
			}

			return SolarTheme.EquipmentState.Standby;
		}

		public static string GetStatusText(
			SolarTheme.EquipmentState status)
		{
			switch (status)
			{
				case SolarTheme.EquipmentState.Healthy:
					return "Healthy";

				case SolarTheme.EquipmentState.Running:
					return "Running";

				case SolarTheme.EquipmentState.Standby:
					return "Standby";

				case SolarTheme.EquipmentState.Warning:
					return "Alarm";

				case SolarTheme.EquipmentState.Fault:
					return "Fault";

				case SolarTheme.EquipmentState.Offline:
					return "Offline";

				default:
					return "Unknown";
			}
		}
	}
}
