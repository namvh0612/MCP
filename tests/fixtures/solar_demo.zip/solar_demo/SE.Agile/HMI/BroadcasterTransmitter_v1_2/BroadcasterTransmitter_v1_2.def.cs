using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region BroadcasterTransmitter_v1_2_HMI;
#endregion BroadcasterTransmitter_v1_2_HMI;

#endregion Definitions;

