/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 6/5/2025
 * Time: 11:04 AM
 * 
 */
using System;
using NxtControl.GuiFramework;
using NxtControl.Services;

#region Definitions;

#endregion Definitions;
