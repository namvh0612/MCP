using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region ListenerTransmitter_v1_2_HMI;
#endregion ListenerTransmitter_v1_2_HMI;

#endregion Definitions;

