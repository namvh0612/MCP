using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region BroadcasterTwoPositionActuator_v1_1_HMI;
#endregion BroadcasterTwoPositionActuator_v1_1_HMI;

#endregion Definitions;

