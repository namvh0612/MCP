/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 8/11/2025
 * Time: 1:58 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.acAnalogOutput_v1_0
{
	/// <summary>
	/// Summary description for overviewSymbol.
	/// </summary>
	partial class sControlValveHoriz
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(sControlValveHoriz));
			this.alarmFrame = new NxtControl.GuiFramework.AlarmFrame();
			this.AssetName = new System.HMI.Symbols.Base.Execute<string>();
			this.lblIZS = new NxtControl.GuiFramework.FreeText();
			this.ValveBody = new NxtControl.GuiFramework.Line();
			this.ValveBaseLeft = new NxtControl.GuiFramework.Polygon();
			this.ValveBaseRight = new NxtControl.GuiFramework.Polygon();
			this.ValveControl = new NxtControl.GuiFramework.Pie();
			this.GroupValve = new NxtControl.GuiFramework.Group();
			this.txtMode = new SE.Agile.Symbols.ModeSelector_v1_0.sModeIcon();
			this.txtIZS = new NxtControl.GuiFramework.DrawnTextBox();
			this.IZS = new SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged();
			this.IE = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.txtAssetName = new NxtControl.GuiFramework.Label();
			this.ISIM = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IFL = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IA = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.StatusBody = new NxtControl.GuiFramework.Ellipse();
			this.StatusPolygon = new NxtControl.GuiFramework.Polygon();
			this.StatusEllipse = new NxtControl.GuiFramework.Ellipse();
			this.GroupStatus = new NxtControl.GuiFramework.Group();
			this.alarmBell = new NxtControl.GuiFramework.Rectangle();
			this.interlocked = new NxtControl.GuiFramework.Rectangle();
			this.IPI = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			((System.ComponentModel.ISupportInitialize)(this.alarmFrame)).BeginInit();
			// 
			// alarmFrame
			// 
			this.alarmFrame.Bounds = new NxtControl.Drawing.RectF(((float)(48D)), ((float)(40D)), ((float)(48D)), ((float)(48D)));
			this.alarmFrame.FrameWidth = ((uint)(2u));
			this.alarmFrame.Name = "alarmFrame";
			this.alarmFrame.Radius = 5D;
			// 
			// AssetName
			// 
			this.AssetName.BeginInit();
			this.AssetName.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.AssetName.IsOnlyInput = true;
			this.AssetName.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.AssetName.Name = "AssetName";
			this.AssetName.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.AssetName.TagName = "AssetName";
			this.AssetName.Value = null;
			this.AssetName.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.AssetNameValueChanged);
			this.AssetName.EndInit();
			// 
			// lblIZS
			// 
			this.lblIZS.Color = new NxtControl.Drawing.Color("LabelTextColor");
			this.lblIZS.Font = new NxtControl.Drawing.Font("LabelFont");
			this.lblIZS.Location = new NxtControl.Drawing.PointF(104D, 40D);
			this.lblIZS.Name = "lblIZS";
			this.lblIZS.Text = "Position %";
			// 
			// ValveBody
			// 
			this.ValveBody.EndPoint = new NxtControl.Drawing.PointF(72D, 75D);
			this.ValveBody.Name = "ValveBody";
			this.ValveBody.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color(((byte)(0)), ((byte)(0)), ((byte)(0))), 1F, NxtControl.Drawing.DashStyle.Solid);
			this.ValveBody.StartPoint = new NxtControl.Drawing.PointF(72D, 51D);
			// 
			// ValveBaseLeft
			// 
			this.ValveBaseLeft.Bounds = new NxtControl.Drawing.RectF(((float)(56D)), ((float)(67D)), ((float)(16D)), ((float)(16D)));
			this.ValveBaseLeft.Closed = true;
			this.ValveBaseLeft.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.ValveBaseLeft.Name = "ValveBaseLeft";
			this.ValveBaseLeft.Points.AddRange(new NxtControl.Drawing.PointF[] {
			new NxtControl.Drawing.PointF(56D, 67D),
			new NxtControl.Drawing.PointF(56D, 83D),
			new NxtControl.Drawing.PointF(72D, 75D)});
			// 
			// ValveBaseRight
			// 
			this.ValveBaseRight.Bounds = new NxtControl.Drawing.RectF(((float)(72D)), ((float)(67D)), ((float)(16D)), ((float)(16D)));
			this.ValveBaseRight.Closed = true;
			this.ValveBaseRight.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.ValveBaseRight.Name = "ValveBaseRight";
			this.ValveBaseRight.Points.AddRange(new NxtControl.Drawing.PointF[] {
			new NxtControl.Drawing.PointF(88D, 67D),
			new NxtControl.Drawing.PointF(88D, 83D),
			new NxtControl.Drawing.PointF(72D, 75D)});
			// 
			// ValveControl
			// 
			this.ValveControl.Bounds = new NxtControl.Drawing.RectF(((float)(60D)), ((float)(46D)), ((float)(24D)), ((float)(24D)));
			this.ValveControl.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(130)), ((byte)(130)), ((byte)(130))));
			this.ValveControl.Center = new NxtControl.Drawing.PointF(72D, 58D);
			this.ValveControl.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.ValveControl.Name = "ValveControl";
			this.ValveControl.RadiusX = 12D;
			this.ValveControl.RadiusY = 12D;
			this.ValveControl.StartAngle = 180D;
			this.ValveControl.SweepAngle = 180D;
			// 
			// GroupValve
			// 
			this.GroupValve.BeginInit();
			this.GroupValve.Name = "GroupValve";
			this.GroupValve.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fMain", NxtControl.GuiFramework.MouseButtonType.Click));
			this.GroupValve.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.ValveBody,
			this.ValveBaseLeft,
			this.ValveBaseRight,
			this.ValveControl});
			this.GroupValve.EndInit();
			// 
			// txtMode
			// 
			this.txtMode.BeginInit();
			this.txtMode.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 38D, 16D);
			this.txtMode.Name = "txtMode";
			this.txtMode.SecurityToken = ((uint)(4294967295u));
			this.txtMode.TagName = "Equipment.Mode";
			this.txtMode.EndInit();
			// 
			// txtIZS
			// 
			this.txtIZS.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtIZS.Bounds = new NxtControl.Drawing.RectF(((float)(104D)), ((float)(50D)), ((float)(48D)), ((float)(25D)));
			this.txtIZS.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.txtIZS.Font = new NxtControl.Drawing.Font("TextBoxFont");
			this.txtIZS.FontScale = true;
			this.txtIZS.Maximum = 100D;
			this.txtIZS.Minimum = 0D;
			this.txtIZS.Name = "txtIZS";
			this.txtIZS.Pen = new NxtControl.Drawing.Pen("TextBoxPen");
			this.txtIZS.Text = "0.00";
			this.txtIZS.TextAutoSizeHorizontalOffset = 10;
			this.txtIZS.TextAutoSizeVerticalOffset = 2;
			this.txtIZS.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// IZS
			// 
			this.IZS.BeginInit();
			this.IZS.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 21D, 84D);
			this.IZS.Name = "IZS";
			this.IZS.SecurityToken = ((uint)(4294967295u));
			this.IZS.TagName = "Equipment.IZS";
			this.IZS.Val = 0F;
			this.IZS.ValDecimalPlaces = ((byte)(0));
			this.IZS.ValMaximum = 0F;
			this.IZS.ValMinimum = 0F;
			this.IZS.ValUnits = null;
			this.IZS.EndInit();
			// 
			// IE
			// 
			this.IE.BeginInit();
			this.IE.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 7D, 41D);
			this.IE.Name = "IE";
			this.IE.SecurityToken = ((uint)(4294967295u));
			this.IE.TagName = "Equipment.IE";
			this.IE.Val = false;
			this.IE.EndInit();
			// 
			// txtAssetName
			// 
			this.txtAssetName.AngleIgnore = true;
			this.txtAssetName.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtAssetName.Bounds = new NxtControl.Drawing.RectF(((float)(41D)), ((float)(91D)), ((float)(62D)), ((float)(20D)));
			this.txtAssetName.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtAssetName.Font = new NxtControl.Drawing.Font("LabelFont");
			this.txtAssetName.FontScale = true;
			this.txtAssetName.Name = "txtAssetName";
			this.txtAssetName.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtAssetName.Text = "Name";
			this.txtAssetName.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleCenter;
			this.txtAssetName.TextAutoSize = true;
			this.txtAssetName.TextAutoSizeHorizontalOffset = 10;
			this.txtAssetName.TextColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.txtAssetName.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// ISIM
			// 
			this.ISIM.BeginInit();
			this.ISIM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 1D, 6D);
			this.ISIM.Name = "ISIM";
			this.ISIM.SecurityToken = ((uint)(4294967295u));
			this.ISIM.TagName = "Equipment.ISIM";
			this.ISIM.Val = false;
			this.ISIM.EndInit();
			// 
			// IFL
			// 
			this.IFL.BeginInit();
			this.IFL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 37D, 123D);
			this.IFL.Name = "IFL";
			this.IFL.SecurityToken = ((uint)(4294967295u));
			this.IFL.TagName = "Equipment.IFL";
			this.IFL.Val = false;
			this.IFL.EndInit();
			// 
			// IA
			// 
			this.IA.BeginInit();
			this.IA.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 16D, 73D);
			this.IA.Name = "IA";
			this.IA.SecurityToken = ((uint)(4294967295u));
			this.IA.TagName = "Equipment.IA";
			this.IA.Val = false;
			this.IA.EndInit();
			// 
			// StatusBody
			// 
			this.StatusBody.Bounds = new NxtControl.Drawing.RectF(((float)(67D)), ((float)(70D)), ((float)(11D)), ((float)(11D)));
			this.StatusBody.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(254)), ((byte)(186)), ((byte)(10))));
			this.StatusBody.Font = new NxtControl.Drawing.Font("HMI Sans Serif", 7F, System.Drawing.FontStyle.Bold);
			this.StatusBody.Name = "StatusBody";
			this.StatusBody.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("Transparent"), 0F, NxtControl.Drawing.DashStyle.Solid);
			this.StatusBody.TextAlignment = NxtControl.Drawing.ContentAlignment.TopCenter;
			this.StatusBody.TextAutoSizeHorizontalOffset = 0;
			this.StatusBody.TextAutoSizeVerticalOffset = 0;
			this.StatusBody.TextColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			// 
			// StatusPolygon
			// 
			this.StatusPolygon.Bounds = new NxtControl.Drawing.RectF(((float)(72D)), ((float)(73D)), ((float)(1D)), ((float)(5D)));
			this.StatusPolygon.Closed = true;
			this.StatusPolygon.Font = new NxtControl.Drawing.Font("HMI Sans Serif", 9F, System.Drawing.FontStyle.Regular);
			this.StatusPolygon.Name = "StatusPolygon";
			this.StatusPolygon.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("Transparent"), 0F, NxtControl.Drawing.DashStyle.Solid);
			this.StatusPolygon.Points.AddRange(new NxtControl.Drawing.PointF[] {
			new NxtControl.Drawing.PointF(73D, 78D),
			new NxtControl.Drawing.PointF(73D, 73D),
			new NxtControl.Drawing.PointF(72D, 73D),
			new NxtControl.Drawing.PointF(72D, 78D)});
			// 
			// StatusEllipse
			// 
			this.StatusEllipse.Bounds = new NxtControl.Drawing.RectF(((float)(72D)), ((float)(78D)), ((float)(1D)), ((float)(1D)));
			this.StatusEllipse.Font = new NxtControl.Drawing.Font("HMI Sans Serif", 2F, System.Drawing.FontStyle.Regular);
			this.StatusEllipse.Name = "StatusEllipse";
			this.StatusEllipse.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("Transparent"), 0F, NxtControl.Drawing.DashStyle.Solid);
			this.StatusEllipse.TextAutoSizeHorizontalOffset = 0;
			this.StatusEllipse.TextAutoSizeVerticalOffset = 0;
			// 
			// GroupStatus
			// 
			this.GroupStatus.BeginInit();
			this.GroupStatus.Name = "GroupStatus";
			this.GroupStatus.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.StatusBody,
			this.StatusPolygon,
			this.StatusEllipse});
			this.GroupStatus.EndInit();
			// 
			// alarmBell
			// 
			this.alarmBell.Bounds = new NxtControl.Drawing.RectF(((float)(46D)), ((float)(40D)), ((float)(14D)), ((float)(14D)));
			this.alarmBell.Brush = new NxtControl.Drawing.Brush(true);
			this.alarmBell.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.alarmBell.ImageName = "SE.Agile.HMI:Icons.Alarm_14x14";
			this.alarmBell.Name = "alarmBell";
			this.alarmBell.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// interlocked
			// 
			this.interlocked.Bounds = new NxtControl.Drawing.RectF(((float)(86D)), ((float)(41D)), ((float)(14D)), ((float)(14D)));
			this.interlocked.Brush = new NxtControl.Drawing.Brush(true);
			this.interlocked.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.interlocked.ImageBytes = resources.GetString("interlocked.ImageBytes");
			this.interlocked.Name = "interlocked";
			this.interlocked.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// IPI
			// 
			this.IPI.BeginInit();
			this.IPI.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 13D, 39D);
			this.IPI.Name = "IPI";
			this.IPI.SecurityToken = ((uint)(4294967295u));
			this.IPI.TagName = "Equipment.IPI";
			this.IPI.Val = false;
			this.IPI.EndInit();
			// 
			// sControlValveHoriz
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.alarmFrame,
			this.AssetName,
			this.lblIZS,
			this.GroupValve,
			this.txtMode,
			this.txtIZS,
			this.IZS,
			this.IE,
			this.txtAssetName,
			this.ISIM,
			this.IFL,
			this.IA,
			this.GroupStatus,
			this.alarmBell,
			this.interlocked,
			this.IPI});
			this.SymbolSize = new System.Drawing.Size(168, 144);
			((System.ComponentModel.ISupportInitialize)(this.alarmFrame)).EndInit();

		}
		private NxtControl.GuiFramework.AlarmFrame alarmFrame;
		private NxtControl.GuiFramework.Label txtAssetName;
		private System.HMI.Symbols.Base.Execute<string> AssetName;
		private NxtControl.GuiFramework.FreeText lblIZS;
		private NxtControl.GuiFramework.Line ValveBody;
		private NxtControl.GuiFramework.Polygon ValveBaseLeft;
		private NxtControl.GuiFramework.Polygon ValveBaseRight;
		private NxtControl.GuiFramework.Pie ValveControl;
		private NxtControl.GuiFramework.Group GroupValve;
		private SE.Agile.Symbols.ModeSelector_v1_0.sModeIcon txtMode;
		private NxtControl.GuiFramework.DrawnTextBox txtIZS;
		private SE.Agile.Symbols.HMI_Indication_Real_v1_0.sValChanged IZS;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IE;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged ISIM;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IFL;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IA;
		private NxtControl.GuiFramework.Ellipse StatusBody;
		private NxtControl.GuiFramework.Polygon StatusPolygon;
		private NxtControl.GuiFramework.Ellipse StatusEllipse;
		private NxtControl.GuiFramework.Group GroupStatus;
		private NxtControl.GuiFramework.Rectangle alarmBell;
		private NxtControl.GuiFramework.Rectangle interlocked;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IPI;
		#endregion
	}
}
