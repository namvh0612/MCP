/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 8/11/2025
 * Time: 1:58 PM
 * 
 */

using System;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.acAnalogOutput_v1_0
{
	/// <summary>
	/// Description of overviewSymbol.
	/// </summary>
	public partial class sControlValveHoriz : NxtControl.GuiFramework.HMISymbol
	{
		private bool _IE;
		private float _IZS;
		private byte _IZSDecimalPlaces;
		private bool _IFL;
		private bool _ISIM;
		private bool _IA;
		private bool _IPI;
		
		private NxtControl.Drawing.Brush _brushOn = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255))));
		private NxtControl.Drawing.Brush _brushOff = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(114)), ((byte)(110)), ((byte)(106))));
		private NxtControl.Drawing.Brush _brushFault = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(234)), ((byte)(22)), ((byte)(30))));
		private NxtControl.Drawing.Brush _brushSimulation = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(254)), ((byte)(186)), ((byte)(10))));

		public sControlValveHoriz()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			ValveControl.Brush = _brushOff;
			ValveBaseLeft.Brush = _brushOff;
			ValveBaseRight.Brush = _brushOff;
			
			IE.OnValChanged += OnSubCatValueChanged;
			IZS.OnValChanged += OnSubCatValueChanged;
			IFL.OnValChanged += OnSubCatValueChanged;
			ISIM.OnValChanged += OnSubCatValueChanged;
			IA.OnValChanged += OnSubCatValueChanged;
			IPI.OnValChanged += OnSubCatValueChanged;
		}
	
		void AssetNameValueChanged(object sender, ValueChangedEventArgs e)
		{
			txtAssetName.Text = e.Value.ToString();
			
			if (_IFL)
    		{
    			StatusBody.Brush = _brushFault;
    		}
    		else if (_ISIM)
    		{
    			StatusBody.Brush = _brushSimulation;
    		}
    		
    		GroupStatus.Visible = _ISIM || _IFL;

    		alarmBell.Visible = _IA;
    		interlocked.Visible = _IPI;
		}
	
		// EXECUTE logic triggered by child value change
	    private void OnSubCatValueChanged(object sender, EventArgs e)
	    {
	    	if (IE.Val != _IE)
	    	{
				if (IE.Val)
				{
					ValveControl.Brush = _brushOn;
					ValveBaseLeft.Brush = _brushOn;
					ValveBaseRight.Brush = _brushOn;
				}
				else
				{
					ValveControl.Brush = _brushOff;
					ValveBaseLeft.Brush = _brushOff;
					ValveBaseRight.Brush = _brushOff;
				}
	    	}
	    	
	    	if ((IZS.Val != _IZS) || (IZS.ValDecimalPlaces != _IZSDecimalPlaces))
	    	{
	    		txtIZS.Text = IZS.Val.ToString($"F{IZS.ValDecimalPlaces}");
	    	}
	    	
			if (IFL.Val != _IFL || ISIM.Val != _ISIM)
	    	{	
	    		if (IFL.Val)
	    		{
	    			StatusBody.Brush = _brushFault;
	    		}
	    		else if (ISIM.Val)
	    		{
	    			StatusBody.Brush = _brushSimulation;
	    		}
	    		
	    		GroupStatus.Visible = ISIM.Val || IFL.Val;
	    	}

	    	if (IA.Val != _IA)
	    	{
	    		alarmBell.Visible = IA.Val;
	    	}
	    	
	    	if (IPI.Val != _IPI)
	    	{
	    		interlocked.Visible = IPI.Val;
	    	}
	    	
	    	_IE = IE.Val;
			_IZS = IZS.Val;
			_IZSDecimalPlaces = IZS.ValDecimalPlaces;
			_IFL = IFL.Val;
			_ISIM = ISIM.Val;
			_IA = IA.Val;
			_IPI = IPI.Val;
		}
	}
}
