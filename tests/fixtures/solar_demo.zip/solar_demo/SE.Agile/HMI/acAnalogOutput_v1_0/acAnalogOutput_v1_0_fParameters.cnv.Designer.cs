/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 9/22/2025
 * Time: 6:51 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using NxtControl.GuiFramework;

namespace SE.Agile.Faceplates.acAnalogOutput_v1_0
{
	/// <summary>
	/// Summary description for sParameters.
	/// </summary>
	partial class fParameters
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.symCHICLAMP = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed();
			this.symCLOCLAMP = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed();
			this.symCZSDBSP = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed();
			this.symCZSDPRE = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed();
			this.symCSIM = new SE.Agile.Symbols.HMI_Control_Bool_v1_0.sButtonTwoStateNamed();
			this.AssetName = new System.HMI.Symbols.Base.Execute<string>();
			// 
			// symCHICLAMP
			// 
			this.symCHICLAMP.BeginInit();
			this.symCHICLAMP.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -16D, 16D);
			this.symCHICLAMP.Enabled = true;
			this.symCHICLAMP.LabelText = "Output High Clamp:";
			this.symCHICLAMP.Name = "symCHICLAMP";
			this.symCHICLAMP.SecurityToken = ((uint)(4294967295u));
			this.symCHICLAMP.TagName = "Equipment.CHICLAMP";
			this.symCHICLAMP.EndInit();
			// 
			// symCLOCLAMP
			// 
			this.symCLOCLAMP.BeginInit();
			this.symCLOCLAMP.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -16D, 48D);
			this.symCLOCLAMP.Enabled = true;
			this.symCLOCLAMP.LabelText = "Output Low Clamp:";
			this.symCLOCLAMP.Name = "symCLOCLAMP";
			this.symCLOCLAMP.SecurityToken = ((uint)(4294967295u));
			this.symCLOCLAMP.TagName = "Equipment.CLOCLAMP";
			this.symCLOCLAMP.EndInit();
			// 
			// symCZSDBSP
			// 
			this.symCZSDBSP.BeginInit();
			this.symCZSDBSP.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -16D, 80D);
			this.symCZSDBSP.Enabled = true;
			this.symCZSDBSP.LabelText = "Pos. Change Deadband";
			this.symCZSDBSP.Name = "symCZSDBSP";
			this.symCZSDBSP.SecurityToken = ((uint)(4294967295u));
			this.symCZSDBSP.TagName = "Equipment.CZSDBSP";
			this.symCZSDBSP.EndInit();
			// 
			// symCZSDPRE
			// 
			this.symCZSDPRE.BeginInit();
			this.symCZSDPRE.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -16D, 112D);
			this.symCZSDPRE.Enabled = true;
			this.symCZSDPRE.LabelText = "Position Change Delay:";
			this.symCZSDPRE.Name = "symCZSDPRE";
			this.symCZSDPRE.SecurityToken = ((uint)(4294967295u));
			this.symCZSDPRE.TagName = "Equipment.CZSDPRE";
			this.symCZSDPRE.EndInit();
			// 
			// symCSIM
			// 
			this.symCSIM.BeginInit();
			this.symCSIM.ButtonFalseColor = new NxtControl.Drawing.Color(((byte)(110)), ((byte)(110)), ((byte)(110)));
			this.symCSIM.ButtonTrueColor = new NxtControl.Drawing.Color(((byte)(0)), ((byte)(168)), ((byte)(231)));
			this.symCSIM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -16D, 144D);
			this.symCSIM.Enabled = true;
			this.symCSIM.LabelText = "Feedback Simulation:";
			this.symCSIM.Name = "symCSIM";
			this.symCSIM.SecurityToken = ((uint)(4294967295u));
			this.symCSIM.TagName = "Equipment.CMSK";
			this.symCSIM.EndInit();
			// 
			// AssetName
			// 
			this.AssetName.BeginInit();
			this.AssetName.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.AssetName.IsOnlyInput = true;
			this.AssetName.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.AssetName.Name = "AssetName";
			this.AssetName.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.AssetName.TagName = "AssetName";
			this.AssetName.Value = null;
			this.AssetName.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.AssetNameValueChanged);
			this.AssetName.EndInit();
			// 
			// fParameters
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(280D)), ((float)(272D)));
			this.Brush = new NxtControl.Drawing.Brush("FaceplateBrush");
			this.FaceplateClose = NxtControl.GuiFramework.CloseFaceplateBehavior.Automatic;
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.symCHICLAMP,
			this.symCLOCLAMP,
			this.symCZSDBSP,
			this.symCZSDPRE,
			this.symCSIM,
			this.AssetName});
			this.Size = new System.Drawing.Size(280, 272);

		}
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed symCHICLAMP;
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed symCLOCLAMP;
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed symCZSDBSP;
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed symCZSDPRE;
		private SE.Agile.Symbols.HMI_Control_Bool_v1_0.sButtonTwoStateNamed symCSIM;
		private System.HMI.Symbols.Base.Execute<string> AssetName;
		#endregion
	}
}
