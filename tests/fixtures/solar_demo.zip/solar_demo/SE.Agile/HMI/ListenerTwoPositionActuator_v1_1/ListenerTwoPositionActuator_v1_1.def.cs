using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region ListenerTwoPositionActuator_v1_1_HMI;
#endregion ListenerTwoPositionActuator_v1_1_HMI;

#endregion Definitions;

