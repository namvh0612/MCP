using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region ListenerContactOutput_v1_1_HMI;
#endregion ListenerContactOutput_v1_1_HMI;

#endregion Definitions;

