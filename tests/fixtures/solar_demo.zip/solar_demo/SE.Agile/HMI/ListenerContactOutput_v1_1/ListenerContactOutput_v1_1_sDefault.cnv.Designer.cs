/*
 * Created by EcoStruxure Automation Expert.
 * User: mdcAdmin
 * Date: 12/9/2024
 * Time: 1:10 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.ListenerContactOutput_v1_1
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sDefault
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      			this.Name = "sDefault";
		}
		#endregion
	}
}
