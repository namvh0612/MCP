using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region BroadcasterContactOutput_v1_1_HMI;
#endregion BroadcasterContactOutput_v1_1_HMI;

#endregion Definitions;

