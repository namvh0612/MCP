﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/25/2026
 * Time: 11:59 PM
 * 
 */

using System;

namespace SE.Agile.SupportClasses
{
	public partial class HmiValueHelper
	{
		public HmiValueHelper()
		{
		}

		public static bool TryToDouble(
			object value,
			out double result)
		{
			try
			{
				if (value == null)
				throw new InvalidCastException();

				result = Convert.ToDouble(value);

				if (double.IsNaN(result) ||
					double.IsInfinity(result))
				{
					throw new InvalidCastException();
				}

				return true;
			}
			catch
			{
				result = 0.0;
				return false;
			}
		}

		public static double ToDouble(object value)
		{
			return ToDouble(value, 0.0);
		}

		public static double ToDouble(
			object value,
			double fallback)
		{
			double result;

			return TryToDouble(value, out result)
				? result
				: fallback;
		}

		public static int ToInt(object value)
		{
			return ToInt(value, 0);
		}

		public static int ToInt(
			object value,
			int fallback)
		{
			try
			{
				if (value == null)
					return fallback;

				return Convert.ToInt32(value);
			}
			catch
			{
				return fallback;
			}
		}

		public static bool ToBool(object value)
		{
			return ToBool(value, false);
		}

		public static bool ToBool(
			object value,
			bool fallback)
		{
			try
			{
				if (value == null)
					return fallback;

				return Convert.ToBoolean(value);
			}
			catch
			{
				return fallback;
			}
		}

		public static string SafeText(
			object value,
			string fallback)
		{
			try
			{
				if (value == null)
					return fallback;

				string result =
					Convert.ToString(value);

				return string.IsNullOrEmpty(result)
					? fallback
					: result;
			}
			catch
			{
				return fallback;
			}
		}

		public static string Format(
			object value,
			string format,
			string unit)
		{
			return Format(
				value,
				format,
				unit,
				"0");
		}

		public static string Format(
			object value,
			string format,
			string unit,
			string fallback)
		{
			double result;

			string safeUnit =
				unit ?? string.Empty;

			if (!TryToDouble(value, out result))
			{
				return fallback + safeUnit;
			}

			try
			{
				string safeFormat =
					string.IsNullOrEmpty(format)
						? "0.##"
						: format;

				return result.ToString(safeFormat)
					+ safeUnit;
			}
			catch
			{
				return fallback + safeUnit;
			}
		}

		public static string FormatSigned(
			object value,
			string format,
			string unit)
		{
			double result =
				ToDouble(value);

			if (Math.Abs(result) < 0.0001)
			{
				result = 0.0;
			}

			return Format(
				result,
				format,
				unit);
		}

		public static double Clamp(
			object value,
			double minimum,
			double maximum)
		{
			double result =
				ToDouble(value);

			if (result < minimum)
				return minimum;

			if (result > maximum)
				return maximum;

			return result;
		}

		public static bool IsInRange(
			object value,
			double minimum,
			double maximum)
		{
			double result;

			if (!TryToDouble(value, out result))
				return false;

			return result >= minimum &&
				result <= maximum;
		}
	}
}
