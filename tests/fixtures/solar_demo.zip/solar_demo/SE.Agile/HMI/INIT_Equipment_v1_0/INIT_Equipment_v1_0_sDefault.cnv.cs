/*
 * Created by EcoStruxure Automation Expert.
 * User: sclark
 * Date: 12/9/2024
 * Time: 9:31 AM
 * 
 */

using System;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.INIT_Equipment_v1_0
{
	/// <summary>
	/// Description of sDefault.
	/// </summary>
	public partial class sDefault : NxtControl.GuiFramework.HMISymbol
	{
		public sDefault()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}
	}
}
