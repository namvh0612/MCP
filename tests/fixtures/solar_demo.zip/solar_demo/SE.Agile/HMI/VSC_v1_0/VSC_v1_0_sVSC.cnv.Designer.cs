/*
 * Created by EcoStruxure Automation Expert.
 * User: sclark
 * Date: 12/9/2024
 * Time: 9:22 AM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.VSC_v1_0
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sVSC
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.RST = new SE.Agile.Symbols.HMI_Control_Bool_v1_0.sButtonValSet();
			this.RO = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed();
			this.I = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueMiddleNamed();
			// 
			// RST
			// 
			this.RST.BeginInit();
			this.RST.ButtonText = "Valid Starts Counter Reset";
			this.RST.DesignMatrix = new NxtControl.Drawing.Matrix2D(3.5151515151515156D, 0D, 0D, 1D, 24D, 56D);
			this.RST.Enabled = true;
			this.RST.Name = "RST";
			this.RST.SecurityToken = ((uint)(4294967295u));
			this.RST.TagName = "RST";
			this.RST.EndInit();
			// 
			// RO
			// 
			this.RO.BeginInit();
			this.RO.DecimalPlacesCount = ((uint)(2u));
			this.RO.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -32D, 24D);
			this.RO.Enabled = true;
			this.RO.LabelText = "Rollover:";
			this.RO.Name = "RO";
			this.RO.SecurityToken = ((uint)(4294967295u));
			this.RO.TagName = "RO";
			this.RO.EndInit();
			// 
			// I
			// 
			this.I.BeginInit();
			this.I.DecimalPlacesCount = ((uint)(0u));
			this.I.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -32D, 0D);
			this.I.LabelText = "Valid Starts:";
			this.I.Name = "I";
			this.I.SecurityToken = ((uint)(4294967295u));
			this.I.TagName = "I";
			this.I.EndInit();
			// 
			// sVSM
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.RST,
			this.RO,
			this.I});
			this.SymbolSize = new System.Drawing.Size(280, 96);

		}
		private SE.Agile.Symbols.HMI_Control_Bool_v1_0.sButtonValSet RST;
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed RO;
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueMiddleNamed I;
		#endregion
	}
}
