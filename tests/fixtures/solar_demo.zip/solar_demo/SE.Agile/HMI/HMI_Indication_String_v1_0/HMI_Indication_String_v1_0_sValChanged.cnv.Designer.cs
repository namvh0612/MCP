﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 9/18/2025
 * Time: 9:40 AM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.HMI_Indication_String_v1_0
{
	/// <summary>
	/// Summary description for sValChanged.
	/// </summary>
	partial class sValChanged
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Value = new System.HMI.Symbols.Base.Execute<NxtControl.GuiFramework.VTQ<string>>();
			// 
			// Value
			// 
			this.Value.BeginInit();
			this.Value.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.Value.IsOnlyInput = true;
			this.Value.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.Value.Name = "Value";
			this.Value.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.Value.TagName = "Value";
			this.Value.Value = new NxtControl.GuiFramework.VTQ<string>(null, new System.DateTime(((long)(0))), ((uint)(0u)));
			this.Value.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.ValueValueChanged);
			this.Value.EndInit();
			// 
			// sValChanged
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.Value});
			this.SymbolSize = new System.Drawing.Size(200, 200);

		}
		private System.HMI.Symbols.Base.Execute<NxtControl.GuiFramework.VTQ<string>> Value;
		#endregion
	}
}
