﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 9/18/2025
 * Time: 9:40 AM
 * 
 */

using System;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.HMI_Indication_String_v1_0
{
	/// <summary>
	/// Description of sValChanged.
	/// </summary>
	public partial class sValChanged : NxtControl.GuiFramework.HMISymbol
	{
		private string _val;
		
		public sValChanged()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}
		
	    // Event to notify value change
	    public event EventHandler OnValChanged;
	
	    public string Val
	    {
	    	get { return _val; }
	        set
	        {
	            if (_val != value)
	            {
	                _val = value;
                    OnValueChanged();
                }
	        }
	    }
		
	    protected virtual void OnValueChanged()
	    {
	        OnValChanged?.Invoke(this, EventArgs.Empty);
	    }

		void ValueValueChanged(object sender, ValueChangedEventArgs e)
		{
			Val = e.Value.ToString();
		}
	}
}
