﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 9/22/2025
 * Time: 1:37 AM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.HMI_Indication_String_v1_0
{
	/// <summary>
	/// Summary description for sValueMiddleNamed.
	/// </summary>
	partial class sValueMiddleNamed
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblText = new NxtControl.GuiFramework.Label();
			this.Value = new System.HMI.Symbols.Base.TextBox<string>();
			// 
			// lblText
			// 
			this.lblText.AngleIgnore = true;
			this.lblText.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.lblText.Bounds = new NxtControl.Drawing.RectF(((float)(8D)), ((float)(16D)), ((float)(150D)), ((float)(26D)));
			this.lblText.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.lblText.Font = new NxtControl.Drawing.Font("LabelFont");
			this.lblText.FontScale = true;
			this.lblText.Name = "lblText";
			this.lblText.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.lblText.Text = "LabelText";
			this.lblText.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.lblText.TextAutoSizeHorizontalOffset = 10;
			this.lblText.TextColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.lblText.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// Value
			// 
			this.Value.BeginInit();
			this.Value.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.Value.DesignMatrix = new NxtControl.Drawing.Matrix2D(0.64D, 0D, 0D, 1D, 160D, 16D);
			this.Value.IsOnlyInput = true;
			this.Value.MaximumTag = null;
			this.Value.MinimumTag = null;
			this.Value.Name = "Value";
			this.Value.NumberBase = NxtControl.GuiFramework.NumberBase.Decimal;
			this.Value.Pen = new NxtControl.Drawing.Pen("Transparent");
			this.Value.SetColor = new NxtControl.Drawing.Color("Yellow");
			this.Value.TagName = "Value";
			this.Value.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.Value.Value = null;
			this.Value.EndInit();
			// 
			// sValueMiddleNamed
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.lblText,
			this.Value});
			this.SymbolSize = new System.Drawing.Size(320, 60);

		}
		private NxtControl.GuiFramework.Label lblText;
		private System.HMI.Symbols.Base.TextBox<string> Value;
		#endregion
	}
}
