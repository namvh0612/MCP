using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region BroadcasterArbiter_v1_2_HMI;
#endregion BroadcasterArbiter_v1_2_HMI;

#endregion Definitions;

