using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region INIT_COMMS_v1_0_HMI;
#endregion INIT_COMMS_v1_0_HMI;

#endregion Definitions;

