/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 5/24/2026
 * Time: 1:55 AM
 * 
 */

using System;
using NxtControl.GuiFramework;

namespace SE.Agile.Faceplates.acFixedSpeedMotor_v1_0
{
	/// <summary>
	/// Description of fCounter.
	/// </summary>
	public partial class fCounters : NxtControl.GuiFramework.HMIFaceplate
	{
		public fCounters()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}
		
		void AssetNameValueChanged(object sender, ValueChangedEventArgs e)
		{
			Title = (string)e.Value;
		}
	}
}
