/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 8/11/2025
 * Time: 2:02 PM
 * 
 */

using System;
using NxtControl.GuiFramework;

namespace SE.Agile.Faceplates.acFixedSpeedMotor_v1_0
{
	/// <summary>
	/// Description of faceplateMain.
	/// </summary>
	public partial class fMain : NxtControl.GuiFramework.HMIFaceplate
	{
		private int _CMODE;
		
		public fMain()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			IRUN.OnValChanged += OnSubCatValueChanged;
			IPRUN.OnValChanged += OnSubCatValueChanged;
			CMODE.OnValChanged += OnSubCatValueChanged;
			IA.OnValChanged += OnSubCatValueChanged;	
			IRSTPERM.OnValChanged += OnSubCatValueChanged;
		}

		void AssetNameValueChanged(object sender, ValueChangedEventArgs e)
		{
			Title = (string)e.Value;
		}

		// EXECUTE logic triggered by child value change
	    private void OnSubCatValueChanged(object sender, EventArgs e)
	    {
			txtStatus.Text = "Error";
			
			if (IRUN.Val && IPRUN.Val)
			{
				txtStatus.Text = "Running";
			}
			else if (!IRUN.Val && IPRUN.Val)
			{
				txtStatus.Text = "Starting";
			}
			else if (IRUN.Val && !IPRUN.Val)
			{
				txtStatus.Text = "Stopping";
			}
			else
			{
				txtStatus.Text = "Stopped";
			}
			
			if (_CMODE != CMODE.Val)
			{
				symBtnCMSTRT.Enabled = (CMODE.Val == 3);
			}
			
			navAlarm.Visible = !IA.Val;
			navAlarmActive.Visible = IA.Val;
			
			symBtnCFLRST.Enabled = IRSTPERM.Val;
			
			_CMODE = CMODE.Val;
		}
		
	}
}
