/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 4/21/2026
 * Time: 1:03 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using NxtControl.GuiFramework;

namespace SE.Agile.Faceplates.acFixedSpeedMotor_v1_0
{
	/// <summary>
	/// Summary description for fData.
	/// </summary>
	partial class fData
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.symHRSTOT = new SE.Agile.Symbols.HRM_v1_0.sHRM();
			this.AssetName = new System.HMI.Symbols.Base.Execute<string>();
			// 
			// symHRSTOT
			// 
			this.symHRSTOT.BeginInit();
			this.symHRSTOT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 16D, 16D);
			this.symHRSTOT.Name = "symHRSTOT";
			this.symHRSTOT.SecurityToken = ((uint)(4294967295u));
			this.symHRSTOT.TagName = "Equipment.HRSTOT";
			this.symHRSTOT.EndInit();
			// 
			// AssetName
			// 
			this.AssetName.BeginInit();
			this.AssetName.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.AssetName.IsOnlyInput = true;
			this.AssetName.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.AssetName.Name = "AssetName";
			this.AssetName.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.AssetName.TagName = "AssetName";
			this.AssetName.Value = null;
			this.AssetName.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.AssetNameValueChanged);
			this.AssetName.EndInit();
			// 
			// fData
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(336D)), ((float)(456D)));
			this.Brush = new NxtControl.Drawing.Brush("FaceplateBrush");
			this.FaceplateClose = NxtControl.GuiFramework.CloseFaceplateBehavior.Automatic;
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.symHRSTOT,
			this.AssetName});
			this.Size = new System.Drawing.Size(336, 456);

		}
		private SE.Agile.Symbols.HRM_v1_0.sHRM symHRSTOT;
		private System.HMI.Symbols.Base.Execute<string> AssetName;
		#endregion
	}
}
