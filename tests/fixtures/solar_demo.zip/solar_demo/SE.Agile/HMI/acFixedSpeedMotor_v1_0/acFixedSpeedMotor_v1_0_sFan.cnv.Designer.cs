/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 8/11/2025
 * Time: 1:58 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.acFixedSpeedMotor_v1_0
{
	/// <summary>
	/// Summary description for overviewSymbol.
	/// </summary>
	partial class sFan
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.alarmFrame = new NxtControl.GuiFramework.AlarmFrame();
			this.AssetName = new System.HMI.Symbols.Base.Execute<string>();
			this.txtAssetName = new NxtControl.GuiFramework.Label();
			this.txtMode = new SE.Agile.Symbols.ModeSelector_v1_0.sModeIcon();
			this.IRUN = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.FanBase = new NxtControl.GuiFramework.Polygon();
			this.FanBody = new NxtControl.GuiFramework.Ellipse();
			this.FanEllipse2 = new NxtControl.GuiFramework.Ellipse();
			this.FanEllipse3 = new NxtControl.GuiFramework.Ellipse();
			this.FanLine1 = new NxtControl.GuiFramework.Line();
			this.FanLine2 = new NxtControl.GuiFramework.Line();
			this.FanLine3 = new NxtControl.GuiFramework.Line();
			this.FanEllipse1 = new NxtControl.GuiFramework.Ellipse();
			this.GroupFan = new NxtControl.GuiFramework.Group();
			this.ISIM = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IA = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IPRUN = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IFL = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.StatusBody = new NxtControl.GuiFramework.Ellipse();
			this.StatusPolygon = new NxtControl.GuiFramework.Polygon();
			this.StatusEllipse = new NxtControl.GuiFramework.Ellipse();
			this.GroupStatus = new NxtControl.GuiFramework.Group();
			this.alarmBell = new NxtControl.GuiFramework.Rectangle();
			this.interlocked = new NxtControl.GuiFramework.Rectangle();
			this.IPI = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			((System.ComponentModel.ISupportInitialize)(this.alarmFrame)).BeginInit();
			// 
			// alarmFrame
			// 
			this.alarmFrame.Bounds = new NxtControl.Drawing.RectF(((float)(56D)), ((float)(34D)), ((float)(40D)), ((float)(34D)));
			this.alarmFrame.FrameWidth = ((uint)(2u));
			this.alarmFrame.Name = "alarmFrame";
			this.alarmFrame.Radius = 5D;
			// 
			// AssetName
			// 
			this.AssetName.BeginInit();
			this.AssetName.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.AssetName.IsOnlyInput = true;
			this.AssetName.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.AssetName.Name = "AssetName";
			this.AssetName.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.AssetName.TagName = "AssetName";
			this.AssetName.Value = null;
			this.AssetName.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.AssetNameValueChanged);
			this.AssetName.EndInit();
			// 
			// txtAssetName
			// 
			this.txtAssetName.AngleIgnore = true;
			this.txtAssetName.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtAssetName.Bounds = new NxtControl.Drawing.RectF(((float)(45D)), ((float)(67D)), ((float)(62D)), ((float)(20D)));
			this.txtAssetName.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtAssetName.Font = new NxtControl.Drawing.Font("LabelFont");
			this.txtAssetName.FontScale = true;
			this.txtAssetName.Name = "txtAssetName";
			this.txtAssetName.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtAssetName.Text = "Name";
			this.txtAssetName.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleCenter;
			this.txtAssetName.TextAutoSize = true;
			this.txtAssetName.TextAutoSizeHorizontalOffset = 10;
			this.txtAssetName.TextColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.txtAssetName.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// txtMode
			// 
			this.txtMode.BeginInit();
			this.txtMode.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 42D, 10D);
			this.txtMode.Name = "txtMode";
			this.txtMode.SecurityToken = ((uint)(4294967295u));
			this.txtMode.TagName = "Equipment.Mode";
			this.txtMode.EndInit();
			// 
			// IRUN
			// 
			this.IRUN.BeginInit();
			this.IRUN.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 28D, 18D);
			this.IRUN.Name = "IRUN";
			this.IRUN.SecurityToken = ((uint)(4294967295u));
			this.IRUN.TagName = "Equipment.IRUN";
			this.IRUN.Val = false;
			this.IRUN.EndInit();
			// 
			// FanBase
			// 
			this.FanBase.Bounds = new NxtControl.Drawing.RectF(((float)(65D)), ((float)(59D)), ((float)(22D)), ((float)(4D)));
			this.FanBase.Closed = true;
			this.FanBase.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.FanBase.Name = "FanBase";
			this.FanBase.Points.AddRange(new NxtControl.Drawing.PointF[] {
			new NxtControl.Drawing.PointF(65D, 63D),
			new NxtControl.Drawing.PointF(87D, 63D),
			new NxtControl.Drawing.PointF(80D, 59D),
			new NxtControl.Drawing.PointF(72D, 59D)});
			// 
			// FanBody
			// 
			this.FanBody.Bounds = new NxtControl.Drawing.RectF(((float)(65D)), ((float)(39D)), ((float)(22D)), ((float)(22D)));
			this.FanBody.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.FanBody.Name = "FanBody";
			this.FanBody.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fpDefault", NxtControl.GuiFramework.MouseButtonType.Click));
			// 
			// FanEllipse2
			// 
			this.FanEllipse2.Bounds = new NxtControl.Drawing.RectF(((float)(76D)), ((float)(51D)), ((float)(6D)), ((float)(3D)));
			this.FanEllipse2.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("Transparent"));
			this.FanEllipse2.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.FanEllipse2.Name = "FanEllipse2";
			// 
			// FanEllipse3
			// 
			this.FanEllipse3.Bounds = new NxtControl.Drawing.RectF(((float)(70D)), ((float)(51D)), ((float)(6D)), ((float)(3D)));
			this.FanEllipse3.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("Transparent"));
			this.FanEllipse3.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.FanEllipse3.Name = "FanEllipse3";
			// 
			// FanLine1
			// 
			this.FanLine1.EndPoint = new NxtControl.Drawing.PointF(85D, 55D);
			this.FanLine1.Name = "FanLine1";
			this.FanLine1.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("SymStaticIconColor"), 1F, NxtControl.Drawing.DashStyle.Solid);
			this.FanLine1.StartPoint = new NxtControl.Drawing.PointF(78D, 39D);
			// 
			// FanLine2
			// 
			this.FanLine2.EndPoint = new NxtControl.Drawing.PointF(67D, 56D);
			this.FanLine2.Name = "FanLine2";
			this.FanLine2.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("SymStaticIconColor"), 1F, NxtControl.Drawing.DashStyle.Solid);
			this.FanLine2.StartPoint = new NxtControl.Drawing.PointF(72D, 40D);
			// 
			// FanLine3
			// 
			this.FanLine3.EndPoint = new NxtControl.Drawing.PointF(76D, 60D);
			this.FanLine3.Name = "FanLine3";
			this.FanLine3.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("SymStaticIconColor"), 1F, NxtControl.Drawing.DashStyle.Solid);
			this.FanLine3.StartPoint = new NxtControl.Drawing.PointF(76D, 55D);
			// 
			// FanEllipse1
			// 
			this.FanEllipse1.Bounds = new NxtControl.Drawing.RectF(((float)(74D)), ((float)(44D)), ((float)(3D)), ((float)(8D)));
			this.FanEllipse1.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("Transparent"));
			this.FanEllipse1.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.FanEllipse1.Name = "FanEllipse1";
			// 
			// GroupFan
			// 
			this.GroupFan.BeginInit();
			this.GroupFan.Name = "GroupFan";
			this.GroupFan.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fMain", NxtControl.GuiFramework.MouseButtonType.Click));
			this.GroupFan.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.FanBase,
			this.FanBody,
			this.FanEllipse2,
			this.FanEllipse3,
			this.FanLine1,
			this.FanLine2,
			this.FanLine3,
			this.FanEllipse1});
			this.GroupFan.EndInit();
			// 
			// ISIM
			// 
			this.ISIM.BeginInit();
			this.ISIM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 15D, 22D);
			this.ISIM.Name = "ISIM";
			this.ISIM.SecurityToken = ((uint)(4294967295u));
			this.ISIM.TagName = "Equipment.ISIM";
			this.ISIM.Val = false;
			this.ISIM.EndInit();
			// 
			// IA
			// 
			this.IA.BeginInit();
			this.IA.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 17D, 29D);
			this.IA.Name = "IA";
			this.IA.SecurityToken = ((uint)(4294967295u));
			this.IA.TagName = "Equipment.IA";
			this.IA.Val = false;
			this.IA.EndInit();
			// 
			// IPRUN
			// 
			this.IPRUN.BeginInit();
			this.IPRUN.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 23D, 52D);
			this.IPRUN.Name = "IPRUN";
			this.IPRUN.SecurityToken = ((uint)(4294967295u));
			this.IPRUN.TagName = "Equipment.IPRUN";
			this.IPRUN.Val = false;
			this.IPRUN.EndInit();
			// 
			// IFL
			// 
			this.IFL.BeginInit();
			this.IFL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 20D, 17D);
			this.IFL.Name = "IFL";
			this.IFL.SecurityToken = ((uint)(4294967295u));
			this.IFL.TagName = "Equipment.IFL";
			this.IFL.Val = false;
			this.IFL.EndInit();
			// 
			// StatusBody
			// 
			this.StatusBody.Bounds = new NxtControl.Drawing.RectF(((float)(80D)), ((float)(50D)), ((float)(11D)), ((float)(11D)));
			this.StatusBody.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(254)), ((byte)(186)), ((byte)(10))));
			this.StatusBody.Font = new NxtControl.Drawing.Font("HMI Sans Serif", 7F, System.Drawing.FontStyle.Bold);
			this.StatusBody.Name = "StatusBody";
			this.StatusBody.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("Transparent"), 0F, NxtControl.Drawing.DashStyle.Solid);
			this.StatusBody.TextAlignment = NxtControl.Drawing.ContentAlignment.TopCenter;
			this.StatusBody.TextAutoSizeHorizontalOffset = 0;
			this.StatusBody.TextAutoSizeVerticalOffset = 0;
			this.StatusBody.TextColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			// 
			// StatusPolygon
			// 
			this.StatusPolygon.Bounds = new NxtControl.Drawing.RectF(((float)(85D)), ((float)(53D)), ((float)(1D)), ((float)(5D)));
			this.StatusPolygon.Closed = true;
			this.StatusPolygon.Font = new NxtControl.Drawing.Font("HMI Sans Serif", 9F, System.Drawing.FontStyle.Regular);
			this.StatusPolygon.Name = "StatusPolygon";
			this.StatusPolygon.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("Transparent"), 0F, NxtControl.Drawing.DashStyle.Solid);
			this.StatusPolygon.Points.AddRange(new NxtControl.Drawing.PointF[] {
			new NxtControl.Drawing.PointF(86D, 58D),
			new NxtControl.Drawing.PointF(86D, 53D),
			new NxtControl.Drawing.PointF(85D, 53D),
			new NxtControl.Drawing.PointF(85D, 58D)});
			// 
			// StatusEllipse
			// 
			this.StatusEllipse.Bounds = new NxtControl.Drawing.RectF(((float)(85D)), ((float)(58D)), ((float)(1D)), ((float)(1D)));
			this.StatusEllipse.Font = new NxtControl.Drawing.Font("HMI Sans Serif", 2F, System.Drawing.FontStyle.Regular);
			this.StatusEllipse.Name = "StatusEllipse";
			this.StatusEllipse.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("Transparent"), 0F, NxtControl.Drawing.DashStyle.Solid);
			this.StatusEllipse.TextAutoSizeHorizontalOffset = 0;
			this.StatusEllipse.TextAutoSizeVerticalOffset = 0;
			// 
			// GroupStatus
			// 
			this.GroupStatus.BeginInit();
			this.GroupStatus.Name = "GroupStatus";
			this.GroupStatus.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.StatusBody,
			this.StatusPolygon,
			this.StatusEllipse});
			this.GroupStatus.EndInit();
			// 
			// alarmBell
			// 
			this.alarmBell.Bounds = new NxtControl.Drawing.RectF(((float)(52D)), ((float)(33D)), ((float)(14D)), ((float)(14D)));
			this.alarmBell.Brush = new NxtControl.Drawing.Brush(true);
			this.alarmBell.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.alarmBell.ImageName = "SE.Agile.HMI:Icons.Alarm_14x14";
			this.alarmBell.Name = "alarmBell";
			this.alarmBell.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// interlocked
			// 
			this.interlocked.Bounds = new NxtControl.Drawing.RectF(((float)(93D)), ((float)(50D)), ((float)(14D)), ((float)(14D)));
			this.interlocked.Brush = new NxtControl.Drawing.Brush(true);
			this.interlocked.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.interlocked.ImageName = "SE.Agile.HMI:Icons.Interlocked_14x14";
			this.interlocked.Name = "interlocked";
			this.interlocked.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// IPI
			// 
			this.IPI.BeginInit();
			this.IPI.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 22D, 13D);
			this.IPI.Name = "IPI";
			this.IPI.SecurityToken = ((uint)(4294967295u));
			this.IPI.TagName = "Equipment.IPI";
			this.IPI.Val = false;
			this.IPI.EndInit();
			// 
			// sFan
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.alarmFrame,
			this.AssetName,
			this.txtAssetName,
			this.txtMode,
			this.IRUN,
			this.GroupFan,
			this.ISIM,
			this.IA,
			this.IPRUN,
			this.IFL,
			this.GroupStatus,
			this.alarmBell,
			this.interlocked,
			this.IPI});
			this.SymbolSize = new System.Drawing.Size(168, 120);
			((System.ComponentModel.ISupportInitialize)(this.alarmFrame)).EndInit();

		}
		private NxtControl.GuiFramework.AlarmFrame alarmFrame;
		private System.HMI.Symbols.Base.Execute<string> AssetName;
		private NxtControl.GuiFramework.Label txtAssetName;
		private SE.Agile.Symbols.ModeSelector_v1_0.sModeIcon txtMode;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IRUN;
		private NxtControl.GuiFramework.Polygon FanBase;
		private NxtControl.GuiFramework.Ellipse FanBody;
		private NxtControl.GuiFramework.Ellipse FanEllipse2;
		private NxtControl.GuiFramework.Ellipse FanEllipse3;
		private NxtControl.GuiFramework.Line FanLine1;
		private NxtControl.GuiFramework.Line FanLine2;
		private NxtControl.GuiFramework.Line FanLine3;
		private NxtControl.GuiFramework.Ellipse FanEllipse1;
		private NxtControl.GuiFramework.Group GroupFan;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged ISIM;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IA;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IPRUN;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IFL;
		private NxtControl.GuiFramework.Ellipse StatusBody;
		private NxtControl.GuiFramework.Polygon StatusPolygon;
		private NxtControl.GuiFramework.Ellipse StatusEllipse;
		private NxtControl.GuiFramework.Group GroupStatus;
		private NxtControl.GuiFramework.Rectangle alarmBell;
		private NxtControl.GuiFramework.Rectangle interlocked;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IPI;
		#endregion
	}
}
