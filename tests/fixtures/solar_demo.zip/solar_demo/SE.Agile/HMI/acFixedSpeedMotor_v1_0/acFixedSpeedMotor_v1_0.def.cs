using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region acFixedSpeedMotor_v1_0_HMI;

namespace SE.Agile.Symbols.acFixedSpeedMotor_v1_0
{
  partial class sPump
  {

    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain fMain
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters fParameters
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms fAlarms
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData fData
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters fCounters
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    protected override void DoOpenFaceplate(OpenFaceplate openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fMain;

      if ("fParameters" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fParameters;

      if ("fAlarms" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fAlarms;

      if ("fData" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fData;

      if ("fCounters" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fCounters;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

    public override void DoOpenFaceplate(string openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == openFaceplate)
        hmiFaceplate = fMain;

      if ("fParameters" == openFaceplate)
        hmiFaceplate = fParameters;

      if ("fAlarms" == openFaceplate)
        hmiFaceplate = fAlarms;

      if ("fData" == openFaceplate)
        hmiFaceplate = fData;

      if ("fCounters" == openFaceplate)
        hmiFaceplate = fCounters;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

  }
}

namespace SE.Agile.Faceplates.acFixedSpeedMotor_v1_0
{
  partial class fMain
  {

    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters fParameters
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters();

          faceplate.SetConnectionInfo(this.TagName, this.ConnectionSymbolPath, this.ChannelId, this.ParentType);

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms fAlarms
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms();

          faceplate.SetConnectionInfo(this.TagName, this.ConnectionSymbolPath, this.ChannelId, this.ParentType);

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData fData
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData();

          faceplate.SetConnectionInfo(this.TagName, this.ConnectionSymbolPath, this.ChannelId, this.ParentType);

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters fCounters
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters();

          faceplate.SetConnectionInfo(this.TagName, this.ConnectionSymbolPath, this.ChannelId, this.ParentType);

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    protected override void DoOpenFaceplate(OpenFaceplate openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fParameters" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fParameters;

      if ("fAlarms" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fAlarms;

      if ("fData" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fData;

      if ("fCounters" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fCounters;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

    public override void DoOpenFaceplate(string openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fParameters" == openFaceplate)
        hmiFaceplate = fParameters;

      if ("fAlarms" == openFaceplate)
        hmiFaceplate = fAlarms;

      if ("fData" == openFaceplate)
        hmiFaceplate = fData;

      if ("fCounters" == openFaceplate)
        hmiFaceplate = fCounters;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

  }
}

namespace SE.Agile.Faceplates.acFixedSpeedMotor_v1_0
{
  partial class fParameters
  {

    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain fMain
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain();

          faceplate.SetConnectionInfo(this.TagName, this.ConnectionSymbolPath, this.ChannelId, this.ParentType);

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms fAlarms
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms();

          faceplate.SetConnectionInfo(this.TagName, this.ConnectionSymbolPath, this.ChannelId, this.ParentType);

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData fData
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData();

          faceplate.SetConnectionInfo(this.TagName, this.ConnectionSymbolPath, this.ChannelId, this.ParentType);

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters fCounters
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters();

          faceplate.SetConnectionInfo(this.TagName, this.ConnectionSymbolPath, this.ChannelId, this.ParentType);

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    protected override void DoOpenFaceplate(OpenFaceplate openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fMain;

      if ("fAlarms" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fAlarms;

      if ("fData" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fData;

      if ("fCounters" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fCounters;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

    public override void DoOpenFaceplate(string openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == openFaceplate)
        hmiFaceplate = fMain;

      if ("fAlarms" == openFaceplate)
        hmiFaceplate = fAlarms;

      if ("fData" == openFaceplate)
        hmiFaceplate = fData;

      if ("fCounters" == openFaceplate)
        hmiFaceplate = fCounters;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

  }
}

namespace SE.Agile.Symbols.acFixedSpeedMotor_v1_0
{
  partial class sAgitator
  {

    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain fMain
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters fParameters
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms fAlarms
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData fData
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters fCounters
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    protected override void DoOpenFaceplate(OpenFaceplate openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fMain;

      if ("fParameters" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fParameters;

      if ("fAlarms" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fAlarms;

      if ("fData" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fData;

      if ("fCounters" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fCounters;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

    public override void DoOpenFaceplate(string openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == openFaceplate)
        hmiFaceplate = fMain;

      if ("fParameters" == openFaceplate)
        hmiFaceplate = fParameters;

      if ("fAlarms" == openFaceplate)
        hmiFaceplate = fAlarms;

      if ("fData" == openFaceplate)
        hmiFaceplate = fData;

      if ("fCounters" == openFaceplate)
        hmiFaceplate = fCounters;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

  }
}

namespace SE.Agile.Symbols.acFixedSpeedMotor_v1_0
{
  partial class sBlower
  {

    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain fMain
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters fParameters
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms fAlarms
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData fData
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters fCounters
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    protected override void DoOpenFaceplate(OpenFaceplate openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fMain;

      if ("fParameters" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fParameters;

      if ("fAlarms" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fAlarms;

      if ("fData" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fData;

      if ("fCounters" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fCounters;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

    public override void DoOpenFaceplate(string openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == openFaceplate)
        hmiFaceplate = fMain;

      if ("fParameters" == openFaceplate)
        hmiFaceplate = fParameters;

      if ("fAlarms" == openFaceplate)
        hmiFaceplate = fAlarms;

      if ("fData" == openFaceplate)
        hmiFaceplate = fData;

      if ("fCounters" == openFaceplate)
        hmiFaceplate = fCounters;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

  }
}

namespace SE.Agile.Symbols.acFixedSpeedMotor_v1_0
{
  partial class sFan
  {

    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain fMain
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters fParameters
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms fAlarms
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData fData
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters fCounters
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    protected override void DoOpenFaceplate(OpenFaceplate openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fMain;

      if ("fParameters" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fParameters;

      if ("fAlarms" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fAlarms;

      if ("fData" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fData;

      if ("fCounters" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fCounters;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

    public override void DoOpenFaceplate(string openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == openFaceplate)
        hmiFaceplate = fMain;

      if ("fParameters" == openFaceplate)
        hmiFaceplate = fParameters;

      if ("fAlarms" == openFaceplate)
        hmiFaceplate = fAlarms;

      if ("fData" == openFaceplate)
        hmiFaceplate = fData;

      if ("fCounters" == openFaceplate)
        hmiFaceplate = fCounters;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

  }
}

namespace SE.Agile.Symbols.acFixedSpeedMotor_v1_0
{
  partial class sMotor
  {

    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain fMain
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters fParameters
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms fAlarms
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData fData
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters fCounters
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    protected override void DoOpenFaceplate(OpenFaceplate openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fMain;

      if ("fParameters" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fParameters;

      if ("fAlarms" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fAlarms;

      if ("fData" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fData;

      if ("fCounters" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fCounters;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

    public override void DoOpenFaceplate(string openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == openFaceplate)
        hmiFaceplate = fMain;

      if ("fParameters" == openFaceplate)
        hmiFaceplate = fParameters;

      if ("fAlarms" == openFaceplate)
        hmiFaceplate = fAlarms;

      if ("fData" == openFaceplate)
        hmiFaceplate = fData;

      if ("fCounters" == openFaceplate)
        hmiFaceplate = fCounters;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

  }
}

namespace SE.Agile.Faceplates.acFixedSpeedMotor_v1_0
{
  partial class fAlarms
  {

    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain fMain
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain();

          faceplate.SetConnectionInfo(this.TagName, this.ConnectionSymbolPath, this.ChannelId, this.ParentType);

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters fParameters
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters();

          faceplate.SetConnectionInfo(this.TagName, this.ConnectionSymbolPath, this.ChannelId, this.ParentType);

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData fData
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData();

          faceplate.SetConnectionInfo(this.TagName, this.ConnectionSymbolPath, this.ChannelId, this.ParentType);

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters fCounters
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters();

          faceplate.SetConnectionInfo(this.TagName, this.ConnectionSymbolPath, this.ChannelId, this.ParentType);

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    protected override void DoOpenFaceplate(OpenFaceplate openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fMain;

      if ("fParameters" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fParameters;

      if ("fData" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fData;

      if ("fCounters" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fCounters;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

    public override void DoOpenFaceplate(string openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == openFaceplate)
        hmiFaceplate = fMain;

      if ("fParameters" == openFaceplate)
        hmiFaceplate = fParameters;

      if ("fData" == openFaceplate)
        hmiFaceplate = fData;

      if ("fCounters" == openFaceplate)
        hmiFaceplate = fCounters;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

  }
}

namespace SE.Agile.Faceplates.acFixedSpeedMotor_v1_0
{
  partial class fData
  {

    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain fMain
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain();

          faceplate.SetConnectionInfo(this.TagName, this.ConnectionSymbolPath, this.ChannelId, this.ParentType);

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters fParameters
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters();

          faceplate.SetConnectionInfo(this.TagName, this.ConnectionSymbolPath, this.ChannelId, this.ParentType);

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms fAlarms
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms();

          faceplate.SetConnectionInfo(this.TagName, this.ConnectionSymbolPath, this.ChannelId, this.ParentType);

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters fCounters
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fCounters();

          faceplate.SetConnectionInfo(this.TagName, this.ConnectionSymbolPath, this.ChannelId, this.ParentType);

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    protected override void DoOpenFaceplate(OpenFaceplate openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fMain;

      if ("fParameters" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fParameters;

      if ("fAlarms" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fAlarms;

      if ("fCounters" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fCounters;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

    public override void DoOpenFaceplate(string openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == openFaceplate)
        hmiFaceplate = fMain;

      if ("fParameters" == openFaceplate)
        hmiFaceplate = fParameters;

      if ("fAlarms" == openFaceplate)
        hmiFaceplate = fAlarms;

      if ("fCounters" == openFaceplate)
        hmiFaceplate = fCounters;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

  }
}

namespace SE.Agile.Faceplates.acFixedSpeedMotor_v1_0
{
  partial class fCounters
  {

    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain fMain
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fMain();

          faceplate.SetConnectionInfo(this.TagName, this.ConnectionSymbolPath, this.ChannelId, this.ParentType);

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters fParameters
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fParameters();

          faceplate.SetConnectionInfo(this.TagName, this.ConnectionSymbolPath, this.ChannelId, this.ParentType);

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms fAlarms
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fAlarms();

          faceplate.SetConnectionInfo(this.TagName, this.ConnectionSymbolPath, this.ChannelId, this.ParentType);

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    private SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData fData
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.acFixedSpeedMotor_v1_0.fData();

          faceplate.SetConnectionInfo(this.TagName, this.ConnectionSymbolPath, this.ChannelId, this.ParentType);

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    protected override void DoOpenFaceplate(OpenFaceplate openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fMain;

      if ("fParameters" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fParameters;

      if ("fAlarms" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fAlarms;

      if ("fData" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fData;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

    public override void DoOpenFaceplate(string openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == openFaceplate)
        hmiFaceplate = fMain;

      if ("fParameters" == openFaceplate)
        hmiFaceplate = fParameters;

      if ("fAlarms" == openFaceplate)
        hmiFaceplate = fAlarms;

      if ("fData" == openFaceplate)
        hmiFaceplate = fData;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

  }
}
#endregion acFixedSpeedMotor_v1_0_HMI;

#endregion Definitions;

