/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 9/22/2025
 * Time: 6:31 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using NxtControl.GuiFramework;

namespace SE.Agile.Faceplates.acFixedSpeedMotor_v1_0
{
	/// <summary>
	/// Summary description for fParameters.
	/// </summary>
	partial class fParameters
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.symCSTTFL = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed();
			this.symCSTPL = new SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed();
			this.symBtnCMSK = new SE.Agile.Symbols.HMI_Control_Bool_v1_0.sButtonTwoStateNamed();
			this.AssetName = new System.HMI.Symbols.Base.Execute<string>();
			// 
			// symCSTTFL
			// 
			this.symCSTTFL.BeginInit();
			this.symCSTTFL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -48D, 8D);
			this.symCSTTFL.Enabled = true;
			this.symCSTTFL.LabelText = "Time to Start:";
			this.symCSTTFL.Name = "symCSTTFL";
			this.symCSTTFL.SecurityToken = ((uint)(4294967295u));
			this.symCSTTFL.TagName = "Equipment.CSTTFL";
			this.symCSTTFL.EndInit();
			// 
			// symCSTPL
			// 
			this.symCSTPL.BeginInit();
			this.symCSTPL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -48D, 40D);
			this.symCSTPL.Enabled = true;
			this.symCSTPL.LabelText = "Time to Stop:";
			this.symCSTPL.Name = "symCSTPL";
			this.symCSTPL.SecurityToken = ((uint)(4294967295u));
			this.symCSTPL.TagName = "Equipment.CSTPFL";
			this.symCSTPL.EndInit();
			// 
			// symBtnCMSK
			// 
			this.symBtnCMSK.BeginInit();
			this.symBtnCMSK.ButtonFalseColor = new NxtControl.Drawing.Color(((byte)(110)), ((byte)(110)), ((byte)(110)));
			this.symBtnCMSK.ButtonTrueColor = new NxtControl.Drawing.Color(((byte)(0)), ((byte)(168)), ((byte)(231)));
			this.symBtnCMSK.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -48D, 72D);
			this.symBtnCMSK.Enabled = true;
			this.symBtnCMSK.LabelText = "Simulation";
			this.symBtnCMSK.Name = "symBtnCMSK";
			this.symBtnCMSK.SecurityToken = ((uint)(4294967295u));
			this.symBtnCMSK.TagName = "Equipment.CMSK";
			this.symBtnCMSK.EndInit();
			// 
			// AssetName
			// 
			this.AssetName.BeginInit();
			this.AssetName.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.AssetName.IsOnlyInput = true;
			this.AssetName.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.AssetName.Name = "AssetName";
			this.AssetName.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.AssetName.TagName = "AssetName";
			this.AssetName.Value = null;
			this.AssetName.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.AssetNameValueChanged);
			this.AssetName.EndInit();
			// 
			// fParameters
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(240D)), ((float)(152D)));
			this.Brush = new NxtControl.Drawing.Brush("FaceplateBrush");
			this.FaceplateClose = NxtControl.GuiFramework.CloseFaceplateBehavior.Automatic;
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.symCSTTFL,
			this.symCSTPL,
			this.symBtnCMSK,
			this.AssetName});
			this.Size = new System.Drawing.Size(240, 152);

		}
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed symCSTTFL;
		private SE.Agile.Symbols.HMI_Control_Real_v1_0.sValueInputMiddleNamed symCSTPL;
		private SE.Agile.Symbols.HMI_Control_Bool_v1_0.sButtonTwoStateNamed symBtnCMSK;
		private System.HMI.Symbols.Base.Execute<string> AssetName;
		#endregion
	}
}
