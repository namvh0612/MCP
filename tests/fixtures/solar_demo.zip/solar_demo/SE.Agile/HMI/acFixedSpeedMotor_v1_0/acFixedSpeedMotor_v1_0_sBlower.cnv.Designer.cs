/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 8/11/2025
 * Time: 1:58 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.acFixedSpeedMotor_v1_0
{
	/// <summary>
	/// Summary description for overviewSymbol.
	/// </summary>
	partial class sBlower
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.alarmFrame = new NxtControl.GuiFramework.AlarmFrame();
			this.AssetName = new System.HMI.Symbols.Base.Execute<string>();
			this.txtAssetName = new NxtControl.GuiFramework.Label();
			this.txtMode = new SE.Agile.Symbols.ModeSelector_v1_0.sModeIcon();
			this.IRUN = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.BlowerInlet = new NxtControl.GuiFramework.Rectangle();
			this.GroupBlowerBody = new NxtControl.GuiFramework.Group();
			this.BlowerBase = new NxtControl.GuiFramework.Ellipse();
			this.GroupBlowerBodyInternal = new NxtControl.GuiFramework.Group();
			this.BlowerBody1 = new NxtControl.GuiFramework.Ellipse();
			this.BlowerBody2 = new NxtControl.GuiFramework.Ellipse();
			this.BlowerLine2 = new NxtControl.GuiFramework.Line();
			this.BlowerLine4 = new NxtControl.GuiFramework.Line();
			this.BlowerLine5 = new NxtControl.GuiFramework.Line();
			this.BlowerLine6 = new NxtControl.GuiFramework.Line();
			this.BlowerLine7 = new NxtControl.GuiFramework.Line();
			this.BlowerLine8 = new NxtControl.GuiFramework.Line();
			this.GroupBlower = new NxtControl.GuiFramework.Group();
			this.ISIM = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IA = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IPRUN = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IFL = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.StatusBody = new NxtControl.GuiFramework.Ellipse();
			this.StatusPolygon = new NxtControl.GuiFramework.Polygon();
			this.StatusEllipse = new NxtControl.GuiFramework.Ellipse();
			this.GroupStatus = new NxtControl.GuiFramework.Group();
			this.alarmBell = new NxtControl.GuiFramework.Rectangle();
			this.interlocked = new NxtControl.GuiFramework.Rectangle();
			this.IPI = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			((System.ComponentModel.ISupportInitialize)(this.alarmFrame)).BeginInit();
			// 
			// alarmFrame
			// 
			this.alarmFrame.Bounds = new NxtControl.Drawing.RectF(((float)(56D)), ((float)(34D)), ((float)(40D)), ((float)(34D)));
			this.alarmFrame.FrameWidth = ((uint)(2u));
			this.alarmFrame.Name = "alarmFrame";
			this.alarmFrame.Radius = 5D;
			// 
			// AssetName
			// 
			this.AssetName.BeginInit();
			this.AssetName.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.AssetName.IsOnlyInput = true;
			this.AssetName.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.AssetName.Name = "AssetName";
			this.AssetName.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.AssetName.TagName = "AssetName";
			this.AssetName.Value = null;
			this.AssetName.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.AssetNameValueChanged);
			this.AssetName.EndInit();
			// 
			// txtAssetName
			// 
			this.txtAssetName.AngleIgnore = true;
			this.txtAssetName.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtAssetName.Bounds = new NxtControl.Drawing.RectF(((float)(45D)), ((float)(67D)), ((float)(62D)), ((float)(20D)));
			this.txtAssetName.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtAssetName.Font = new NxtControl.Drawing.Font("LabelFont");
			this.txtAssetName.FontScale = true;
			this.txtAssetName.Name = "txtAssetName";
			this.txtAssetName.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtAssetName.Text = "Name";
			this.txtAssetName.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleCenter;
			this.txtAssetName.TextAutoSize = true;
			this.txtAssetName.TextAutoSizeHorizontalOffset = 10;
			this.txtAssetName.TextColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.txtAssetName.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// txtMode
			// 
			this.txtMode.BeginInit();
			this.txtMode.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 42D, 10D);
			this.txtMode.Name = "txtMode";
			this.txtMode.SecurityToken = ((uint)(4294967295u));
			this.txtMode.TagName = "Equipment.Mode";
			this.txtMode.EndInit();
			// 
			// IRUN
			// 
			this.IRUN.BeginInit();
			this.IRUN.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 28D, 18D);
			this.IRUN.Name = "IRUN";
			this.IRUN.SecurityToken = ((uint)(4294967295u));
			this.IRUN.TagName = "Equipment.IRUN";
			this.IRUN.Val = false;
			this.IRUN.EndInit();
			// 
			// BlowerInlet
			// 
			this.BlowerInlet.Bounds = new NxtControl.Drawing.RectF(((float)(76D)), ((float)(40D)), ((float)(13D)), ((float)(10D)));
			this.BlowerInlet.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.BlowerInlet.Name = "BlowerInlet";
			// 
			// GroupBlowerBody
			// 
			this.GroupBlowerBody.BeginInit();
			this.GroupBlowerBody.Name = "GroupBlowerBody";
			this.GroupBlowerBody.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.BlowerBase,
			this.GroupBlowerBodyInternal});
			this.GroupBlowerBody.EndInit();
			// 
			// BlowerBase
			// 
			this.BlowerBase.Bounds = new NxtControl.Drawing.RectF(((float)(64D)), ((float)(40D)), ((float)(22D)), ((float)(22D)));
			this.BlowerBase.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.BlowerBase.Name = "BlowerBase";
			// 
			// GroupBlowerBodyInternal
			// 
			this.GroupBlowerBodyInternal.BeginInit();
			this.GroupBlowerBodyInternal.Name = "GroupBlowerBodyInternal";
			this.GroupBlowerBodyInternal.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.BlowerBody1,
			this.BlowerBody2,
			this.BlowerLine2,
			this.BlowerLine4,
			this.BlowerLine5,
			this.BlowerLine6,
			this.BlowerLine7,
			this.BlowerLine8});
			this.GroupBlowerBodyInternal.EndInit();
			// 
			// BlowerBody1
			// 
			this.BlowerBody1.Bounds = new NxtControl.Drawing.RectF(((float)(72D)), ((float)(49D)), ((float)(5D)), ((float)(5D)));
			this.BlowerBody1.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("Transparent"));
			this.BlowerBody1.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.BlowerBody1.Name = "BlowerBody1";
			this.BlowerBody1.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.None;
			// 
			// BlowerBody2
			// 
			this.BlowerBody2.Bounds = new NxtControl.Drawing.RectF(((float)(67D)), ((float)(44D)), ((float)(15D)), ((float)(15D)));
			this.BlowerBody2.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color("Transparent"));
			this.BlowerBody2.Font = new NxtControl.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular);
			this.BlowerBody2.Name = "BlowerBody2";
			this.BlowerBody2.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.None;
			// 
			// BlowerLine2
			// 
			this.BlowerLine2.EndPoint = new NxtControl.Drawing.PointF(73D, 53D);
			this.BlowerLine2.Name = "BlowerLine2";
			this.BlowerLine2.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("SymStaticIconColor"), 1F, NxtControl.Drawing.DashStyle.Solid);
			this.BlowerLine2.StartPoint = new NxtControl.Drawing.PointF(68D, 55D);
			// 
			// BlowerLine4
			// 
			this.BlowerLine4.EndPoint = new NxtControl.Drawing.PointF(75D, 44D);
			this.BlowerLine4.Name = "BlowerLine4";
			this.BlowerLine4.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("SymStaticIconColor"), 1F, NxtControl.Drawing.DashStyle.Solid);
			this.BlowerLine4.StartPoint = new NxtControl.Drawing.PointF(75D, 49D);
			// 
			// BlowerLine5
			// 
			this.BlowerLine5.EndPoint = new NxtControl.Drawing.PointF(81D, 55D);
			this.BlowerLine5.Name = "BlowerLine5";
			this.BlowerLine5.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("SymStaticIconColor"), 1F, NxtControl.Drawing.DashStyle.Solid);
			this.BlowerLine5.StartPoint = new NxtControl.Drawing.PointF(76D, 53D);
			// 
			// BlowerLine6
			// 
			this.BlowerLine6.EndPoint = new NxtControl.Drawing.PointF(75D, 54D);
			this.BlowerLine6.Name = "BlowerLine6";
			this.BlowerLine6.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("SymStaticIconColor"), 1F, NxtControl.Drawing.DashStyle.Solid);
			this.BlowerLine6.StartPoint = new NxtControl.Drawing.PointF(75D, 59D);
			// 
			// BlowerLine7
			// 
			this.BlowerLine7.EndPoint = new NxtControl.Drawing.PointF(73D, 50D);
			this.BlowerLine7.Name = "BlowerLine7";
			this.BlowerLine7.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("SymStaticIconColor"), 1F, NxtControl.Drawing.DashStyle.Solid);
			this.BlowerLine7.StartPoint = new NxtControl.Drawing.PointF(68D, 48D);
			// 
			// BlowerLine8
			// 
			this.BlowerLine8.EndPoint = new NxtControl.Drawing.PointF(81D, 47D);
			this.BlowerLine8.Name = "BlowerLine8";
			this.BlowerLine8.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("SymStaticIconColor"), 1F, NxtControl.Drawing.DashStyle.Solid);
			this.BlowerLine8.StartPoint = new NxtControl.Drawing.PointF(76D, 50D);
			// 
			// GroupBlower
			// 
			this.GroupBlower.BeginInit();
			this.GroupBlower.Name = "GroupBlower";
			this.GroupBlower.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fMain", NxtControl.GuiFramework.MouseButtonType.Click));
			this.GroupBlower.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.BlowerInlet,
			this.GroupBlowerBody});
			this.GroupBlower.EndInit();
			// 
			// ISIM
			// 
			this.ISIM.BeginInit();
			this.ISIM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 17D, 8D);
			this.ISIM.Name = "ISIM";
			this.ISIM.SecurityToken = ((uint)(4294967295u));
			this.ISIM.TagName = "Equipment.ISIM";
			this.ISIM.Val = false;
			this.ISIM.EndInit();
			// 
			// IA
			// 
			this.IA.BeginInit();
			this.IA.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 37D, 25D);
			this.IA.Name = "IA";
			this.IA.SecurityToken = ((uint)(4294967295u));
			this.IA.TagName = "Equipment.IA";
			this.IA.Val = false;
			this.IA.EndInit();
			// 
			// IPRUN
			// 
			this.IPRUN.BeginInit();
			this.IPRUN.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 13D, 72D);
			this.IPRUN.Name = "IPRUN";
			this.IPRUN.SecurityToken = ((uint)(4294967295u));
			this.IPRUN.TagName = "Equipment.IPRUN";
			this.IPRUN.Val = false;
			this.IPRUN.EndInit();
			// 
			// IFL
			// 
			this.IFL.BeginInit();
			this.IFL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 23D, 77D);
			this.IFL.Name = "IFL";
			this.IFL.SecurityToken = ((uint)(4294967295u));
			this.IFL.TagName = "Equipment.IFL";
			this.IFL.Val = false;
			this.IFL.EndInit();
			// 
			// StatusBody
			// 
			this.StatusBody.Bounds = new NxtControl.Drawing.RectF(((float)(78D)), ((float)(52D)), ((float)(11D)), ((float)(11D)));
			this.StatusBody.Brush = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(254)), ((byte)(186)), ((byte)(10))));
			this.StatusBody.Font = new NxtControl.Drawing.Font("HMI Sans Serif", 7F, System.Drawing.FontStyle.Bold);
			this.StatusBody.Name = "StatusBody";
			this.StatusBody.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("Transparent"), 0F, NxtControl.Drawing.DashStyle.Solid);
			this.StatusBody.TextAlignment = NxtControl.Drawing.ContentAlignment.TopCenter;
			this.StatusBody.TextAutoSizeHorizontalOffset = 0;
			this.StatusBody.TextAutoSizeVerticalOffset = 0;
			this.StatusBody.TextColor = new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255)));
			// 
			// StatusPolygon
			// 
			this.StatusPolygon.Bounds = new NxtControl.Drawing.RectF(((float)(83D)), ((float)(55D)), ((float)(1D)), ((float)(5D)));
			this.StatusPolygon.Closed = true;
			this.StatusPolygon.Font = new NxtControl.Drawing.Font("HMI Sans Serif", 9F, System.Drawing.FontStyle.Regular);
			this.StatusPolygon.Name = "StatusPolygon";
			this.StatusPolygon.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("Transparent"), 0F, NxtControl.Drawing.DashStyle.Solid);
			this.StatusPolygon.Points.AddRange(new NxtControl.Drawing.PointF[] {
			new NxtControl.Drawing.PointF(84D, 60D),
			new NxtControl.Drawing.PointF(84D, 55D),
			new NxtControl.Drawing.PointF(83D, 55D),
			new NxtControl.Drawing.PointF(83D, 60D)});
			// 
			// StatusEllipse
			// 
			this.StatusEllipse.Bounds = new NxtControl.Drawing.RectF(((float)(83D)), ((float)(60D)), ((float)(1D)), ((float)(1D)));
			this.StatusEllipse.Font = new NxtControl.Drawing.Font("HMI Sans Serif", 2F, System.Drawing.FontStyle.Regular);
			this.StatusEllipse.Name = "StatusEllipse";
			this.StatusEllipse.Pen = new NxtControl.Drawing.Pen(new NxtControl.Drawing.Color("Transparent"), 0F, NxtControl.Drawing.DashStyle.Solid);
			this.StatusEllipse.TextAutoSizeHorizontalOffset = 0;
			this.StatusEllipse.TextAutoSizeVerticalOffset = 0;
			// 
			// GroupStatus
			// 
			this.GroupStatus.BeginInit();
			this.GroupStatus.Name = "GroupStatus";
			this.GroupStatus.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.StatusBody,
			this.StatusPolygon,
			this.StatusEllipse});
			this.GroupStatus.EndInit();
			// 
			// alarmBell
			// 
			this.alarmBell.Bounds = new NxtControl.Drawing.RectF(((float)(52D)), ((float)(33D)), ((float)(14D)), ((float)(14D)));
			this.alarmBell.Brush = new NxtControl.Drawing.Brush(true);
			this.alarmBell.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.alarmBell.ImageName = "SE.Agile.HMI:Icons.Alarm_14x14";
			this.alarmBell.Name = "alarmBell";
			this.alarmBell.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// interlocked
			// 
			this.interlocked.Bounds = new NxtControl.Drawing.RectF(((float)(93D)), ((float)(52D)), ((float)(14D)), ((float)(14D)));
			this.interlocked.Brush = new NxtControl.Drawing.Brush(true);
			this.interlocked.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.interlocked.ImageName = "SE.Agile.HMI:Icons.Interlocked_14x14";
			this.interlocked.Name = "interlocked";
			this.interlocked.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// IPI
			// 
			this.IPI.BeginInit();
			this.IPI.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 20D, 46D);
			this.IPI.Name = "IPI";
			this.IPI.SecurityToken = ((uint)(4294967295u));
			this.IPI.TagName = "Equipment.IPI";
			this.IPI.Val = false;
			this.IPI.EndInit();
			// 
			// sBlower
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.alarmFrame,
			this.AssetName,
			this.txtAssetName,
			this.txtMode,
			this.IRUN,
			this.GroupBlower,
			this.ISIM,
			this.IA,
			this.IPRUN,
			this.IFL,
			this.GroupStatus,
			this.alarmBell,
			this.interlocked,
			this.IPI});
			this.SymbolSize = new System.Drawing.Size(168, 120);
			((System.ComponentModel.ISupportInitialize)(this.alarmFrame)).EndInit();

		}
		private NxtControl.GuiFramework.AlarmFrame alarmFrame;
		private System.HMI.Symbols.Base.Execute<string> AssetName;
		private NxtControl.GuiFramework.Label txtAssetName;
		private SE.Agile.Symbols.ModeSelector_v1_0.sModeIcon txtMode;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IRUN;
		private NxtControl.GuiFramework.Rectangle BlowerInlet;
		private NxtControl.GuiFramework.Group GroupBlowerBody;
		private NxtControl.GuiFramework.Ellipse BlowerBase;
		private NxtControl.GuiFramework.Group GroupBlowerBodyInternal;
		private NxtControl.GuiFramework.Ellipse BlowerBody1;
		private NxtControl.GuiFramework.Ellipse BlowerBody2;
		private NxtControl.GuiFramework.Line BlowerLine2;
		private NxtControl.GuiFramework.Line BlowerLine4;
		private NxtControl.GuiFramework.Line BlowerLine5;
		private NxtControl.GuiFramework.Line BlowerLine6;
		private NxtControl.GuiFramework.Line BlowerLine7;
		private NxtControl.GuiFramework.Line BlowerLine8;
		private NxtControl.GuiFramework.Group GroupBlower;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged ISIM;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IA;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IPRUN;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IFL;
		private NxtControl.GuiFramework.Ellipse StatusBody;
		private NxtControl.GuiFramework.Polygon StatusPolygon;
		private NxtControl.GuiFramework.Ellipse StatusEllipse;
		private NxtControl.GuiFramework.Group GroupStatus;
		private NxtControl.GuiFramework.Rectangle alarmBell;
		private NxtControl.GuiFramework.Rectangle interlocked;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IPI;
		#endregion
	}
}
