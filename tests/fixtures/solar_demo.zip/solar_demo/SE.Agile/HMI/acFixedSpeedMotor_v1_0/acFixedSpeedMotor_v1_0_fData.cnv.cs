﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 4/21/2026
 * Time: 1:03 PM
 * 
 */

using System;
using NxtControl.GuiFramework;

namespace SE.Agile.Faceplates.acFixedSpeedMotor_v1_0
{
	/// <summary>
	/// Description of fData.
	/// </summary>
	public partial class fData : NxtControl.GuiFramework.HMIFaceplate
	{
		public fData()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}
		
		void AssetNameValueChanged(object sender, ValueChangedEventArgs e)
		{
			Title = (string)e.Value;
		}
	}
}
