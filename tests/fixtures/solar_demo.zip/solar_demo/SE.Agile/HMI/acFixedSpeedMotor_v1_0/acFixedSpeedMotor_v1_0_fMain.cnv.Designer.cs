/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 8/11/2025
 * Time: 2:02 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using NxtControl.GuiFramework;

namespace SE.Agile.Faceplates.acFixedSpeedMotor_v1_0
{
	/// <summary>
	/// Summary description for faceplateMain.
	/// </summary>
	partial class fMain
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fMain));
			this.AssetName = new System.HMI.Symbols.Base.Execute<string>();
			this.lblStatus = new NxtControl.GuiFramework.FreeText();
			this.IRUN = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.IPRUN = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.symTxtMode = new SE.Agile.Symbols.ModeSelector_v1_0.sModeNamedMiddle();
			this.txtStatus = new NxtControl.GuiFramework.FreeText();
			this.symIFL = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed();
			this.symIAOK = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed();
			this.symISIM = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed();
			this.symIPI = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed();
			this.symBtnMode = new SE.Agile.Symbols.ModeSelector_v1_0.sButtonQuad();
			this.symBtnCMSTRT = new SE.Agile.Symbols.HMI_Control_Bool_v1_0.sButtonVert2();
			this.navParameters = new NxtControl.GuiFramework.Rectangle();
			this.navData1 = new NxtControl.GuiFramework.Rectangle();
			this.navInterlock = new NxtControl.GuiFramework.Rectangle();
			this.navAlarm = new NxtControl.GuiFramework.Rectangle();
			this.navPermissive = new NxtControl.GuiFramework.Rectangle();
			this.navTrend = new NxtControl.GuiFramework.Rectangle();
			this.CMODE = new SE.Agile.Symbols.HMI_Control_Integer_v1_0.sValChanged();
			this.symBtnCFLRST = new SE.Agile.Symbols.HMI_Control_Bool_v1_0.sButtonValSet();
			this.IRSTPERM = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.navPrograms = new SE.Agile.Symbols.Broadcaster_v1_0.sButtonNavProgram();
			this.navAlarmActive = new NxtControl.GuiFramework.Rectangle();
			this.IA = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.navData2 = new NxtControl.GuiFramework.Rectangle();
			this.symIIOFL = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed();
			// 
			// AssetName
			// 
			this.AssetName.BeginInit();
			this.AssetName.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.AssetName.IsOnlyInput = true;
			this.AssetName.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.AssetName.Name = "AssetName";
			this.AssetName.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.AssetName.TagName = "AssetName";
			this.AssetName.Value = null;
			this.AssetName.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.AssetNameValueChanged);
			this.AssetName.EndInit();
			// 
			// lblStatus
			// 
			this.lblStatus.Color = new NxtControl.Drawing.Color("LabelTextColor");
			this.lblStatus.Font = new NxtControl.Drawing.Font("LabelFont");
			this.lblStatus.Location = new NxtControl.Drawing.PointF(87D, 32D);
			this.lblStatus.Name = "lblStatus";
			this.lblStatus.Text = "Status:";
			// 
			// IRUN
			// 
			this.IRUN.BeginInit();
			this.IRUN.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 18D, 14D);
			this.IRUN.Name = "IRUN";
			this.IRUN.SecurityToken = ((uint)(4294967295u));
			this.IRUN.TagName = "Equipment.IRUN";
			this.IRUN.Val = false;
			this.IRUN.EndInit();
			// 
			// IPRUN
			// 
			this.IPRUN.BeginInit();
			this.IPRUN.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 20D, 14D);
			this.IPRUN.Name = "IPRUN";
			this.IPRUN.SecurityToken = ((uint)(4294967295u));
			this.IPRUN.TagName = "Equipment.IPRUN";
			this.IPRUN.Val = false;
			this.IPRUN.EndInit();
			// 
			// symTxtMode
			// 
			this.symTxtMode.BeginInit();
			this.symTxtMode.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -24D, 8D);
			this.symTxtMode.LabelText = "Mode:";
			this.symTxtMode.Name = "symTxtMode";
			this.symTxtMode.SecurityToken = ((uint)(4294967295u));
			this.symTxtMode.TagName = "Equipment.Mode";
			this.symTxtMode.EndInit();
			// 
			// txtStatus
			// 
			this.txtStatus.Color = new NxtControl.Drawing.Color("LabelTextColor");
			this.txtStatus.Font = new NxtControl.Drawing.Font("HMI Sans Serif", 9F, System.Drawing.FontStyle.Regular);
			this.txtStatus.Location = new NxtControl.Drawing.PointF(130D, 32D);
			this.txtStatus.Name = "txtStatus";
			this.txtStatus.Text = "Unknown";
			// 
			// symIFL
			// 
			this.symIFL.BeginInit();
			this.symIFL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -24D, 48D);
			this.symIFL.LabelText = "Fault Status:";
			this.symIFL.Name = "symIFL";
			this.symIFL.OffText = "Ok";
			this.symIFL.OnText = "Failed";
			this.symIFL.SecurityToken = ((uint)(4294967295u));
			this.symIFL.TagName = "Equipment.IFL";
			this.symIFL.EndInit();
			// 
			// symIAOK
			// 
			this.symIAOK.BeginInit();
			this.symIAOK.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -24D, 72D);
			this.symIAOK.LabelText = "Available in Auto:";
			this.symIAOK.Name = "symIAOK";
			this.symIAOK.OffText = "No";
			this.symIAOK.OnText = "Yes";
			this.symIAOK.SecurityToken = ((uint)(4294967295u));
			this.symIAOK.TagName = "Equipment.IAOK";
			this.symIAOK.EndInit();
			// 
			// symISIM
			// 
			this.symISIM.BeginInit();
			this.symISIM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -24D, 120D);
			this.symISIM.LabelText = "Simulation:";
			this.symISIM.Name = "symISIM";
			this.symISIM.SecurityToken = ((uint)(4294967295u));
			this.symISIM.TagName = "Equipment.ISIM";
			this.symISIM.EndInit();
			// 
			// symIPI
			// 
			this.symIPI.BeginInit();
			this.symIPI.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -24D, 144D);
			this.symIPI.LabelText = "Process Interlock:";
			this.symIPI.Name = "symIPI";
			this.symIPI.OffText = "Inactive";
			this.symIPI.OnText = "Active";
			this.symIPI.SecurityToken = ((uint)(4294967295u));
			this.symIPI.TagName = "Equipment.IPI";
			this.symIPI.EndInit();
			// 
			// symBtnMode
			// 
			this.symBtnMode.BeginInit();
			this.symBtnMode.ButtonTextDisabledColor = new NxtControl.Drawing.Color("ButtonTextDisabledColor");
			this.symBtnMode.ButtonToggleOnBrush = new NxtControl.Drawing.Brush("ButtonBrush");
			this.symBtnMode.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 88D, 176D);
			this.symBtnMode.Name = "symBtnMode";
			this.symBtnMode.SecurityToken = ((uint)(4294967295u));
			this.symBtnMode.TagName = "Equipment.Mode";
			this.symBtnMode.EndInit();
			// 
			// symBtnCMSTRT
			// 
			this.symBtnCMSTRT.BeginInit();
			this.symBtnCMSTRT.ButtonDisableText = "Stop";
			this.symBtnCMSTRT.ButtonEnableText = "Start";
			this.symBtnCMSTRT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 16D, 176D);
			this.symBtnCMSTRT.Enabled = false;
			this.symBtnCMSTRT.Name = "symBtnCMSTRT";
			this.symBtnCMSTRT.SecurityToken = ((uint)(4294967295u));
			this.symBtnCMSTRT.TagName = "Equipment.CMSTRT";
			this.symBtnCMSTRT.EndInit();
			// 
			// navParameters
			// 
			this.navParameters.Bounds = new NxtControl.Drawing.RectF(((float)(232D)), ((float)(24D)), ((float)(24D)), ((float)(24D)));
			this.navParameters.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.navParameters.ImageBytes = resources.GetString("navParameters.ImageBytes");
			this.navParameters.Name = "navParameters";
			this.navParameters.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fParameters", NxtControl.GuiFramework.MouseButtonType.Click));
			// 
			// navData1
			// 
			this.navData1.Bounds = new NxtControl.Drawing.RectF(((float)(232D)), ((float)(48D)), ((float)(24D)), ((float)(24D)));
			this.navData1.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.navData1.ImageBytes = resources.GetString("navData1.ImageBytes");
			this.navData1.Name = "navData1";
			this.navData1.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fData", NxtControl.GuiFramework.MouseButtonType.Click));
			// 
			// navInterlock
			// 
			this.navInterlock.Bounds = new NxtControl.Drawing.RectF(((float)(232D)), ((float)(96D)), ((float)(24D)), ((float)(24D)));
			this.navInterlock.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.navInterlock.ImageBytes = resources.GetString("navInterlock.ImageBytes");
			this.navInterlock.Name = "navInterlock";
			// 
			// navAlarm
			// 
			this.navAlarm.Bounds = new NxtControl.Drawing.RectF(((float)(232D)), ((float)(120D)), ((float)(24D)), ((float)(24D)));
			this.navAlarm.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.navAlarm.ImageBytes = resources.GetString("navAlarm.ImageBytes");
			this.navAlarm.Name = "navAlarm";
			this.navAlarm.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fAlarms", NxtControl.GuiFramework.MouseButtonType.Click));
			// 
			// navPermissive
			// 
			this.navPermissive.Bounds = new NxtControl.Drawing.RectF(((float)(232D)), ((float)(144D)), ((float)(24D)), ((float)(24D)));
			this.navPermissive.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.navPermissive.ImageBytes = resources.GetString("navPermissive.ImageBytes");
			this.navPermissive.Name = "navPermissive";
			// 
			// navTrend
			// 
			this.navTrend.Bounds = new NxtControl.Drawing.RectF(((float)(232D)), ((float)(168D)), ((float)(24D)), ((float)(24D)));
			this.navTrend.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.navTrend.ImageBytes = resources.GetString("navTrend.ImageBytes");
			this.navTrend.Name = "navTrend";
			// 
			// CMODE
			// 
			this.CMODE.BeginInit();
			this.CMODE.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 19D, 25D);
			this.CMODE.Name = "CMODE";
			this.CMODE.SecurityToken = ((uint)(4294967295u));
			this.CMODE.TagName = "Equipment.Mode.CMODE";
			this.CMODE.Val = ((short)(0));
			this.CMODE.ValMaximum = ((short)(0));
			this.CMODE.ValMinimum = ((short)(0));
			this.CMODE.ValUnits = null;
			this.CMODE.EndInit();
			// 
			// symBtnCFLRST
			// 
			this.symBtnCFLRST.BeginInit();
			this.symBtnCFLRST.ButtonText = "Reset";
			this.symBtnCFLRST.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 157D, 264D);
			this.symBtnCFLRST.Enabled = false;
			this.symBtnCFLRST.Name = "symBtnCFLRST";
			this.symBtnCFLRST.SecurityToken = ((uint)(4294967295u));
			this.symBtnCFLRST.TagName = "Equipment.CFLRST";
			this.symBtnCFLRST.EndInit();
			// 
			// IRSTPERM
			// 
			this.IRSTPERM.BeginInit();
			this.IRSTPERM.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 25D, 48D);
			this.IRSTPERM.Name = "IRSTPERM";
			this.IRSTPERM.SecurityToken = ((uint)(4294967295u));
			this.IRSTPERM.TagName = "Equipment.IRSTPERM";
			this.IRSTPERM.Val = false;
			this.IRSTPERM.EndInit();
			// 
			// navPrograms
			// 
			this.navPrograms.BeginInit();
			this.navPrograms.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 232D, 0D);
			this.navPrograms.Name = "navPrograms";
			this.navPrograms.SecurityToken = ((uint)(4294967295u));
			this.navPrograms.TagName = "Control.Broadcaster_v1_0";
			this.navPrograms.EndInit();
			// 
			// navAlarmActive
			// 
			this.navAlarmActive.Bounds = new NxtControl.Drawing.RectF(((float)(232D)), ((float)(120D)), ((float)(24D)), ((float)(24D)));
			this.navAlarmActive.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.navAlarmActive.ImageBytes = resources.GetString("navAlarmActive.ImageBytes");
			this.navAlarmActive.Name = "navAlarmActive";
			this.navAlarmActive.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fAlarms", NxtControl.GuiFramework.MouseButtonType.Click));
			this.navAlarmActive.Visible = false;
			// 
			// IA
			// 
			this.IA.BeginInit();
			this.IA.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 31D, 31D);
			this.IA.Name = "IA";
			this.IA.SecurityToken = ((uint)(4294967295u));
			this.IA.TagName = "Equipment.IA";
			this.IA.Val = false;
			this.IA.EndInit();
			// 
			// navData2
			// 
			this.navData2.Bounds = new NxtControl.Drawing.RectF(((float)(232D)), ((float)(72D)), ((float)(24D)), ((float)(24D)));
			this.navData2.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.navData2.ImageBytes = resources.GetString("navData2.ImageBytes");
			this.navData2.Name = "navData2";
			this.navData2.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fCounters", NxtControl.GuiFramework.MouseButtonType.Click));
			// 
			// symIIOFL
			// 
			this.symIIOFL.BeginInit();
			this.symIIOFL.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -24D, 96D);
			this.symIIOFL.LabelText = "IO Fault:";
			this.symIIOFL.Name = "symIIOFL";
			this.symIIOFL.OffText = "No";
			this.symIIOFL.OnText = "Yes";
			this.symIIOFL.SecurityToken = ((uint)(4294967295u));
			this.symIIOFL.TagName = "Equipment.IIOFL";
			this.symIIOFL.EndInit();
			// 
			// fMain
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(260D)), ((float)(304D)));
			this.Brush = new NxtControl.Drawing.Brush("FaceplateBrush");
			this.FaceplateClose = NxtControl.GuiFramework.CloseFaceplateBehavior.Automatic;
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.AssetName,
			this.lblStatus,
			this.IRUN,
			this.IPRUN,
			this.symTxtMode,
			this.txtStatus,
			this.symIFL,
			this.symIAOK,
			this.symISIM,
			this.symIPI,
			this.symBtnMode,
			this.symBtnCMSTRT,
			this.navParameters,
			this.navData1,
			this.navInterlock,
			this.navAlarm,
			this.navPermissive,
			this.navTrend,
			this.CMODE,
			this.symBtnCFLRST,
			this.IRSTPERM,
			this.navPrograms,
			this.navAlarmActive,
			this.IA,
			this.navData2,
			this.symIIOFL});
			this.Size = new System.Drawing.Size(260, 304);

		}
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IRUN;
		private System.HMI.Symbols.Base.Execute<string> AssetName;
		private NxtControl.GuiFramework.FreeText lblStatus;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IPRUN;
		private SE.Agile.Symbols.ModeSelector_v1_0.sModeNamedMiddle symTxtMode;
		private NxtControl.GuiFramework.FreeText txtStatus;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed symIFL;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed symIAOK;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed symISIM;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed symIPI;
		private SE.Agile.Symbols.ModeSelector_v1_0.sButtonQuad symBtnMode;
		private SE.Agile.Symbols.HMI_Control_Bool_v1_0.sButtonVert2 symBtnCMSTRT;
		private NxtControl.GuiFramework.Rectangle navParameters;
		private NxtControl.GuiFramework.Rectangle navData1;
		private NxtControl.GuiFramework.Rectangle navInterlock;
		private NxtControl.GuiFramework.Rectangle navAlarm;
		private NxtControl.GuiFramework.Rectangle navPermissive;
		private NxtControl.GuiFramework.Rectangle navTrend;
		private SE.Agile.Symbols.HMI_Control_Integer_v1_0.sValChanged CMODE;
		private SE.Agile.Symbols.HMI_Control_Bool_v1_0.sButtonValSet symBtnCFLRST;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IRSTPERM;
		private SE.Agile.Symbols.Broadcaster_v1_0.sButtonNavProgram navPrograms;
		private NxtControl.GuiFramework.Rectangle navAlarmActive;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IA;
		private NxtControl.GuiFramework.Rectangle navData2;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed symIIOFL;
		#endregion
	}
}
