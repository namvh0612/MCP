/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 5/24/2026
 * Time: 1:55 AM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using NxtControl.GuiFramework;

namespace SE.Agile.Faceplates.acFixedSpeedMotor_v1_0
{
	/// <summary>
	/// Summary description for fCounter.
	/// </summary>
	partial class fCounters
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.AssetName = new System.HMI.Symbols.Base.Execute<string>();
			this.symVSCTOT = new SE.Agile.Symbols.VSC_v1_0.sVSC();
			// 
			// AssetName
			// 
			this.AssetName.BeginInit();
			this.AssetName.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.AssetName.IsOnlyInput = true;
			this.AssetName.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.AssetName.Name = "AssetName";
			this.AssetName.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.AssetName.TagName = "AssetName";
			this.AssetName.Value = null;
			this.AssetName.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.AssetNameValueChanged);
			this.AssetName.EndInit();
			// 
			// symVSCTOT
			// 
			this.symVSCTOT.BeginInit();
			this.symVSCTOT.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -32D, 8D);
			this.symVSCTOT.Name = "symVSCTOT";
			this.symVSCTOT.SecurityToken = ((uint)(4294967295u));
			this.symVSCTOT.TagName = "Equipment.VSCTOT";
			this.symVSCTOT.EndInit();
			// 
			// fCounters
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(280D)), ((float)(112D)));
			this.Brush = new NxtControl.Drawing.Brush("FaceplateBrush");
			this.FaceplateClose = NxtControl.GuiFramework.CloseFaceplateBehavior.Automatic;
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.AssetName,
			this.symVSCTOT});
			this.Size = new System.Drawing.Size(280, 112);

		}
		private System.HMI.Symbols.Base.Execute<string> AssetName;
		private SE.Agile.Symbols.VSC_v1_0.sVSC symVSCTOT;
		#endregion
	}
}
