using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region ListenerVariableSpeedMotor_v1_1_HMI;
#endregion ListenerVariableSpeedMotor_v1_1_HMI;

#endregion Definitions;

