using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region ASC_v1_0_HMI;
#endregion ASC_v1_0_HMI;

#endregion Definitions;

