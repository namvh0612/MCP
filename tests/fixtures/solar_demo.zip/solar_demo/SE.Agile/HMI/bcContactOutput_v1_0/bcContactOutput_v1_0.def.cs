using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region bcContactOutput_v1_0_HMI;

namespace SE.Agile.Symbols.bcContactOutput_v1_0
{
  partial class sContactOutput
  {

    private SE.Agile.Faceplates.bcContactOutput_v1_0.fMain fMain
    {
      get
      { 
        if (IsOpenFaceplateSecure() == false)
          return null;

        SE.Agile.Faceplates.bcContactOutput_v1_0.fMain faceplate = null;
        
        IHMIManagementService hmiManagementService = (IHMIManagementService)ServiceProvider.GetService(typeof(IHMIManagementService));
        if (hmiManagementService != null)
          faceplate = (SE.Agile.Faceplates.bcContactOutput_v1_0.fMain)hmiManagementService.GetRegisteredHMIFaceplate(MapPath, typeof(SE.Agile.Faceplates.bcContactOutput_v1_0.fMain));
        
        if (faceplate == null)
        {
          faceplate = new SE.Agile.Faceplates.bcContactOutput_v1_0.fMain();

          faceplate.SetConnectionInfo(this.TagName, this.SymbolPath, this.ChannelId, GetType());

          if (hmiManagementService != null)
            hmiManagementService.RegisterHMIFaceplate(faceplate);
        }
        return faceplate;
      }
    }
     
    protected override void DoOpenFaceplate(OpenFaceplate openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == (string)openFaceplate.FaceplateType)
        hmiFaceplate = fMain;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

    public override void DoOpenFaceplate(string openFaceplate)
    {
      NxtControl.GuiFramework.HMIFaceplate hmiFaceplate = null;

      if ("fMain" == openFaceplate)
        hmiFaceplate = fMain;

      if (hmiFaceplate != null)
      {
        if (hmiFaceplate.Initialized == true)
          hmiFaceplate.Activate();
        else
        {
          OnInitializeFaceplate(hmiFaceplate);
          hmiFaceplate.Show(this);
        }
      }
    }

  }
}
#endregion bcContactOutput_v1_0_HMI;

#endregion Definitions;

