/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 9/18/2025
 * Time: 6:16 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;
using NxtControl.GuiFramework;

namespace SE.Agile.Faceplates.bcContactOutput_v1_0
{
	/// <summary>
	/// Summary description for fMain.
	/// </summary>
	partial class fMain
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fMain));
			this.AssetName = new System.HMI.Symbols.Base.Execute<string>();
			this.navParameters = new NxtControl.GuiFramework.Rectangle();
			this.navData = new NxtControl.GuiFramework.Rectangle();
			this.navInterlock = new NxtControl.GuiFramework.Rectangle();
			this.navAlarm = new NxtControl.GuiFramework.Rectangle();
			this.navPermissive = new NxtControl.GuiFramework.Rectangle();
			this.navTrend = new NxtControl.GuiFramework.Rectangle();
			this.symIE = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed();
			this.symIAOK = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed();
			this.symIPI = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed();
			this.symBtnCME = new SE.Agile.Symbols.HMI_Control_Bool_v1_0.sButtonVert2();
			this.symMode = new SE.Agile.Symbols.ModeSelector_v1_0.sModeNamedMiddle();
			this.Mode = new SE.Agile.Symbols.ModeSelector_v1_0.sButtonQuad();
			this.CMODE = new SE.Agile.Symbols.HMI_Control_Integer_v1_0.sValChanged();
			// 
			// AssetName
			// 
			this.AssetName.BeginInit();
			this.AssetName.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.AssetName.IsOnlyInput = true;
			this.AssetName.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.AssetName.Name = "AssetName";
			this.AssetName.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.AssetName.TagName = "AssetName";
			this.AssetName.Value = null;
			this.AssetName.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.AssetNameValueChanged);
			this.AssetName.EndInit();
			// 
			// navParameters
			// 
			this.navParameters.Bounds = new NxtControl.Drawing.RectF(((float)(232D)), ((float)(0D)), ((float)(24D)), ((float)(24D)));
			this.navParameters.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.navParameters.ImageBytes = resources.GetString("navParameters.ImageBytes");
			this.navParameters.Name = "navParameters";
			this.navParameters.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fParameters", NxtControl.GuiFramework.MouseButtonType.Click));
			// 
			// navData
			// 
			this.navData.Bounds = new NxtControl.Drawing.RectF(((float)(232D)), ((float)(24D)), ((float)(24D)), ((float)(24D)));
			this.navData.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.navData.ImageBytes = resources.GetString("navData.ImageBytes");
			this.navData.Name = "navData";
			// 
			// navInterlock
			// 
			this.navInterlock.Bounds = new NxtControl.Drawing.RectF(((float)(232D)), ((float)(48D)), ((float)(24D)), ((float)(24D)));
			this.navInterlock.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.navInterlock.ImageBytes = resources.GetString("navInterlock.ImageBytes");
			this.navInterlock.Name = "navInterlock";
			// 
			// navAlarm
			// 
			this.navAlarm.Bounds = new NxtControl.Drawing.RectF(((float)(232D)), ((float)(72D)), ((float)(24D)), ((float)(24D)));
			this.navAlarm.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.navAlarm.ImageBytes = resources.GetString("navAlarm.ImageBytes");
			this.navAlarm.Name = "navAlarm";
			// 
			// navPermissive
			// 
			this.navPermissive.Bounds = new NxtControl.Drawing.RectF(((float)(232D)), ((float)(96D)), ((float)(24D)), ((float)(24D)));
			this.navPermissive.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.navPermissive.ImageBytes = resources.GetString("navPermissive.ImageBytes");
			this.navPermissive.Name = "navPermissive";
			// 
			// navTrend
			// 
			this.navTrend.Bounds = new NxtControl.Drawing.RectF(((float)(232D)), ((float)(120D)), ((float)(24D)), ((float)(24D)));
			this.navTrend.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.navTrend.ImageBytes = resources.GetString("navTrend.ImageBytes");
			this.navTrend.Name = "navTrend";
			// 
			// symIE
			// 
			this.symIE.BeginInit();
			this.symIE.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -32D, 40D);
			this.symIE.LabelText = "Status:";
			this.symIE.Name = "symIE";
			this.symIE.OffText = "De-Energised";
			this.symIE.OnText = "Energised";
			this.symIE.SecurityToken = ((uint)(4294967295u));
			this.symIE.TagName = "IE";
			this.symIE.EndInit();
			// 
			// symIAOK
			// 
			this.symIAOK.BeginInit();
			this.symIAOK.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -32D, 64D);
			this.symIAOK.LabelText = "Available in Auto:";
			this.symIAOK.Name = "symIAOK";
			this.symIAOK.OffText = "No";
			this.symIAOK.OnText = "Yes";
			this.symIAOK.SecurityToken = ((uint)(4294967295u));
			this.symIAOK.TagName = "IAOK";
			this.symIAOK.EndInit();
			// 
			// symIPI
			// 
			this.symIPI.BeginInit();
			this.symIPI.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -32D, 88D);
			this.symIPI.LabelText = "Process Interlock:";
			this.symIPI.Name = "symIPI";
			this.symIPI.OffText = "Inactive";
			this.symIPI.OnText = "Active";
			this.symIPI.SecurityToken = ((uint)(4294967295u));
			this.symIPI.TagName = "IPI";
			this.symIPI.EndInit();
			// 
			// symBtnCME
			// 
			this.symBtnCME.BeginInit();
			this.symBtnCME.ButtonDisableText = "Off";
			this.symBtnCME.ButtonEnableText = "On";
			this.symBtnCME.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 16D, 120D);
			this.symBtnCME.Enabled = false;
			this.symBtnCME.Name = "symBtnCME";
			this.symBtnCME.SecurityToken = ((uint)(4294967295u));
			this.symBtnCME.TagName = "CME";
			this.symBtnCME.EndInit();
			// 
			// symMode
			// 
			this.symMode.BeginInit();
			this.symMode.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, -32D, 16D);
			this.symMode.LabelText = "Mode:";
			this.symMode.Name = "symMode";
			this.symMode.SecurityToken = ((uint)(4294967295u));
			this.symMode.TagName = "Mode";
			this.symMode.EndInit();
			// 
			// Mode
			// 
			this.Mode.BeginInit();
			this.Mode.ButtonTextDisabledColor = new NxtControl.Drawing.Color("ButtonTextDisabledColor");
			this.Mode.ButtonToggleOnBrush = new NxtControl.Drawing.Brush("ButtonBrush");
			this.Mode.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 88D, 120D);
			this.Mode.Name = "Mode";
			this.Mode.SecurityToken = ((uint)(4294967295u));
			this.Mode.TagName = "Mode";
			this.Mode.EndInit();
			// 
			// CMODE
			// 
			this.CMODE.BeginInit();
			this.CMODE.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 5D, 10D);
			this.CMODE.Name = "CMODE";
			this.CMODE.SecurityToken = ((uint)(4294967295u));
			this.CMODE.TagName = "Mode.CMODE";
			this.CMODE.Val = ((short)(0));
			this.CMODE.ValMaximum = ((short)(0));
			this.CMODE.ValMinimum = ((short)(0));
			this.CMODE.ValUnits = null;
			this.CMODE.EndInit();
			// 
			// fMain
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(260D)), ((float)(192D)));
			this.Brush = new NxtControl.Drawing.Brush("FaceplateBrush");
			this.FaceplateClose = NxtControl.GuiFramework.CloseFaceplateBehavior.Automatic;
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.AssetName,
			this.navParameters,
			this.navData,
			this.navInterlock,
			this.navAlarm,
			this.navPermissive,
			this.navTrend,
			this.symIE,
			this.symIAOK,
			this.symIPI,
			this.symBtnCME,
			this.symMode,
			this.Mode,
			this.CMODE});
			this.Size = new System.Drawing.Size(260, 192);

		}
		private System.HMI.Symbols.Base.Execute<string> AssetName;
		private NxtControl.GuiFramework.Rectangle navParameters;
		private NxtControl.GuiFramework.Rectangle navData;
		private NxtControl.GuiFramework.Rectangle navInterlock;
		private NxtControl.GuiFramework.Rectangle navAlarm;
		private NxtControl.GuiFramework.Rectangle navPermissive;
		private NxtControl.GuiFramework.Rectangle navTrend;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed symIE;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed symIAOK;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValueTextMiddleNamed symIPI;
		private SE.Agile.Symbols.HMI_Control_Bool_v1_0.sButtonVert2 symBtnCME;
		private SE.Agile.Symbols.ModeSelector_v1_0.sModeNamedMiddle symMode;
		private SE.Agile.Symbols.ModeSelector_v1_0.sButtonQuad Mode;
		private SE.Agile.Symbols.HMI_Control_Integer_v1_0.sValChanged CMODE;
		#endregion
	}
}
