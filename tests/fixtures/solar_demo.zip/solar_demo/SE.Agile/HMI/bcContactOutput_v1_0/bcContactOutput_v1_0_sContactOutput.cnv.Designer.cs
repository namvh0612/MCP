/*
 * Created by EcoStruxure Automation Expert.
 * User: sclark
 * Date: 12/9/2024
 * Time: 9:22 AM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.bcContactOutput_v1_0
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sContactOutput
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(sContactOutput));
			this.alarmFrame = new NxtControl.GuiFramework.AlarmFrame();
			this.AssetName = new System.HMI.Symbols.Base.Execute<string>();
			this.txtAssetName = new NxtControl.GuiFramework.Label();
			this.COutBase = new NxtControl.GuiFramework.Ellipse();
			this.COutBody = new NxtControl.GuiFramework.Ellipse();
			this.IE = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			this.txtMode = new SE.Agile.Symbols.ModeSelector_v1_0.sModeIcon();
			this.interlocked = new NxtControl.GuiFramework.Rectangle();
			this.IPI = new SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged();
			((System.ComponentModel.ISupportInitialize)(this.alarmFrame)).BeginInit();
			// 
			// alarmFrame
			// 
			this.alarmFrame.Bounds = new NxtControl.Drawing.RectF(((float)(40D)), ((float)(32D)), ((float)(40D)), ((float)(20D)));
			this.alarmFrame.FrameWidth = ((uint)(2u));
			this.alarmFrame.Name = "alarmFrame";
			this.alarmFrame.Radius = 5D;
			// 
			// AssetName
			// 
			this.AssetName.BeginInit();
			this.AssetName.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.AssetName.IsOnlyInput = true;
			this.AssetName.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.AssetName.Name = "AssetName";
			this.AssetName.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.AssetName.TagName = "AssetName";
			this.AssetName.Value = null;
			this.AssetName.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.AssetNameValueChanged);
			this.AssetName.EndInit();
			// 
			// txtAssetName
			// 
			this.txtAssetName.AngleIgnore = true;
			this.txtAssetName.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtAssetName.Bounds = new NxtControl.Drawing.RectF(((float)(29D)), ((float)(51D)), ((float)(62D)), ((float)(20D)));
			this.txtAssetName.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtAssetName.Font = new NxtControl.Drawing.Font("LabelFont");
			this.txtAssetName.FontScale = true;
			this.txtAssetName.Name = "txtAssetName";
			this.txtAssetName.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtAssetName.Text = "Name";
			this.txtAssetName.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleCenter;
			this.txtAssetName.TextAutoSize = true;
			this.txtAssetName.TextAutoSizeHorizontalOffset = 10;
			this.txtAssetName.TextColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.txtAssetName.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// COutBase
			// 
			this.COutBase.Bounds = new NxtControl.Drawing.RectF(((float)(52D)), ((float)(34D)), ((float)(16D)), ((float)(16D)));
			this.COutBase.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.COutBase.Name = "COutBase";
			// 
			// COutBody
			// 
			this.COutBody.Bounds = new NxtControl.Drawing.RectF(((float)(55D)), ((float)(37D)), ((float)(10D)), ((float)(10D)));
			this.COutBody.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.COutBody.Name = "COutBody";
			this.COutBody.OpenFaceplates.Add(new NxtControl.GuiFramework.OpenFaceplate("fMain", NxtControl.GuiFramework.MouseButtonType.Click));
			// 
			// IE
			// 
			this.IE.BeginInit();
			this.IE.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 30D, 12D);
			this.IE.Name = "IE";
			this.IE.SecurityToken = ((uint)(4294967295u));
			this.IE.TagName = "IE";
			this.IE.Val = false;
			this.IE.EndInit();
			// 
			// txtMode
			// 
			this.txtMode.BeginInit();
			this.txtMode.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 26D, 11D);
			this.txtMode.Name = "txtMode";
			this.txtMode.SecurityToken = ((uint)(4294967295u));
			this.txtMode.TagName = "Equipment.Mode";
			this.txtMode.EndInit();
			// 
			// interlocked
			// 
			this.interlocked.Bounds = new NxtControl.Drawing.RectF(((float)(71D)), ((float)(35D)), ((float)(14D)), ((float)(14D)));
			this.interlocked.Brush = new NxtControl.Drawing.Brush(true);
			this.interlocked.Font = new NxtControl.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular);
			this.interlocked.ImageBytes = resources.GetString("interlocked.ImageBytes");
			this.interlocked.Name = "interlocked";
			this.interlocked.Pen = new NxtControl.Drawing.Pen("Transparent");
			// 
			// IPI
			// 
			this.IPI.BeginInit();
			this.IPI.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 23D, 42D);
			this.IPI.Name = "IPI";
			this.IPI.SecurityToken = ((uint)(4294967295u));
			this.IPI.TagName = "IPI";
			this.IPI.Val = false;
			this.IPI.EndInit();
			// 
			// sContactOutput
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.alarmFrame,
			this.AssetName,
			this.txtAssetName,
			this.COutBase,
			this.COutBody,
			this.IE,
			this.txtMode,
			this.interlocked,
			this.IPI});
			this.SymbolSize = new System.Drawing.Size(120, 88);
			((System.ComponentModel.ISupportInitialize)(this.alarmFrame)).EndInit();

		}
		private NxtControl.GuiFramework.AlarmFrame alarmFrame;
		private NxtControl.GuiFramework.Label txtAssetName;
		private System.HMI.Symbols.Base.Execute<string> AssetName;
		private SE.Agile.Symbols.ModeSelector_v1_0.sModeIcon txtMode;
		private NxtControl.GuiFramework.Ellipse COutBase;
		private NxtControl.GuiFramework.Ellipse COutBody;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IE;
		private NxtControl.GuiFramework.Rectangle interlocked;
		private SE.Agile.Symbols.HMI_Indication_Bool_v1_0.sValChanged IPI;
		#endregion
	}
}
