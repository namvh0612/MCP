/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 9/18/2025
 * Time: 6:16 PM
 * 
 */

using System;
using NxtControl.GuiFramework;

namespace SE.Agile.Faceplates.bcContactOutput_v1_0
{
	/// <summary>
	/// Description of fMain.
	/// </summary>
	public partial class fMain : NxtControl.GuiFramework.HMIFaceplate
	{
		private int _CMODE;
		
		public fMain()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			CMODE.OnValChanged += OnSubCatValueChanged;
		}

		void AssetNameValueChanged(object sender, ValueChangedEventArgs e)
		{
			Title = (string)e.Value;
		}

		// EXECUTE logic triggered by child value change
	    private void OnSubCatValueChanged(object sender, EventArgs e)
	    {
			if (_CMODE != CMODE.Val)
			{
				symBtnCME.Enabled = (CMODE.Val == 3);
			}
			
			_CMODE = CMODE.Val;
		}
	}
}
