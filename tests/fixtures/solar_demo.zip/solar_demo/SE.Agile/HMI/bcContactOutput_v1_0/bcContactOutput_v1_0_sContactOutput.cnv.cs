/*
 * Created by EcoStruxure Automation Expert.
 * User: sclark
 * Date: 12/9/2024
 * Time: 9:22 AM
 * 
 */

using System;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.bcContactOutput_v1_0
{
	/// <summary>
	/// Description of sDefault.
	/// </summary>
	public partial class sContactOutput : NxtControl.GuiFramework.HMISymbol
	{
		private bool _IE;
		private bool _IPI;
		
		private NxtControl.Drawing.Brush _brushOn = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(255)), ((byte)(255)), ((byte)(255))));
		private NxtControl.Drawing.Brush _brushOff = new NxtControl.Drawing.Brush(new NxtControl.Drawing.Color(((byte)(114)), ((byte)(110)), ((byte)(106))));
		
		public sContactOutput()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();

			COutBody.Brush = _brushOff;
			
			IE.OnValChanged += OnSubCatValueChanged;
			IPI.OnValChanged += OnSubCatValueChanged;
		}

		void AssetNameValueChanged(object sender, ValueChangedEventArgs e)
		{
			txtAssetName.Text = e.Value.ToString();	
			
			interlocked.Visible = _IPI;
		}
	
		// EXECUTE logic triggered by child value change
	    private void OnSubCatValueChanged(object sender, EventArgs e)
	    {
	    	if (IE.Val != _IE)
	    	{
				if (IE.Val)
				{
					COutBody.Brush = _brushOn;
				}
				else
				{
					COutBody.Brush = _brushOff;
				}
	    	}

	    	if (IPI.Val != _IPI)
	    	{
	    		interlocked.Visible = IPI.Val;
	    	}
	    	
			_IE = IE.Val;
			_IPI = IPI.Val;
		}
	}
}
