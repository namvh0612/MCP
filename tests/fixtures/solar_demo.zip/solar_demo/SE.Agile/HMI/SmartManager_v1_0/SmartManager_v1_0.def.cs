using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region SmartManager_v1_0_HMI;
#endregion SmartManager_v1_0_HMI;

#endregion Definitions;

