/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/16/2025
 * Time: 9:15 PM
 * 
 */

using System;
using System.Text.Json;
using System.Collections.Generic;
using NxtControl.GuiFramework;
using System.Linq;

// GPA specific
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;


namespace SE.Agile.Symbols.SmartManager_v1_0
{
    /// <summary>
    /// Description of sDefault.
    /// </summary>
    public partial class sDefault : NxtControl.GuiFramework.HMISymbol
    {
        Dictionary<string, Dictionary<string, PointDetails>> dictionary = new Dictionary<string, Dictionary<string, PointDetails>>();
        Dictionary<string, ModulesDetails> modules = new Dictionary<string, ModulesDetails>();

        Dictionary<int, SmartElement> smartElementsById = new Dictionary<int, SmartElement>();
        Dictionary<string, SmartElement> smartElementsByName = new Dictionary<string, SmartElement>();

        Dictionary<string, PointDetails> opcTags = new Dictionary<string, PointDetails>();	// Tags from csv defined as OPC points
        Dictionary<string, PointDetails> pointerTags = new Dictionary<string, PointDetails>();  // Tags from csv defined as pointers (i.e. Symlinks associated with a Module Channel)
        Dictionary<string, PointDetails> symTags = new Dictionary<string, PointDetails>(); // Tags from csv but not currently used (requires method to verify symlink exists online)
        Dictionary<string, string> opcvalues = new Dictionary<string, string>(); //hack - need to create a proper list of delta values not in a seperate dict
        Dictionary<string, string> pointerToChannel = new Dictionary<string, string>();
        Dictionary<string, string> channelToPointer = new Dictionary<string, string>();
        Dictionary<string, DeltaValues> deltaDict = new Dictionary<string, DeltaValues>();

        string payload = string.Empty;
        List<LogEntry> logMessages = new List<LogEntry>();
        bool applyReady = false;
        bool connected = false;
        string resourcePrefix = string.Empty;
        JsonValues jsonValues = new JsonValues();
        List<string> chunks = new List<string>();
        int sentChunks = 0;
        const string tokenSymlink = "SYMLINK";
        bool sending = false;

        string connectionStatus = string.Empty;
        string opcPrefix = string.Empty;

        bool loading = false;


        SmartElement se; // Handle to the smart element that is waiting CONF_EMPTY or PARAM events - set by fetchParameters()
        PointDetails activeTag;

        int readCount; // Tracks the number of pages received from the Basic block GET_GRAPH request
        List<int> fetchList = new List<int>(); // List of registered items to iterate through during proxy read operation
        List<PointDetails> opcTagFetchList = new List<PointDetails>();  // List of opc tags to iterate through during OPC read operation

        public sDefault()
        {
            //
            // The InitializeComponent() call is required for Windows Forms designer support.
            //
            InitializeComponent();
            this.CNF_END_Fired += CNF_END_Fired_EventHandler;			// JSON Parser has completed processing the chunk
            this.END_CNF_Fired += END_CNF_Fired_EventHandler;			// Element array JSON Builder has sent a JSON string [Payload] (page of elements)
            this.CONF_EMPTY_Fired += CONF_EMPTY_Fired_EventHandler;     // CONF-CONFO trigger returns no parameters for the smart element
            this.PARAM_Fired += PARAM_Fired_EventHandler;               // Parameter array JSON Builder has sent a JSON string [Parameters] (parameter key, value/datatype)
            this.OPC_READ_Fired += OPC_READ_Fired_EventHandler;         // OPC read with value - OpcValue
            this.OPC_ERROR_Fired += OPC_ERROR_Fired_EventHandler;       // OPC read error - tag not found most likely - could consider returning the error number

            dataGridViewLog.Columns.Add("Level", "Level");
            dataGridViewLog.Columns.Add("Message", "Message");
            dataGridViewLog.Columns[0].Width = 60;
            dataGridViewLog.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewLog.RowHeadersVisible = false;
            dataGridViewLog.AllowUserToAddRows = false;
            dataGridViewLog.ReadOnly = true;
            dataGridViewLog.CellBorderStyle = DataGridViewCellBorderStyle.None;
            dataGridViewLog.GridColor = new NxtControl.Drawing.Color("White"); // Optional, just in case
            dataGridViewLog.BackgroundColor = new NxtControl.Drawing.Color("White");
            dataGridViewLog.RowTemplate.Height = 18; // Set a smaller height
            dataGridViewLog.DefaultCellStyle.Padding = new Padding(0); // Remove padding
            dataGridViewLog.EnableHeadersVisualStyles = false;
            dataGridViewLog.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridViewLog.AllowUserToResizeColumns = false;
            dataGridViewLog.AllowUserToResizeRows = false;
            dataGridViewLog.AllowUserToOrderColumns = false;
            dataGridViewLog.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.REQ_OPCCONNECT_Fired += REQ_OPCCONNECT_Fired_EventHandler;

        }

        void Res_1ValueChanged(object sender, ValueChangedEventArgs e)
        {
            resourcePrefix = (string)e.Value;
        }

        void CNF_END_Fired_EventHandler(object sender, CNF_ENDEventArgs e)
        {
            if (chunks.Count > sentChunks)
            {
                FireEvent_CNF(chunks[sentChunks]);
                sentChunks++;
            }
            else
            {
                FireEvent_VALUES_SET();
                if (sending)
                {
                    Load();
                    sending = false;
                }
            }
        }

        void Load()
        {
            applyReady = false;
            loading = true;
            logMessages.Clear();
            dictionary.Clear();
            modules.Clear();
            payload = string.Empty;
            chunks = new List<string>();
            sentChunks = 0;
            drawnButtonPreview.Enabled = false;
            drawnButtonCNF.Enabled = false;

            smartElementsById.Clear();
            smartElementsByName.Clear();
            opcTags.Clear();
            pointerTags.Clear();
            symTags.Clear();

            if (string.IsNullOrEmpty(resourcePrefix))
            {
                Log($"No resource prefix loaded for input 'Res'", LogLevel.Error);
                applyReady = !CheckLogForError();
                return;
            }


            // Load the list of modules and tags from the csv import.
            if (LoadLookup(drawnTextBoxDictionary.Text) && LoadModules(drawnTextBoxModules.Text) && LoadRat(drawnTextBoxRatData.Text))
            {
                foreach (ModulesDetails module in modules.Values)
                {
                    if (dictionary.ContainsKey(module.PointType))
                    {
                        if (!dictionary[module.PointType].ContainsKey("SYMLINK"))
                            continue;
                    }

                    if (!dictionary.ContainsKey(module.PointType))
                    {
                        Log($"Dictionary key not provided for : {module.PointType} - {module.Tag}", LogLevel.Warning);
                        continue;
                    }

                    var pd = new PointDetails()
                    {
                        dst = $"{module.Id}.CH{module.ChannelNo.PadLeft(2, '0')}",
                        v = $"{resourcePrefix}.{ToSafeName(module.Tag)}{dictionary[module.PointType][tokenSymlink].dst}",
                        dt = (int)DataType.STRING,
                        method = (int)CommunicationMethod.POINTER,
                    };

                    pointerTags.Add(pd.dst, pd);

                    if (!module.RAT)
                    {
                        Log($"No RAT data found for module: {module.Tag}", LogLevel.Warning);
                    }
                }
            }

            readCount = 0;
            FireEvent_GET_GRAPH(0);  // Send a request to the SmartManager Basic block to start paging SmartElements from index 0 - END_CNF is triggered on receipt of each page			
        }

        void LoadCsv(object sender, EventArgs e)
        {
            Load();
        }

        void END_CNF_Fired_EventHandler(object sender, END_CNFEventArgs e)
        {
            if (!loading)
                return;

            string[] result = JsonSerializer.Deserialize<string[]>(e.Payload);

            for (int i = 0; i < result.Length - 1; i += 2)
            {
                string[] elements = result[i].Split(',');
                int id = -1;
                int type = -1;
                int a = -1;
                int b = -1;
                int c = -1;

                int.TryParse(elements[0], out id);
                int.TryParse(elements[1], out type);
                int.TryParse(elements[2], out a);
                int.TryParse(elements[3], out b);
                int.TryParse(elements[4], out c);


                var smartelement = new SmartElement
                {
                    Id = id,
                    Name = result[i + 1],
                    NodeType = type,
                    Connections = new int[] { a, b, c }
                };

                smartElementsById[smartelement.Id] = smartelement; // Overwrites if key already exists
                smartElementsByName[smartelement.Name] = smartelement; // Overwrites if key already exists
            }


            if (smartElementsById.Count < e.Size && readCount < 100)
            {
                // Request the next page of values from the basic block array
                readCount++;
                FireEvent_GET_GRAPH((short)smartElementsById.Count);
            }
            else
            {
                // All values read from the basic block array - check for required io modules
                if (smartElementsById.Count > 0)
                {
                    GetModuleOnlineValues();
                }
            }
        }

        void GetModuleOnlineValues()
        {
            // Fetch all modules as a module assignment may result in a move from a module not referenced by the import list
            foreach (SmartElement element in smartElementsByName.Values)
            {
                if (element.NodeType > 100 && element.NodeType < 110) // Assumed range for I/O module class id
                {
                    fetchList.Add(element.Id); // Add the modules element id to the parameter fetch list
                }
            }

            foreach (ModulesDetails module in modules.Values)
            {
                if (!smartElementsByName.ContainsKey(module.Id))
                {
                    Log($"Module not registered online: {module.Id} ({module.ChannelNo})", LogLevel.Error);
                }
            }

            pointerToChannel.Clear();
            channelToPointer.Clear();

            fetchParameters();	// Recursively fetch the parameters for elements in the fetch list - returns CONF_EMPTY or PARAM input events
        }

        void CONF_EMPTY_Fired_EventHandler(object sender, CONF_EMPTYEventArgs e)
        {
            if (!loading)
                return;

            // Incoming Parameter JSON Payload - CONF_EMPTY is triggered when no configuration parameters are returned by CONFO
            if (se != null)
            {
                se.Parameters.Clear();  // Clear the current paramter settings in preparation for the CONF_EMPTY or PARAM return event
                fetchParameters();      // progress to the next item in the fetch list
            }
        }

        void fetchParameters()
        {
            if (fetchList.Count > 0)
            {
                var id = fetchList[0];
                se = smartElementsById[id];
                FireEvent_GET_CONFIG($"SmartId{id}"); // Expected to return CONF_EMPTY or PARAM (with Parameters) input events
                fetchList.RemoveAt(0);
                double percentComplete = ((double)(modules.Count - fetchList.Count) / modules.Count) * 100;
                freeTextFetchProgress.Text = $"Uploading modules {percentComplete:F1}% complete";
            }
            else
            {
                freeTextFetchProgress.Text = $"Modules done";
                activeTag = new PointDetails(); // Clear the active tag

                // Parameters done - next step: Get the OPC online values
                foreach (var tag in opcTags.Values)
                {
                    opcTagFetchList.Add(tag);
                }
                ReadOpcOnlineValues();
            }
        }

        void ReadOpcOnlineValues()
        {
            if (!loading)
                return;

            deltaDict.Clear();

            if (opcTagFetchList.Count > 0)
            {
                activeTag = opcTagFetchList[0];
                string opcTag = $"{opcPrefix}{activeTag.dst}";

                switch (activeTag.dt)
                {
                    case (int)DataType.BOOL:
                        FireEvent_OPC_BOOL(opcTag);
                        break;
                    case (int)DataType.INT:
                        FireEvent_OPC_INT(opcTag);
                        break;
                    case (int)DataType.REAL:
                        FireEvent_OPC_REAL(opcTag);
                        break;
                    case (int)DataType.DINT:
                        FireEvent_OPC_DINT(opcTag);
                        break;
                    case (int)DataType.STRING:
                        FireEvent_OPC_STRING(opcTag);
                        break;

                    default:
                        Log($"Module not registered online: {activeTag.dst} unhandled OPC datatype {activeTag.dt}", LogLevel.Error);
                        break;
                }

                double percentComplete = ((double)(opcTags.Count - opcTagFetchList.Count) / opcTags.Count) * 100;
                freeTextFetchProgress.Text = $"Reading OPC values {percentComplete:F1}% complete";
            }
            else
            {
                freeTextFetchProgress.Text = $"Upload complete";

                // Add the pointers to the output list
                foreach (PointDetails pd in pointerTags.Values)
                {
                    string val = string.Empty;
                    string status = string.Empty;
                    bool error = false;
                    bool modified = false;

                    if (!smartElementsByName.ContainsKey(pd.dst.Split('.')[0]))
                    {
                        error = true;
                        status = "Module not found";
                    }

                    if (pointerToChannel.ContainsKey(pd.v))
                    {
                        var previousAssignment = pointerToChannel[pd.v];

                        if (pd.dst != previousAssignment)
                        {
                            status = $"Moved from {previousAssignment}";
                            modified = true;

                            // Clear previous position if the position is not being assigned a new value in the current import
                            if (!deltaDict.ContainsKey(previousAssignment))
                            {
                                deltaDict[previousAssignment] = new DeltaValues { Tagname = previousAssignment, Value = "", DataType = pd.dt, Type = pd.method, CurrentValue = pd.v, Status = $"Moved to {pd.dst}", Modified = modified };
                            }
                        }
                    }
                    else
                    {
                        if (!error)
                        {
                            status = $"New assignment";
                            modified = true;
                        }
                    }

                    deltaDict[pd.dst] = new DeltaValues { Tagname = pd.dst, Value = pd.v, DataType = pd.dt, Type = pd.method, CurrentValue = val, Status = status, Error = error, Modified = modified };
                }

                // Add the OPC values to the change list
                foreach (PointDetails pd in opcTags.Values)
                {
                    string val = string.Empty;
                    string status = string.Empty;
                    bool error = false;
                    bool modified = false;

                    if (opcvalues.ContainsKey(pd.dst))
                    {
                        val = opcvalues[pd.dst];
                        if (val != pd.v)
                        {
                            status = $"Modified";
                            modified = true;
                        }
                    }
                    else
                    {
                        error = true;
                        status = "Value not found";
                    }

                    deltaDict[pd.dst] = new DeltaValues { Tagname = pd.dst, Value = pd.v, DataType = pd.dt, Type = pd.method, CurrentValue = val, Status = status, Error = error, Modified = modified };
                }

                applyReady = !CheckLogForError();
                drawnButtonCNF.Enabled = true; //applyReady && connected;

                drawnButtonPreview.Enabled = true;
                loading = false;
            }
        }

        void PreviewPayload(object sender, EventArgs e)
        {
            // Create a new form
            var gridForm2 = new Form
            {
                Text = "Preview",
                Width = 800,
                Height = 400,
                StartPosition = FormStartPosition.CenterParent,
                ShowIcon = false
            };

            // Create a DataGridView
            var dataGridView = new System.Windows.Forms.DataGridView
            {
                Dock = DockStyle.Fill,
                AutoGenerateColumns = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
            };


            // Define columns
            dataGridView.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Tagname", HeaderText = "Tagname" });
            dataGridView.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Value", HeaderText = "Imported value" });
            dataGridView.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "CurrentValue", HeaderText = "Online Value" });
            dataGridView.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Status", HeaderText = "Status" });
            dataGridView.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Modified", HeaderText = "Modified" });

            // Bind to DataGridView
            var bindingList = new BindingSource();
            bindingList.DataSource = new List<DeltaValues>(deltaDict.Values);
            dataGridView.DataSource = bindingList;


            // Handle row formatting
            dataGridView.RowPrePaint += (s, x) =>
            {
                var row = dataGridView.Rows[x.RowIndex];
                var data = row.DataBoundItem as DeltaValues;
                if (data != null && data.Error)
                {
                    row.DefaultCellStyle.ForeColor = new NxtControl.Drawing.Color("Red");
                }
            };

            // Add the grid to the form
            gridForm2.Controls.Add(dataGridView);

            // Show the form as a dialog
            gridForm2.ShowDialog();
        }

        void OPC_READ_Fired_EventHandler(object sender, OPC_READEventArgs e)
        {
            Log($"Error reading OPC value: {activeTag.dst} returned error {e.OpcValue}", LogLevel.Info);
            opcvalues[activeTag.dst] = e.OpcValue;
            opcTagFetchList.RemoveAt(0);
            ReadOpcOnlineValues();
        }

        void OPC_ERROR_Fired_EventHandler(object sender, OPC_ERROREventArgs e)
        {
            Log($"Error reading OPC value: {activeTag.dst} returned error {e.ErrorCode}", LogLevel.Error);
            opcTagFetchList.RemoveAt(0);
            ReadOpcOnlineValues();
        }

        void PARAM_Fired_EventHandler(object sender, PARAMEventArgs e)
        {
            // Incoming Parameter JSON Payload
            if (se != null && e.Parameters.Length > 0 && smartElementsById.Count > 0)
            {
                se.Parameters.Clear();

                string[] kvArray = JsonSerializer.Deserialize<string[]>((string)e.Parameters);
                for (int i = 0; i < kvArray.Length; i += 2)
                {
                    var pName = kvArray[i];
                    var pValue = kvArray[i + 1];

                    se.Parameters.Add(new Parameter
                    {
                        Name = pName,
                        Value = pValue
                    });

                    if (!string.IsNullOrEmpty(pValue))
                    {
                        if (pointerToChannel.ContainsKey(pValue))
                        {
                            Log($"Duplicate pointer value in runtime: {pValue} assigned to {pName} AND {pointerToChannel[pValue]}", LogLevel.Error);
                        }
                        else
                        {
                            pointerToChannel.Add(pValue, pName);
                        }

                        if (channelToPointer.ContainsKey(pName))
                        {
                            Log($"Duplicate channel value in runtime: {pValue} assigned to {pName} AND {pointerToChannel[pValue]}", LogLevel.Error);
                        }
                        else
                        {
                            channelToPointer.Add(pName, pValue);
                        }
                    }
                }

                fetchParameters();
            }
        }

        void Apply(object sender, EventArgs e)
        {
            // Add the modified values to the JSON array for serialisation
            var jsonValues = new JsonValues();
            jsonValues.values = new List<PointDetails>();

            foreach (DeltaValues dv in deltaDict.Values)
            {
                if (dv.Modified)
                {
                    PointDetails pd = new PointDetails()
                    {
                        dst = dv.Tagname,
                        dt = dv.DataType,
                        v = dv.Value,
                        method = dv.Type
                    };

                    jsonValues.values.Add(pd);
                }
            }

            sentChunks = 0;
            sending = true;

            chunks = SplitJsonPayload(jsonValues); // Split the JSON array into chunks to ensure the string size does not exceed the event buffer

            if (chunks.Count > sentChunks)
            {
                FireEvent_CNF(chunks[sentChunks]);  // Send the payload and wait for the CNF_Fired to proceed to the next chunk or end of stream
                sentChunks++;
            }
        }

        string GetSizeInBytes(string val)
        {
            string ret = string.Empty;
            int byteSize = Encoding.UTF8.GetByteCount(val);
            ret = $"{byteSize} bytes";
            return ret;
        }

        bool CheckFileAccess(string filename)
        {
            if (File.Exists(filename))
            {
                Log($"Using file: {filename}", LogLevel.Info);
            }
            else
            {
                Log($"File not found: {filename}", LogLevel.Error);
                return false;
            }

            try
            {
                using (var fs = new FileStream(filename, FileMode.Open, FileAccess.Read, FileShare.None))
                {
                    return true;
                }
            }
            catch (IOException ex)
            {
                Log($"File is currently in use or inaccessible: {filename}. Error: {ex.Message}", LogLevel.Error);
            }
            catch (UnauthorizedAccessException ex)
            {
                Log($"You do not have permission to access this file: {filename}. Error: {ex.Message}", LogLevel.Error);
            }
            catch (Exception ex)
            {
                Log($"An unexpected error occurred: {filename}. Error: {ex.Message}", LogLevel.Error);
            }

            return false;
        }

        bool LoadLookup(string filename)
        {
            if (!CheckFileAccess(filename))
                return false;

            var columnIndex = new Dictionary<string, int>();
            string[] expectedColumns = { "Point Type", "Cell Name", "Method", "DataType", "Destination" };
            var posPointType = -1;
            var posCellName = -1;
            var posMethod = -1;
            var posDataType = -1;
            var posDestination = -1;

            foreach (var line in File.ReadLines(filename))
            {
                if (line.Contains("Point Type,"))
                {
                    var columnNames = line.Split(',');
                    for (int i = 0; i < columnNames.Length; i++)
                    {
                        columnIndex[columnNames[i]] = i;
                    }

                    foreach (var column in expectedColumns)
                    {
                        if (!columnIndex.ContainsKey(column))
                        {
                            Log($"Dictionary missing required column: {column}", LogLevel.Warning);
                            return false;
                        }
                    }

                    // Access column indices by name
                    posPointType = columnIndex["Point Type"];
                    posCellName = columnIndex["Cell Name"];
                    posMethod = columnIndex["Method"];
                    posDataType = columnIndex["DataType"];
                    posDestination = columnIndex["Destination"];

                    continue; // Skip header
                }

                if (posPointType == -1)
                {
                    Log($"Invalid Dictionary file. Expecting header containing 'Point Type'", LogLevel.Error);
                    return false;
                }

                var parts = line.Split(',');

                if (parts.Length < 5) // Skip malformed lines
                {
                    if (parts.Length > 1)
                    {
                        Log($"Invalid dictionary entry: {line}", LogLevel.Error);
                    }
                    continue;
                }

                string pointType = parts[posPointType].Trim();
                string cellName = parts[posCellName].Trim();
                string method = parts[posMethod].Trim();
                string dataType = parts[posDataType].Trim();
                string destination = parts[posDestination].Trim();

                if (!dictionary.ContainsKey(pointType))
                    dictionary[pointType] = new Dictionary<string, PointDetails>();

                DataType dt = DataType.Unknown;
                CommunicationMethod communicationMethod = CommunicationMethod.Unknown;

                Enum.TryParse<DataType>(dataType, true, out dt);
                Enum.TryParse<CommunicationMethod>(method, true, out communicationMethod);

                var pd = new PointDetails
                {
                    method = (int)communicationMethod,
                    dt = (int)dt,
                    dst = destination
                };

                dictionary[pointType][cellName] = pd;
            }
            return true;
        }

        bool LoadModules(string filename)
        {
            if (!CheckFileAccess(filename))
                return false;

            foreach (var line in File.ReadLines(filename))
            {
                if (line.StartsWith("Tag Number", StringComparison.InvariantCulture))
                    continue; // Skip header

                var parts = line.Split(',');

                if (parts.Length < 13) continue; // Ensure enough columns

                var tag = parts[1].Trim(); // Tag column

                if (string.IsNullOrEmpty(tag)) continue;

                if (modules.ContainsKey(tag))
                    Log($"Multiple module entries found for : {tag}", LogLevel.Error);

                var module = new ModulesDetails
                {
                    Tag = tag,
                    TagNumber = parts[0].Trim(),
                    EndpointPackage = parts[2].Trim(),
                    Description = parts[3].Trim(),
                    PointType = parts[4].Trim(),
                    LogicDevice = parts[5].Trim(),
                    IOLocation = parts[6].Trim(),
                    Processor = parts[7].Trim(),
                    DropNo = parts[8].Trim(),
                    Rack = parts[9].Trim(),
                    LSlotNo = parts[10].Trim(),
                    ChannelNo = parts[11].Trim(),
                    FullDescription = parts[12].Trim()
                };

                module.Id = $"D{module.DropNo.PadLeft(2, '0')}R{module.Rack.PadLeft(2, '0')}S{module.LSlotNo.PadLeft(2, '0')}";
                modules[tag] = module;
            }
            return true;
        }

        bool LoadRat(string filename)
        {
            if (!CheckFileAccess(filename))
                return false;

            var rows = SanitiseCsv(filename);
            var lines = File.ReadAllLines(filename);

            if (rows.Count < 1)
            {
                Log($"Parameter file is empty or missing data: {filename}", LogLevel.Error);
                return false;
            }

            foreach (var row in rows)
            {
                if (row.ContainsKey("Source Tag"))
                {
                    //var sourceTag = row["Source Tag"];
                    var sourceTag = row["Alarm Tag"];

                    if (modules.ContainsKey(sourceTag))
                    {
                        var module = modules[sourceTag];

                        if (module.RAT)
                        {
                            Log($"Multiple RAT entries found for : {sourceTag}", LogLevel.Error);
                        }

                        module.RAT = true;
                        var parameters = module.Parameters;

                        foreach (var cell in row)
                        {
                            if (dictionary.ContainsKey(module.PointType))
                            {
                                if (!dictionary[module.PointType].ContainsKey(cell.Key))
                                {
                                    // Skip cell values where the cell header has not been included in the dictionary for the module type
                                    //Log($"Dictionary key not providedfor {module.Tag}. Type: {module.PointType} - {cell.Key}", LogLevel.Error);
                                    continue;
                                }
                            }
                            else
                            {
                                Log($"Dictionary key not provided for {module.Tag}. Type: {module.PointType}", LogLevel.Warning);
                                continue;
                            }

                            // Skip cell entries that conatain where the value is '-'
                            if (cell.Value != "-")
                            {
                                string rawValue = cell.Value;
                                object parsedValue = rawValue;

                                PointDetails pointDetails = dictionary[module.PointType][cell.Key];

                                if (rawValue.StartsWith("HOLD "))
                                {
                                    Log($"Skipping value {module.Tag}. Type: {rawValue}", LogLevel.Warning);
                                    continue;
                                }

                                try
                                {
                                    switch ((DataType)pointDetails.dt)
                                    {
                                        case DataType.BOOL:
                                            parsedValue = false;
                                            if (rawValue.Trim() == "1")
                                            {
                                                parsedValue = true;
                                            }
                                            else if (rawValue.Trim() == "0")
                                            {
                                                parsedValue = false;
                                            }
                                            else
                                            {
                                                parsedValue = bool.TryParse(rawValue, out var b) ? b : throw new FormatException();
                                            }
                                            break;
                                        case DataType.INT:
                                            parsedValue = int.TryParse(rawValue, out var i) ? i : throw new FormatException();
                                            break;
                                        case DataType.REAL:
                                            parsedValue = float.TryParse(rawValue, out var f) ? f : throw new FormatException();
                                            break;
                                    }

                                    var parameter = new PointDetails()
                                    {
                                        dt = pointDetails.dt,
                                        method = pointDetails.method,
                                        dst = $"{ToSafeName(sourceTag)}.{pointDetails.dst}",
                                        v = parsedValue.ToString()
                                    };

                                    parameters[cell.Key] = parameter;

                                    if (parameter.method == (int)CommunicationMethod.SYM)
                                    {
                                        symTags.Add(parameter.dst, parameter);
                                    }
                                    else if (parameter.method == (int)CommunicationMethod.OPC)
                                    {
                                        opcTags.Add(parameter.dst, parameter);
                                    }
                                    else if (parameter.method == (int)CommunicationMethod.POINTER)
                                    {
                                        pointerTags.Add(parameter.dst, parameter);
                                    }
                                }
                                catch
                                {
                                    Log($"Failed to parse value '{rawValue}' for tag '{sourceTag}.{cell.Key}' as {((DataType)pointDetails.dt)}", LogLevel.Warning);
                                }
                            }
                        }
                    }
                    else
                    {
                        Log($"No Module found for Source Tag: {sourceTag}", LogLevel.Warning);
                    }
                }
            }
            return true;
        }

        static string[] SplitCsvLine(string line)
        {
            var fields = new List<string>();
            bool inQuotes = false;
            string current = "";

            for (int i = 0; i < line.Length; i++)
            {
                char c = line[i];

                if (c == '\"')
                {
                    inQuotes = !inQuotes;
                    continue;
                }

                if (c == ',' && !inQuotes)
                {
                    fields.Add(current);
                    current = "";
                }
                else
                {
                    current += c;
                }
            }

            fields.Add(current);
            return fields.ToArray();
        }

        static List<Dictionary<string, string>> SanitiseCsv(string filename)
        {
            var ret = new List<Dictionary<string, string>>();

            using (var reader = new StreamReader(filename, Encoding.UTF7))
            {
                string headerLine = reader.ReadLine().Trim();
                if (headerLine == null)
                {
                    Console.WriteLine("Empty file.");
                    return ret;
                }

                string[] headers = SplitCsvLine(headerLine);
                int expectedFieldCount = headers.Length;

                var rows = new List<Dictionary<string, string>>();
                string buffer = "";

                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    buffer += line + "\n"; // Preserve line breaks for quoted fields

                    string[] fields = SplitCsvLine(buffer);

                    if (fields.Length == expectedFieldCount)
                    {
                        var rowDict = new Dictionary<string, string>();
                        for (int i = 0; i < expectedFieldCount; i++)
                        {
                            rowDict[headers[i]] = fields[i];
                        }
                        rows.Add(rowDict);
                        buffer = ""; // Reset buffer for next row
                    }
                }

                return rows;
            }
        }

        static string ToSafeName(string input)
        {
            // Replace invalid characters with underscores
            string safe = Regex.Replace(input, @"[^a-zA-Z0-9_]", "_");

            // If it starts with a digit, prefix with underscore
            if (Regex.IsMatch(safe, @"^[0-9]"))
            {
                safe = "_" + safe;
            }

            // Optionally, check against reserved keywords
            string[] reserved = { "class", "namespace", "void", "int", "string", "public", "private", "protected", "static", "new", "return" };
            if (Array.Exists(reserved, keyword => keyword == safe))
            {
                safe = "_" + safe;
            }

            return safe;
        }

        void ShowFileDialogDictionary(object sender, EventArgs e)
        {
            var openFileDialog = new OpenFileDialog();
            var presetFilePath = drawnTextBoxDictionary.Text;

            // Optional: Set initial directory
            if (!string.IsNullOrEmpty(presetFilePath))
            {
                openFileDialog.InitialDirectory = System.IO.Path.GetDirectoryName(presetFilePath);
                openFileDialog.FileName = System.IO.Path.GetFileName(presetFilePath);
            }

            openFileDialog.Title = "Select a file";
            openFileDialog.Filter = "Comma delimited files (*.csv)|*.csv";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                drawnTextBoxDictionary.Text = openFileDialog.FileName;
            }
        }

        void ShowFileDialogModules(object sender, EventArgs e)
        {
            var openFileDialog = new OpenFileDialog();
            var presetFilePath = drawnTextBoxModules.Text;

            // Optional: Set initial directory
            if (!string.IsNullOrEmpty(presetFilePath))
            {
                openFileDialog.InitialDirectory = System.IO.Path.GetDirectoryName(presetFilePath);
                openFileDialog.FileName = System.IO.Path.GetFileName(presetFilePath);
            }

            openFileDialog.Title = "Select a file";
            openFileDialog.Filter = "Comma delimited files (*.csv)|*.csv";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                drawnTextBoxModules.Text = openFileDialog.FileName;
            }
        }

        void ShowFileDialogParameters(object sender, EventArgs e)
        {
            var openFileDialog = new OpenFileDialog();
            var presetFilePath = drawnTextBoxRatData.Text;

            // Optional: Set initial directory
            if (!string.IsNullOrEmpty(presetFilePath))
            {
                openFileDialog.InitialDirectory = System.IO.Path.GetDirectoryName(presetFilePath);
                openFileDialog.FileName = System.IO.Path.GetFileName(presetFilePath);
            }

            openFileDialog.Title = "Select a file";
            openFileDialog.Filter = "Comma delimited files (*.csv)|*.csv";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                drawnTextBoxRatData.Text = openFileDialog.FileName;
            }
        }

        bool CheckLogForError()
        {
            dataGridViewLog.Rows.Clear();
            bool ret = false;

            foreach (var entry in logMessages)
            {
                int rowIndex = dataGridViewLog.Rows.Add(entry.Level.ToString(), entry.Message);
                var row = dataGridViewLog.Rows[rowIndex];

                switch (entry.Level)
                {
                    case LogLevel.Info:
                        row.DefaultCellStyle.ForeColor = new NxtControl.Drawing.Color("CoolWater"); //Color.Green;
                        break;
                    case LogLevel.Warning:
                        row.DefaultCellStyle.ForeColor = new NxtControl.Drawing.Color("DarkYellow"); //Color.Goldenrod;
                        break;
                    case LogLevel.Error:
                        row.DefaultCellStyle.ForeColor = new NxtControl.Drawing.Color("Red"); //Color.Red;
                        ret = true;
                        break;
                }
            }

            return ret;
        }

        void Log(string message, LogLevel level = LogLevel.Info)
        {
            logMessages.Add(new LogEntry
            {
                Time = DateTime.Now,
                Message = message,
                Level = level
            });
        }

        void ErrorValueChanged(object sender, ValueChangedEventArgs e)
        {
            string connectionStatus = (string)e.Value;

            connected = (connectionStatus.ToLower() == "connected");
            drawnButtonCNF.Enabled = applyReady && connected;
            freeTextConnectionStatus.Text = CapitalizeFirstLetter(connectionStatus);
        }


        static string CapitalizeFirstLetter(string input)
        {
            if (string.IsNullOrEmpty(input))
                return input;

            return char.ToUpper(input[0]) + input.Substring(1);
        }

        List<string> SplitJsonPayload(JsonValues jsonValues, int maxBytes = 2000)
        {
            var chunks = new List<string>();
            var currentChunk = new List<PointDetails>();

            foreach (var point in jsonValues.values)
            {
                currentChunk.Add(point);
                var tempJson = new JsonValues { values = currentChunk };
                byte[] utf8Bytes = JsonSerializer.SerializeToUtf8Bytes(tempJson);

                if (utf8Bytes.Length > maxBytes)
                {
                    // Remove last item and finalize current chunk
                    currentChunk.RemoveAt(currentChunk.Count - 1);
                    tempJson = new JsonValues { values = currentChunk };
                    chunks.Add(Encoding.UTF8.GetString(JsonSerializer.SerializeToUtf8Bytes(tempJson)));

                    // Start new chunk with the item that didn't fit
                    currentChunk = new List<PointDetails> { point };
                }
            }

            // Add the final chunk
            if (currentChunk.Count > 0)
            {
                var finalJson = new JsonValues { values = currentChunk };
                chunks.Add(Encoding.UTF8.GetString(JsonSerializer.SerializeToUtf8Bytes(finalJson)));
            }

            return chunks;
        }

        void REQ_OPCCONNECT_Fired_EventHandler(object sender, REQ_OPCCONNECTEventArgs e)
        {
            connectionStatus = e.ConnectStatus;
            opcPrefix = e.OPC_Prefix;
        }


        enum DataType
        {
            Unknown = 0,     // No value
            BOOL = 11,       // VT_BOOL (Boolean)
            INT = 22,        // Custom INT (possibly PLC-style 16-bit)
            DINT = 3,        // VT_I4 (32-bit signed integer)
            REAL = 5,        // VT_R4 or VT_R8 depending on your system
            STRING = 8       // VT_BSTR (String)
        }


        enum CommunicationMethod
        {
            Unknown = 0,
            OPC = 1,
            SYM = 2,
            POINTER = 3,
            MQTT = 4
        }

        enum LogLevel
        {
            Info = 0,
            Warning = 1,
            Error = 2
        }

        enum ModuleType
        {
            Unkown = 0,
            AI = 101,
            AO = 102,
            DI = 103,
            DO = 104
        }

        class LogEntry
        {
            public DateTime Time { get; set; }
            public string Message { get; set; }
            public LogLevel Level { get; set; }
        }

        class JsonValues
        {
            public List<PointDetails> values { get; set; }
        }

        class PointDetails
        {
            public string dst { get; set; }
            public string v { get; set; }
            public int dt { get; set; }
            public int method { get; set; }
        }

        class ModulesDetails
        {
            public string Tag { get; set; }
            public string TagNumber { get; set; }
            public string EndpointPackage { get; set; }
            public string Description { get; set; }
            public string PointType { get; set; }
            public string LogicDevice { get; set; }
            public string IOLocation { get; set; }
            public string Processor { get; set; }
            public string DropNo { get; set; }
            public string Rack { get; set; }
            public string LSlotNo { get; set; }
            public string ChannelNo { get; set; }
            public string FullDescription { get; set; }
            public bool RAT { get; set; }

            public string Id { get; set; } // $"D{module.DropNo.PadLeft(2, '0')}R{module.Rack.PadLeft(2, '0')}S{module.LSlotNo.PadLeft(2, '0')}"
            public Dictionary<string, PointDetails> Parameters = new Dictionary<string, PointDetails>();
        }

        class SmartElement
        {
            public int Id { get; set; }             //6th element in the array
            public string Name { get; set; }
            public int NodeType { get; set; }		//5th element in the array           
            public int[] Connections { get; set; } 	//first 4 elements of the array
            public List<Parameter> Parameters = new List<Parameter>();
        }

        class Parameter
        {
            public string Name { get; set; }
            public string Value { get; set; }
        }

        class DeltaValues
        {
            public string Tagname { get; set; } // dst
            public string Value { get; set; } // v
            public int DataType { get; set; } // dt
            public int Type { get; set; } // method
            public string CurrentValue { get; set; } // new
            public string Status { get; set; }
            public bool Error { get; set; }
            public bool Modified { get; set; }
        }
    }
}



