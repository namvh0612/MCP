/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/16/2025
 * Time: 9:15 PM
 * 
 */
using System;
using NxtControl.GuiFramework;
using NxtControl.Services;

#region Definitions;
#region #SmartManager_v1_0_HMI;

namespace SE.Agile.Symbols.SmartManager_v1_0
{

  public class END_CNFEventArgs : System.EventArgs
  {
    IHMIAccessorService accessorService;
    int channelId;
    int cookie; 
    int eventIndex;

    public END_CNFEventArgs(int channelId, int cookie, int eventIndex)
    {
      this.accessorService = (IHMIAccessorService)ServiceProvider.GetService(typeof(IHMIAccessorService));
      this.channelId = channelId;
      this.cookie = cookie;
      this.eventIndex = eventIndex;
    }
    public bool Get_Payload(ref System.String value)
    {
      if (accessorService == null)
        return false;
      string var = null;
      bool ret = accessorService.GetStringValue(channelId, cookie, eventIndex, true,0, ref var);
      if (ret) value = (System.String) var;
      return ret;
    }

    public System.String Payload
    { get {
      if (accessorService == null)
        return null;
      string var = null;
      bool ret = accessorService.GetStringValue(channelId, cookie, eventIndex, true,0, ref var);
      if (!ret) return null;
      return (System.String) var;
    }  }

    public bool Get_Size(ref System.Int16 value)
    {
      if (accessorService == null)
        return false;
      System.Int64 var = 0;
      bool ret = accessorService.GetInt64Value(channelId, cookie, eventIndex, true,1, ref var);
      if (ret) value = (System.Int16) var;
      return ret;
    }

    public System.Int16? Size
    { get {
      if (accessorService == null)
        return null;
      System.Int64 var = 0;
      bool ret = accessorService.GetInt64Value(channelId, cookie, eventIndex, true,1, ref var);
      if (!ret) return null;
      return (System.Int16) var;
    }  }


  }

  public class PARAMEventArgs : System.EventArgs
  {
    IHMIAccessorService accessorService;
    int channelId;
    int cookie; 
    int eventIndex;

    public PARAMEventArgs(int channelId, int cookie, int eventIndex)
    {
      this.accessorService = (IHMIAccessorService)ServiceProvider.GetService(typeof(IHMIAccessorService));
      this.channelId = channelId;
      this.cookie = cookie;
      this.eventIndex = eventIndex;
    }
    public bool Get_Parameters(ref System.String value)
    {
      if (accessorService == null)
        return false;
      string var = null;
      bool ret = accessorService.GetStringValue(channelId, cookie, eventIndex, true,0, ref var);
      if (ret) value = (System.String) var;
      return ret;
    }

    public System.String Parameters
    { get {
      if (accessorService == null)
        return null;
      string var = null;
      bool ret = accessorService.GetStringValue(channelId, cookie, eventIndex, true,0, ref var);
      if (!ret) return null;
      return (System.String) var;
    }  }


  }

  public class CONF_EMPTYEventArgs : System.EventArgs
  {
    IHMIAccessorService accessorService;
    int channelId;
    int cookie; 
    int eventIndex;

    public CONF_EMPTYEventArgs(int channelId, int cookie, int eventIndex)
    {
      this.accessorService = (IHMIAccessorService)ServiceProvider.GetService(typeof(IHMIAccessorService));
      this.channelId = channelId;
      this.cookie = cookie;
      this.eventIndex = eventIndex;
    }

  }

  public class REQ_UPDATEEventArgs : System.EventArgs
  {
    IHMIAccessorService accessorService;
    int channelId;
    int cookie; 
    int eventIndex;

    public REQ_UPDATEEventArgs(int channelId, int cookie, int eventIndex)
    {
      this.accessorService = (IHMIAccessorService)ServiceProvider.GetService(typeof(IHMIAccessorService));
      this.channelId = channelId;
      this.cookie = cookie;
      this.eventIndex = eventIndex;
    }

  }

  public class REQ_OPCCONNECTEventArgs : System.EventArgs
  {
    IHMIAccessorService accessorService;
    int channelId;
    int cookie; 
    int eventIndex;

    public REQ_OPCCONNECTEventArgs(int channelId, int cookie, int eventIndex)
    {
      this.accessorService = (IHMIAccessorService)ServiceProvider.GetService(typeof(IHMIAccessorService));
      this.channelId = channelId;
      this.cookie = cookie;
      this.eventIndex = eventIndex;
    }
    public bool Get_Res(ref System.String value)
    {
      if (accessorService == null)
        return false;
      string var = null;
      bool ret = accessorService.GetStringValue(channelId, cookie, eventIndex, true,0, ref var);
      if (ret) value = (System.String) var;
      return ret;
    }

    public System.String Res
    { get {
      if (accessorService == null)
        return null;
      string var = null;
      bool ret = accessorService.GetStringValue(channelId, cookie, eventIndex, true,0, ref var);
      if (!ret) return null;
      return (System.String) var;
    }  }

    public bool Get_ConnectStatus(ref System.String value)
    {
      if (accessorService == null)
        return false;
      string var = null;
      bool ret = accessorService.GetStringValue(channelId, cookie, eventIndex, true,1, ref var);
      if (ret) value = (System.String) var;
      return ret;
    }

    public System.String ConnectStatus
    { get {
      if (accessorService == null)
        return null;
      string var = null;
      bool ret = accessorService.GetStringValue(channelId, cookie, eventIndex, true,1, ref var);
      if (!ret) return null;
      return (System.String) var;
    }  }

    public bool Get_OPC_Prefix(ref System.String value)
    {
      if (accessorService == null)
        return false;
      string var = null;
      bool ret = accessorService.GetStringValue(channelId, cookie, eventIndex, true,2, ref var);
      if (ret) value = (System.String) var;
      return ret;
    }

    public System.String OPC_Prefix
    { get {
      if (accessorService == null)
        return null;
      string var = null;
      bool ret = accessorService.GetStringValue(channelId, cookie, eventIndex, true,2, ref var);
      if (!ret) return null;
      return (System.String) var;
    }  }


  }

  public class CNF_ENDEventArgs : System.EventArgs
  {
    IHMIAccessorService accessorService;
    int channelId;
    int cookie; 
    int eventIndex;

    public CNF_ENDEventArgs(int channelId, int cookie, int eventIndex)
    {
      this.accessorService = (IHMIAccessorService)ServiceProvider.GetService(typeof(IHMIAccessorService));
      this.channelId = channelId;
      this.cookie = cookie;
      this.eventIndex = eventIndex;
    }

  }

  public class OPC_READEventArgs : System.EventArgs
  {
    IHMIAccessorService accessorService;
    int channelId;
    int cookie; 
    int eventIndex;

    public OPC_READEventArgs(int channelId, int cookie, int eventIndex)
    {
      this.accessorService = (IHMIAccessorService)ServiceProvider.GetService(typeof(IHMIAccessorService));
      this.channelId = channelId;
      this.cookie = cookie;
      this.eventIndex = eventIndex;
    }
    public bool Get_OpcValue(ref System.String value)
    {
      if (accessorService == null)
        return false;
      string var = null;
      bool ret = accessorService.GetStringValue(channelId, cookie, eventIndex, true,0, ref var);
      if (ret) value = (System.String) var;
      return ret;
    }

    public System.String OpcValue
    { get {
      if (accessorService == null)
        return null;
      string var = null;
      bool ret = accessorService.GetStringValue(channelId, cookie, eventIndex, true,0, ref var);
      if (!ret) return null;
      return (System.String) var;
    }  }


  }

  public class OPC_ERROREventArgs : System.EventArgs
  {
    IHMIAccessorService accessorService;
    int channelId;
    int cookie; 
    int eventIndex;

    public OPC_ERROREventArgs(int channelId, int cookie, int eventIndex)
    {
      this.accessorService = (IHMIAccessorService)ServiceProvider.GetService(typeof(IHMIAccessorService));
      this.channelId = channelId;
      this.cookie = cookie;
      this.eventIndex = eventIndex;
    }
    public bool Get_ErrorCode(ref System.Int32 value)
    {
      if (accessorService == null)
        return false;
      System.Int64 var = 0;
      bool ret = accessorService.GetInt64Value(channelId, cookie, eventIndex, true,0, ref var);
      if (ret) value = (System.Int32) var;
      return ret;
    }

    public System.Int32? ErrorCode
    { get {
      if (accessorService == null)
        return null;
      System.Int64 var = 0;
      bool ret = accessorService.GetInt64Value(channelId, cookie, eventIndex, true,0, ref var);
      if (!ret) return null;
      return (System.Int32) var;
    }  }


  }

  public class AssignRename_CNFEventArgs : System.EventArgs
  {
    IHMIAccessorService accessorService;
    int channelId;
    int cookie; 
    int eventIndex;

    public AssignRename_CNFEventArgs(int channelId, int cookie, int eventIndex)
    {
      this.accessorService = (IHMIAccessorService)ServiceProvider.GetService(typeof(IHMIAccessorService));
      this.channelId = channelId;
      this.cookie = cookie;
      this.eventIndex = eventIndex;
    }

  }

}

namespace SE.Agile.Symbols.SmartManager_v1_0
{

  public class CNFEventArgs : System.EventArgs
  {
    public CNFEventArgs()
    {
    }
    private System.String ValuesJSON_field = null;
    public System.String ValuesJSON
    {
       get { return ValuesJSON_field; }
       set { ValuesJSON_field = value; }
    }

  }

  public class GET_GRAPHEventArgs : System.EventArgs
  {
    public GET_GRAPHEventArgs()
    {
    }
    private System.Int16? GetStart_field = null;
    public System.Int16? GetStart
    {
       get { return GetStart_field; }
       set { GetStart_field = value; }
    }

  }

  public class SEND_GRAPHEventArgs : System.EventArgs
  {
    public SEND_GRAPHEventArgs()
    {
    }
    private System.String Graph_field = null;
    public System.String Graph
    {
       get { return Graph_field; }
       set { Graph_field = value; }
    }

  }

  public class VALUES_SETEventArgs : System.EventArgs
  {
    public VALUES_SETEventArgs()
    {
    }

  }

  public class OPC_BOOLEventArgs : System.EventArgs
  {
    public OPC_BOOLEventArgs()
    {
    }
    private System.String OpcTagname_field = null;
    public System.String OpcTagname
    {
       get { return OpcTagname_field; }
       set { OpcTagname_field = value; }
    }

  }

  public class OPC_INTEventArgs : System.EventArgs
  {
    public OPC_INTEventArgs()
    {
    }
    private System.String OpcTagname_field = null;
    public System.String OpcTagname
    {
       get { return OpcTagname_field; }
       set { OpcTagname_field = value; }
    }

  }

  public class OPC_REALEventArgs : System.EventArgs
  {
    public OPC_REALEventArgs()
    {
    }
    private System.String OpcTagname_field = null;
    public System.String OpcTagname
    {
       get { return OpcTagname_field; }
       set { OpcTagname_field = value; }
    }

  }

  public class OPC_DINTEventArgs : System.EventArgs
  {
    public OPC_DINTEventArgs()
    {
    }
    private System.String OpcTagname_field = null;
    public System.String OpcTagname
    {
       get { return OpcTagname_field; }
       set { OpcTagname_field = value; }
    }

  }

  public class OPC_STRINGEventArgs : System.EventArgs
  {
    public OPC_STRINGEventArgs()
    {
    }
    private System.String OpcTagname_field = null;
    public System.String OpcTagname
    {
       get { return OpcTagname_field; }
       set { OpcTagname_field = value; }
    }

  }

  public class GET_CONFIGEventArgs : System.EventArgs
  {
    public GET_CONFIGEventArgs()
    {
    }
    private System.String MessageDst_field = null;
    public System.String MessageDst
    {
       get { return MessageDst_field; }
       set { MessageDst_field = value; }
    }

  }

}

namespace SE.Agile.Symbols.SmartManager_v1_0
{
  partial class sDefault
  {

    private event EventHandler<SE.Agile.Symbols.SmartManager_v1_0.END_CNFEventArgs> END_CNF_Fired;

    private event EventHandler<SE.Agile.Symbols.SmartManager_v1_0.PARAMEventArgs> PARAM_Fired;

    private event EventHandler<SE.Agile.Symbols.SmartManager_v1_0.CONF_EMPTYEventArgs> CONF_EMPTY_Fired;

    private event EventHandler<SE.Agile.Symbols.SmartManager_v1_0.REQ_UPDATEEventArgs> REQ_UPDATE_Fired;

    private event EventHandler<SE.Agile.Symbols.SmartManager_v1_0.REQ_OPCCONNECTEventArgs> REQ_OPCCONNECT_Fired;

    private event EventHandler<SE.Agile.Symbols.SmartManager_v1_0.CNF_ENDEventArgs> CNF_END_Fired;

    private event EventHandler<SE.Agile.Symbols.SmartManager_v1_0.OPC_READEventArgs> OPC_READ_Fired;

    private event EventHandler<SE.Agile.Symbols.SmartManager_v1_0.OPC_ERROREventArgs> OPC_ERROR_Fired;

    private event EventHandler<SE.Agile.Symbols.SmartManager_v1_0.AssignRename_CNFEventArgs> AssignRename_CNF_Fired;

    protected override void OnEndInit()
    {
      if (END_CNF_Fired != null)
        AttachEventInput(0);
      if (PARAM_Fired != null)
        AttachEventInput(1);
      if (CONF_EMPTY_Fired != null)
        AttachEventInput(2);
      if (REQ_UPDATE_Fired != null)
        AttachEventInput(3);
      if (REQ_OPCCONNECT_Fired != null)
        AttachEventInput(4);
      if (CNF_END_Fired != null)
        AttachEventInput(5);
      if (OPC_READ_Fired != null)
        AttachEventInput(6);
      if (OPC_ERROR_Fired != null)
        AttachEventInput(7);
      if (AssignRename_CNF_Fired != null)
        AttachEventInput(8);

    }

    protected override void FireEventCallback(int channelId, int cookie, int eventIndex)
    {
      switch(eventIndex)
      {
        default:
          break;
        case 0:
          if (END_CNF_Fired != null)
          {
            try
            {
              END_CNF_Fired(this, new SE.Agile.Symbols.SmartManager_v1_0.END_CNFEventArgs(channelId, cookie, eventIndex));
            }
            catch (System.Exception e)
            {
              NxtControl.Services.LoggingService.ErrorFormatted(@"In Event Callback for event:'{0}' Type:'{1}' CAT:'{2}' came exception:{3}
stack Trace:
{4}","END_CNF_Fired", this.GetType().Name, this.CATName, e.Message, e.StackTrace);
            }
          }
        break; 
        case 1:
          if (PARAM_Fired != null)
          {
            try
            {
              PARAM_Fired(this, new SE.Agile.Symbols.SmartManager_v1_0.PARAMEventArgs(channelId, cookie, eventIndex));
            }
            catch (System.Exception e)
            {
              NxtControl.Services.LoggingService.ErrorFormatted(@"In Event Callback for event:'{0}' Type:'{1}' CAT:'{2}' came exception:{3}
stack Trace:
{4}","PARAM_Fired", this.GetType().Name, this.CATName, e.Message, e.StackTrace);
            }
          }
        break; 
        case 2:
          if (CONF_EMPTY_Fired != null)
          {
            try
            {
              CONF_EMPTY_Fired(this, new SE.Agile.Symbols.SmartManager_v1_0.CONF_EMPTYEventArgs(channelId, cookie, eventIndex));
            }
            catch (System.Exception e)
            {
              NxtControl.Services.LoggingService.ErrorFormatted(@"In Event Callback for event:'{0}' Type:'{1}' CAT:'{2}' came exception:{3}
stack Trace:
{4}","CONF_EMPTY_Fired", this.GetType().Name, this.CATName, e.Message, e.StackTrace);
            }
          }
        break; 
        case 3:
          if (REQ_UPDATE_Fired != null)
          {
            try
            {
              REQ_UPDATE_Fired(this, new SE.Agile.Symbols.SmartManager_v1_0.REQ_UPDATEEventArgs(channelId, cookie, eventIndex));
            }
            catch (System.Exception e)
            {
              NxtControl.Services.LoggingService.ErrorFormatted(@"In Event Callback for event:'{0}' Type:'{1}' CAT:'{2}' came exception:{3}
stack Trace:
{4}","REQ_UPDATE_Fired", this.GetType().Name, this.CATName, e.Message, e.StackTrace);
            }
          }
        break; 
        case 4:
          if (REQ_OPCCONNECT_Fired != null)
          {
            try
            {
              REQ_OPCCONNECT_Fired(this, new SE.Agile.Symbols.SmartManager_v1_0.REQ_OPCCONNECTEventArgs(channelId, cookie, eventIndex));
            }
            catch (System.Exception e)
            {
              NxtControl.Services.LoggingService.ErrorFormatted(@"In Event Callback for event:'{0}' Type:'{1}' CAT:'{2}' came exception:{3}
stack Trace:
{4}","REQ_OPCCONNECT_Fired", this.GetType().Name, this.CATName, e.Message, e.StackTrace);
            }
          }
        break; 
        case 5:
          if (CNF_END_Fired != null)
          {
            try
            {
              CNF_END_Fired(this, new SE.Agile.Symbols.SmartManager_v1_0.CNF_ENDEventArgs(channelId, cookie, eventIndex));
            }
            catch (System.Exception e)
            {
              NxtControl.Services.LoggingService.ErrorFormatted(@"In Event Callback for event:'{0}' Type:'{1}' CAT:'{2}' came exception:{3}
stack Trace:
{4}","CNF_END_Fired", this.GetType().Name, this.CATName, e.Message, e.StackTrace);
            }
          }
        break; 
        case 6:
          if (OPC_READ_Fired != null)
          {
            try
            {
              OPC_READ_Fired(this, new SE.Agile.Symbols.SmartManager_v1_0.OPC_READEventArgs(channelId, cookie, eventIndex));
            }
            catch (System.Exception e)
            {
              NxtControl.Services.LoggingService.ErrorFormatted(@"In Event Callback for event:'{0}' Type:'{1}' CAT:'{2}' came exception:{3}
stack Trace:
{4}","OPC_READ_Fired", this.GetType().Name, this.CATName, e.Message, e.StackTrace);
            }
          }
        break; 
        case 7:
          if (OPC_ERROR_Fired != null)
          {
            try
            {
              OPC_ERROR_Fired(this, new SE.Agile.Symbols.SmartManager_v1_0.OPC_ERROREventArgs(channelId, cookie, eventIndex));
            }
            catch (System.Exception e)
            {
              NxtControl.Services.LoggingService.ErrorFormatted(@"In Event Callback for event:'{0}' Type:'{1}' CAT:'{2}' came exception:{3}
stack Trace:
{4}","OPC_ERROR_Fired", this.GetType().Name, this.CATName, e.Message, e.StackTrace);
            }
          }
        break; 
        case 8:
          if (AssignRename_CNF_Fired != null)
          {
            try
            {
              AssignRename_CNF_Fired(this, new SE.Agile.Symbols.SmartManager_v1_0.AssignRename_CNFEventArgs(channelId, cookie, eventIndex));
            }
            catch (System.Exception e)
            {
              NxtControl.Services.LoggingService.ErrorFormatted(@"In Event Callback for event:'{0}' Type:'{1}' CAT:'{2}' came exception:{3}
stack Trace:
{4}","AssignRename_CNF_Fired", this.GetType().Name, this.CATName, e.Message, e.StackTrace);
            }
          }
        break; 

      }
    }
    public bool FireEvent_CNF(System.String ValuesJSON)
    {
      return ((IHMIAccessorOutput)this).FireEvent(0, new object[] {ValuesJSON});
    }
    public bool FireEvent_CNF(SE.Agile.Symbols.SmartManager_v1_0.CNFEventArgs ea)
    {
      object[] _values_ = new object[1];
      if (ea.ValuesJSON != null) _values_[0] = ea.ValuesJSON;
      return ((IHMIAccessorOutput)this).FireEvent(0, _values_);
    }
    public bool FireEvent_CNF(System.String ValuesJSON, bool ignore_ValuesJSON)
    {
      object[] _values_ = new object[1];
      if (!ignore_ValuesJSON) _values_[0] = ValuesJSON;
      return ((IHMIAccessorOutput)this).FireEvent(0, _values_);
    }
    public bool FireEvent_GET_GRAPH(System.Int16 GetStart)
    {
      return ((IHMIAccessorOutput)this).FireEvent(1, new object[] {GetStart});
    }
    public bool FireEvent_GET_GRAPH(SE.Agile.Symbols.SmartManager_v1_0.GET_GRAPHEventArgs ea)
    {
      object[] _values_ = new object[1];
      if (ea.GetStart.HasValue) _values_[0] = ea.GetStart.Value;
      return ((IHMIAccessorOutput)this).FireEvent(1, _values_);
    }
    public bool FireEvent_GET_GRAPH(System.Int16 GetStart, bool ignore_GetStart)
    {
      object[] _values_ = new object[1];
      if (!ignore_GetStart) _values_[0] = GetStart;
      return ((IHMIAccessorOutput)this).FireEvent(1, _values_);
    }
    public bool FireEvent_SEND_GRAPH(System.String Graph)
    {
      return ((IHMIAccessorOutput)this).FireEvent(2, new object[] {Graph});
    }
    public bool FireEvent_SEND_GRAPH(SE.Agile.Symbols.SmartManager_v1_0.SEND_GRAPHEventArgs ea)
    {
      object[] _values_ = new object[1];
      if (ea.Graph != null) _values_[0] = ea.Graph;
      return ((IHMIAccessorOutput)this).FireEvent(2, _values_);
    }
    public bool FireEvent_SEND_GRAPH(System.String Graph, bool ignore_Graph)
    {
      object[] _values_ = new object[1];
      if (!ignore_Graph) _values_[0] = Graph;
      return ((IHMIAccessorOutput)this).FireEvent(2, _values_);
    }
    public bool FireEvent_VALUES_SET()
    {
      return ((IHMIAccessorOutput)this).FireEvent(3, new object[] {});
    }
    public bool FireEvent_VALUES_SET(SE.Agile.Symbols.SmartManager_v1_0.VALUES_SETEventArgs ea)
    {
      object[] _values_ = new object[0];
      return ((IHMIAccessorOutput)this).FireEvent(3, _values_);
    }
    public bool FireEvent_OPC_BOOL(System.String OpcTagname)
    {
      return ((IHMIAccessorOutput)this).FireEvent(4, new object[] {OpcTagname});
    }
    public bool FireEvent_OPC_BOOL(SE.Agile.Symbols.SmartManager_v1_0.OPC_BOOLEventArgs ea)
    {
      object[] _values_ = new object[1];
      if (ea.OpcTagname != null) _values_[0] = ea.OpcTagname;
      return ((IHMIAccessorOutput)this).FireEvent(4, _values_);
    }
    public bool FireEvent_OPC_BOOL(System.String OpcTagname, bool ignore_OpcTagname)
    {
      object[] _values_ = new object[1];
      if (!ignore_OpcTagname) _values_[0] = OpcTagname;
      return ((IHMIAccessorOutput)this).FireEvent(4, _values_);
    }
    public bool FireEvent_OPC_INT(System.String OpcTagname)
    {
      return ((IHMIAccessorOutput)this).FireEvent(5, new object[] {OpcTagname});
    }
    public bool FireEvent_OPC_INT(SE.Agile.Symbols.SmartManager_v1_0.OPC_INTEventArgs ea)
    {
      object[] _values_ = new object[1];
      if (ea.OpcTagname != null) _values_[0] = ea.OpcTagname;
      return ((IHMIAccessorOutput)this).FireEvent(5, _values_);
    }
    public bool FireEvent_OPC_INT(System.String OpcTagname, bool ignore_OpcTagname)
    {
      object[] _values_ = new object[1];
      if (!ignore_OpcTagname) _values_[0] = OpcTagname;
      return ((IHMIAccessorOutput)this).FireEvent(5, _values_);
    }
    public bool FireEvent_OPC_REAL(System.String OpcTagname)
    {
      return ((IHMIAccessorOutput)this).FireEvent(6, new object[] {OpcTagname});
    }
    public bool FireEvent_OPC_REAL(SE.Agile.Symbols.SmartManager_v1_0.OPC_REALEventArgs ea)
    {
      object[] _values_ = new object[1];
      if (ea.OpcTagname != null) _values_[0] = ea.OpcTagname;
      return ((IHMIAccessorOutput)this).FireEvent(6, _values_);
    }
    public bool FireEvent_OPC_REAL(System.String OpcTagname, bool ignore_OpcTagname)
    {
      object[] _values_ = new object[1];
      if (!ignore_OpcTagname) _values_[0] = OpcTagname;
      return ((IHMIAccessorOutput)this).FireEvent(6, _values_);
    }
    public bool FireEvent_OPC_DINT(System.String OpcTagname)
    {
      return ((IHMIAccessorOutput)this).FireEvent(7, new object[] {OpcTagname});
    }
    public bool FireEvent_OPC_DINT(SE.Agile.Symbols.SmartManager_v1_0.OPC_DINTEventArgs ea)
    {
      object[] _values_ = new object[1];
      if (ea.OpcTagname != null) _values_[0] = ea.OpcTagname;
      return ((IHMIAccessorOutput)this).FireEvent(7, _values_);
    }
    public bool FireEvent_OPC_DINT(System.String OpcTagname, bool ignore_OpcTagname)
    {
      object[] _values_ = new object[1];
      if (!ignore_OpcTagname) _values_[0] = OpcTagname;
      return ((IHMIAccessorOutput)this).FireEvent(7, _values_);
    }
    public bool FireEvent_OPC_STRING(System.String OpcTagname)
    {
      return ((IHMIAccessorOutput)this).FireEvent(8, new object[] {OpcTagname});
    }
    public bool FireEvent_OPC_STRING(SE.Agile.Symbols.SmartManager_v1_0.OPC_STRINGEventArgs ea)
    {
      object[] _values_ = new object[1];
      if (ea.OpcTagname != null) _values_[0] = ea.OpcTagname;
      return ((IHMIAccessorOutput)this).FireEvent(8, _values_);
    }
    public bool FireEvent_OPC_STRING(System.String OpcTagname, bool ignore_OpcTagname)
    {
      object[] _values_ = new object[1];
      if (!ignore_OpcTagname) _values_[0] = OpcTagname;
      return ((IHMIAccessorOutput)this).FireEvent(8, _values_);
    }
    public bool FireEvent_GET_CONFIG(System.String MessageDst)
    {
      return ((IHMIAccessorOutput)this).FireEvent(9, new object[] {MessageDst});
    }
    public bool FireEvent_GET_CONFIG(SE.Agile.Symbols.SmartManager_v1_0.GET_CONFIGEventArgs ea)
    {
      object[] _values_ = new object[1];
      if (ea.MessageDst != null) _values_[0] = ea.MessageDst;
      return ((IHMIAccessorOutput)this).FireEvent(9, _values_);
    }
    public bool FireEvent_GET_CONFIG(System.String MessageDst, bool ignore_MessageDst)
    {
      object[] _values_ = new object[1];
      if (!ignore_MessageDst) _values_[0] = MessageDst;
      return ((IHMIAccessorOutput)this).FireEvent(9, _values_);
    }

  }
}

namespace SE.Agile.Symbols.SmartManager_v1_0
{
  partial class sManager
  {

    private event EventHandler<SE.Agile.Symbols.SmartManager_v1_0.END_CNFEventArgs> END_CNF_Fired;

    private event EventHandler<SE.Agile.Symbols.SmartManager_v1_0.PARAMEventArgs> PARAM_Fired;

    private event EventHandler<SE.Agile.Symbols.SmartManager_v1_0.CONF_EMPTYEventArgs> CONF_EMPTY_Fired;

    private event EventHandler<SE.Agile.Symbols.SmartManager_v1_0.REQ_UPDATEEventArgs> REQ_UPDATE_Fired;

    private event EventHandler<SE.Agile.Symbols.SmartManager_v1_0.REQ_OPCCONNECTEventArgs> REQ_OPCCONNECT_Fired;

    private event EventHandler<SE.Agile.Symbols.SmartManager_v1_0.CNF_ENDEventArgs> CNF_END_Fired;

    private event EventHandler<SE.Agile.Symbols.SmartManager_v1_0.OPC_READEventArgs> OPC_READ_Fired;

    private event EventHandler<SE.Agile.Symbols.SmartManager_v1_0.OPC_ERROREventArgs> OPC_ERROR_Fired;

    private event EventHandler<SE.Agile.Symbols.SmartManager_v1_0.AssignRename_CNFEventArgs> AssignRename_CNF_Fired;

    protected override void OnEndInit()
    {
      if (END_CNF_Fired != null)
        AttachEventInput(0);
      if (PARAM_Fired != null)
        AttachEventInput(1);
      if (CONF_EMPTY_Fired != null)
        AttachEventInput(2);
      if (REQ_UPDATE_Fired != null)
        AttachEventInput(3);
      if (REQ_OPCCONNECT_Fired != null)
        AttachEventInput(4);
      if (CNF_END_Fired != null)
        AttachEventInput(5);
      if (OPC_READ_Fired != null)
        AttachEventInput(6);
      if (OPC_ERROR_Fired != null)
        AttachEventInput(7);
      if (AssignRename_CNF_Fired != null)
        AttachEventInput(8);

    }

    protected override void FireEventCallback(int channelId, int cookie, int eventIndex)
    {
      switch(eventIndex)
      {
        default:
          break;
        case 0:
          if (END_CNF_Fired != null)
          {
            try
            {
              END_CNF_Fired(this, new SE.Agile.Symbols.SmartManager_v1_0.END_CNFEventArgs(channelId, cookie, eventIndex));
            }
            catch (System.Exception e)
            {
              NxtControl.Services.LoggingService.ErrorFormatted(@"In Event Callback for event:'{0}' Type:'{1}' CAT:'{2}' came exception:{3}
stack Trace:
{4}","END_CNF_Fired", this.GetType().Name, this.CATName, e.Message, e.StackTrace);
            }
          }
        break; 
        case 1:
          if (PARAM_Fired != null)
          {
            try
            {
              PARAM_Fired(this, new SE.Agile.Symbols.SmartManager_v1_0.PARAMEventArgs(channelId, cookie, eventIndex));
            }
            catch (System.Exception e)
            {
              NxtControl.Services.LoggingService.ErrorFormatted(@"In Event Callback for event:'{0}' Type:'{1}' CAT:'{2}' came exception:{3}
stack Trace:
{4}","PARAM_Fired", this.GetType().Name, this.CATName, e.Message, e.StackTrace);
            }
          }
        break; 
        case 2:
          if (CONF_EMPTY_Fired != null)
          {
            try
            {
              CONF_EMPTY_Fired(this, new SE.Agile.Symbols.SmartManager_v1_0.CONF_EMPTYEventArgs(channelId, cookie, eventIndex));
            }
            catch (System.Exception e)
            {
              NxtControl.Services.LoggingService.ErrorFormatted(@"In Event Callback for event:'{0}' Type:'{1}' CAT:'{2}' came exception:{3}
stack Trace:
{4}","CONF_EMPTY_Fired", this.GetType().Name, this.CATName, e.Message, e.StackTrace);
            }
          }
        break; 
        case 3:
          if (REQ_UPDATE_Fired != null)
          {
            try
            {
              REQ_UPDATE_Fired(this, new SE.Agile.Symbols.SmartManager_v1_0.REQ_UPDATEEventArgs(channelId, cookie, eventIndex));
            }
            catch (System.Exception e)
            {
              NxtControl.Services.LoggingService.ErrorFormatted(@"In Event Callback for event:'{0}' Type:'{1}' CAT:'{2}' came exception:{3}
stack Trace:
{4}","REQ_UPDATE_Fired", this.GetType().Name, this.CATName, e.Message, e.StackTrace);
            }
          }
        break; 
        case 4:
          if (REQ_OPCCONNECT_Fired != null)
          {
            try
            {
              REQ_OPCCONNECT_Fired(this, new SE.Agile.Symbols.SmartManager_v1_0.REQ_OPCCONNECTEventArgs(channelId, cookie, eventIndex));
            }
            catch (System.Exception e)
            {
              NxtControl.Services.LoggingService.ErrorFormatted(@"In Event Callback for event:'{0}' Type:'{1}' CAT:'{2}' came exception:{3}
stack Trace:
{4}","REQ_OPCCONNECT_Fired", this.GetType().Name, this.CATName, e.Message, e.StackTrace);
            }
          }
        break; 
        case 5:
          if (CNF_END_Fired != null)
          {
            try
            {
              CNF_END_Fired(this, new SE.Agile.Symbols.SmartManager_v1_0.CNF_ENDEventArgs(channelId, cookie, eventIndex));
            }
            catch (System.Exception e)
            {
              NxtControl.Services.LoggingService.ErrorFormatted(@"In Event Callback for event:'{0}' Type:'{1}' CAT:'{2}' came exception:{3}
stack Trace:
{4}","CNF_END_Fired", this.GetType().Name, this.CATName, e.Message, e.StackTrace);
            }
          }
        break; 
        case 6:
          if (OPC_READ_Fired != null)
          {
            try
            {
              OPC_READ_Fired(this, new SE.Agile.Symbols.SmartManager_v1_0.OPC_READEventArgs(channelId, cookie, eventIndex));
            }
            catch (System.Exception e)
            {
              NxtControl.Services.LoggingService.ErrorFormatted(@"In Event Callback for event:'{0}' Type:'{1}' CAT:'{2}' came exception:{3}
stack Trace:
{4}","OPC_READ_Fired", this.GetType().Name, this.CATName, e.Message, e.StackTrace);
            }
          }
        break; 
        case 7:
          if (OPC_ERROR_Fired != null)
          {
            try
            {
              OPC_ERROR_Fired(this, new SE.Agile.Symbols.SmartManager_v1_0.OPC_ERROREventArgs(channelId, cookie, eventIndex));
            }
            catch (System.Exception e)
            {
              NxtControl.Services.LoggingService.ErrorFormatted(@"In Event Callback for event:'{0}' Type:'{1}' CAT:'{2}' came exception:{3}
stack Trace:
{4}","OPC_ERROR_Fired", this.GetType().Name, this.CATName, e.Message, e.StackTrace);
            }
          }
        break; 
        case 8:
          if (AssignRename_CNF_Fired != null)
          {
            try
            {
              AssignRename_CNF_Fired(this, new SE.Agile.Symbols.SmartManager_v1_0.AssignRename_CNFEventArgs(channelId, cookie, eventIndex));
            }
            catch (System.Exception e)
            {
              NxtControl.Services.LoggingService.ErrorFormatted(@"In Event Callback for event:'{0}' Type:'{1}' CAT:'{2}' came exception:{3}
stack Trace:
{4}","AssignRename_CNF_Fired", this.GetType().Name, this.CATName, e.Message, e.StackTrace);
            }
          }
        break; 

      }
    }
    public bool FireEvent_CNF(System.String ValuesJSON)
    {
      return ((IHMIAccessorOutput)this).FireEvent(0, new object[] {ValuesJSON});
    }
    public bool FireEvent_CNF(SE.Agile.Symbols.SmartManager_v1_0.CNFEventArgs ea)
    {
      object[] _values_ = new object[1];
      if (ea.ValuesJSON != null) _values_[0] = ea.ValuesJSON;
      return ((IHMIAccessorOutput)this).FireEvent(0, _values_);
    }
    public bool FireEvent_CNF(System.String ValuesJSON, bool ignore_ValuesJSON)
    {
      object[] _values_ = new object[1];
      if (!ignore_ValuesJSON) _values_[0] = ValuesJSON;
      return ((IHMIAccessorOutput)this).FireEvent(0, _values_);
    }
    public bool FireEvent_GET_GRAPH(System.Int16 GetStart)
    {
      return ((IHMIAccessorOutput)this).FireEvent(1, new object[] {GetStart});
    }
    public bool FireEvent_GET_GRAPH(SE.Agile.Symbols.SmartManager_v1_0.GET_GRAPHEventArgs ea)
    {
      object[] _values_ = new object[1];
      if (ea.GetStart.HasValue) _values_[0] = ea.GetStart.Value;
      return ((IHMIAccessorOutput)this).FireEvent(1, _values_);
    }
    public bool FireEvent_GET_GRAPH(System.Int16 GetStart, bool ignore_GetStart)
    {
      object[] _values_ = new object[1];
      if (!ignore_GetStart) _values_[0] = GetStart;
      return ((IHMIAccessorOutput)this).FireEvent(1, _values_);
    }
    public bool FireEvent_SEND_GRAPH(System.String Graph)
    {
      return ((IHMIAccessorOutput)this).FireEvent(2, new object[] {Graph});
    }
    public bool FireEvent_SEND_GRAPH(SE.Agile.Symbols.SmartManager_v1_0.SEND_GRAPHEventArgs ea)
    {
      object[] _values_ = new object[1];
      if (ea.Graph != null) _values_[0] = ea.Graph;
      return ((IHMIAccessorOutput)this).FireEvent(2, _values_);
    }
    public bool FireEvent_SEND_GRAPH(System.String Graph, bool ignore_Graph)
    {
      object[] _values_ = new object[1];
      if (!ignore_Graph) _values_[0] = Graph;
      return ((IHMIAccessorOutput)this).FireEvent(2, _values_);
    }
    public bool FireEvent_VALUES_SET()
    {
      return ((IHMIAccessorOutput)this).FireEvent(3, new object[] {});
    }
    public bool FireEvent_VALUES_SET(SE.Agile.Symbols.SmartManager_v1_0.VALUES_SETEventArgs ea)
    {
      object[] _values_ = new object[0];
      return ((IHMIAccessorOutput)this).FireEvent(3, _values_);
    }
    public bool FireEvent_OPC_BOOL(System.String OpcTagname)
    {
      return ((IHMIAccessorOutput)this).FireEvent(4, new object[] {OpcTagname});
    }
    public bool FireEvent_OPC_BOOL(SE.Agile.Symbols.SmartManager_v1_0.OPC_BOOLEventArgs ea)
    {
      object[] _values_ = new object[1];
      if (ea.OpcTagname != null) _values_[0] = ea.OpcTagname;
      return ((IHMIAccessorOutput)this).FireEvent(4, _values_);
    }
    public bool FireEvent_OPC_BOOL(System.String OpcTagname, bool ignore_OpcTagname)
    {
      object[] _values_ = new object[1];
      if (!ignore_OpcTagname) _values_[0] = OpcTagname;
      return ((IHMIAccessorOutput)this).FireEvent(4, _values_);
    }
    public bool FireEvent_OPC_INT(System.String OpcTagname)
    {
      return ((IHMIAccessorOutput)this).FireEvent(5, new object[] {OpcTagname});
    }
    public bool FireEvent_OPC_INT(SE.Agile.Symbols.SmartManager_v1_0.OPC_INTEventArgs ea)
    {
      object[] _values_ = new object[1];
      if (ea.OpcTagname != null) _values_[0] = ea.OpcTagname;
      return ((IHMIAccessorOutput)this).FireEvent(5, _values_);
    }
    public bool FireEvent_OPC_INT(System.String OpcTagname, bool ignore_OpcTagname)
    {
      object[] _values_ = new object[1];
      if (!ignore_OpcTagname) _values_[0] = OpcTagname;
      return ((IHMIAccessorOutput)this).FireEvent(5, _values_);
    }
    public bool FireEvent_OPC_REAL(System.String OpcTagname)
    {
      return ((IHMIAccessorOutput)this).FireEvent(6, new object[] {OpcTagname});
    }
    public bool FireEvent_OPC_REAL(SE.Agile.Symbols.SmartManager_v1_0.OPC_REALEventArgs ea)
    {
      object[] _values_ = new object[1];
      if (ea.OpcTagname != null) _values_[0] = ea.OpcTagname;
      return ((IHMIAccessorOutput)this).FireEvent(6, _values_);
    }
    public bool FireEvent_OPC_REAL(System.String OpcTagname, bool ignore_OpcTagname)
    {
      object[] _values_ = new object[1];
      if (!ignore_OpcTagname) _values_[0] = OpcTagname;
      return ((IHMIAccessorOutput)this).FireEvent(6, _values_);
    }
    public bool FireEvent_OPC_DINT(System.String OpcTagname)
    {
      return ((IHMIAccessorOutput)this).FireEvent(7, new object[] {OpcTagname});
    }
    public bool FireEvent_OPC_DINT(SE.Agile.Symbols.SmartManager_v1_0.OPC_DINTEventArgs ea)
    {
      object[] _values_ = new object[1];
      if (ea.OpcTagname != null) _values_[0] = ea.OpcTagname;
      return ((IHMIAccessorOutput)this).FireEvent(7, _values_);
    }
    public bool FireEvent_OPC_DINT(System.String OpcTagname, bool ignore_OpcTagname)
    {
      object[] _values_ = new object[1];
      if (!ignore_OpcTagname) _values_[0] = OpcTagname;
      return ((IHMIAccessorOutput)this).FireEvent(7, _values_);
    }
    public bool FireEvent_OPC_STRING(System.String OpcTagname)
    {
      return ((IHMIAccessorOutput)this).FireEvent(8, new object[] {OpcTagname});
    }
    public bool FireEvent_OPC_STRING(SE.Agile.Symbols.SmartManager_v1_0.OPC_STRINGEventArgs ea)
    {
      object[] _values_ = new object[1];
      if (ea.OpcTagname != null) _values_[0] = ea.OpcTagname;
      return ((IHMIAccessorOutput)this).FireEvent(8, _values_);
    }
    public bool FireEvent_OPC_STRING(System.String OpcTagname, bool ignore_OpcTagname)
    {
      object[] _values_ = new object[1];
      if (!ignore_OpcTagname) _values_[0] = OpcTagname;
      return ((IHMIAccessorOutput)this).FireEvent(8, _values_);
    }
    public bool FireEvent_GET_CONFIG(System.String MessageDst)
    {
      return ((IHMIAccessorOutput)this).FireEvent(9, new object[] {MessageDst});
    }
    public bool FireEvent_GET_CONFIG(SE.Agile.Symbols.SmartManager_v1_0.GET_CONFIGEventArgs ea)
    {
      object[] _values_ = new object[1];
      if (ea.MessageDst != null) _values_[0] = ea.MessageDst;
      return ((IHMIAccessorOutput)this).FireEvent(9, _values_);
    }
    public bool FireEvent_GET_CONFIG(System.String MessageDst, bool ignore_MessageDst)
    {
      object[] _values_ = new object[1];
      if (!ignore_MessageDst) _values_[0] = MessageDst;
      return ((IHMIAccessorOutput)this).FireEvent(9, _values_);
    }

  }
}
#endregion #SmartManager_v1_0_HMI;

#endregion Definitions;
