/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 9/25/2025
 * Time: 3:34 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.SmartManager_v1_0
{
	/// <summary>
	/// Summary description for sManager.
	/// </summary>
	partial class sManager
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.drawnButtonGet = new NxtControl.GuiFramework.DrawnButton();
			// 
			// drawnButtonGet
			// 
			this.drawnButtonGet.Bounds = new NxtControl.Drawing.RectF(((float)(56D)), ((float)(24D)), ((float)(72D)), ((float)(25D)));
			this.drawnButtonGet.Brush = new NxtControl.Drawing.Brush("ButtonBrush");
			this.drawnButtonGet.Font = new NxtControl.Drawing.Font("ButtonFont");
			this.drawnButtonGet.InnerBorderColor = new NxtControl.Drawing.Color("ButtonInnerBorderColor");
			this.drawnButtonGet.Name = "drawnButtonGet";
			this.drawnButtonGet.Pen = new NxtControl.Drawing.Pen("ButtonPen");
			this.drawnButtonGet.Radius = 4D;
			this.drawnButtonGet.Text = "Get";
			this.drawnButtonGet.TextColor = new NxtControl.Drawing.Color("ButtonTextColor");
			this.drawnButtonGet.TextColorMouseDown = new NxtControl.Drawing.Color("ButtonTextColorMouseDown");
			this.drawnButtonGet.Use3DEffect = false;
			this.drawnButtonGet.Click += new System.EventHandler(this.DrawnButtonGetClick);
			// 
			// sManager
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.drawnButtonGet});
			this.SymbolSize = new System.Drawing.Size(200, 200);

		}
		private NxtControl.GuiFramework.DrawnButton drawnButtonGet;
		#endregion
	}
}
