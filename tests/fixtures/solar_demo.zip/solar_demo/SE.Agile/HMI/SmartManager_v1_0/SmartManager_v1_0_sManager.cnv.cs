/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 9/25/2025
 * Time: 3:34 PM
 * 
 */

using System;
using NxtControl.GuiFramework;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Text.Json;

namespace SE.Agile.Symbols.SmartManager_v1_0
{
	/// <summary>
	/// Description of sManager.
	/// </summary>
	public partial class sManager : NxtControl.GuiFramework.HMISymbol
	{
		Dictionary<int, SmartElement> smartElementsById = new Dictionary<int, SmartElement>();
        Form previewDialog;
		BindingSource bindingList;
		System.Windows.Forms.DataGridView dataGridView;
		List<SmartElement> smartElementList;
		
		bool fetchingParameters = false;
		SmartElement se; // Handle to the smart element that is waiting CONF_EMPTY or PARAM events - set by fetchParameters()

		public static readonly Dictionary<int, string> NodeTypeById = new Dictionary<int, string>
		{
		    { 1,   "MQTT connection" },
		    { 2,   "Smart valve" },
		    { 11,  "Analog output" },
		    { 12,  "Contact input" },
		    { 13,  "Fixed speed motor" },
		    { 14,  "PID Control" },
		    { 15,  "Transmitter" },
		    { 16,  "Two position actuator" },
		    { 17,  "Variable speed motor" },
		    { 55,  "EV charger" },
		    { 101, "Virtual module: AI" },
		    { 102, "Virtual module: AO" },
		    { 103, "Virtual module: DI" },
		    { 104, "Virtual module: DO" },
		    { 201, "Sequence" }
		};

		
		int readCount; // Tracks the number of pages received from the Basic block GET_GRAPH request
		bool loading;
		
		public sManager()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			this.END_CNF_Fired += END_CNF_Fired_EventHandler;
			this.AssignRename_CNF_Fired += AssignRename_CNF_Fired_EventHandler;
			this.CONF_EMPTY_Fired += CONF_EMPTY_Fired_EventHandler;
			this.PARAM_Fired += PARAM_Fired_EventHandler;
		}

		void DrawnButtonGetClick(object sender, EventArgs e)
		{
			smartElementsById = new Dictionary<int, SmartElement>();
			loading = true;
			readCount = 0;
			FireEvent_GET_GRAPH(0); 
		}

		void END_CNF_Fired_EventHandler(object sender, END_CNFEventArgs e)
		{
        	if(!loading)
				return;
            
        	string[] result = JsonSerializer.Deserialize<string[]>(e.Payload);

            for (int i = 0; i < result.Length - 1; i += 2)
            {
                string[] elements = result[i].Split(',');
                int id = -1;
                int type = -1;
                int a = -1;
                int b = -1;
                int c = -1;

                int.TryParse(elements[0], out id);
                int.TryParse(elements[1], out type);
                int.TryParse(elements[2], out a);
                int.TryParse(elements[3], out b);
                int.TryParse(elements[4], out c);


                var smartelement = new SmartElement
                {
                    Id = id,
                    Name = result[i + 1],
                    NodeType = type,
                    Connections = new int[] { a, b, c }
                };

                smartElementsById[smartelement.Id] = smartelement; // Overwrites if key already exists
            }


            if (smartElementsById.Count < e.Size && readCount < 100)
            {
                // Request the next page of values from the basic block array
                readCount++;
                FireEvent_GET_GRAPH((short)smartElementsById.Count);
            }
            else
            {
				loading = false;
				
				if (!loading && previewDialog != null && !previewDialog.IsDisposed && previewDialog.Visible)
				{
					smartElementList = new List<SmartElement>(smartElementsById.Values);
									// Bind to DataGridView
		            bindingList = new BindingSource();
					bindingList.DataSource = smartElementList;
					dataGridView.DataSource = bindingList;
					dataGridView.Refresh();
				
					//bindingList.ResetBindings(false);
				}
				else
				{
					ShowData();
				}
            }
		}

		void ShowData()
		{
			int height = 400;
			int width = 800;
			
            // Create a new form
            previewDialog  = new Form
            {
                Text = "Registered objects",
                Width = width,
                Height = height,
                StartPosition = FormStartPosition.CenterParent,
                ShowIcon = false
            };
           
            // Create a DataGridView
			dataGridView = new System.Windows.Forms.DataGridView
			{
			    Dock = DockStyle.Fill,
			    AutoGenerateColumns = false,
			    ReadOnly = true,
			    AllowUserToAddRows = false,
			    // Do NOT set AutoSizeColumnsMode here, we'll control per-column
			};
			
			dataGridView.CellClick += DataGridView_CellClick;
			
			// Define columns with fixed widths
			var colId = new DataGridViewTextBoxColumn { DataPropertyName = "Id", HeaderText = "Id", Width = 40, AutoSizeMode = DataGridViewAutoSizeColumnMode.None };
			var colName = new DataGridViewTextBoxColumn { DataPropertyName = "Name", HeaderText = "Name", Width = 120, AutoSizeMode = DataGridViewAutoSizeColumnMode.None };
			var colType = new DataGridViewTextBoxColumn { DataPropertyName = "Type", HeaderText = "Type", Width = 140, AutoSizeMode = DataGridViewAutoSizeColumnMode.None };
			var colA = new DataGridViewTextBoxColumn { DataPropertyName = "A", HeaderText = "A", Width = 40, AutoSizeMode = DataGridViewAutoSizeColumnMode.None };
			var colB = new DataGridViewTextBoxColumn { DataPropertyName = "B", HeaderText = "B", Width = 40, AutoSizeMode = DataGridViewAutoSizeColumnMode.None };
			var colC = new DataGridViewTextBoxColumn { DataPropertyName = "C", HeaderText = "C", Width = 40, AutoSizeMode = DataGridViewAutoSizeColumnMode.None };
		
			// Last column: auto-fit (fill)
			var colPath = new DataGridViewTextBoxColumn { DataPropertyName = "Path", HeaderText = "Path", AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill };
			
			// Add columns to grid
			dataGridView.Columns.AddRange(new DataGridViewColumn[] { colId, colName, colType, colA, colB, colC, colPath });
            
            smartElementList = new List<SmartElement>(smartElementsById.Values);
            
			// Bind to DataGridView
            bindingList = new BindingSource();
			bindingList.DataSource = smartElementList;
			dataGridView.DataSource = bindingList;

			// Add the grid to the form
			previewDialog.Controls.Add(dataGridView);

            // Show the form as a dialog
            previewDialog.ShowDialog();
		}

		private void DataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
		{
		    // Ignore header clicks
		    if (e.RowIndex < 0)
		        return;
		
		    // Get the clicked row's data object
		    var row = dataGridView.Rows[e.RowIndex];
		    
			int id = -1;
			if (row.Cells[0].Value != null)
    			int.TryParse(row.Cells[0].Value.ToString(), out id);
			
		    //if(!fetchingParameters && smartElementsById.ContainsKey(id))
            if (smartElementsById.ContainsKey(id))
            {
		    	se = smartElementsById[id];
		    	fetchingParameters = true;
		    	FireEvent_GET_CONFIG($"SmartId{id}"); // Expected to return CONF_EMPTY or PARAM (with Parameters) input events
		    }
		}

		
		void AssignRename_CNF_Fired_EventHandler(object sender, AssignRename_CNFEventArgs e)
		{
			if (!loading && previewDialog != null && !previewDialog.IsDisposed && previewDialog.Visible)
			{
				loading = true;
				readCount = 0;
				FireEvent_GET_GRAPH(0); 
			}
		}

		void CONF_EMPTY_Fired_EventHandler(object sender, CONF_EMPTYEventArgs e)
		{
			fetchingParameters = false;
		}

		void PARAM_Fired_EventHandler(object sender, PARAMEventArgs e)
		{
			// Incoming Parameter JSON Payload
			if(se != null && e.Parameters.Length > 0 && fetchingParameters)
			{
				se.Parameters.Clear();
				
	        	string[] kvArray = JsonSerializer.Deserialize<string[]>((string)e.Parameters);
				for (int i = 0; i < kvArray.Length; i += 2)
				{
					var pName = kvArray[i];
					var pValue = kvArray[i + 1];

					if (pName.StartsWith("_", StringComparison.InvariantCultureIgnoreCase))
				    {
				    	//internal parameter
				    	if(pName == "_Path")
				    	{
				    		se.Path = pValue;
							bindingList.ResetBindings(false);
				    	}
				    }
				    else
				    {
						se.Parameters.Add(new Parameter
						{
							Name = pName,
							Value = pValue
						});
					}
				}
			}
			fetchingParameters = false;
		}
		
		
		 class SmartElement
        {
			public int Id { get; set; }				//6th element in the array
			public string Name { get; set; }
			public int NodeType { get; set; }		//5th element in the array           
            public int[] Connections { get; set; } 	//first 4 elements of the array
            public List<Parameter> Parameters = new List<Parameter>();
        	
            public string Path { get; set; }
            
            
            	
            public string Type
			{
			    get
			    {
			    	return NodeTypeById.ContainsKey(NodeType) ? NodeTypeById[NodeType] : NodeType.ToString("D3");
			    }
			}
            
            public string A
			{
			    get
			    {
			        return (Connections != null && Connections.Length > 0 && Connections[0] > -1) ? Connections[0].ToString() : string.Empty;
			    }
			}	

            public string B
			{
			    get
			    {
			        return (Connections != null && Connections.Length > 1 && Connections[1] > -1) ? Connections[1].ToString() : string.Empty;
			    }
			}	

            public string C
			{
			    get
			    {
			        return (Connections != null && Connections.Length > 2 && Connections[2] > -1) ? Connections[2].ToString() : string.Empty;
			    }
			}	            
		 }
		
		class Parameter
		{
			public string Name {get; set; }
			public string Value {get; set; }
		}
		
	}
}
