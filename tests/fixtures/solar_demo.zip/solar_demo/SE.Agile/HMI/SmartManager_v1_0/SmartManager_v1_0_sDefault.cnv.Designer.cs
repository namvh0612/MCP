/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 7/16/2025
 * Time: 9:15 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.SmartManager_v1_0
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sDefault
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Id = new System.HMI.Symbols.Base.Execute<int>();
			this.drawnButton1 = new NxtControl.GuiFramework.DrawnButton();
			this.drawnTextBoxDictionary = new NxtControl.GuiFramework.DrawnTextBox();
			this.drawnTextBoxModules = new NxtControl.GuiFramework.DrawnTextBox();
			this.drawnTextBoxRatData = new NxtControl.GuiFramework.DrawnTextBox();
			this.labelDictionary = new NxtControl.GuiFramework.Label();
			this.labelModules = new NxtControl.GuiFramework.Label();
			this.labelRat = new NxtControl.GuiFramework.Label();
			this.labelLog = new NxtControl.GuiFramework.Label();
			this.drawnButtonCNF = new NxtControl.GuiFramework.DrawnButton();
			this.dataGridViewLog = new NxtControl.GuiFramework.DataGridView();
			this.freeTextConnectionStatus = new NxtControl.GuiFramework.FreeText();
			this.labelOPC = new NxtControl.GuiFramework.Label();
			this.drawnButtonDictionary = new NxtControl.GuiFramework.DrawnButton();
			this.drawnButtonModules = new NxtControl.GuiFramework.DrawnButton();
			this.drawnButtonParameters = new NxtControl.GuiFramework.DrawnButton();
			this.drawnButtonPreview = new NxtControl.GuiFramework.DrawnButton();
			this.Res = new System.HMI.Symbols.Base.Execute<string>();
			this.ConnectStatus = new System.HMI.Symbols.Base.Execute<string>();
			this.freeTextFetchProgress = new NxtControl.GuiFramework.FreeText();
			((System.ComponentModel.ISupportInitialize)(this.dataGridViewLog)).BeginInit();
			// 
			// Id
			// 
			this.Id.BeginInit();
			this.Id.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.Id.IsOnlyInput = true;
			this.Id.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.Id.Name = "Id";
			this.Id.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.Id.TagName = "";
			this.Id.Value = 0;
			this.Id.EndInit();
			// 
			// drawnButton1
			// 
			this.drawnButton1.Bounds = new NxtControl.Drawing.RectF(((float)(456D)), ((float)(144D)), ((float)(64D)), ((float)(25D)));
			this.drawnButton1.Brush = new NxtControl.Drawing.Brush("ButtonBrush");
			this.drawnButton1.Font = new NxtControl.Drawing.Font("ButtonFont");
			this.drawnButton1.InnerBorderColor = new NxtControl.Drawing.Color("ButtonInnerBorderColor");
			this.drawnButton1.Name = "drawnButton1";
			this.drawnButton1.Pen = new NxtControl.Drawing.Pen("ButtonPen");
			this.drawnButton1.Radius = 4D;
			this.drawnButton1.Text = "Load";
			this.drawnButton1.TextColor = new NxtControl.Drawing.Color("ButtonTextColor");
			this.drawnButton1.TextColorMouseDown = new NxtControl.Drawing.Color("ButtonTextColorMouseDown");
			this.drawnButton1.Use3DEffect = false;
			this.drawnButton1.Click += new System.EventHandler(this.LoadCsv);
			// 
			// drawnTextBoxDictionary
			// 
			this.drawnTextBoxDictionary.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.drawnTextBoxDictionary.Bounds = new NxtControl.Drawing.RectF(((float)(104D)), ((float)(48D)), ((float)(552D)), ((float)(25D)));
			this.drawnTextBoxDictionary.Font = new NxtControl.Drawing.Font("TextBoxFont");
			this.drawnTextBoxDictionary.FontScale = true;
			this.drawnTextBoxDictionary.Maximum = 100D;
			this.drawnTextBoxDictionary.Minimum = 0D;
			this.drawnTextBoxDictionary.Name = "drawnTextBoxDictionary";
			this.drawnTextBoxDictionary.Pen = new NxtControl.Drawing.Pen("TextBoxPen");
			this.drawnTextBoxDictionary.SetTextWhenLostFocus = true;
			this.drawnTextBoxDictionary.Text = "C:\\Work\\GPA\\GPA Dictionary.csv";
			this.drawnTextBoxDictionary.TextAutoSizeHorizontalOffset = 10;
			this.drawnTextBoxDictionary.TextAutoSizeVerticalOffset = 2;
			this.drawnTextBoxDictionary.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// drawnTextBoxModules
			// 
			this.drawnTextBoxModules.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.drawnTextBoxModules.Bounds = new NxtControl.Drawing.RectF(((float)(104D)), ((float)(80D)), ((float)(552D)), ((float)(25D)));
			this.drawnTextBoxModules.Font = new NxtControl.Drawing.Font("TextBoxFont");
			this.drawnTextBoxModules.FontScale = true;
			this.drawnTextBoxModules.Maximum = 100D;
			this.drawnTextBoxModules.Minimum = 0D;
			this.drawnTextBoxModules.Name = "drawnTextBoxModules";
			this.drawnTextBoxModules.Pen = new NxtControl.Drawing.Pen("TextBoxPen");
			this.drawnTextBoxModules.SetTextWhenLostFocus = true;
			this.drawnTextBoxModules.Text = "C:\\Work\\GPA\\GPA IO.csv";
			this.drawnTextBoxModules.TextAutoSizeHorizontalOffset = 10;
			this.drawnTextBoxModules.TextAutoSizeVerticalOffset = 2;
			this.drawnTextBoxModules.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// drawnTextBoxRatData
			// 
			this.drawnTextBoxRatData.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.drawnTextBoxRatData.Bounds = new NxtControl.Drawing.RectF(((float)(104D)), ((float)(112D)), ((float)(552D)), ((float)(25D)));
			this.drawnTextBoxRatData.Font = new NxtControl.Drawing.Font("TextBoxFont");
			this.drawnTextBoxRatData.FontScale = true;
			this.drawnTextBoxRatData.Maximum = 100D;
			this.drawnTextBoxRatData.Minimum = 0D;
			this.drawnTextBoxRatData.Name = "drawnTextBoxRatData";
			this.drawnTextBoxRatData.Pen = new NxtControl.Drawing.Pen("TextBoxPen");
			this.drawnTextBoxRatData.SetTextWhenLostFocus = true;
			this.drawnTextBoxRatData.Text = "C:\\Work\\GPA\\GPA RAT.csv";
			this.drawnTextBoxRatData.TextAutoSizeHorizontalOffset = 10;
			this.drawnTextBoxRatData.TextAutoSizeVerticalOffset = 2;
			this.drawnTextBoxRatData.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// labelDictionary
			// 
			this.labelDictionary.AngleIgnore = true;
			this.labelDictionary.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.labelDictionary.Bounds = new NxtControl.Drawing.RectF(((float)(8D)), ((float)(48D)), ((float)(88D)), ((float)(26D)));
			this.labelDictionary.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.labelDictionary.Font = new NxtControl.Drawing.Font("LabelFont");
			this.labelDictionary.FontScale = true;
			this.labelDictionary.Name = "labelDictionary";
			this.labelDictionary.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.labelDictionary.Text = "Dictionary:";
			this.labelDictionary.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.labelDictionary.TextAutoSizeHorizontalOffset = 10;
			this.labelDictionary.TextColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.labelDictionary.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// labelModules
			// 
			this.labelModules.AngleIgnore = true;
			this.labelModules.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.labelModules.Bounds = new NxtControl.Drawing.RectF(((float)(8D)), ((float)(80D)), ((float)(88D)), ((float)(26D)));
			this.labelModules.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.labelModules.Font = new NxtControl.Drawing.Font("LabelFont");
			this.labelModules.FontScale = true;
			this.labelModules.Name = "labelModules";
			this.labelModules.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.labelModules.Text = "Modules:";
			this.labelModules.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.labelModules.TextAutoSizeHorizontalOffset = 10;
			this.labelModules.TextColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.labelModules.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// labelRat
			// 
			this.labelRat.AngleIgnore = true;
			this.labelRat.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.labelRat.Bounds = new NxtControl.Drawing.RectF(((float)(8D)), ((float)(112D)), ((float)(88D)), ((float)(26D)));
			this.labelRat.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.labelRat.Font = new NxtControl.Drawing.Font("LabelFont");
			this.labelRat.FontScale = true;
			this.labelRat.Name = "labelRat";
			this.labelRat.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.labelRat.Text = "RAT data:";
			this.labelRat.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.labelRat.TextAutoSizeHorizontalOffset = 10;
			this.labelRat.TextColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.labelRat.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// labelLog
			// 
			this.labelLog.AngleIgnore = true;
			this.labelLog.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.labelLog.Bounds = new NxtControl.Drawing.RectF(((float)(8D)), ((float)(168D)), ((float)(80D)), ((float)(26D)));
			this.labelLog.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.labelLog.Font = new NxtControl.Drawing.Font("LabelFont");
			this.labelLog.FontScale = true;
			this.labelLog.Name = "labelLog";
			this.labelLog.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.labelLog.Text = "Log:";
			this.labelLog.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.labelLog.TextAutoSizeHorizontalOffset = 10;
			this.labelLog.TextColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.labelLog.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// drawnButtonCNF
			// 
			this.drawnButtonCNF.Bounds = new NxtControl.Drawing.RectF(((float)(624D)), ((float)(144D)), ((float)(64D)), ((float)(25D)));
			this.drawnButtonCNF.Brush = new NxtControl.Drawing.Brush("ButtonBrush");
			this.drawnButtonCNF.Enabled = false;
			this.drawnButtonCNF.Font = new NxtControl.Drawing.Font("ButtonFont");
			this.drawnButtonCNF.InnerBorderColor = new NxtControl.Drawing.Color("ButtonInnerBorderColor");
			this.drawnButtonCNF.Name = "drawnButtonCNF";
			this.drawnButtonCNF.Pen = new NxtControl.Drawing.Pen("ButtonPen");
			this.drawnButtonCNF.Radius = 4D;
			this.drawnButtonCNF.Text = "Apply";
			this.drawnButtonCNF.TextColor = new NxtControl.Drawing.Color("ButtonTextColor");
			this.drawnButtonCNF.TextColorMouseDown = new NxtControl.Drawing.Color("ButtonTextColorMouseDown");
			this.drawnButtonCNF.Use3DEffect = false;
			this.drawnButtonCNF.Click += new System.EventHandler(this.Apply);
			// 
			// dataGridViewLog
			// 
			this.dataGridViewLog.GridColor = System.Drawing.SystemColors.Control;
			this.dataGridViewLog.Location = new System.Drawing.Point(104, 176);
			this.dataGridViewLog.Name = "dataGridViewLog";
			this.dataGridViewLog.Size = new System.Drawing.Size(585, 145);
			this.dataGridViewLog.TabIndex = 0;
			this.dataGridViewLog.Text = "dataGridView1";
			// 
			// freeTextConnectionStatus
			// 
			this.freeTextConnectionStatus.Color = new NxtControl.Drawing.Color("LabelTextColor");
			this.freeTextConnectionStatus.Font = new NxtControl.Drawing.Font("LabelFont");
			this.freeTextConnectionStatus.Location = new NxtControl.Drawing.PointF(104D, 21D);
			this.freeTextConnectionStatus.Name = "freeTextConnectionStatus";
			// 
			// labelOPC
			// 
			this.labelOPC.AngleIgnore = true;
			this.labelOPC.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.labelOPC.Bounds = new NxtControl.Drawing.RectF(((float)(8D)), ((float)(16D)), ((float)(104D)), ((float)(26D)));
			this.labelOPC.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.labelOPC.Font = new NxtControl.Drawing.Font("LabelFont");
			this.labelOPC.FontScale = true;
			this.labelOPC.Name = "labelOPC";
			this.labelOPC.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.labelOPC.Text = "OPC Connection:";
			this.labelOPC.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.labelOPC.TextAutoSizeHorizontalOffset = 10;
			this.labelOPC.TextColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.labelOPC.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// drawnButtonDictionary
			// 
			this.drawnButtonDictionary.Bounds = new NxtControl.Drawing.RectF(((float)(664D)), ((float)(48D)), ((float)(24D)), ((float)(25D)));
			this.drawnButtonDictionary.Brush = new NxtControl.Drawing.Brush("ButtonBrush");
			this.drawnButtonDictionary.Font = new NxtControl.Drawing.Font("ButtonFont");
			this.drawnButtonDictionary.InnerBorderColor = new NxtControl.Drawing.Color("ButtonInnerBorderColor");
			this.drawnButtonDictionary.Name = "drawnButtonDictionary";
			this.drawnButtonDictionary.Pen = new NxtControl.Drawing.Pen("ButtonPen");
			this.drawnButtonDictionary.Radius = 4D;
			this.drawnButtonDictionary.Text = ". . .";
			this.drawnButtonDictionary.TextColor = new NxtControl.Drawing.Color("ButtonTextColor");
			this.drawnButtonDictionary.TextColorMouseDown = new NxtControl.Drawing.Color("ButtonTextColorMouseDown");
			this.drawnButtonDictionary.Use3DEffect = false;
			this.drawnButtonDictionary.Click += new System.EventHandler(this.ShowFileDialogDictionary);
			// 
			// drawnButtonModules
			// 
			this.drawnButtonModules.Bounds = new NxtControl.Drawing.RectF(((float)(664D)), ((float)(80D)), ((float)(24D)), ((float)(25D)));
			this.drawnButtonModules.Brush = new NxtControl.Drawing.Brush("ButtonBrush");
			this.drawnButtonModules.Font = new NxtControl.Drawing.Font("ButtonFont");
			this.drawnButtonModules.InnerBorderColor = new NxtControl.Drawing.Color("ButtonInnerBorderColor");
			this.drawnButtonModules.Name = "drawnButtonModules";
			this.drawnButtonModules.Pen = new NxtControl.Drawing.Pen("ButtonPen");
			this.drawnButtonModules.Radius = 4D;
			this.drawnButtonModules.Text = ". . .";
			this.drawnButtonModules.TextColor = new NxtControl.Drawing.Color("ButtonTextColor");
			this.drawnButtonModules.TextColorMouseDown = new NxtControl.Drawing.Color("ButtonTextColorMouseDown");
			this.drawnButtonModules.Use3DEffect = false;
			this.drawnButtonModules.Click += new System.EventHandler(this.ShowFileDialogModules);
			// 
			// drawnButtonParameters
			// 
			this.drawnButtonParameters.Bounds = new NxtControl.Drawing.RectF(((float)(664D)), ((float)(112D)), ((float)(24D)), ((float)(25D)));
			this.drawnButtonParameters.Brush = new NxtControl.Drawing.Brush("ButtonBrush");
			this.drawnButtonParameters.Font = new NxtControl.Drawing.Font("ButtonFont");
			this.drawnButtonParameters.InnerBorderColor = new NxtControl.Drawing.Color("ButtonInnerBorderColor");
			this.drawnButtonParameters.Name = "drawnButtonParameters";
			this.drawnButtonParameters.Pen = new NxtControl.Drawing.Pen("ButtonPen");
			this.drawnButtonParameters.Radius = 4D;
			this.drawnButtonParameters.Text = ". . .";
			this.drawnButtonParameters.TextColor = new NxtControl.Drawing.Color("ButtonTextColor");
			this.drawnButtonParameters.TextColorMouseDown = new NxtControl.Drawing.Color("ButtonTextColorMouseDown");
			this.drawnButtonParameters.Use3DEffect = false;
			this.drawnButtonParameters.Click += new System.EventHandler(this.ShowFileDialogParameters);
			// 
			// drawnButtonPreview
			// 
			this.drawnButtonPreview.Bounds = new NxtControl.Drawing.RectF(((float)(528D)), ((float)(144D)), ((float)(64D)), ((float)(25D)));
			this.drawnButtonPreview.Brush = new NxtControl.Drawing.Brush("ButtonBrush");
			this.drawnButtonPreview.Enabled = false;
			this.drawnButtonPreview.Font = new NxtControl.Drawing.Font("ButtonFont");
			this.drawnButtonPreview.InnerBorderColor = new NxtControl.Drawing.Color("ButtonInnerBorderColor");
			this.drawnButtonPreview.Name = "drawnButtonPreview";
			this.drawnButtonPreview.Pen = new NxtControl.Drawing.Pen("ButtonPen");
			this.drawnButtonPreview.Radius = 4D;
			this.drawnButtonPreview.Text = "Preview";
			this.drawnButtonPreview.TextColor = new NxtControl.Drawing.Color("ButtonTextColor");
			this.drawnButtonPreview.TextColorMouseDown = new NxtControl.Drawing.Color("ButtonTextColorMouseDown");
			this.drawnButtonPreview.Use3DEffect = false;
			this.drawnButtonPreview.Click += new System.EventHandler(this.PreviewPayload);
			// 
			// Res
			// 
			this.Res.BeginInit();
			this.Res.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.Res.IsOnlyInput = true;
			this.Res.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.Res.Name = "Res";
			this.Res.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.Res.TagName = "Res";
			this.Res.Value = null;
			this.Res.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.Res_1ValueChanged);
			this.Res.EndInit();
			// 
			// ConnectStatus
			// 
			this.ConnectStatus.BeginInit();
			this.ConnectStatus.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.ConnectStatus.IsOnlyInput = true;
			this.ConnectStatus.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.ConnectStatus.Name = "ConnectStatus";
			this.ConnectStatus.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.ConnectStatus.TagName = "ConnectStatus";
			this.ConnectStatus.Value = null;
			this.ConnectStatus.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.ErrorValueChanged);
			this.ConnectStatus.EndInit();
			// 
			// freeTextFetchProgress
			// 
			this.freeTextFetchProgress.Color = new NxtControl.Drawing.Color("LabelTextColor");
			this.freeTextFetchProgress.Font = new NxtControl.Drawing.Font("LabelFont");
			this.freeTextFetchProgress.Location = new NxtControl.Drawing.PointF(104D, 152D);
			this.freeTextFetchProgress.Name = "freeTextFetchProgress";
			// 
			// sDefault
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.Id,
			this.drawnButton1,
			this.drawnTextBoxDictionary,
			this.drawnTextBoxModules,
			this.drawnTextBoxRatData,
			this.labelDictionary,
			this.labelModules,
			this.labelRat,
			this.labelLog,
			this.drawnButtonCNF,
			this.dataGridViewLog,
			this.freeTextConnectionStatus,
			this.labelOPC,
			this.drawnButtonDictionary,
			this.drawnButtonModules,
			this.drawnButtonParameters,
			this.drawnButtonPreview,
			this.Res,
			this.ConnectStatus,
			this.freeTextFetchProgress});
			this.SymbolSize = new System.Drawing.Size(696, 360);
			((System.ComponentModel.ISupportInitialize)(this.dataGridViewLog)).EndInit();

		}
		private System.HMI.Symbols.Base.Execute<int> Id;
		private NxtControl.GuiFramework.DrawnButton drawnButton1;
		private NxtControl.GuiFramework.DrawnTextBox drawnTextBoxDictionary;
		private NxtControl.GuiFramework.DrawnTextBox drawnTextBoxModules;
		private NxtControl.GuiFramework.DrawnTextBox drawnTextBoxRatData;
		private NxtControl.GuiFramework.Label labelDictionary;
		private NxtControl.GuiFramework.Label labelModules;
		private NxtControl.GuiFramework.Label labelRat;
		private NxtControl.GuiFramework.Label labelLog;
		private NxtControl.GuiFramework.DrawnButton drawnButtonCNF;
		private NxtControl.GuiFramework.DataGridView dataGridViewLog;
		private NxtControl.GuiFramework.FreeText freeTextConnectionStatus;
		private NxtControl.GuiFramework.Label labelOPC;
		private NxtControl.GuiFramework.DrawnButton drawnButtonDictionary;
		private NxtControl.GuiFramework.DrawnButton drawnButtonModules;
		private NxtControl.GuiFramework.DrawnButton drawnButtonParameters;
		private NxtControl.GuiFramework.DrawnButton drawnButtonPreview;
		private System.HMI.Symbols.Base.Execute<string> Res;
		private System.HMI.Symbols.Base.Execute<string> ConnectStatus;
		private NxtControl.GuiFramework.FreeText freeTextFetchProgress;
		#endregion
	}
}
