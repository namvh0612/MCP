/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 3/14/2025
 * Time: 1:36 PM
 * 
 */

using System;
using NxtControl.GuiFramework;
using System.ComponentModel;

namespace SE.Agile.Symbols.HMI_Indication_Bool_v1_0
{
	/// <summary>
	/// Description of sDefault.
	/// </summary>
	public partial class sIndicatorMiddleNamed : NxtControl.GuiFramework.HMISymbol
	{
		private string _labelText = "LabelText";
		
		public sIndicatorMiddleNamed()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();

		}
		
		[DefaultValue("LabelText"), RefreshProperties(RefreshProperties.All), Category("Symbol")]
		public string LabelText
		{
			get { return _labelText; }
			
			set
			{ 
				_labelText = value;
				lblText.Text = _labelText;
			}
		}
		
		[RefreshProperties(RefreshProperties.All), Category("Symbol")]
		public NxtControl.Drawing.Color OffColor
		{
			get { return Led.Ranges[0].PropertyValues["Color"] as NxtControl.Drawing.Color; }
			set
			{
				Led.Ranges[0].PropertyValues["Color"] = value;
			}
		}
		
		[RefreshProperties(RefreshProperties.All), Category("Symbol")]
		public NxtControl.Drawing.Color OnColor
		{
			get { return Led.Ranges[1].PropertyValues["Color"] as NxtControl.Drawing.Color; }
			set
			{
				Led.Ranges[1].PropertyValues["Color"] = value;
			}
		}
	}
}
