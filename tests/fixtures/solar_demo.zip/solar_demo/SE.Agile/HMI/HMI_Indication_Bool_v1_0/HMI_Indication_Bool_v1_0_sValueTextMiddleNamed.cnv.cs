/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 3/14/2025
 * Time: 1:36 PM
 * 
 */

using System;
using NxtControl.GuiFramework;
using System.ComponentModel;

namespace SE.Agile.Symbols.HMI_Indication_Bool_v1_0
{
	/// <summary>
	/// Description of sDefault.
	/// </summary>
	public partial class sValueTextMiddleNamed : NxtControl.GuiFramework.HMISymbol
	{
		private string _labelText = "LabelText";
		private string _onText = "Enabled";
		private string _offText = "Disabled";
		
		public sValueTextMiddleNamed()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}

		[DefaultValue("LabelText"), RefreshProperties(RefreshProperties.All), Category("Symbol")]
		public string LabelText
		{
			get { return _labelText; }
			
			set
			{ 
				_labelText = value;
				lblText.Text = _labelText;
			}
		}
		
		[DefaultValue("Enabled"), RefreshProperties(RefreshProperties.All), Category("Symbol")]
		public string OnText
		{
			get
			{
				return _onText;
			}
			
			set
			{
				_onText = value;
		    }
		}

		[DefaultValue("Disabled"), RefreshProperties(RefreshProperties.All), Category("Symbol")]
		public string OffText
		{
			get
			{
				return _offText;
			}
			
			set
			{
				_offText = value;
		    }
		}
		
		void ValueValueChanged(object sender, ValueChangedEventArgs e)
		{
			if ((bool)e.Value)
			{
				txtValue.Text = OnText;
			}
			else
			{
				txtValue.Text = OffText;
			}
		}
	}
}
