/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 3/14/2025
 * Time: 1:36 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.HMI_Indication_Bool_v1_0
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sValueTextMiddleNamed
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Value = new System.HMI.Symbols.Base.Execute<bool>();
			this.lblText = new NxtControl.GuiFramework.Label();
			this.txtValue = new NxtControl.GuiFramework.Label();
			// 
			// Value
			// 
			this.Value.BeginInit();
			this.Value.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.Value.IsOnlyInput = true;
			this.Value.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.Value.Name = "Value";
			this.Value.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.Value.TagName = "Value";
			this.Value.Value = false;
			this.Value.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.ValueValueChanged);
			this.Value.EndInit();
			// 
			// lblText
			// 
			this.lblText.AngleIgnore = true;
			this.lblText.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.lblText.Bounds = new NxtControl.Drawing.RectF(((float)(8D)), ((float)(16D)), ((float)(150D)), ((float)(26D)));
			this.lblText.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.lblText.Font = new NxtControl.Drawing.Font("LabelFont");
			this.lblText.FontScale = true;
			this.lblText.Name = "lblText";
			this.lblText.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.lblText.Text = "LabelText";
			this.lblText.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.lblText.TextAutoSizeHorizontalOffset = 10;
			this.lblText.TextColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.lblText.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// txtValue
			// 
			this.txtValue.AngleIgnore = true;
			this.txtValue.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtValue.Bounds = new NxtControl.Drawing.RectF(((float)(160D)), ((float)(16D)), ((float)(96D)), ((float)(26D)));
			this.txtValue.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.txtValue.Font = new NxtControl.Drawing.Font("HMI Sans Serif", 9F, System.Drawing.FontStyle.Regular);
			this.txtValue.FontScale = true;
			this.txtValue.Name = "txtValue";
			this.txtValue.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.txtValue.Text = "Unknown";
			this.txtValue.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.txtValue.TextAutoSizeHorizontalOffset = 10;
			this.txtValue.TextColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.txtValue.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// sValueTextMiddleNamed
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.Value,
			this.lblText,
			this.txtValue});
			this.SymbolSize = new System.Drawing.Size(320, 60);

		}
		private NxtControl.GuiFramework.Label txtValue;
		private System.HMI.Symbols.Base.Execute<bool> Value;
		private NxtControl.GuiFramework.Label lblText;
		#endregion
	}
}
