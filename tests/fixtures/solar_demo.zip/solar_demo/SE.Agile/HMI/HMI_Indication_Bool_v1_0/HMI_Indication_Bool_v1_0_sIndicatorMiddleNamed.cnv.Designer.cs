/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 3/14/2025
 * Time: 1:36 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.HMI_Indication_Bool_v1_0
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sIndicatorMiddleNamed
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary2 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary3 = new NxtControl.GuiFramework.PropertyDictionary();
			NxtControl.GuiFramework.PropertyDictionary propertyDictionary1 = new NxtControl.GuiFramework.PropertyDictionary();
			this.Led = new System.HMI.Symbols.Base.Led<bool>();
			this.lblText = new NxtControl.GuiFramework.Label();
			// 
			// Led
			// 
			this.Led.BeginInit();
			this.Led.ColorFrame = new NxtControl.Drawing.Color("LedFrameColor");
			this.Led.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, 169D, 28D);
			this.Led.FrameSize = 33F;
			this.Led.IsOnlyInput = true;
			this.Led.Name = "Led";
			propertyDictionary2.Add("Color", new NxtControl.Drawing.Color("LedFalseColor"));
			propertyDictionary3.Add("Color", new NxtControl.Drawing.Color("LedTrueColor"));
			this.Led.Ranges.Clear();
			this.Led.Ranges.Add(new NxtControl.GuiFramework.Range<bool>(false, propertyDictionary2));
			this.Led.Ranges.Add(new NxtControl.GuiFramework.Range<bool>(true, propertyDictionary3));
			propertyDictionary1.Add("Color", new NxtControl.Drawing.Color("LedFalseColor"));
			this.Led.Ranges.DefaultPropertyValues = propertyDictionary1;
			this.Led.TagName = "Value";
			this.Led.EndInit();
			// 
			// lblText
			// 
			this.lblText.AngleIgnore = true;
			this.lblText.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.lblText.Bounds = new NxtControl.Drawing.RectF(((float)(8D)), ((float)(16D)), ((float)(150D)), ((float)(26D)));
			this.lblText.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.lblText.Font = new NxtControl.Drawing.Font("LabelFont");
			this.lblText.FontScale = true;
			this.lblText.Name = "lblText";
			this.lblText.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.lblText.Text = "LabelText";
			this.lblText.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.lblText.TextAutoSizeHorizontalOffset = 10;
			this.lblText.TextColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.lblText.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// sIndicator
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.Led,
			this.lblText});
			this.SymbolSize = new System.Drawing.Size(320, 60);

		}
		private System.HMI.Symbols.Base.Led<bool> Led;
		private NxtControl.GuiFramework.Label lblText;
		#endregion
	}
}
