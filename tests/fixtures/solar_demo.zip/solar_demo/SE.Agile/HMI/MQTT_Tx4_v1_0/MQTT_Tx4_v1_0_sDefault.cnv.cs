/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 6/5/2025
 * Time: 11:04 AM
 * 
 */

using System;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.MQTT_Tx4_v1_0
{
	/// <summary>
	/// Description of sDefault.
	/// </summary>
	public partial class sDefault : NxtControl.GuiFramework.HMISymbol
	{
		public sDefault()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}
	}
}
