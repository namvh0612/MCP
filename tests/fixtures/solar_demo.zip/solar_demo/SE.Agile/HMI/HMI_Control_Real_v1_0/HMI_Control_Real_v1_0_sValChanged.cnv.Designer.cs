﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 9/18/2025
 * Time: 9:27 AM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.HMI_Control_Real_v1_0
{
	/// <summary>
	/// Summary description for sValChanged.
	/// </summary>
	partial class sValChanged
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.iValue = new System.HMI.Symbols.Base.Execute<float>();
			this.DecimalPlaces = new System.HMI.Symbols.Base.Execute<byte>();
			this.Units = new System.HMI.Symbols.Base.Execute<string>();
			this.Minimum = new System.HMI.Symbols.Base.Execute<float>();
			this.Maximum = new System.HMI.Symbols.Base.Execute<float>();
			// 
			// iValue
			// 
			this.iValue.BeginInit();
			this.iValue.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.iValue.IsOnlyInput = true;
			this.iValue.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.iValue.Name = "iValue";
			this.iValue.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.iValue.TagName = "iValue";
			this.iValue.Value = 0F;
			this.iValue.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.IValueValueChanged);
			this.iValue.EndInit();
			// 
			// DecimalPlaces
			// 
			this.DecimalPlaces.BeginInit();
			this.DecimalPlaces.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.DecimalPlaces.IsOnlyInput = true;
			this.DecimalPlaces.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.DecimalPlaces.Name = "DecimalPlaces";
			this.DecimalPlaces.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.DecimalPlaces.TagName = "DecimalPlaces";
			this.DecimalPlaces.Value = ((byte)(0));
			this.DecimalPlaces.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.DecimalPlacesValueChanged);
			this.DecimalPlaces.EndInit();
			// 
			// Units
			// 
			this.Units.BeginInit();
			this.Units.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.Units.IsOnlyInput = true;
			this.Units.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.Units.Name = "Units";
			this.Units.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.Units.TagName = "Units";
			this.Units.Value = null;
			this.Units.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.UnitsValueChanged);
			this.Units.EndInit();
			// 
			// Minimum
			// 
			this.Minimum.BeginInit();
			this.Minimum.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.Minimum.IsOnlyInput = true;
			this.Minimum.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.Minimum.Name = "Minimum";
			this.Minimum.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.Minimum.TagName = "Minimum";
			this.Minimum.Value = 0F;
			this.Minimum.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.MinimumValueChanged);
			this.Minimum.EndInit();
			// 
			// Maximum
			// 
			this.Maximum.BeginInit();
			this.Maximum.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.Maximum.IsOnlyInput = true;
			this.Maximum.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.Maximum.Name = "Maximum";
			this.Maximum.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.Maximum.TagName = "Maximum";
			this.Maximum.Value = 0F;
			this.Maximum.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.MaximumValueChanged);
			this.Maximum.EndInit();
			// 
			// sValChanged
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.iValue,
			this.DecimalPlaces,
			this.Units,
			this.Minimum,
			this.Maximum});
			this.SymbolSize = new System.Drawing.Size(200, 200);

		}
		private System.HMI.Symbols.Base.Execute<float> iValue;
		private System.HMI.Symbols.Base.Execute<byte> DecimalPlaces;
		private System.HMI.Symbols.Base.Execute<string> Units;
		private System.HMI.Symbols.Base.Execute<float> Minimum;
		private System.HMI.Symbols.Base.Execute<float> Maximum;
		#endregion
	}
}
