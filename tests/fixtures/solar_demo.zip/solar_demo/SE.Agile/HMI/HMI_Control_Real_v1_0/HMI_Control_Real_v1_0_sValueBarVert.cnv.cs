﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 10/1/2025
 * Time: 10:14 AM
 * 
 */

using System;
using NxtControl.Drawing;
using NxtControl.GuiFramework;
using System.ComponentModel;
using System.Windows.Forms;


namespace SE.Agile.Symbols.HMI_Control_Real_v1_0
{
	/// <summary>
	/// Description of sValueBarVert.
	/// </summary>
	public partial class sValueBarVert : NxtControl.GuiFramework.HMISymbol
	{
		private string _labelText = "LabelText";
		
		public sValueBarVert()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}
		
		[DefaultValue("LabelText"), RefreshProperties(RefreshProperties.All), Category("Symbol")]
		public string LabelText
		{
			get { return _labelText; }
			
			set
			{ 
				_labelText = value;
				lblText.Text = _labelText;
			}
		}
		
		[RefreshProperties(RefreshProperties.All), Category("Symbol")]
		public PointF LabelTextLocation
		{
			get { return lblText.Location; }
			
			set
			{ 
				lblText.Location = value;
			}
		}
		
		[RefreshProperties(RefreshProperties.All), Category("Symbol")]
		public bool ShowUnits
		{
			get { return lblUnits.Visible; }
			
			set
			{ 
				lblUnits.Visible = value;
			}
		}
		
		[RefreshProperties(RefreshProperties.All), Category("Symbol")]
		public PointF UnitsTextLocation
		{
			get { return lblUnits.Location; }
			
			set
			{ 
				lblUnits.Location = value;
			}
		}
		
		[RefreshProperties(RefreshProperties.All), Category("Symbol")]
		public NxtControl.Drawing.Brush BarValueBrush
		{
			get { return iValue.BarValueBrush; }
			set
			{
				iValue.BarValueBrush = value;
			}
		}
		
		[RefreshProperties(RefreshProperties.All), Category("Symbol")]
		public TickStyle BarRangeTextStyle
		{
			get { return iValue.TextStyle; }
			set
			{
				iValue.TextStyle = value;
			}
		}
		
		[RefreshProperties(RefreshProperties.All), Category("Symbol")]
		public TickStyle BarTickStyle
		{
			get { return iValue.TickStyle; }
			set
			{
				iValue.TickStyle = value;
			}
		}
		
		void DecimalPlacesValueChanged(object sender, ValueChangedEventArgs e)
		{
			iValue.LabelFormatString = string.Format("{0}{1}{2}", "{0,0:F", (uint)((byte)e.Value), "}");
		}
		
		void UnitsValueChanged(object sender, ValueChangedEventArgs e)
		{
			lblUnits.Text = e.Value.ToString();
		}
	}
}
