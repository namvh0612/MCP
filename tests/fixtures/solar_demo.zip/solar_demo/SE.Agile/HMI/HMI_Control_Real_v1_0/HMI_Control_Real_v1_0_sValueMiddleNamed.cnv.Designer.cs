﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 9/22/2025
 * Time: 11:07 AM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.HMI_Control_Real_v1_0
{
	/// <summary>
	/// Summary description for sValueMiddleNamed.
	/// </summary>
	partial class sValueMiddleNamed
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblText = new NxtControl.GuiFramework.Label();
			this.iValue = new System.HMI.Symbols.Base.TextBox<float>();
			this.DecimalPlaces = new System.HMI.Symbols.Base.Execute<byte>();
			// 
			// lblText
			// 
			this.lblText.AngleIgnore = true;
			this.lblText.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.lblText.Bounds = new NxtControl.Drawing.RectF(((float)(8D)), ((float)(16D)), ((float)(150D)), ((float)(26D)));
			this.lblText.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.lblText.Font = new NxtControl.Drawing.Font("LabelFont");
			this.lblText.FontScale = true;
			this.lblText.Name = "lblText";
			this.lblText.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.lblText.Text = "LabelText";
			this.lblText.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.lblText.TextAutoSizeHorizontalOffset = 10;
			this.lblText.TextColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.lblText.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// iValue
			// 
			this.iValue.BeginInit();
			this.iValue.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.iValue.DesignMatrix = new NxtControl.Drawing.Matrix2D(0.64D, 0D, 0D, 1D, 160D, 16D);
			this.iValue.IsOnlyInput = true;
			this.iValue.MaximumTag = new NxtControl.GuiFramework.AuxHMIAccessor("Maximum", this.iValue);
			this.iValue.MinimumTag = new NxtControl.GuiFramework.AuxHMIAccessor("Minimum", this.iValue);
			this.iValue.Name = "iValue";
			this.iValue.NumberBase = NxtControl.GuiFramework.NumberBase.Decimal;
			this.iValue.Pen = new NxtControl.Drawing.Pen("Transparent");
			this.iValue.SetColor = new NxtControl.Drawing.Color("Yellow");
			this.iValue.SuffixTag = new NxtControl.GuiFramework.AuxHMIAccessor("Units", this.iValue);
			this.iValue.TagName = "iValue";
			this.iValue.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.iValue.UseRange = true;
			this.iValue.Value = 0F;
			this.iValue.EndInit();
			// 
			// DecimalPlaces
			// 
			this.DecimalPlaces.BeginInit();
			this.DecimalPlaces.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.DecimalPlaces.IsOnlyInput = true;
			this.DecimalPlaces.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.DecimalPlaces.Name = "DecimalPlaces";
			this.DecimalPlaces.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.DecimalPlaces.TagName = "DecimalPlaces";
			this.DecimalPlaces.Value = ((byte)(0));
			this.DecimalPlaces.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.DecimalPlacesValueChanged);
			this.DecimalPlaces.EndInit();
			// 
			// sValueMiddleNamed
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.lblText,
			this.iValue,
			this.DecimalPlaces});
			this.SymbolSize = new System.Drawing.Size(320, 60);

		}
		private NxtControl.GuiFramework.Label lblText;
		private System.HMI.Symbols.Base.TextBox<float> iValue;
		private System.HMI.Symbols.Base.Execute<byte> DecimalPlaces;
		#endregion
	}
}
