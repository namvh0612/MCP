using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region HMI_Control_Real_v1_0_HMI;
#endregion HMI_Control_Real_v1_0_HMI;

#endregion Definitions;

