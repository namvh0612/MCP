﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 10/15/2025
 * Time: 11:35 AM
 * 
 */

using System;
using NxtControl.Drawing;
using NxtControl.GuiFramework;
using System.ComponentModel;

namespace SE.Agile.Symbols.HMI_Control_Real_v1_0
{
	/// <summary>
	/// Description of sValue.
	/// </summary>
	public partial class sValue : NxtControl.GuiFramework.HMISymbol
	{
		private bool _showUnits = true;
		
		public sValue()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			UpdateUI();
		}
		
		[RefreshProperties(RefreshProperties.All), Category("Symbol")]
		public Pen TextBorder
		{
			get { return iValue.Pen; }
			
			set
			{ 
				iValue.Pen = value;
			}
		}
		
		[RefreshProperties(RefreshProperties.All), Category("Symbol")]
		public ContentAlignment TextAlignment
		{
			get { return iValue.TextAlignment; }
			
			set
			{ 
				iValue.TextAlignment = value;
			}
		}
		
		[DefaultValue(2), RefreshProperties(RefreshProperties.All), Category("Symbol")]
		public uint DecimalPlacesCount
		{
			get { return iValue.DecimalPlacesCount; }
			
			set
			{ 
				iValue.DecimalPlacesCount = value;
			}
		}
		
		[DefaultValue(true), RefreshProperties(RefreshProperties.All), Category("Symbol")]
		public bool ShowUnits
		{
			get { return _showUnits; }
			
			set
			{ 
				_showUnits = value;
			}
		}

		void DecimalPlacesValueChanged(object sender, ValueChangedEventArgs e)
		{
			iValue.DecimalPlacesCount = (uint)((byte)e.Value);
		}
		
		void UpdateUI()
		{				
			if (ShowUnits)
			{
				iValue.SuffixTag = new NxtControl.GuiFramework.AuxHMIAccessor("Units", iValue);
			}
			else
			{
				iValue.SuffixTag = null;
			}
		}
	}
}
