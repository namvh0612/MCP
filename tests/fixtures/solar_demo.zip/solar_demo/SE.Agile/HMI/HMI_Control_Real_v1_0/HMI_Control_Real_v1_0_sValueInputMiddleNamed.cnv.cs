/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 3/13/2025
 * Time: 10:57 AM
 * 
 */

using System;
using NxtControl.GuiFramework;
using System.ComponentModel;

namespace SE.Agile.Symbols.HMI_Control_Real_v1_0
{
	/// <summary>
	/// Description of sDefault.
	/// </summary>
	public partial class sValueInputMiddleNamed : NxtControl.GuiFramework.HMISymbol
	{
		private string _labelText = "LabelText";
		private bool _enabled = true;
		
		public sValueInputMiddleNamed()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}
				
		[DefaultValue("LabelText"), RefreshProperties(RefreshProperties.All), Category("Symbol")]
		public string LabelText
		{
			get { return _labelText; }
			
			set
			{ 
				_labelText = value;
				lblText.Text = _labelText;
			}
		}
		
		[DefaultValue(2), RefreshProperties(RefreshProperties.All), Category("Symbol")]
		public uint DecimalPlacesCount
		{
			get { return oValue.DecimalPlacesCount; }
			
			set
			{ 
				oValue.DecimalPlacesCount = value;
			}
		}
		
		public bool Enabled
		{
			get { return _enabled; }
			
			set
			{ 
				_enabled = value;
				oValue.Enabled = _enabled;
			}
		}
			
		void IValueValueChanged(object sender, ValueChangedEventArgs e)
		{
		    FireEvent_CNF((float)e.Value, false);
		}
		
		void DecimalPlacesValueChanged(object sender, ValueChangedEventArgs e)
		{
			oValue.DecimalPlacesCount = (uint)((byte)e.Value);
		}
	}
}
