﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 10/15/2025
 * Time: 11:35 AM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.HMI_Control_Real_v1_0
{
	/// <summary>
	/// Summary description for sValue.
	/// </summary>
	partial class sValue
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.iValue = new System.HMI.Symbols.Base.TextBox<float>();
			this.DecimalPlaces = new System.HMI.Symbols.Base.Execute<byte>();
			// 
			// iValue
			// 
			this.iValue.BeginInit();
			this.iValue.Brush = new NxtControl.Drawing.Brush("Transparent");
			this.iValue.DesignMatrix = new NxtControl.Drawing.Matrix2D(0.64D, 0D, 0D, 0.96153846153846156D, 24D, 16D);
			this.iValue.IgnoreMouseEvents = true;
			this.iValue.IsOnlyInput = true;
			this.iValue.IsPrefixSuffixOutside = false;
			this.iValue.MaximumTag = new NxtControl.GuiFramework.AuxHMIAccessor("Maximum", this.iValue);
			this.iValue.MinimumTag = new NxtControl.GuiFramework.AuxHMIAccessor("Minimum", this.iValue);
			this.iValue.Name = "iValue";
			this.iValue.NumberBase = NxtControl.GuiFramework.NumberBase.Decimal;
			this.iValue.Pen = new NxtControl.Drawing.Pen("Transparent");
			this.iValue.SetColor = new NxtControl.Drawing.Color("Yellow");
			this.iValue.TagName = "iValue";
			this.iValue.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.iValue.UseRange = true;
			this.iValue.Value = 0F;
			this.iValue.EndInit();
			// 
			// DecimalPlaces
			// 
			this.DecimalPlaces.BeginInit();
			this.DecimalPlaces.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.DecimalPlaces.IsOnlyInput = true;
			this.DecimalPlaces.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.DecimalPlaces.Name = "DecimalPlaces";
			this.DecimalPlaces.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.DecimalPlaces.TagName = "DecimalPlaces";
			this.DecimalPlaces.Value = ((byte)(0));
			this.DecimalPlaces.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.DecimalPlacesValueChanged);
			this.DecimalPlaces.EndInit();
			// 
			// sValue
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.iValue,
			this.DecimalPlaces});
			this.SymbolSize = new System.Drawing.Size(168, 60);

		}
		private System.HMI.Symbols.Base.TextBox<float> iValue;
		private System.HMI.Symbols.Base.Execute<byte> DecimalPlaces;
		#endregion
	}
}
