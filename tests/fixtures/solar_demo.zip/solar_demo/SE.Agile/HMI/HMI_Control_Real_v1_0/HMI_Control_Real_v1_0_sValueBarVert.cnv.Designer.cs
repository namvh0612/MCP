﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 10/1/2025
 * Time: 10:14 AM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.HMI_Control_Real_v1_0
{
	/// <summary>
	/// Summary description for sValueBarVert.
	/// </summary>
	partial class sValueBarVert
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.DecimalPlaces = new System.HMI.Symbols.Base.Execute<byte>();
			this.lblText = new NxtControl.GuiFramework.Label();
			this.iValue = new System.HMI.Symbols.Base.BarValueVertical<float>();
			this.lblUnits = new NxtControl.GuiFramework.Label();
			this.Units = new System.HMI.Symbols.Base.Execute<string>();
			// 
			// DecimalPlaces
			// 
			this.DecimalPlaces.BeginInit();
			this.DecimalPlaces.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.DecimalPlaces.IsOnlyInput = true;
			this.DecimalPlaces.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.DecimalPlaces.Name = "DecimalPlaces";
			this.DecimalPlaces.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.DecimalPlaces.TagName = "DecimalPlaces";
			this.DecimalPlaces.Value = ((byte)(0));
			this.DecimalPlaces.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.DecimalPlacesValueChanged);
			this.DecimalPlaces.EndInit();
			// 
			// lblText
			// 
			this.lblText.AngleIgnore = true;
			this.lblText.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.lblText.Bounds = new NxtControl.Drawing.RectF(((float)(86D)), ((float)(223D)), ((float)(150D)), ((float)(26D)));
			this.lblText.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.lblText.Font = new NxtControl.Drawing.Font("LabelFont");
			this.lblText.FontScale = true;
			this.lblText.Name = "lblText";
			this.lblText.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.lblText.Text = "LabelText";
			this.lblText.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleCenter;
			this.lblText.TextAutoSizeHorizontalOffset = 10;
			this.lblText.TextColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.lblText.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// iValue
			// 
			this.iValue.BeginInit();
			this.iValue.Brush = new NxtControl.Drawing.Brush("TrackerBrush");
			this.iValue.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 0.70666666666666667D, 96D, 32D);
			this.iValue.Font = new NxtControl.Drawing.Font("TrackerFont");
			this.iValue.IgnoreMouseEvents = true;
			this.iValue.IsOnlyInput = true;
			this.iValue.Maximum = 100F;
			this.iValue.MaximumTag = new NxtControl.GuiFramework.AuxHMIAccessor("Maximum", this.iValue);
			this.iValue.Minimum = 0F;
			this.iValue.MinimumTag = new NxtControl.GuiFramework.AuxHMIAccessor("Minimum", this.iValue);
			this.iValue.MouseMoveValueThreshold = 0D;
			this.iValue.Name = "iValue";
			this.iValue.Pen = new NxtControl.Drawing.Pen("TrackerPen");
			this.iValue.Radius = 20D;
			this.iValue.TagName = "iValue";
			this.iValue.TextStyle = System.Windows.Forms.TickStyle.TopLeft;
			this.iValue.TickLength = 5;
			this.iValue.TickStyle = System.Windows.Forms.TickStyle.Both;
			this.iValue.Value = 0F;
			this.iValue.ValueFont = new NxtControl.Drawing.Font("TrackerValueFont");
			this.iValue.EndInit();
			// 
			// lblUnits
			// 
			this.lblUnits.AngleIgnore = true;
			this.lblUnits.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.lblUnits.Bounds = new NxtControl.Drawing.RectF(((float)(86D)), ((float)(34D)), ((float)(150D)), ((float)(26D)));
			this.lblUnits.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.lblUnits.Font = new NxtControl.Drawing.Font("LabelFont");
			this.lblUnits.FontScale = true;
			this.lblUnits.Name = "lblUnits";
			this.lblUnits.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.lblUnits.Text = "Units";
			this.lblUnits.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleCenter;
			this.lblUnits.TextAutoSizeHorizontalOffset = 10;
			this.lblUnits.TextColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.lblUnits.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// Units
			// 
			this.Units.BeginInit();
			this.Units.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.Units.IsOnlyInput = true;
			this.Units.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.Units.Name = "Units";
			this.Units.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.Units.TagName = "Units";
			this.Units.Value = null;
			this.Units.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.UnitsValueChanged);
			this.Units.EndInit();
			// 
			// sValueBarVert
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.DecimalPlaces,
			this.lblText,
			this.iValue,
			this.lblUnits,
			this.Units});
			this.SymbolSize = new System.Drawing.Size(320, 308);

		}
		private System.HMI.Symbols.Base.Execute<byte> DecimalPlaces;
		private NxtControl.GuiFramework.Label lblText;
		private System.HMI.Symbols.Base.BarValueVertical<float> iValue;
		private System.HMI.Symbols.Base.Execute<string> Units;
		private NxtControl.GuiFramework.Label lblUnits;
		#endregion
	}
}
