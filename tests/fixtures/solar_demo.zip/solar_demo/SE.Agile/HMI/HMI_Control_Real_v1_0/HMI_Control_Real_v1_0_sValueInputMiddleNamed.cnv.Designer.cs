/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 3/13/2025
 * Time: 10:57 AM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.HMI_Control_Real_v1_0
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sValueInputMiddleNamed
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.iValue = new System.HMI.Symbols.Base.Execute<float>();
			this.DecimalPlaces = new System.HMI.Symbols.Base.Execute<byte>();
			this.oValue = new System.HMI.Symbols.Base.TextBox<float>();
			this.lblText = new NxtControl.GuiFramework.Label();
			// 
			// iValue
			// 
			this.iValue.BeginInit();
			this.iValue.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.iValue.IsOnlyInput = true;
			this.iValue.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.iValue.Name = "iValue";
			this.iValue.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.iValue.TagName = "iValue";
			this.iValue.Value = 0F;
			this.iValue.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.IValueValueChanged);
			this.iValue.EndInit();
			// 
			// DecimalPlaces
			// 
			this.DecimalPlaces.BeginInit();
			this.DecimalPlaces.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.DecimalPlaces.IsOnlyInput = true;
			this.DecimalPlaces.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.DecimalPlaces.Name = "DecimalPlaces";
			this.DecimalPlaces.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.DecimalPlaces.TagName = "DecimalPlaces";
			this.DecimalPlaces.Value = ((byte)(0));
			this.DecimalPlaces.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.DecimalPlacesValueChanged);
			this.DecimalPlaces.EndInit();
			// 
			// oValue
			// 
			this.oValue.BeginInit();
			this.oValue.DesignMatrix = new NxtControl.Drawing.Matrix2D(0.64D, 0D, 0D, 1D, 160D, 16D);
			this.oValue.MaximumTag = new NxtControl.GuiFramework.AuxHMIAccessor("Maximum", this.oValue);
			this.oValue.MinimumTag = new NxtControl.GuiFramework.AuxHMIAccessor("Minimum", this.oValue);
			this.oValue.Name = "oValue";
			this.oValue.NumberBase = NxtControl.GuiFramework.NumberBase.Decimal;
			this.oValue.Pen = new NxtControl.Drawing.Pen("TextBoxPen");
			this.oValue.SendValueOnLostFocus = true;
			this.oValue.SetColor = new NxtControl.Drawing.Color("Yellow");
			this.oValue.SuffixTag = new NxtControl.GuiFramework.AuxHMIAccessor("Units", this.oValue);
			this.oValue.TagName = "oValue";
			this.oValue.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.oValue.UseRange = true;
			this.oValue.Value = 0F;
			this.oValue.EndInit();
			// 
			// lblText
			// 
			this.lblText.AngleIgnore = true;
			this.lblText.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.lblText.Bounds = new NxtControl.Drawing.RectF(((float)(8D)), ((float)(16D)), ((float)(150D)), ((float)(26D)));
			this.lblText.Brush = new NxtControl.Drawing.Brush("LabelBrush");
			this.lblText.Font = new NxtControl.Drawing.Font("HMI Sans Serif", 9F, System.Drawing.FontStyle.Regular);
			this.lblText.FontScale = true;
			this.lblText.Name = "lblText";
			this.lblText.Pen = new NxtControl.Drawing.Pen("LabelPen");
			this.lblText.Text = "LabelText";
			this.lblText.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleRight;
			this.lblText.TextAutoSizeHorizontalOffset = 10;
			this.lblText.TextColor = new NxtControl.Drawing.Color("LabelTextColor");
			this.lblText.TextPadding = new NxtControl.Drawing.Padding(2);
			// 
			// sValueInputMiddleNamed
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.iValue,
			this.DecimalPlaces,
			this.oValue,
			this.lblText});
			this.SymbolSize = new System.Drawing.Size(320, 60);

		}
		private System.HMI.Symbols.Base.Execute<float> iValue;
		private System.HMI.Symbols.Base.Execute<byte> DecimalPlaces;
		private System.HMI.Symbols.Base.TextBox<float> oValue;
		private NxtControl.GuiFramework.Label lblText;
		#endregion
	}
}
