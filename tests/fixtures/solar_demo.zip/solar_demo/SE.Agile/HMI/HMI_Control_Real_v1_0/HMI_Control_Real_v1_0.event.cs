/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 3/13/2025
 * Time: 10:57 AM
 * 
 */
using System;
using NxtControl.GuiFramework;
using NxtControl.Services;

#region Definitions;
#region #HMI_Control_Real_v1_0_HMI;

namespace SE.Agile.Symbols.HMI_Control_Real_v1_0
{

  public class REQEventArgs : System.EventArgs
  {
    IHMIAccessorService accessorService;
    int channelId;
    int cookie; 
    int eventIndex;

    public REQEventArgs(int channelId, int cookie, int eventIndex)
    {
      this.accessorService = (IHMIAccessorService)ServiceProvider.GetService(typeof(IHMIAccessorService));
      this.channelId = channelId;
      this.cookie = cookie;
      this.eventIndex = eventIndex;
    }
    public bool Get_iValue(ref System.Single value)
    {
      if (accessorService == null)
        return false;
      float var = 0;
      bool ret = accessorService.GetFloatValue(channelId, cookie, eventIndex, true,0, ref var);
      if (ret) value = (System.Single) var;
      return ret;
    }

    public System.Single? iValue
    { get {
      if (accessorService == null)
        return null;
      float var = 0;
      bool ret = accessorService.GetFloatValue(channelId, cookie, eventIndex, true,0, ref var);
      if (!ret) return null;
      return (System.Single) var;
    }  }

    public bool Get_Minimum(ref System.Single value)
    {
      if (accessorService == null)
        return false;
      float var = 0;
      bool ret = accessorService.GetFloatValue(channelId, cookie, eventIndex, true,1, ref var);
      if (ret) value = (System.Single) var;
      return ret;
    }

    public System.Single? Minimum
    { get {
      if (accessorService == null)
        return null;
      float var = 0;
      bool ret = accessorService.GetFloatValue(channelId, cookie, eventIndex, true,1, ref var);
      if (!ret) return null;
      return (System.Single) var;
    }  }

    public bool Get_Maximum(ref System.Single value)
    {
      if (accessorService == null)
        return false;
      float var = 0;
      bool ret = accessorService.GetFloatValue(channelId, cookie, eventIndex, true,2, ref var);
      if (ret) value = (System.Single) var;
      return ret;
    }

    public System.Single? Maximum
    { get {
      if (accessorService == null)
        return null;
      float var = 0;
      bool ret = accessorService.GetFloatValue(channelId, cookie, eventIndex, true,2, ref var);
      if (!ret) return null;
      return (System.Single) var;
    }  }

    public bool Get_Units(ref System.String value)
    {
      if (accessorService == null)
        return false;
      string var = null;
      bool ret = accessorService.GetStringValue(channelId, cookie, eventIndex, true,3, ref var);
      if (ret) value = (System.String) var;
      return ret;
    }

    public System.String Units
    { get {
      if (accessorService == null)
        return null;
      string var = null;
      bool ret = accessorService.GetStringValue(channelId, cookie, eventIndex, true,3, ref var);
      if (!ret) return null;
      return (System.String) var;
    }  }

    public bool Get_DecimalPlaces(ref System.Byte value)
    {
      if (accessorService == null)
        return false;
      byte var = 0;
      bool ret = accessorService.GetByteValue(channelId, cookie, eventIndex, true,4, ref var);
      if (ret) value = (System.Byte) var;
      return ret;
    }

    public System.Byte? DecimalPlaces
    { get {
      if (accessorService == null)
        return null;
      byte var = 0;
      bool ret = accessorService.GetByteValue(channelId, cookie, eventIndex, true,4, ref var);
      if (!ret) return null;
      return (System.Byte) var;
    }  }


  }

}

namespace SE.Agile.Symbols.HMI_Control_Real_v1_0
{

  public class CNFEventArgs : System.EventArgs
  {
    public CNFEventArgs()
    {
    }
    private System.Single? oValue_field = null;
    public System.Single? oValue
    {
       get { return oValue_field; }
       set { oValue_field = value; }
    }

  }

}

namespace SE.Agile.Symbols.HMI_Control_Real_v1_0
{
  partial class sValChanged
  {

    private event EventHandler<SE.Agile.Symbols.HMI_Control_Real_v1_0.REQEventArgs> REQ_Fired;

    protected override void OnEndInit()
    {
      if (REQ_Fired != null)
        AttachEventInput(0);

    }

    protected override void FireEventCallback(int channelId, int cookie, int eventIndex)
    {
      switch(eventIndex)
      {
        default:
          break;
        case 0:
          if (REQ_Fired != null)
          {
            try
            {
              REQ_Fired(this, new SE.Agile.Symbols.HMI_Control_Real_v1_0.REQEventArgs(channelId, cookie, eventIndex));
            }
            catch (System.Exception e)
            {
              NxtControl.Services.LoggingService.ErrorFormatted(@"In Event Callback for event:'{0}' Type:'{1}' CAT:'{2}' came exception:{3}
stack Trace:
{4}","REQ_Fired", this.GetType().Name, this.CATName, e.Message, e.StackTrace);
            }
          }
        break; 

      }
    }
    public bool FireEvent_CNF(System.Single oValue)
    {
      return ((IHMIAccessorOutput)this).FireEvent(0, new object[] {oValue});
    }
    public bool FireEvent_CNF(SE.Agile.Symbols.HMI_Control_Real_v1_0.CNFEventArgs ea)
    {
      object[] _values_ = new object[1];
      if (ea.oValue.HasValue) _values_[0] = ea.oValue.Value;
      return ((IHMIAccessorOutput)this).FireEvent(0, _values_);
    }
    public bool FireEvent_CNF(System.Single oValue, bool ignore_oValue)
    {
      object[] _values_ = new object[1];
      if (!ignore_oValue) _values_[0] = oValue;
      return ((IHMIAccessorOutput)this).FireEvent(0, _values_);
    }

  }
}

namespace SE.Agile.Symbols.HMI_Control_Real_v1_0
{
  partial class sValueInputMiddleNamed
  {

    private event EventHandler<SE.Agile.Symbols.HMI_Control_Real_v1_0.REQEventArgs> REQ_Fired;

    protected override void OnEndInit()
    {
      if (REQ_Fired != null)
        AttachEventInput(0);

    }

    protected override void FireEventCallback(int channelId, int cookie, int eventIndex)
    {
      switch(eventIndex)
      {
        default:
          break;
        case 0:
          if (REQ_Fired != null)
          {
            try
            {
              REQ_Fired(this, new SE.Agile.Symbols.HMI_Control_Real_v1_0.REQEventArgs(channelId, cookie, eventIndex));
            }
            catch (System.Exception e)
            {
              NxtControl.Services.LoggingService.ErrorFormatted(@"In Event Callback for event:'{0}' Type:'{1}' CAT:'{2}' came exception:{3}
stack Trace:
{4}","REQ_Fired", this.GetType().Name, this.CATName, e.Message, e.StackTrace);
            }
          }
        break; 

      }
    }
    public bool FireEvent_CNF(System.Single oValue)
    {
      return ((IHMIAccessorOutput)this).FireEvent(0, new object[] {oValue});
    }
    public bool FireEvent_CNF(SE.Agile.Symbols.HMI_Control_Real_v1_0.CNFEventArgs ea)
    {
      object[] _values_ = new object[1];
      if (ea.oValue.HasValue) _values_[0] = ea.oValue.Value;
      return ((IHMIAccessorOutput)this).FireEvent(0, _values_);
    }
    public bool FireEvent_CNF(System.Single oValue, bool ignore_oValue)
    {
      object[] _values_ = new object[1];
      if (!ignore_oValue) _values_[0] = oValue;
      return ((IHMIAccessorOutput)this).FireEvent(0, _values_);
    }

  }
}

namespace SE.Agile.Symbols.HMI_Control_Real_v1_0
{
  partial class sValueMiddleNamed
  {

    private event EventHandler<SE.Agile.Symbols.HMI_Control_Real_v1_0.REQEventArgs> REQ_Fired;

    protected override void OnEndInit()
    {
      if (REQ_Fired != null)
        AttachEventInput(0);

    }

    protected override void FireEventCallback(int channelId, int cookie, int eventIndex)
    {
      switch(eventIndex)
      {
        default:
          break;
        case 0:
          if (REQ_Fired != null)
          {
            try
            {
              REQ_Fired(this, new SE.Agile.Symbols.HMI_Control_Real_v1_0.REQEventArgs(channelId, cookie, eventIndex));
            }
            catch (System.Exception e)
            {
              NxtControl.Services.LoggingService.ErrorFormatted(@"In Event Callback for event:'{0}' Type:'{1}' CAT:'{2}' came exception:{3}
stack Trace:
{4}","REQ_Fired", this.GetType().Name, this.CATName, e.Message, e.StackTrace);
            }
          }
        break; 

      }
    }
    public bool FireEvent_CNF(System.Single oValue)
    {
      return ((IHMIAccessorOutput)this).FireEvent(0, new object[] {oValue});
    }
    public bool FireEvent_CNF(SE.Agile.Symbols.HMI_Control_Real_v1_0.CNFEventArgs ea)
    {
      object[] _values_ = new object[1];
      if (ea.oValue.HasValue) _values_[0] = ea.oValue.Value;
      return ((IHMIAccessorOutput)this).FireEvent(0, _values_);
    }
    public bool FireEvent_CNF(System.Single oValue, bool ignore_oValue)
    {
      object[] _values_ = new object[1];
      if (!ignore_oValue) _values_[0] = oValue;
      return ((IHMIAccessorOutput)this).FireEvent(0, _values_);
    }

  }
}

namespace SE.Agile.Symbols.HMI_Control_Real_v1_0
{
  partial class sValueBarVert
  {

    private event EventHandler<SE.Agile.Symbols.HMI_Control_Real_v1_0.REQEventArgs> REQ_Fired;

    protected override void OnEndInit()
    {
      if (REQ_Fired != null)
        AttachEventInput(0);

    }

    protected override void FireEventCallback(int channelId, int cookie, int eventIndex)
    {
      switch(eventIndex)
      {
        default:
          break;
        case 0:
          if (REQ_Fired != null)
          {
            try
            {
              REQ_Fired(this, new SE.Agile.Symbols.HMI_Control_Real_v1_0.REQEventArgs(channelId, cookie, eventIndex));
            }
            catch (System.Exception e)
            {
              NxtControl.Services.LoggingService.ErrorFormatted(@"In Event Callback for event:'{0}' Type:'{1}' CAT:'{2}' came exception:{3}
stack Trace:
{4}","REQ_Fired", this.GetType().Name, this.CATName, e.Message, e.StackTrace);
            }
          }
        break; 

      }
    }
    public bool FireEvent_CNF(System.Single oValue)
    {
      return ((IHMIAccessorOutput)this).FireEvent(0, new object[] {oValue});
    }
    public bool FireEvent_CNF(SE.Agile.Symbols.HMI_Control_Real_v1_0.CNFEventArgs ea)
    {
      object[] _values_ = new object[1];
      if (ea.oValue.HasValue) _values_[0] = ea.oValue.Value;
      return ((IHMIAccessorOutput)this).FireEvent(0, _values_);
    }
    public bool FireEvent_CNF(System.Single oValue, bool ignore_oValue)
    {
      object[] _values_ = new object[1];
      if (!ignore_oValue) _values_[0] = oValue;
      return ((IHMIAccessorOutput)this).FireEvent(0, _values_);
    }

  }
}

namespace SE.Agile.Symbols.HMI_Control_Real_v1_0
{
  partial class sValue
  {

    private event EventHandler<SE.Agile.Symbols.HMI_Control_Real_v1_0.REQEventArgs> REQ_Fired;

    protected override void OnEndInit()
    {
      if (REQ_Fired != null)
        AttachEventInput(0);

    }

    protected override void FireEventCallback(int channelId, int cookie, int eventIndex)
    {
      switch(eventIndex)
      {
        default:
          break;
        case 0:
          if (REQ_Fired != null)
          {
            try
            {
              REQ_Fired(this, new SE.Agile.Symbols.HMI_Control_Real_v1_0.REQEventArgs(channelId, cookie, eventIndex));
            }
            catch (System.Exception e)
            {
              NxtControl.Services.LoggingService.ErrorFormatted(@"In Event Callback for event:'{0}' Type:'{1}' CAT:'{2}' came exception:{3}
stack Trace:
{4}","REQ_Fired", this.GetType().Name, this.CATName, e.Message, e.StackTrace);
            }
          }
        break; 

      }
    }
    public bool FireEvent_CNF(System.Single oValue)
    {
      return ((IHMIAccessorOutput)this).FireEvent(0, new object[] {oValue});
    }
    public bool FireEvent_CNF(SE.Agile.Symbols.HMI_Control_Real_v1_0.CNFEventArgs ea)
    {
      object[] _values_ = new object[1];
      if (ea.oValue.HasValue) _values_[0] = ea.oValue.Value;
      return ((IHMIAccessorOutput)this).FireEvent(0, _values_);
    }
    public bool FireEvent_CNF(System.Single oValue, bool ignore_oValue)
    {
      object[] _values_ = new object[1];
      if (!ignore_oValue) _values_[0] = oValue;
      return ((IHMIAccessorOutput)this).FireEvent(0, _values_);
    }

  }
}

namespace SE.Agile.Symbols.HMI_Control_Real_v1_0
{
  partial class sValueInput
  {

    private event EventHandler<SE.Agile.Symbols.HMI_Control_Real_v1_0.REQEventArgs> REQ_Fired;

    protected override void OnEndInit()
    {
      if (REQ_Fired != null)
        AttachEventInput(0);

    }

    protected override void FireEventCallback(int channelId, int cookie, int eventIndex)
    {
      switch(eventIndex)
      {
        default:
          break;
        case 0:
          if (REQ_Fired != null)
          {
            try
            {
              REQ_Fired(this, new SE.Agile.Symbols.HMI_Control_Real_v1_0.REQEventArgs(channelId, cookie, eventIndex));
            }
            catch (System.Exception e)
            {
              NxtControl.Services.LoggingService.ErrorFormatted(@"In Event Callback for event:'{0}' Type:'{1}' CAT:'{2}' came exception:{3}
stack Trace:
{4}","REQ_Fired", this.GetType().Name, this.CATName, e.Message, e.StackTrace);
            }
          }
        break; 

      }
    }
    public bool FireEvent_CNF(System.Single oValue)
    {
      return ((IHMIAccessorOutput)this).FireEvent(0, new object[] {oValue});
    }
    public bool FireEvent_CNF(SE.Agile.Symbols.HMI_Control_Real_v1_0.CNFEventArgs ea)
    {
      object[] _values_ = new object[1];
      if (ea.oValue.HasValue) _values_[0] = ea.oValue.Value;
      return ((IHMIAccessorOutput)this).FireEvent(0, _values_);
    }
    public bool FireEvent_CNF(System.Single oValue, bool ignore_oValue)
    {
      object[] _values_ = new object[1];
      if (!ignore_oValue) _values_[0] = oValue;
      return ((IHMIAccessorOutput)this).FireEvent(0, _values_);
    }

  }
}

namespace SE.Agile.Symbols.HMI_Control_Real_v1_0
{
  partial class sValueInputSmall
  {

    private event EventHandler<SE.Agile.Symbols.HMI_Control_Real_v1_0.REQEventArgs> REQ_Fired;

    protected override void OnEndInit()
    {
      if (REQ_Fired != null)
        AttachEventInput(0);

    }

    protected override void FireEventCallback(int channelId, int cookie, int eventIndex)
    {
      switch(eventIndex)
      {
        default:
          break;
        case 0:
          if (REQ_Fired != null)
          {
            try
            {
              REQ_Fired(this, new SE.Agile.Symbols.HMI_Control_Real_v1_0.REQEventArgs(channelId, cookie, eventIndex));
            }
            catch (System.Exception e)
            {
              NxtControl.Services.LoggingService.ErrorFormatted(@"In Event Callback for event:'{0}' Type:'{1}' CAT:'{2}' came exception:{3}
stack Trace:
{4}","REQ_Fired", this.GetType().Name, this.CATName, e.Message, e.StackTrace);
            }
          }
        break; 

      }
    }
    public bool FireEvent_CNF(System.Single oValue)
    {
      return ((IHMIAccessorOutput)this).FireEvent(0, new object[] {oValue});
    }
    public bool FireEvent_CNF(SE.Agile.Symbols.HMI_Control_Real_v1_0.CNFEventArgs ea)
    {
      object[] _values_ = new object[1];
      if (ea.oValue.HasValue) _values_[0] = ea.oValue.Value;
      return ((IHMIAccessorOutput)this).FireEvent(0, _values_);
    }
    public bool FireEvent_CNF(System.Single oValue, bool ignore_oValue)
    {
      object[] _values_ = new object[1];
      if (!ignore_oValue) _values_[0] = oValue;
      return ((IHMIAccessorOutput)this).FireEvent(0, _values_);
    }

  }
}
#endregion #HMI_Control_Real_v1_0_HMI;

#endregion Definitions;
