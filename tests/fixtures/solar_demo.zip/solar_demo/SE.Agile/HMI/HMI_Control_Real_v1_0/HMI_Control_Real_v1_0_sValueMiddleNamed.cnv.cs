﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 9/22/2025
 * Time: 11:07 AM
 * 
 */

using System;
using NxtControl.GuiFramework;
using System.ComponentModel;

namespace SE.Agile.Symbols.HMI_Control_Real_v1_0
{
	/// <summary>
	/// Description of sValueMiddleNamed.
	/// </summary>
	public partial class sValueMiddleNamed : NxtControl.GuiFramework.HMISymbol
	{
		private string _labelText = "LabelText";
		
		public sValueMiddleNamed()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}

		[DefaultValue("LabelText"), RefreshProperties(RefreshProperties.All), Category("Symbol")]
		public string LabelText
		{
			get { return _labelText; }
			
			set
			{ 
				_labelText = value;
				lblText.Text = _labelText;
			}
		}
		
		[DefaultValue(2), RefreshProperties(RefreshProperties.All), Category("Symbol")]
		public uint DecimalPlacesCount
		{
			get { return iValue.DecimalPlacesCount; }
			
			set
			{ 
				iValue.DecimalPlacesCount = value;
			}
		}
		
		void DecimalPlacesValueChanged(object sender, ValueChangedEventArgs e)
		{
			iValue.DecimalPlacesCount = (uint)((byte)e.Value);
		}
	}
}
