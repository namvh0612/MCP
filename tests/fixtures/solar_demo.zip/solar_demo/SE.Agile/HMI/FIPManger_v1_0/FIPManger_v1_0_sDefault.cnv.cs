/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 11/18/2025
 * Time: 10:53 AM
 * 
 */

using System;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.FIPManger_v1_0
{
	/// <summary>
	/// Description of sDefault.
	/// </summary>
	public partial class sDefault : NxtControl.GuiFramework.HMISymbol
	{
		public sDefault()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}
	}
}
