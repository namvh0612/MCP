using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region FIPManger_v1_0_HMI;
#endregion FIPManger_v1_0_HMI;

#endregion Definitions;

