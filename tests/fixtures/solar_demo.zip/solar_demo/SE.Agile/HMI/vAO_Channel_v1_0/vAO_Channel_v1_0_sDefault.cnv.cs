/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 9/8/2025
 * Time: 2:16 PM
 * 
 */

using System;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.vAO_Channel_v1_0
{
	/// <summary>
	/// Description of sDefault.
	/// </summary>
	public partial class sDefault : NxtControl.GuiFramework.HMISymbol
	{
		public sDefault()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
		}

		void ValueValueChanged(object sender, ValueChangedEventArgs e)
		{

		}
	}
}
