/*
 * Created by EcoStruxure Automation Expert.
 * User:  
 * Date: 9/8/2025
 * Time: 2:16 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using NxtControl.GuiFramework;

namespace SE.Agile.Symbols.vAO_Channel_v1_0
{
	/// <summary>
	/// Summary description for sDefault.
	/// </summary>
	partial class sDefault
	{

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Value = new System.HMI.Symbols.Base.Execute<NxtControl.GuiFramework.VTQ<float>>();
			this.Dst = new System.HMI.Symbols.Base.TextBox<string>();
			// 
			// Value
			// 
			this.Value.BeginInit();
			this.Value.DesignMatrix = new NxtControl.Drawing.Matrix2D(1D, 0D, 0D, 1D, double.NaN, double.NaN);
			this.Value.IsOnlyInput = true;
			this.Value.Location = new NxtControl.Drawing.PointF(double.NaN, double.NaN);
			this.Value.Name = "Value";
			this.Value.Size = new NxtControl.Drawing.SizeF(double.NegativeInfinity, double.NegativeInfinity);
			this.Value.TagName = "";
			this.Value.Value = new NxtControl.GuiFramework.VTQ<float>(0F, new System.DateTime(((long)(0))), ((uint)(0u)));
			this.Value.ValueChanged += new System.EventHandler<NxtControl.GuiFramework.ValueChangedEventArgs>(this.ValueValueChanged);
			this.Value.EndInit();
			// 
			// Dst
			// 
			this.Dst.BeginInit();
			this.Dst.DesignMatrix = new NxtControl.Drawing.Matrix2D(1.2533333333333334D, 0D, 0D, 1D, 44D, 31D);
			this.Dst.IsOnlyInput = true;
			this.Dst.MaximumTag = null;
			this.Dst.MinimumTag = null;
			this.Dst.Name = "Dst";
			this.Dst.NumberBase = NxtControl.GuiFramework.NumberBase.Decimal;
			this.Dst.Pen = new NxtControl.Drawing.Pen("TextBoxPen");
			this.Dst.SetColor = new NxtControl.Drawing.Color("Yellow");
			this.Dst.TagName = "Dst";
			this.Dst.TextAlignment = NxtControl.Drawing.ContentAlignment.MiddleLeft;
			this.Dst.Value = null;
			this.Dst.EndInit();
			// 
			// sDefault
			// 
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
			this.Value,
			this.Dst});
			this.SymbolSize = new System.Drawing.Size(600, 400);

		}
		private System.HMI.Symbols.Base.Execute<NxtControl.GuiFramework.VTQ<float>> Value;
		private System.HMI.Symbols.Base.TextBox<string> Dst;
		#endregion
	}
}
