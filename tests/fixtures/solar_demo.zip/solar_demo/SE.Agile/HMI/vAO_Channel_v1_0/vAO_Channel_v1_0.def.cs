using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region vAO_Channel_v1_0_HMI;
#endregion vAO_Channel_v1_0_HMI;

#endregion Definitions;

