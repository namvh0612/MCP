namespace SE.Agile.Symbols.HMI_Indication_Integer_v1_0 {
  export class seValChanged extends NxtControl.GuiFramework.RuntimeSymbol {
    @System.DefaultValue('SE.Agile.Symbols.HMI_Indication_Integer_v1_0.seValChanged')
    protected type: string;
    private currentValue: number = 0;
    private lastUpdate: Date = new Date();
    private valueChangedHandler: any = null;
    constructor() { super(); }
    load(options: any): this { options = options || {}; super.load(options); this.notifyChanged(); return this; }
    public getSnapshot(): any { return { value: this.currentValue, lastUpdate: this.lastUpdate }; }
    public getCurrentValue(): number { return this.currentValue; }
    public getValue(): number { return this.currentValue; }
    public setValueChangedHandler(handler: any) { this.valueChangedHandler = handler; }
    protected Value_valueChanged(sender: any, ea: any) {
      this.currentValue = this.toInt(this.getEventValue(sender, ea));
      this.lastUpdate = new Date(); this.notifyChanged();
    }
    private notifyChanged() { if (this.valueChangedHandler) this.valueChangedHandler(this, this.getSnapshot()); }
    private getEventValue(sender: any, ea: any): any {
      if (ea) { if (ea.value !== undefined) return ea.value; if (ea.Value !== undefined) return ea.Value; }
      if (sender) { if (sender.value !== undefined) return sender.value; if (sender.Value !== undefined) return sender.Value; }
      return null;
    }
    private toNumber(value: any): number { const n = Number(value); return isNaN(n) || !isFinite(n) ? 0 : n; }
    private toInt(value: any): number { return Math.round(this.toNumber(value)); }
  }
}
