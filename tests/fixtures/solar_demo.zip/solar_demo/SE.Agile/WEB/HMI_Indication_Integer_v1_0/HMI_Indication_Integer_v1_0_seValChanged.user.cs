using System;
using System.Drawing;
using NxtControl.GuiHTMLFramework;
namespace SE.Agile.Symbols.HMI_Indication_Integer_v1_0
{
  public partial class seValChanged : NxtControl.GuiHTMLFramework.RuntimeSymbol { }
}
