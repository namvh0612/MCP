﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:    
 * Date: 5/31/2026
 * Time: 10:25 PM
 * 
 */

using System;
using System.Drawing;
using NxtControl.GuiHTMLFramework;

namespace SE.Agile.Symbols.HMI_Control_Integer_v1_0
{
	/// <summary>
	/// Description of seValControl.
	/// </summary>
	public partial class seValControl : NxtControl.GuiHTMLFramework.RuntimeSymbol
	{
	}
}
