/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 5/31/2026
 * Time: 10:25 PM
 *
 * Hidden REAL control bridge.
 *
 * Required JSON objects:
 * - iValue  : System.WEB.Symbols.Base.Execute, isOnlyInput = true
 * - Minimum : System.WEB.Symbols.Base.Execute, isOnlyInput = true
 * - Maximum : System.WEB.Symbols.Base.Execute, isOnlyInput = true
 * - Units   : System.WEB.Symbols.Base.Execute, isOnlyInput = true
 * - oValue  : System.WEB.Symbols.Base.Execute, isOnlyInput = false
 */

namespace SE.Agile.Symbols.HMI_Control_Real_v1_0 {

  export class seValControl extends NxtControl.GuiFramework.RuntimeSymbol {

    @System.DefaultValue('SE.Agile.Symbols.HMI_Control_Real_v1_0.seValControl')
    protected type: string;

    private iValue: any;
    private oValue: any;

    private feedbackValue: number = 0;
    private commandValue: number = 0;

    private minimumValue: number = 0;
    private maximumValue: number = 100;
    private units: string = '';

    private qi: boolean = true;
    private hasPendingCommand: boolean = false;
    private lastUpdate: Date = new Date();

    private valueChangedHandler: any = null;
    private commandChangedHandler: any = null;

    private debugEnabled: boolean = true;

    constructor() {
      super();
    }

    load(options: any): this {
      options = options || {};
      super.load(options);

      this.findObjects();
      this.debug('load', {
        iValue: !!this.iValue,
        oValue: !!this.oValue,
        keys: this.safeKeys(this)
      });

      this.notifyValueChanged();
      return this;
    }

    private findObjects() {
      this.iValue = this.find('iValue');
      this.oValue = this.find('oValue');
    }

    public getSnapshot(): any {
      return {
        value: this.feedbackValue,
        feedbackValue: this.feedbackValue,
        commandValue: this.commandValue,
        minimum: this.minimumValue,
        maximum: this.maximumValue,
        units: this.units,
        qi: this.qi,
        pending: this.hasPendingCommand,
        lastUpdate: this.lastUpdate
      };
    }

    public getValue(): number { return this.feedbackValue; }
    public getFeedbackValue(): number { return this.feedbackValue; }
    public getCommandValue(): number { return this.commandValue; }
    public getMinimum(): number { return this.minimumValue; }
    public getMaximum(): number { return this.maximumValue; }
    public getUnits(): string { return this.units; }
    public isPending(): boolean { return this.hasPendingCommand; }

    public setValueChangedHandler(handler: any) {
      this.valueChangedHandler = handler;
    }

    public setCommandChangedHandler(handler: any) {
      this.commandChangedHandler = handler;
    }

    public setCommand(value: number) {
      const command = this.clampReal(this.toNumber(value), this.minimumValue, this.maximumValue);

      this.commandValue = command;
      this.hasPendingCommand = true;
      this.lastUpdate = new Date();

      const wroteOutput = this.writeOutputValue(command);
      const firedEvent = this.fireCnf(command);

      this.debug('setCommand', {
        command: command,
        wroteOutput: wroteOutput,
        firedEvent: firedEvent
      });

      this.notifyCommandChanged();
      this.notifyValueChanged();
    }

    public increment(step: number = 1) {
      this.setCommand(this.feedbackValue + this.toNumber(step));
    }

    public decrement(step: number = 1) {
      this.setCommand(this.feedbackValue - this.toNumber(step));
    }

    public setMinimum() { this.setCommand(this.minimumValue); }
    public setMaximum() { this.setCommand(this.maximumValue); }

    public setCommandOptimistic(value: number) {
      const command = this.clampReal(this.toNumber(value), this.minimumValue, this.maximumValue);

      this.commandValue = command;
      this.feedbackValue = command;
      this.hasPendingCommand = true;
      this.lastUpdate = new Date();

      const wroteOutput = this.writeOutputValue(command);
      const firedEvent = this.fireCnf(command);

      this.debug('setCommandOptimistic', {
        command: command,
        wroteOutput: wroteOutput,
        firedEvent: firedEvent
      });

      this.notifyCommandChanged();
      this.notifyValueChanged();
    }

    protected iValue_valueChanged(sender: any, ea: any) {
      this.updateFeedback(this.getEventValue(sender, ea));
    }

    protected IValue_valueChanged(sender: any, ea: any) {
      this.updateFeedback(this.getEventValue(sender, ea));
    }

    protected Minimum_valueChanged(sender: any, ea: any) {
      this.minimumValue = this.toNumber(this.getEventValue(sender, ea));
      if (this.maximumValue < this.minimumValue) this.maximumValue = this.minimumValue;
      this.feedbackValue = this.clampReal(this.feedbackValue, this.minimumValue, this.maximumValue);
      this.commandValue = this.clampReal(this.commandValue, this.minimumValue, this.maximumValue);
      this.lastUpdate = new Date();
      this.notifyValueChanged();
    }

    protected Maximum_valueChanged(sender: any, ea: any) {
      this.maximumValue = this.toNumber(this.getEventValue(sender, ea));
      if (this.maximumValue < this.minimumValue) this.minimumValue = this.maximumValue;
      this.feedbackValue = this.clampReal(this.feedbackValue, this.minimumValue, this.maximumValue);
      this.commandValue = this.clampReal(this.commandValue, this.minimumValue, this.maximumValue);
      this.lastUpdate = new Date();
      this.notifyValueChanged();
    }

    protected Units_valueChanged(sender: any, ea: any) {
      this.units = this.cleanText(this.getEventValue(sender, ea));
      this.lastUpdate = new Date();
      this.notifyValueChanged();
    }

    private updateFeedback(rawValue: any) {
      const newValue = this.clampReal(this.toNumber(rawValue), this.minimumValue, this.maximumValue);
      this.feedbackValue = newValue;
      this.lastUpdate = new Date();

      if (this.hasPendingCommand && Math.abs(this.feedbackValue - this.commandValue) < 0.000001) {
        this.hasPendingCommand = false;
      }

      this.debug('feedback', this.getSnapshot());
      this.notifyValueChanged();
    }

    private writeOutputValue(value: number): boolean {
      if (!this.oValue) {
        this.warn('oValue object missing. Add oValue to .sym.json.');
        return false;
      }

      const obj: any = this.oValue;

      if (obj.setValue) { obj.setValue(value); return true; }
      if (obj.set) { obj.set(value); return true; }
      if (obj.execute) { obj.execute(value); return true; }
      if (obj.fire) { obj.fire(value); return true; }
      if (obj._set) { obj._set('value', value, true); return true; }

      obj.value = value;
      return true;
    }

    private fireCnf(value: number): boolean {
      const runtime: any = this;

      if (runtime.FireEvent_CNF) { runtime.FireEvent_CNF(value); return true; }
      if (runtime.fireEvent_CNF) { runtime.fireEvent_CNF(value); return true; }
      if (runtime.fireEvent) { runtime.fireEvent('CNF', value); return true; }
      if (runtime.FireEvent) { runtime.FireEvent('CNF', value); return true; }
      if (runtime.triggerEvent) { runtime.triggerEvent('CNF', value); return true; }
      if (runtime.CNF && runtime.CNF.fire) { runtime.CNF.fire(value); return true; }
      if (runtime.CNF && runtime.CNF.FireEvent) { runtime.CNF.FireEvent(value); return true; }

      this.warn('No CNF fire method found. If oValue write does not trigger CNF, command will remain local.', this.safeKeys(runtime));
      return false;
    }

    private notifyValueChanged() {
      if (this.valueChangedHandler) {
        this.valueChangedHandler(this, this.getSnapshot());
      }
    }

    private notifyCommandChanged() {
      if (this.commandChangedHandler) {
        this.commandChangedHandler(this, this.getSnapshot());
      }
    }

    private getEventValue(sender: any, ea: any): any {
      if (ea) {
        if (ea.value !== undefined) return ea.value;
        if (ea.Value !== undefined) return ea.Value;
      }
      if (sender) {
        if (sender.value !== undefined) return sender.value;
        if (sender.Value !== undefined) return sender.Value;
      }
      return null;
    }

    private toNumber(value: any): number {
      const n = Number(value);
      return isNaN(n) || !isFinite(n) ? 0 : n;
    }

    private cleanText(value: any): string {
      if (value === null || value === undefined) return '';
      return value.toString().replace(/'/g, '').trim();
    }

    private clampReal(value: number, min: number, max: number): number {
      if (value < min) return min;
      if (value > max) return max;
      return value;
    }

    private safeKeys(obj: any): any {
      try { return Object.keys(obj); } catch (e) { return []; }
    }

    private debug(message: string, data?: any) {
      if (!this.debugEnabled) return;
      if (data !== undefined) console.log('[Integer seValControl] ' + message, data);
      else console.log('[Integer seValControl] ' + message);
    }

    private warn(message: string, data?: any) {
      if (data !== undefined) console.warn('[Integer seValControl] ' + message, data);
      else console.warn('[Integer seValControl] ' + message);
    }
  }
}
