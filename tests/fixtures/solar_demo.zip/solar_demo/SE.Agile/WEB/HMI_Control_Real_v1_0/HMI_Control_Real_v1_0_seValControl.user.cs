using System;
using System.Drawing;
using NxtControl.GuiHTMLFramework;
namespace SE.Agile.Symbols.HMI_Control_Real_v1_0
{
  public partial class seValControl : NxtControl.GuiHTMLFramework.RuntimeSymbol { }
}
