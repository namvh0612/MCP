﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 5/31/2026
 * Time: 9:15 PM
 *
 * Hidden BOOL value bridge.
 *
 * Required mapping:
 * Value -> valueChanged -> Value_valueChanged
 */

namespace SE.Agile.Symbols.HMI_Indication_Bool_v1_0 {

  export class seValChanged extends NxtControl.GuiFramework.RuntimeSymbol {

    /**
     * Type of an object (never change this)
     * @type String
     * @default
     */
    @System.DefaultValue('SE.Agile.Symbols.HMI_Indication_Bool_v1_0.seValChanged')
    protected type: string;

    // -----------------------------
    // Runtime value
    // -----------------------------

    private currentValue: boolean = false;
    private lastUpdate: Date = new Date();
    private valueChangedHandler: any = null;

    /**** DO NOT DELETE CONSTRUCTOR *****/
    constructor() {
      super();
    }

    load(options: any): this {
      options = options || {};
      super.load(options);

      this.notifyChanged();

      return this;
    }

    // -----------------------------
    // Public API for Canvas / Parent Symbol
    // -----------------------------

    public getSnapshot(): any {
      return {
        value: this.currentValue,
        lastUpdate: this.lastUpdate
      };
    }

    public getCurrentValue(): boolean {
      return this.currentValue;
    }

    public setValueChangedHandler(handler: any) {
      this.valueChangedHandler = handler;
    }

    // -----------------------------
    // Value changed event
    // Map:
    // Value -> valueChanged -> Value_valueChanged
    // -----------------------------

    protected Value_valueChanged(sender: any, ea: any) {
      this.currentValue = this.toBool(this.getEventValue(sender, ea));
      this.lastUpdate = new Date();
      this.notifyChanged();
    }

    // -----------------------------
    // Internal notify
    // -----------------------------

    private notifyChanged() {
      if (this.valueChangedHandler) {
        this.valueChangedHandler(this, this.getSnapshot());
      }
    }

    // -----------------------------
    // Helpers
    // -----------------------------

    private getEventValue(sender: any, ea: any): any {
      if (ea) {
        if (ea.value !== undefined) {
          return ea.value;
        }

        if (ea.Value !== undefined) {
          return ea.Value;
        }
      }

      if (sender) {
        if (sender.value !== undefined) {
          return sender.value;
        }

        if (sender.Value !== undefined) {
          return sender.Value;
        }
      }

      return null;
    }

    private toBool(value: any): boolean {
      return value === true ||
             value === "true" ||
             value === "True" ||
             value === "TRUE" ||
             value === 1 ||
             value === "1";
    }
  }
}