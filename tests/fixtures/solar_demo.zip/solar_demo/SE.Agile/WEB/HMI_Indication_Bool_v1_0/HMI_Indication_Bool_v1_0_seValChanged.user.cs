﻿/*
 * Created by EcoStruxure Automation Expert.
 * User:    
 * Date: 5/31/2026
 * Time: 9:15 PM
 * 
 */

using System;
using System.Drawing;
using NxtControl.GuiHTMLFramework;

namespace SE.Agile.Symbols.HMI_Indication_Bool_v1_0
{
	/// <summary>
	/// Description of seValChanged.
	/// </summary>
	public partial class seValChanged : NxtControl.GuiHTMLFramework.RuntimeSymbol
	{
	}
}
