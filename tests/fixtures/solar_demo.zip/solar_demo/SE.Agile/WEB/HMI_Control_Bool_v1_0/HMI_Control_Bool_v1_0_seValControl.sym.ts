/*
 * Created by EcoStruxure Automation Expert.
 * User:
 * Date: 5/31/2026
 * Time: 9:36 PM
 *
 * Hidden BOOL control bridge.
 *
 * Required JSON objects:
 * - iValue : System.WEB.Symbols.Base.Execute, isOnlyInput = true
 * - oValue : System.WEB.Symbols.Base.Execute, isOnlyInput = false
 */

namespace SE.Agile.Symbols.HMI_Control_Bool_v1_0 {

  export class seValControl extends NxtControl.GuiFramework.RuntimeSymbol {

    @System.DefaultValue('SE.Agile.Symbols.HMI_Control_Bool_v1_0.seValControl')
    protected type: string;

    private iValue: any;
    private oValue: any;

    private feedbackValue: boolean = false;
    private commandValue: boolean = false;
    private hasPendingCommand: boolean = false;
    private lastUpdate: Date = new Date();

    private valueChangedHandler: any = null;
    private commandChangedHandler: any = null;

    private debugEnabled: boolean = true;

    constructor() {
      super();
    }

    load(options: any): this {
      options = options || {};
      super.load(options);

      this.findObjects();
      this.debug('load', {
        iValue: !!this.iValue,
        oValue: !!this.oValue,
        keys: this.safeKeys(this)
      });

      this.notifyValueChanged();
      return this;
    }

    private findObjects() {
      this.iValue = this.find('iValue');
      this.oValue = this.find('oValue');
    }

    public getSnapshot(): any {
      return {
        value: this.feedbackValue,
        feedbackValue: this.feedbackValue,
        commandValue: this.commandValue,
        pending: this.hasPendingCommand,
        lastUpdate: this.lastUpdate
      };
    }

    public getValue(): boolean {
      return this.feedbackValue;
    }

    public getFeedbackValue(): boolean {
      return this.feedbackValue;
    }

    public getCommandValue(): boolean {
      return this.commandValue;
    }

    public isPending(): boolean {
      return this.hasPendingCommand;
    }

    public setValueChangedHandler(handler: any) {
      this.valueChangedHandler = handler;
    }

    public setCommandChangedHandler(handler: any) {
      this.commandChangedHandler = handler;
    }

    public setCommand(value: boolean) {
      const command = this.toBool(value);

      this.commandValue = command;
      this.hasPendingCommand = true;
      this.lastUpdate = new Date();

      const wroteOutput = this.writeOutputValue(command);
      const firedEvent = this.fireCnf(command);

      this.debug('setCommand', {
        command: command,
        wroteOutput: wroteOutput,
        firedEvent: firedEvent
      });

      this.notifyCommandChanged();
      this.notifyValueChanged();
    }

    public setOn() {
      this.setCommand(true);
    }

    public setOff() {
      this.setCommand(false);
    }

    public toggleCommand() {
      this.setCommand(!this.feedbackValue);
    }

    public setCommandOptimistic(value: boolean) {
      const command = this.toBool(value);

      this.commandValue = command;
      this.feedbackValue = command;
      this.hasPendingCommand = true;
      this.lastUpdate = new Date();

      const wroteOutput = this.writeOutputValue(command);
      const firedEvent = this.fireCnf(command);

      this.debug('setCommandOptimistic', {
        command: command,
        wroteOutput: wroteOutput,
        firedEvent: firedEvent
      });

      this.notifyCommandChanged();
      this.notifyValueChanged();
    }

    protected iValue_valueChanged(sender: any, ea: any) {
      this.updateFeedback(this.getEventValue(sender, ea));
    }

    private updateFeedback(rawValue: any) {
      const newValue = this.toBool(rawValue);

      this.feedbackValue = newValue;
      this.lastUpdate = new Date();

      if (this.hasPendingCommand && this.feedbackValue === this.commandValue) {
        this.hasPendingCommand = false;
      }

      this.debug('feedback', this.getSnapshot());
      this.notifyValueChanged();
    }

    private writeOutputValue(value: boolean): boolean {
      if (!this.oValue) {
        this.warn('oValue object missing. Add oValue to .sym.json.');
        return false;
      }

      const obj: any = this.oValue;

      if (obj.setValue) {
        obj.setValue(value);
        return true;
      }

      if (obj.set) {
        obj.set(value);
        return true;
      }

      if (obj.execute) {
        obj.execute(value);
        return true;
      }

      if (obj.fire) {
        obj.fire(value);
        return true;
      }

      if (obj._set) {
        obj._set('value', value, true);
        return true;
      }

      obj.value = value;
      return true;
    }

    private fireCnf(value: boolean): boolean {
      const runtime: any = this;

      if (runtime.FireEvent_CNF) {
        runtime.FireEvent_CNF(value);
        return true;
      }

      if (runtime.fireEvent_CNF) {
        runtime.fireEvent_CNF(value);
        return true;
      }

      if (runtime.fireEvent) {
        runtime.fireEvent('CNF', value);
        return true;
      }

      if (runtime.FireEvent) {
        runtime.FireEvent('CNF', value);
        return true;
      }

      if (runtime.triggerEvent) {
        runtime.triggerEvent('CNF', value);
        return true;
      }

      if (runtime.CNF && runtime.CNF.fire) {
        runtime.CNF.fire(value);
        return true;
      }

      if (runtime.CNF && runtime.CNF.FireEvent) {
        runtime.CNF.FireEvent(value);
        return true;
      }

      this.warn('No CNF fire method found. If oValue write does not trigger CNF, command will remain local.', this.safeKeys(runtime));
      return false;
    }

    private notifyValueChanged() {
      if (this.valueChangedHandler) {
        this.valueChangedHandler(this, this.getSnapshot());
      }
    }

    private notifyCommandChanged() {
      if (this.commandChangedHandler) {
        this.commandChangedHandler(this, this.getSnapshot());
      }
    }

    private getEventValue(sender: any, ea: any): any {
      if (ea) {
        if (ea.value !== undefined) return ea.value;
        if (ea.Value !== undefined) return ea.Value;
      }

      if (sender) {
        if (sender.value !== undefined) return sender.value;
        if (sender.Value !== undefined) return sender.Value;
      }

      return null;
    }

    private toBool(value: any): boolean {
      return value === true ||
             value === 'true' ||
             value === 'True' ||
             value === 'TRUE' ||
             value === 1 ||
             value === '1';
    }

    private safeKeys(obj: any): any {
      try {
        return Object.keys(obj);
      } catch (e) {
        return [];
      }
    }

    private debug(message: string, data?: any) {
      if (!this.debugEnabled) return;
      if (data !== undefined) console.log('[Bool seValControl] ' + message, data);
      else console.log('[Bool seValControl] ' + message);
    }

    private warn(message: string, data?: any) {
      if (data !== undefined) console.warn('[Bool seValControl] ' + message, data);
      else console.warn('[Bool seValControl] ' + message);
    }
  }
}
