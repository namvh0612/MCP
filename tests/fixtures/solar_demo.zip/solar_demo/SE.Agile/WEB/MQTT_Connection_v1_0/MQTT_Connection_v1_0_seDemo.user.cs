﻿/*
 * Created by EcoStruxure Automation Expert.
 * eHMI wrapper for MQTT_Connection_v1_0.seDemo.
 */
using System;
using System.Drawing;
using NxtControl.GuiHTMLFramework;

namespace SE.Agile.Symbols.MQTT_Connection_v1_0
{
    /// <summary>
    /// MQTT connection demonstration symbol for eHMI.
    /// </summary>
    public partial class seDemo : NxtControl.GuiHTMLFramework.RuntimeSymbol
    {
    }
}
