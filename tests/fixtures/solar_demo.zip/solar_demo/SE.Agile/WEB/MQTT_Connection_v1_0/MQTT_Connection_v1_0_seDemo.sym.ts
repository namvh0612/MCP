﻿/*
 * MQTT_Connection_v1_0 - seDemo eHMI symbol
 * Converted from the original desktop HMI symbol.
 *
 * CONNECT input mapping:
 *   IsConnected; Mac; RootPath; DevicePath; DeviceTopic;
 *   BroadcasterPath; SCADAPath; ManifestPath; BrokerUrl;
 *   Username; Password; AssetName
 */
namespace SE.Agile.Symbols.MQTT_Connection_v1_0 {

  export class seDemo extends NxtControl.GuiFramework.RuntimeSymbol {

    @System.DefaultValue('SE.Agile.Symbols.MQTT_Connection_v1_0.seDemo')
    protected type: string;

    // Visual objects
    private rectBtn: any = null;
    private txtData: any = null;
    private txtLabel: any = null;
    private iconBox: any = null;

    // Runtime state
    private hasConnectionValue: boolean = false;
    private isConnected: boolean = false;
    private isHovered: boolean = false;

    private mac: string = '';
    private rootPath: string = '';
    private devicePath: string = '';
    private deviceTopic: string = '';
    private broadcasterPath: string = '';
    private scadaPath: string = '';
    private manifestPath: string = '';
    private brokerUrl: string = '';
    private username: string = '';
    private assetName: string = '';
    private passwordConfigured: boolean = false;

    private valueChangedHandler: any = null;

    // Local theme values based on the Solar Plant desktop HMI theme.
    private readonly surfacePanel: any = [8, 28, 27, 1];
    private readonly surfaceRaised: any = [12, 35, 33, 1];
    private readonly surfaceDisabled: any = [17, 27, 27, 1];
    private readonly surfaceHover: any = [18, 45, 42, 1];

    private readonly borderNormal: any = [37, 64, 61, 1];
    private readonly borderHover: any = [54, 91, 84, 1];
    private readonly borderOnline: any = [61, 205, 88, 1];
    private readonly borderOffline: any = [73, 84, 81, 1];

    private readonly textPrimary: any = [238, 243, 241, 1];
    private readonly textSecondary: any = [174, 187, 182, 1];
    private readonly textUnknown: any = [92, 108, 104, 1];

    private readonly iconOnline: any = [22, 52, 31, 1];
    private readonly iconOffline: any = [33, 40, 38, 1];
    private readonly iconUnknown: any = [8, 28, 27, 1];

    constructor() {
      super();
    }

    load(options: any): this {
      options = options || {};
      super.load(options);

      this.rectBtn = this.find('rectBtn');
      this.txtData = this.find('txtData');
      this.txtLabel = this.find('txtLabel');
      this.iconBox = this.find('iconBox');

      this.updateUi();
      return this;
    }

    // Public API for canvas-level consumers and testing.
    public setConnectionData(
      isConnected: any,
      rootPath?: any,
      devicePath?: any,
      mac?: any,
      deviceTopic?: any,
      brokerUrl?: any,
      assetName?: any
    ): void {
      this.hasConnectionValue = isConnected !== null && isConnected !== undefined;
      this.isConnected = this.toBool(isConnected);
      this.rootPath = this.cleanText(rootPath);
      this.devicePath = this.cleanText(devicePath);
      this.mac = this.cleanText(mac);
      this.deviceTopic = this.cleanText(deviceTopic);
      this.brokerUrl = this.cleanText(brokerUrl);
      this.assetName = this.cleanText(assetName);
      this.updateUi();
    }

    public setValueChangedHandler(handler: any): void {
      this.valueChangedHandler = handler;
    }

    public getSnapshot(): any {
      return {
        state: this.getStateText(),
        hasConnectionValue: this.hasConnectionValue,
        isConnected: this.isConnected,
        mac: this.mac,
        rootPath: this.rootPath,
        devicePath: this.devicePath,
        deviceTopic: this.deviceTopic,
        broadcasterPath: this.broadcasterPath,
        scadaPath: this.scadaPath,
        manifestPath: this.manifestPath,
        brokerUrl: this.brokerUrl,
        username: this.username,
        passwordConfigured: this.passwordConfigured,
        assetName: this.assetName,
        topicPath: this.buildTopicPath()
      };
    }

    // CONNECT data handlers. EAE updates these Execute objects when CONNECT fires.
    protected IsConnected_valueChanged(sender: any, ea: any): void {
      const value = this.getEventValue(sender, ea);
      this.hasConnectionValue = value !== null && value !== undefined;
      this.isConnected = this.toBool(value);
      this.updateUi();
    }

    protected Mac_valueChanged(sender: any, ea: any): void {
      this.mac = this.cleanText(this.getEventValue(sender, ea));
      this.updateUi();
    }

    protected RootPath_valueChanged(sender: any, ea: any): void {
      this.rootPath = this.cleanText(this.getEventValue(sender, ea));
      this.updateUi();
    }

    protected DevicePath_valueChanged(sender: any, ea: any): void {
      this.devicePath = this.cleanText(this.getEventValue(sender, ea));
      this.updateUi();
    }

    protected DeviceTopic_valueChanged(sender: any, ea: any): void {
      this.deviceTopic = this.cleanText(this.getEventValue(sender, ea));
      this.notifyChanged();
    }

    protected BroadcasterPath_valueChanged(sender: any, ea: any): void {
      this.broadcasterPath = this.cleanText(this.getEventValue(sender, ea));
      this.notifyChanged();
    }

    protected SCADAPath_valueChanged(sender: any, ea: any): void {
      this.scadaPath = this.cleanText(this.getEventValue(sender, ea));
      this.notifyChanged();
    }

    protected ManifestPath_valueChanged(sender: any, ea: any): void {
      this.manifestPath = this.cleanText(this.getEventValue(sender, ea));
      this.notifyChanged();
    }

    protected BrokerUrl_valueChanged(sender: any, ea: any): void {
      this.brokerUrl = this.cleanText(this.getEventValue(sender, ea));
      this.updateUi();
    }

    protected Username_valueChanged(sender: any, ea: any): void {
      this.username = this.cleanText(this.getEventValue(sender, ea));
      this.notifyChanged();
    }

    protected Password_valueChanged(sender: any, ea: any): void {
      // Do not retain the credential in the browser-side visual symbol.
      this.passwordConfigured = this.cleanText(this.getEventValue(sender, ea)) !== '';
      this.notifyChanged();
    }

    protected AssetName_valueChanged(sender: any, ea: any): void {
      this.assetName = this.cleanText(this.getEventValue(sender, ea));
      this.updateUi();
    }

    // Pointer events configured on hitArea in the graphic JSON.
    protected CardMouseEnter(sender: any, ea: any): void {
      this.isHovered = true;
      this.updateUi();
    }

    protected CardMouseLeave(sender: any, ea: any): void {
      this.isHovered = false;
      this.updateUi();
    }

    protected CardClick(sender: any, ea: any): void {
      const owner: any = this;
      if (owner._doOpenFaceplates) {
        owner._doOpenFaceplates();
      }
    }

    private updateUi(): void {
      const state = this.getStateText();

      this.writeText(this.txtLabel, this.getDisplayLabel());
      this.writeText(this.txtData, state);

      if (this.isHovered) {
        this.writeBrush(this.rectBtn, this.surfaceHover);
        this.writePen(this.rectBtn, this.borderHover, 2);
        this.writeBrush(this.iconBox, this.surfaceRaised);
        this.writePen(this.iconBox, this.borderHover, 2);
      } else if (!this.hasConnectionValue) {
        this.writeBrush(this.rectBtn, this.surfacePanel);
        this.writePen(this.rectBtn, this.borderNormal, 1);
        this.writeBrush(this.iconBox, this.iconUnknown);
        this.writePen(this.iconBox, this.borderNormal, 1);
      } else if (this.isConnected) {
        this.writeBrush(this.rectBtn, this.surfacePanel);
        this.writePen(this.rectBtn, this.borderOnline, 1);
        this.writeBrush(this.iconBox, this.iconOnline);
        this.writePen(this.iconBox, this.borderOnline, 1);
      } else {
        this.writeBrush(this.rectBtn, this.surfaceDisabled);
        this.writePen(this.rectBtn, this.borderOffline, 1);
        this.writeBrush(this.iconBox, this.iconOffline);
        this.writePen(this.iconBox, this.borderOffline, 1);
      }

      this.writeTextColor(this.txtLabel, this.textSecondary);
      this.writeTextColor(
        this.txtData,
        !this.hasConnectionValue
          ? this.textUnknown
          : (this.isConnected ? this.textPrimary : this.textSecondary)
      );

      this.notifyChanged();
      this.invalidate();
    }

    private getStateText(): string {
      if (!this.hasConnectionValue) {
        return 'Unknown';
      }
      return this.isConnected ? 'Online' : 'Offline';
    }

    private getDisplayLabel(): string {
      const asset = this.cleanText(this.assetName);
      if (asset !== '') {
        return this.limitText(asset, 24);
      }

      const broker = this.extractBrokerName(this.brokerUrl);
      if (broker !== '') {
        return this.limitText(broker, 24);
      }

      return 'MQTT Broker';
    }

    private buildTopicPath(): string {
      return this.joinPath(
        this.rootPath,
        this.devicePath,
        this.mac,
        this.deviceTopic
      );
    }

    private extractBrokerName(value: any): string {
      let text = this.cleanText(value);
      if (text === '') {
        return '';
      }

      text = text.replace(/^mqtts?:\/\//i, '');
      const slash = text.indexOf('/');
      if (slash >= 0) {
        text = text.substring(0, slash);
      }
      return text;
    }

    private notifyChanged(): void {
      if (this.valueChangedHandler) {
        this.valueChangedHandler(this, this.getSnapshot());
      }
    }

    private getEventValue(sender: any, ea: any): any {
      if (ea) {
        if (ea.value !== undefined) return ea.value;
        if (ea.Value !== undefined) return ea.Value;
        if (ea.newValue !== undefined) return ea.newValue;
      }

      if (sender) {
        if (sender.value !== undefined) return sender.value;
        if (sender.Value !== undefined) return sender.Value;
        if (sender.Val !== undefined) return sender.Val;
      }

      return null;
    }

    private cleanText(value: any): string {
      if (value === null || value === undefined) {
        return '';
      }
      return value.toString().trim().replace(/^'+|'+$/g, '');
    }

    private joinPath(...values: any[]): string {
      const parts: string[] = [];
      for (let i = 0; i < values.length; i++) {
        const part = this.cleanText(values[i]).replace(/^\/+|\/+$/g, '');
        if (part !== '') {
          parts.push(part);
        }
      }
      return parts.join('/');
    }

    private limitText(value: string, maxLength: number): string {
      if (!value || value.length <= maxLength) {
        return value || '';
      }
      if (maxLength <= 3) {
        return value.substring(0, maxLength);
      }
      return value.substring(0, maxLength - 3) + '...';
    }

    private toBool(value: any): boolean {
      if (typeof value === 'boolean') return value;
      if (typeof value === 'number') return value !== 0;
      if (value === null || value === undefined) return false;
      const text = value.toString().trim().toLowerCase();
      return text === 'true' || text === '1' || text === 'on' || text === 'yes';
    }

    private writeText(obj: any, value: any): void {
      if (!obj) return;
      const text = value === null || value === undefined ? '' : value.toString();
      if (obj.setText) obj.setText(text);
      else if (obj._set) obj._set('text', text, true);
      else obj.text = text;
    }

    private writeTextColor(obj: any, color: any): void {
      if (!obj) return;
      if (obj.setTextColor) obj.setTextColor(color);
      else if (obj._set) obj._set('textColor', color, true);
      else obj.textColor = color;
    }

    private writeBrush(obj: any, color: any): void {
      if (!obj) return;
      const brush: any = { color: color };
      if (obj.setBrush) obj.setBrush(brush);
      else if (obj._set) obj._set('brush', brush, true);
      else obj.brush = brush;
    }

    private writePen(obj: any, color: any, width: number): void {
      if (!obj) return;
      const pen: any = { color: color, width: width };
      if (obj.setPen) obj.setPen(pen);
      else if (obj._set) obj._set('pen', pen, true);
      else obj.pen = pen;
    }
  }
}
